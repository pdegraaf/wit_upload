package org.mitre.wit;


import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class SpecialTime {
	
	public SpecialTime() {
		
		
	}
	
	public Date parse(String time) {
		
		// format YYYY_DDD_sssssss
		String[] parts = time.split("_");
	
		int year = Integer.parseInt(parts[0]);
		int dayOfYear = Integer.parseInt(parts[1]);
		int secondsOfDay = Integer.parseInt(parts[2]);
		
		return create(year, dayOfYear, secondsOfDay);
		
	}
	
	public Date create(int year, int dayOfYear, int secondsOfDay) {
		
		Calendar cal = Calendar.getInstance();
		
		int hours = secondsOfDay / 3600;
		int mintues = (secondsOfDay % 3600) / 60;
		int seconds = (secondsOfDay % 3600) % 60;
		
		cal.set(Calendar.DAY_OF_YEAR, dayOfYear);
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.HOUR_OF_DAY, hours);
		cal.set(Calendar.MINUTE, mintues);
		cal.set(Calendar.SECOND, seconds);
		
		return cal.getTime();
	}

}
