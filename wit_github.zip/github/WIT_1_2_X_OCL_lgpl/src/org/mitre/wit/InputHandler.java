package org.mitre.wit;

import java.io.InputStream;


public class InputHandler extends Thread{

	InputStream input_;
	
	int cExposed;
	
	InputHandler(InputStream input, String name){
		super(name);
		input_ = input;
	
	}
	
	public void run(){
		try{
			int c;
			while((c = input_.read()) != -1){
				System.out.write(c);
				cExposed=c;
			}
			
		} catch (Throwable t){
			t.printStackTrace();
		}
	}
}
