/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

/** @author Adrian Johnson **/
 
package org.mitre.wit;

public class BookmarkEvent {

	// save these as serialized objects for later review
	
	int eventType = WC.EVENT_ERROR;
	
	int satID = WC.STATUS_ERROR;
	int scaID = WC.STATUS_ERROR;

	// info
	
	// detection criteria
	boolean eventDetectors[] = new boolean[WC.MAX_DETECTORS];
	float detectionConfidence[] = new float[WC.MAX_DETECTORS];
	
	// frame coordinates
	int rasterX = WC.STATUS_ERROR;
	int rasterY = WC.STATUS_ERROR;
	
	// geo coords
	float lat = WC.INVALID_GEOLOCATION;
	float lon = WC.INVALID_GEOLOCATION;
	float el = WC.INVALID_GEOLOCATION;
	
	int intensity;

	int timeStampSecOfDay;
	
	int statusCheckedByOperator =0;
	int statusDismissedByOperator =0;
	int statusCheckedByAuto = 0;
	int statusDismissedByAuto = 0;
	
	int statusEventClassification =0;
	
	int statusVisible =0;
	String eventLabel;
	String eventDesc;
	
	String eventAuthor;
	
	int triggerCount=0; // how many ways this frame was flagged
	
	public void BookmarkEvent(){
		
	}
	
	
}
