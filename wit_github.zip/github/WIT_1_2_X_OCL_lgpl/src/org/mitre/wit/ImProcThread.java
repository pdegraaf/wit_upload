/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

/** @author Adrian Johnson **/
 
package org.mitre.wit;

import static com.jogamp.opencl.CLMemory.Mem.READ_ONLY;
import static com.jogamp.opencl.CLMemory.Mem.WRITE_ONLY;
import static java.lang.Math.min;
import static java.lang.System.nanoTime;
import static java.lang.System.out;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Container;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.Transparency;
import java.awt.color.ColorSpace;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.ComponentColorModel;
import java.awt.image.ComponentSampleModel;
import java.awt.image.ConvolveOp;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferFloat;
import java.awt.image.DataBufferInt;
import java.awt.image.DataBufferUShort;
import java.awt.image.Kernel;
import java.awt.image.Raster;
import java.awt.image.SampleModel;
import java.awt.image.WritableRaster;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.media.opengl.GL2;
//import javax.media.opengl.GL;
//import javax.media.opengl.GLCapabilities;
//import javax.media.opengl.GLContext;
//import javax.media.opengl.GLProfile;
//import javax.media.opengl.awt.GLCanvas;
//import javax.media.opengl.glu.GLU;

import ncsa.hdf.object.Dataset;
import ncsa.hdf.object.FileFormat;
import ncsa.hdf.object.Group;
import ncsa.hdf.object.h5.H5File;

import javax.vecmath.*;

//import com.jogamp.opencl.CL;
//import com.jogamp.opencl.CLContext;
//import com.jogamp.opencl.CLDevice;
//import com.jogamp.opengl.*;

import com.jogamp.opencl.CLBuffer;
import com.jogamp.opencl.CLCommandQueue;
import com.jogamp.opencl.CLContext;
import com.jogamp.opencl.CLDevice;
import com.jogamp.opencl.CLKernel;
import com.jogamp.opencl.CLProgram;
import com.jogamp.opengl.util.texture.awt.*;

public class ImProcThread implements Runnable {

	int frameStart;
	int frameStop;

	int mode;
	int sca;

	ArrayList paramList = new ArrayList();

	// TivoFrame[] tf;

	int frameCount = 10;
	// WITFrame tf[];// = new TivoFrame[frameCount];
	ArrayList wfl;

	String name;

	static String threadIndentStr = "      OP UPDATE: ";

	static int verbosity = 0;

	int threadStatus = WC.THREAD_STATUS_READY;

	static String formatExtensions[];

	static int exportMode = WC.FORMAT_MP4;
	static int importMode = WC.FORMAT_PNG;

	static float exportQuality = 100.0f;
	static float exportFrameRate = 10.0f;

	static String exportLocation = "C:/javadev/data/WIT_OUTPUT/";
	static String exportName = "tivo1.mpg";

	static String importLocation = "/home/ajohnson/WIT/DEV_DATA/sbirs/seq3/cropped/";// "C:/javadev/data/seq3/cropped/";
	static String importName = "";

	static String scratchStr = "/export/WIT_DEV/ffmpeg_scratch/";// "/home/adrian/CWID_DEV/ffmpeg_scratch/";

	static int scaOffsets[][] = new int[8][2];

	static int stripeBiasCorrections[][][] = new int[2][8][768];
	static float stripeGainCorrections[][][] = new float[2][8][768];

	int seqIndexMask[][] = new int[WC.TOTAL_FLIGHTS][WC.SCAN_SEQ_INDEX_MAX_VAL];

	public ImProcThread(String str, int m, ArrayList wfList, int fstart,
			int fstop, ArrayList pList) {
		this.frameStart = fstart;
		this.frameStop = fstop;// -1;
		// this.tf = tivoFrameRay;
		this.name = str;
		this.mode = m;
		this.paramList = pList;
		this.wfl = wfList;

		// this.sca=((WITFrame)wfList.get(0)).scaID;

		// super(str);
	}

	public void run() {
		// threadStatus = WC.THREAD_STATUS_WORKING; allow dispatcher to switch
		// to WORKING

		// processFrames(tivoFrameRay, frameStart, frameStop, mode);
		processFrames(mode, wfl, frameStart, frameStop, paramList);

		threadStatus = WC.THREAD_STATUS_COMPLETE;
	}

	public void processFrames(int mode, ArrayList wfl, int a, int b,
			ArrayList paramList) {

		// System.out.println("PROCESSING FRAMES "+a+"-"+b+" ON THREAD "+this.name);

		// threadStatus = WC.THREAD_STATUS_WORKING;
		if (mode == WC.THREAD_LOAD) {
			// .h5rData(tf, a, b, paramList);

			// .rawImage(tf, a, b, paramList);
		} else if (mode == WC.THREAD_CONV) {

			// ie.convImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_FEAT) {

			// ie.watershedImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_THRS) {

			// ie.threshImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_DIFF) {

			//diffImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_TEMPORAL) {

			// ie.diffImageDJ(wfl, a, b, paramList);
			// .DWT_CPU_DJ_Filter(tf, a, b, paramList);
			// .DWT_CPU_Filter(tf, a, b, paramList);
		} else if (mode == WC.THREAD_FILT) {

			// ie.filterImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_PREFILTER) {

			preFilterData(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_SEGMENT) {

			// ie.watershedImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_MON) {
			// monitor progress of threads
		} else if (mode == WC.THREAD_EXPORT_VIDEO) {
			//exportVideo(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_EXPORT_WEATHER_VIDEO) {
			//exportWeatherVideo(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_EXPORT_IMAGES) {
			//exportImages2(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_EXPORT_MARKED_IMAGES) {
			//exportImages2(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_EXPORT_PROJ_IMAGES) {
			//exportImagesMerc(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_DEJITTER) {
			// .dejitterScanlines(tf, a, b, paramList);

			// need to bring paramlist back into CV class
			// ie.dejitterImage2(wfl, a, b, paramList);

		} else if (mode == WC.THREAD_DEJITTER_ADV) {

			// .georegAffine(tf, a, b, paramList);
			// ScanRegistration.execRegWIT(wfl, a, b, paramList);

		} else if (mode == WC.THREAD_CONTRAST) {
			// .manualContrastAdjust(tf, a, b, null);
			// .uiContrastImage(tf, a, b, paramList);
			wrapperContrastImage(wfl, a, b, paramList);
			// .autoContrastImage(tf, a, b, paramList);
			// .contrastImage(tf, a, b, null);
		} else if (mode == WC.THREAD_LOAD_HDF5R) {
			loadHDF5RStitchList(wfl, a, b, paramList); // !! DEV !!
		} else if (mode == WC.THREAD_HISTOGRAM) {
			histogramImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_TIMELAPSE) {
			//timelapseImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_REGISTRATION) {
			//registerSubFrame(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_SCAN_DIR_Y_OFFSET) {
			determineScanDirYOffset(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_GPU_OPENCL_TEST) {
			oclMath(wfl, a, b, paramList);
			//updateFramesFromClResults(wfl, a, b, paramList);
		}

		// threadStatus = WC.THREAD_STATUS_COMPLETE; // may want to event...or
		// send data over IP
		// threadStatus = WC.THREAD_STATUS_READY;
	}

	private static String padFrameID(int id, int pad) {
		String paddedID = "" + id;
		if (id < 10) {
			paddedID = "00" + paddedID;
		} else if (id < 100) {
			paddedID = "0" + paddedID;
		}
		return paddedID;
	}

	public static float[] interpolateLonLatFramePointFast(WITFrame t,
			int scaID, int xPoint, int yPoint) {

		// this method only interpolates for small region of the SCA
		float latLonCoords[] = new float[2];

		// NOTE USE 0-5 scaID
		scaOffsets = initSCAoffsets(1);
		// for (int i=0; i<6; i++){

		// todo - extern config
		// int scanYdiff = 0;// 100;
		// int staticFrameW = 768 * 6 + 1;
		// int staticFrameH = 865 + scanYdiff + SCA_Y_OFFSET;

		int scaXoffset = scaOffsets[scaID][WC.X];
		int scaYoffset = scaOffsets[scaID][WC.Y];

		int W = t.numChannels;
		int H = t.numLines;

		int Y_Stepsize_Pixels = t.geoLocYskip;
		int X_Stepsize_Pixels = t.geoLocXskip;

		int sparseXindices = t.geoLocSparseCols;// t.numChannels/X_Stepsize_Pixels;
		int sparseYindices = t.geoLocSparseRows;// t.numLines/Y_Stepsize_Pixels;

		// System.out.println(sparseYindices);

		float lon = 0;
		float lat = 0;

		// int numRows = t.geoLocSparseRows;
		// int numCols = t.geoLocSparseCols;

		float[][] f = new float[4][2];

		// find the notch at which we begin
		int startJ = (int) Math.floor((float) xPoint
				/ (float) X_Stepsize_Pixels);
		int startK = (int) Math.floor((float) yPoint
				/ (float) Y_Stepsize_Pixels);

		// find the fractional portion, ie offset from Stepsize pixels
		int insetJ = (xPoint - (startJ * X_Stepsize_Pixels));
		int insetK = (yPoint - (startK * Y_Stepsize_Pixels));

		int j = startJ; //0
		int k = startK;

		// System.out.println("   interpFast "+startJ+" "+startK+" : "+insetJ+" "+insetK+" mouse >> "+xPoint+" "+yPoint);

		// FASTMOUSE
		// System.out.println("MOUSE EXEC "+xPoint+" "+yPoint+" : "+insetJ+" "+insetK+" "+startJ+" "+startK);

		if (j < sparseXindices && k < sparseYindices) {
			// corner point to use for interpolation

			int ji1 = j-1;
			int ji2 = j + 1;

			int ki1 = k;
			int ki2 = k + 1;

			if ((scaID) % 2 == 0) {
				ji1 = sparseXindices - j;
				ji2 = sparseXindices - j - 1;
			}
			if (t.scanDirection == 0) {
				ki1 = sparseYindices - k;
				ki2 = sparseYindices - k - 1;
			}

			if (ji1 >= sparseXindices || ji2 >= sparseXindices || ji1 < 0
					|| ji2 < 0 || ki1 >= sparseYindices
					|| ki2 >= sparseYindices || ki1 < 0 || ki2 < 0) {
				// SCA seam
			} else {

				for (int c = 0; c < 2; c++) {
					f[0][c] = t.geoLocDataSparse[ji1][ki1][c];
					f[1][c] = t.geoLocDataSparse[ji1][ki2][c];
					f[2][c] = t.geoLocDataSparse[ji2][ki1][c];
					f[3][c] = t.geoLocDataSparse[ji2][ki2][c];
				}

				int bypassFlag = 0; // if one portion is off-earth, throw out
				// this whole tile, don't interpoate
				for (int a = 0; a < 4; a++) {
					for (int b = 0; b < 2; b++) {
						if (f[a][b] < -999) {
							bypassFlag = 1;
						}
					}
				}
				
				// perform the interpolation

				int x = insetJ;
				int y = insetK;

				// float ym = 1.0f-((float) y / (float) Y_Stepsize_Pixels);
				// float xm = 1.0f-((float) x / (float) X_Stepsize_Pixels);

				float ym = (float) y / (float) Y_Stepsize_Pixels;
				float xm = (float) x / (float) X_Stepsize_Pixels;

				// complements
				float xmc = 1.0f - xm;
				float ymc = 1.0f - ym;

				int row = xPoint;// j * Y_Stepsize_Pixels + y;
				int col = yPoint;// k * X_Stepsize_Pixels + x;

				lon = f[0][0] * xmc * ymc + f[2][0] * xm * ymc + f[1][0] * xmc
						* ym + f[3][0] * xm * ym;

				lat = f[0][1] * xmc * ymc + f[2][1] * xm * ymc + f[1][1] * xmc
						* ym + f[3][1] * xm * ym;

				// int scanYoffset = scaOffsets[scaID][Y];

				if (bypassFlag == 0) {
					latLonCoords[WC.GEODATA_LON] = lon;
					latLonCoords[WC.GEODATA_LAT] = lat;
				} else if (bypassFlag == 1) {
					latLonCoords[WC.GEODATA_LON] = -9999;
					latLonCoords[WC.GEODATA_LAT] = -9999;
				}
				if (xPoint <16){
					System.out.println(xPoint+": " +lat+","+lon+" ... "+f[0][0]+"/"+f[0][1]+ " - "+f[1][0]+"/"+f[1][1]+ " - "+f[2][0]+"/"+f[2][1]+ " - "+f[3][0]+"/"+f[3][1]);
				}

			}
		}

		return latLonCoords;
	}

	public static WITFrame interpolateLonLatFrame(WITFrame t) {

		// System.out.println("GEN SCA GEOLOCATION");
		WITFrame tempFrame = t;
		int scaID = t.scaID;
		// WITFrame tempFrame= new WITFrame();
		tempFrame.numLines = t.numLines;
		// NOTE USE 0-5 scaID
		scaOffsets = initSCAoffsets(1);
		// for (int i=0; i<6; i++){

		// todo - extern config
		int scanYdiff = 0;// 100;
		int staticFrameW = t.numChannels;// 768 * 6 + 1;
		int staticFrameH = t.numLines;

		tempFrame.geoLocDataFull = new float[staticFrameW][staticFrameH][2];

		int scaXoffset = scaOffsets[scaID][WC.X];
		int scaYoffset = scaOffsets[scaID][WC.Y];

		int W = 768;
		int H = 864;

		int Y_Stepsize_Pixels = t.geoLocYskip;
		int X_Stepsize_Pixels = t.geoLocXskip;

		float lon = 0;
		float lat = 0;

		int numRows = t.geoLocSparseRows;
		int numCols = t.geoLocSparseCols;

		float[][] f = new float[4][2];

		float tLatLon[] = new float[2];

		int destX = 0;
		int destY = 0;

		for (int x = 0; x < t.numChannels; x++) {
			for (int y = 0; y < t.numLines; y++) {

				destX = x;
				destY = y;

				tempFrame.geoLocDataFull[destX][destY][0] = -9999;
				tempFrame.geoLocDataFull[destX][destY][1] = -9999;

				tLatLon = interpolateLonLatFramePointFast(t, scaID, x, y);

				// System.out.println(tLatLon[WC.GEODATA_LON]+" "+tLatLon[WC.GEODATA_LAT]);

				tempFrame.geoLocDataFull[destX][destY][WC.GEODATA_LON] = tLatLon[WC.GEODATA_LON];
				tempFrame.geoLocDataFull[destX][destY][WC.GEODATA_LAT] = tLatLon[WC.GEODATA_LAT];
			}
		}

		// }

		return tempFrame;

	}


	
	public int[] getLatLonRasterPos(float lat, float lon, WITFrame w, int scaID) {
		scaOffsets = initSCAoffsets(1);

		int[] rasterPos = new int[2];
		rasterPos[WC.X] = WC.INVALID_GEOLOCATION;
		rasterPos[WC.Y] = WC.INVALID_GEOLOCATION;

		// WITFrame tempFrame = .interpolateLonLatFrame(w,scaID);

		float minDist = Float.MAX_VALUE;

		// chunk of sparse array
		int xIndex = -1;
		int yIndex = -1;

		float distThreshold = .5f;

		for (int x = 0; x < w.numChannels; x++) {
			for (int y = 0; y < w.numLines; y++) {

				float thisDist = (w.geoLocDataFull[x][y][WC.GEODATA_LON] - lon)
						* (w.geoLocDataFull[x][y][WC.GEODATA_LON] - lon)
						+ (w.geoLocDataFull[x][y][WC.GEODATA_LAT] - lat)
						* (w.geoLocDataFull[x][y][WC.GEODATA_LAT] - lat);

				if (thisDist < minDist) {

					minDist = thisDist;

					xIndex = x;
					yIndex = y;
				}
			}
		}

		if (xIndex != -1 && yIndex != -1) {
			rasterPos[WC.X] = scaOffsets[scaID][WC.X] + (xIndex);
			rasterPos[WC.Y] = scaOffsets[scaID][WC.Y] + (yIndex);
		}

		return rasterPos;
	}

	// interpolate across sparse grid to find raster locations
	public int[] getLatLonRasterPos_dev(float lat, float lon, WITFrame w,
			int scaID) {
		scaOffsets = initSCAoffsets(1);

		int[] rasterPos = new int[2];
		rasterPos[WC.X] = WC.INVALID_GEOLOCATION;
		rasterPos[WC.Y] = WC.INVALID_GEOLOCATION;

		int Y_Stepsize_Pixels = w.geoLocYskip;
		int X_Stepsize_Pixels = w.geoLocXskip;

		for (int i = 0; i < w.geoLocSparseCols; i++) {
			for (int j = 0; j < w.geoLocSparseRows; j++) {

				if (lon > w.geoLocDataSparse[i][j][WC.GEODATA_LON]
						&& lon <= w.geoLocDataSparse[i + 1][j][WC.GEODATA_LON]
						&& lat > w.geoLocDataSparse[i][j][WC.GEODATA_LAT]
						&& lat <= w.geoLocDataSparse[i][j + 1][WC.GEODATA_LAT]) {

					// base
					rasterPos[WC.X] = scaOffsets[scaID][WC.X];
					rasterPos[WC.Y] = scaOffsets[scaID][WC.Y];

					// add interpolation value
					float xm = (float) i / (float) X_Stepsize_Pixels;
					float ym = (float) j / (float) Y_Stepsize_Pixels;

					// complements
					float xmc = 1.0f - xm;
					float ymc = 1.0f - ym;

	
				}

			}
		}

		return rasterPos;
	}

	public int[] getLatLonRasterPos_old(float lat, float lon, WITFrame w,
			int scaID) {
		scaOffsets = initSCAoffsets(1);

		int[] rasterPos = new int[2];
		rasterPos[WC.X] = WC.INVALID_GEOLOCATION;
		rasterPos[WC.Y] = WC.INVALID_GEOLOCATION;

		// min vals
		float minDiffX = 999f;
		float minDiffY = 999f;

		float minDist = 999f;

		// min indices
		int minDiffXi = 0;
		int minDiffYi = 0;

		int assignFlag = 0;

		for (int i = 0; i < w.geoLocSparseCols * w.geoLocXskip; i++) {
			for (int j = 0; j < w.geoLocSparseRows * w.geoLocYskip; j++) {
				float dx = Math.abs(w.geoLocDataFull[i][j][WC.GEODATA_LAT]
						- lat);
				float dy = Math.abs(w.geoLocDataFull[i][j][WC.GEODATA_LON]
						- lon);

				float thisDist = (dx * dx) + (dy * dy);

				if (thisDist <= .1f) {
					// if ((dx<.1f) && (dy<.1f)){
					assignFlag = 1; // at least one match

					if (thisDist < minDist) {
						minDiffXi = i;
						// minDiffX=dx;

						minDiffYi = j;
						// minDiffY=dy;

						minDist = thisDist;
					}

					// System.out.println("RASTER AT "+rasterPos[WC.X]+" "+rasterPos[WC.Y]);
				}
			}
		}

		if (assignFlag == 1) {
			// assign the min
			rasterPos[WC.X] = minDiffXi + scaOffsets[scaID][WC.X];
			rasterPos[WC.Y] = minDiffYi + scaOffsets[scaID][WC.Y];
		}

		return rasterPos;
	}

	// from a WIT frame, create the GPU textures
	public void createTexTiles(ArrayList wfl, int a, int b, ArrayList paramList) {

	}

	public WITFrame generateTiles(WITFrame wf, int[] coordSpaceLoadMask) {

		// need to add logic for creating tiles for the edges...end of scan
		
		//GLContext glc = null;
	
		
		int colorBands = 6;

		
		int colorScheme = WC.COLOR_SCHEME_GRAYSCALE;//;COLOR_SCHEME_HEATMAP//COLOR_SCHEME_GRAYSCALE

		
		wf.witFrameTiles.clear();
		
		wf.tileGPUoptimizationState = WC.STATUS_READY;

		scaOffsets = initSCAoffsets(1);

		// int cs = coordSpace;

		float mercatorMapDivisor = 180f; // stay to map scale

		float sensorPlaneScale = WC.SENSOR_PLANE_SCALE * (12f/(float)wf.tileSizeX);//(float)1f / ((float) (WC.SCA_CHANNELS * 8));
		float sensorPlaneScaleOffsetX = -((float) (WC.SCA_CHANNELS * 4))
				* sensorPlaneScale ;
		float sensorPlaneScaleOffsetY = -((float) (WC.SCA_CHANNELS / 2))
				* sensorPlaneScale ;

		// we can use arbitrary tile sizes since we interpolate
		int xSkip = wf.tileSizeX;// wf.geoLocXskip;
		int ySkip = wf.tileSizeY;// wf.geoLocYskip;

		float shortScale = 1f;//1f / (float) (Math.pow(2, 8));
		
		int k = wf.scaID;

		int blockSizeX=wf.tileSizeX/wf.geoLocXskip;
		int blockSizeY=wf.tileSizeY/wf.geoLocYskip;
				
		int blockCountX = wf.geoLocDataSparse.length/blockSizeX;
		int blockLimitX = blockCountX*blockSizeX; // round the cols to multiple of blockSize
		int blockCountY = wf.geoLocDataSparse[0].length/blockSizeY;
		int blockLimitY = blockCountY*blockSizeY;
		int blockLimitYOverflow = wf.geoLocDataSparse[0].length-blockLimitY;
		//System.out.println("overflow "+blockLimitYOverflow);
		// 
		for (int x = 0; x < (blockCountX); x++) {
			
			for (int y = 0; y < (blockCountY); y++) {
			//for (int y = 0; y <= ((wf.hdrValsRaw[0].length) / ySkip); y++) {

				float tLatLon[][] = new float[4][2];

				WITFrameTile wft = new WITFrameTile();
				

				// assume the worst
				for (int cs = 0; cs < WC.COORDINATES_MODE_MAX; cs++) {
					wft.tileStatusPerCoordinateSystem[cs] = WC.STATUS_ERROR;
				}

				int tileOffEarthAbortFlag = 0; // for off-earth

				int indicesX[] = new int[4];
				int indicesY[] = new int[4];

				indicesX[0] = x;
				indicesX[1] = x;
				indicesX[2] = x + 1;
				indicesX[3] = x + 1;

				indicesY[0] = y;
				indicesY[1] = y + 1;
				indicesY[2] = y + 1;
				indicesY[3] = y;

				for (int j = 0; j < 4; j++) {
					indicesX[j] *=blockSizeX;
					indicesY[j] *=blockSizeY;
				}
				for (int j = 0; j < 4; j++) {
					//indicesY[j] -=1;
					//indicesX[j] -=1;
				}
				
				int destXsimple[] = new int[4];
				int destYsimple[] = new int[4];
				
				for (int j = 0; j < 4; j++) {
					destXsimple[j] = indicesX[j] * xSkip;
					destYsimple[j] = indicesY[j] * ySkip;
				}
		
				
				if ((wf.scaID) % 2 == 0) {
					for (int jj=0; jj<4; jj++){
						indicesX[jj] = blockLimitX-1-indicesX[jj];
					}
				}
				if (wf.scanDirection == 0) {
					for (int jj=0; jj<4; jj++){
						indicesY[jj] = blockLimitY-1-indicesY[jj];
						//indicesY[jj] = blockLimitY-(-1)-indicesY[jj];
					}
				}
				
				int destX[] = new int[4];
				int destY[] = new int[4];

				int okayCountX=0;
				int okayCountY=0;
				for (int j = 0; j < 4; j++) {
					
					
					int okayX=0;
					int okayY=0;

					if (indicesX[j] >=0 && indicesX[j] < blockLimitX){
						okayX=1;
						okayCountX++;
					}
					if (indicesY[j] >=0 && indicesY[j]<blockLimitY){
						okayY=1;
						okayCountY++;
					}
					
					if (okayX ==1 && okayY ==1){

						destX[j] = indicesX[j] * xSkip;
						destY[j] = indicesY[j] * ySkip;
						      
					tLatLon[j][WC.GEODATA_LON] = wf.geoLocDataSparse[indicesX[j]][indicesY[j]][WC.GEODATA_LON];
					tLatLon[j][WC.GEODATA_LAT] = wf.geoLocDataSparse[indicesX[j]][indicesY[j]][WC.GEODATA_LAT];
					

					}
					
				}
				if (okayCountY!= 4){
					//System.out.println("Y FLAG - X "+indicesX[0]+" "+indicesX[2]+" ... Y "+indicesY[0]+" "+indicesY[1]+ " Y LIMIT "+wf.geoLocDataSparse[0].length +"/"+blockLimitY+" scan Dir  "+wf.scanDirection);
				} 
				if (okayCountX!= 4){
					//System.out.println("X FLAG - X "+indicesX[0]+" "+indicesX[2]+" ... Y "+indicesY[0]+" "+indicesY[1]+ " X LIMIT "+wf.geoLocDataSparse.length+"/"+blockLimitX+" scan Dir  "+wf.scanDirection);
				}
				
				for (int j = 0; j < 4; j++) {
					if (tLatLon[j][WC.GEODATA_LAT] == WC.INVALID_GEOLOCATION
							|| tLatLon[j][WC.GEODATA_LON] == WC.INVALID_GEOLOCATION
							|| tLatLon[j][WC.GEODATA_LAT] == 0
							|| tLatLon[j][WC.GEODATA_LON] == 0) {
						tileOffEarthAbortFlag = 1;
					}
				}

				
				
				//for (int cs = WC.COORDINATES_SENSOR; cs <= WC.COORDINATES_SENSOR; cs++) {
				for (int cs = 0; cs < WC.COORDINATES_MODE_MAX; cs++) {
					// right hand vs left hand coord systems
					if (coordSpaceLoadMask[cs] == 1){
					if (cs == WC.COORDINATES_SENSOR) { // don't care about
														// off-earth
						
				
						int offsetScid = wf.scaID-WC.SCID_BASE_OFFSET;
						
						for (int j = 0; j < 4; j++) {
							wft.xyzLoc[cs][j][WC.X] = (((float) (destXsimple[j] + ((scaOffsets[wf.scaID][WC.X]-WC.SCA_CHANNELS*3) * (wf.tileSizeX/12)))*sensorPlaneScale));
									//+ (float)(WC.SCA_CHANNELS*sensorPlaneScale);
							wft.xyzLoc[cs][j][WC.Y] = -(((float) (destYsimple[j] + ((scaOffsets[wf.scaID][WC.Y]-WC.SCA_CHANNELS/2) * (wf.tileSizeY/12)))*sensorPlaneScale));
									//+ (float)(WC.SCA_CHANNELS*sensorPlaneScale);// + (1000*offsetScid);
							

							wft.xyzLoc[cs][j][WC.Z] = .0001f*offsetScid;


						}
						

						wft.tileStatusPerCoordinateSystem[cs] = WC.STATUS_COMPLETE;
					} else if (cs == WC.COORDINATES_MERCATOR) {

						
						
						if (tileOffEarthAbortFlag == 0) { // may have been
															// caught by other
															// coord sys

							// check for off-earth
							for (int j = 0; j < 4; j++) {

								wft.xyzLoc[cs][j][WC.X] = tLatLon[j][WC.GEODATA_LON]
										/ mercatorMapDivisor;
								wft.xyzLoc[cs][j][WC.Y] = tLatLon[j][WC.GEODATA_LAT]
										/ mercatorMapDivisor;
								wft.xyzLoc[cs][j][WC.Z] = 0;
							}

						}

						wft.tileStatusPerCoordinateSystem[cs] = WC.STATUS_COMPLETE;
					} else if (cs == WC.COORDINATES_GLOBE) {
						
						if (tileOffEarthAbortFlag == 0) { // may have been
															// caught by other
															// coord sys

							for (int j = 0; j < 4; j++) {

								wft.xyzLoc[cs][j][WC.X] = getLatLonX(
										WC.GLOBE_RADIUS,
										tLatLon[j][WC.GEODATA_LAT],
										tLatLon[j][WC.GEODATA_LON]);
								wft.xyzLoc[cs][j][WC.Y] = getLatLonY(
										WC.GLOBE_RADIUS,
										tLatLon[j][WC.GEODATA_LAT],
										tLatLon[j][WC.GEODATA_LON]);
								wft.xyzLoc[cs][j][WC.Z] = getLatLonZ(
										WC.GLOBE_RADIUS,
										tLatLon[j][WC.GEODATA_LAT],
										tLatLon[j][WC.GEODATA_LON]);
				

							}
							

							wft.tileStatusPerCoordinateSystem[cs] = WC.STATUS_COMPLETE;

						} else {
							//System.out.println("TILE ID X - "+x);

						}
						
						//wft.bufferData[WC.VBO_VERTICES].rewind();
					} // end globe
					}
				} // end cs loop
				
				for (int j = 0; j < 4; j++) {

					if (destX[j] >= 0 && destY[j] >= 0
							&& destX[j] < wf.numChannels
							&& destY[j] < wf.numLines) {
						wft.floatVal[j] = (float) wf.hdrValsRaw[destX[j]][destY[j]]
								* shortScale;

						if (tileOffEarthAbortFlag == 0) {
						for (int ck=0; ck<WC.VBO_VERTEX_COMPONENTS; ck++){
							wft.bufferDataRaw[WC.BUFFER_COL][WC.VBO_COLOR_COMPONENTS*j+ck] = wft.floatVal[j];
						}
						}
					}
				}
				

				
				int dbType = DataBuffer.TYPE_SHORT;

				SampleModel sm = new ComponentSampleModel(dbType, xSkip, ySkip, 1, xSkip, new int[]{0});

				DataBuffer db = new DataBufferFloat(xSkip* ySkip);
				WritableRaster wr = Raster.createWritableRaster(sm, db, null);
				ColorSpace cs = ColorSpace.getInstance(ColorSpace.CS_GRAY);
				ColorModel cm = new ComponentColorModel(cs, false, true, Transparency.OPAQUE, dbType);
				
				//wft.texBI = new BufferedImage(xSkip, ySkip, BufferedImage.TYPE_USHORT_GRAY);
				wft.texBI = new BufferedImage(cm,wr,true, null);
			
				// statistics
				wft.tileRasterX = x*xSkip;
				wft.tileRasterY = y*ySkip;
				
				wft.ySkip = ySkip;
				wft.xSkip = xSkip;
				
				if (wft.texBI != null) {
				// create temp tile as short[][]
					wr = updateTileTextureData(wf, wft, wr, WC.THREAD_LOAD);
				}

				if (tileOffEarthAbortFlag == 0) {
					wft.tileVBOstatus = WC.STATUS_COMPLETE; 
				}
				
				wf.witFrameTiles.add(wft);
			} 
		}
		
		//System.out.println(wf.witFrameTiles.size() + " tiles created for SCA "+ wf.scaID);
		wf.tileState = WC.STATUS_COMPLETE;
		
		return wf;
		// }
		// }
	}
	
	public void updateFramesFromClResults(ArrayList wfl, int a, int b, ArrayList paramList) {
		

		int inputSrc = WC.THREAD_GPU_OPENCL_TEST;//(Integer) paramList.get(0);
		

		int minT = (Integer) paramList.get(1);
		int maxT = (Integer) paramList.get(2);
		
		int skipT =  (Integer) paramList.get(3);
		

		
	}
	
	public WITFrame updateFrameTileTextureDataFromClResults(WITFrame wf){
	
			wf.tileGPUoptimizationState = WC.STATUS_READY;

			scaOffsets = initSCAoffsets(1);

			// int cs = coordSpace;

			float mercatorMapDivisor = 180f; // stay to map scale

			float sensorPlaneScale = WC.SENSOR_PLANE_SCALE * (12f/(float)wf.tileSizeX);//(float)1f / ((float) (WC.SCA_CHANNELS * 8));
			float sensorPlaneScaleOffsetX = -((float) (WC.SCA_CHANNELS * 4))
					* sensorPlaneScale ;
			float sensorPlaneScaleOffsetY = -((float) (WC.SCA_CHANNELS / 2))
					* sensorPlaneScale ;

			// we can use arbitrary tile sizes since we interpolate
			int xSkip = wf.tileSizeX;// wf.geoLocXskip;
			int ySkip = wf.tileSizeY;// wf.geoLocYskip;

			float shortScale = 1f;//1f / (float) (Math.pow(2, 8));
			
			int k = wf.scaID;

			int blockSizeX=wf.tileSizeX/wf.geoLocXskip;
			int blockSizeY=wf.tileSizeY/wf.geoLocYskip;
					
			int blockCountX = wf.geoLocDataSparse.length/blockSizeX;
			int blockLimitX = blockCountX*blockSizeX; // round the cols to multiple of blockSize
			int blockCountY = wf.geoLocDataSparse[0].length/blockSizeY;
			int blockLimitY = blockCountY*blockSizeY;
			int blockLimitYOverflow = wf.geoLocDataSparse[0].length-blockLimitY;
			//System.out.println("overflow "+blockLimitYOverflow);
			// 
			
			for (int wti = 0; wti<wf.witFrameTiles.size(); wti++){
			
					WITFrameTile wft = (WITFrameTile)wf.witFrameTiles.get(wti);
					
					//int dbType = DataBuffer.TYPE_FLOAT;
					int dbType = DataBuffer.TYPE_SHORT;

					SampleModel sm = new ComponentSampleModel(dbType, xSkip, ySkip, 1, xSkip, new int[]{0});
					//SampleModel sm = new ComponentSampleModel(DataBuffer.TYPE_FLOAT, xSkip, ySkip, 1, xSkip, new int[]{0});
					

					DataBuffer db = new DataBufferFloat(xSkip* ySkip);
					WritableRaster wr = Raster.createWritableRaster(sm, db, null);
					ColorSpace cs = ColorSpace.getInstance(ColorSpace.CS_GRAY);
					//ColorSpace cs = ColorSpace.getInstance(ColorSpace.CS_GRAY);
					ColorModel cm = new ComponentColorModel(cs, false, true, Transparency.OPAQUE, dbType);
					
					//wft.texBI = new BufferedImage(xSkip, ySkip, BufferedImage.TYPE_USHORT_GRAY);
					wft.texBI = new BufferedImage(cm,wr,true, null);
					
					if (wft.texBI != null) {
					// create temp tile as short[][]
						wr = updateTileTextureData(wf, wft, wr, WC.THREAD_GPU_OPENCL_TEST);
						
					}
					
					wf.witFrameTiles.set(wti, wft);
					// }
			} // end tiles
			
			wf.tileState = WC.STATUS_COMPLETE;
			return wf;

	}
	
	public  WritableRaster updateTileTextureData(WITFrame wf, WITFrameTile wft, WritableRaster wr, int dataMode){
		

			//DataBuffer db = new DataBuffer();
			int indexC=0;
			int eleCount = 0;
			int tileID =0;
			int maxVal = -1;
			int maxValRaw = -1;
			
			char maxChar1 = 0;
			char maxChar2 = 0;
			
			//System.out.println("UPDATING TILES "+wf.width+" "+wf.height+" "+wft.tileRasterX+" "+wft.tileRasterY);
			
			for (int xr = 0; xr < wft.xSkip; xr++) {
				for (int yr = 0; yr < wft.ySkip; yr++) {
					
					int rasterFinalY = wft.tileRasterY+yr;
					int rasterFinalX = wft.tileRasterX+xr;
			
					short newValRay[] = new short[1];
					try {
						if (dataMode == WC.THREAD_LOAD){
							newValRay[0] = (short) (wf.hdrValsRaw[rasterFinalX][rasterFinalY]*WC.CONTRAST_RANGE_SCALE_SHIM);//newVal;
						} else if (dataMode == WC.THREAD_GPU_OPENCL_TEST){
							newValRay[0] = (short) (wf.hdrValsClResults[rasterFinalX][rasterFinalY]*WC.CONTRAST_RANGE_SCALE_SHIM);//newVal;
						} 
						if (newValRay[0] < 0 ){newValRay[0] = Short.MAX_VALUE;}
					} catch (Exception e){
						e.printStackTrace();
						newValRay[0] = Short.MAX_VALUE;
					}

					wr.setDataElements(xr, yr, newValRay);
					//System.out.println(newValRay+ " VAL");
				}
			}

			
			try {
				//ImageIO.write(wft.texBI, "png", new File("tile_"+tileID+"_"+System.currentTimeMillis()+".png"));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
		return wr;
	}
	

	public static float getLatLonX(float radius, float lat, float lon) {

		float latRad = (float) (lat * (Math.PI / 180.0f));
		float lonRad = (float) (lon * (Math.PI / 180.0f));
		float x = (float) (-radius * Math.cos(latRad) * Math.cos(lonRad));
		return -x;
	}

	public static float getLatLonY(float radius, float lat, float lon) {

		float latRad = (float) (lat * (Math.PI / 180.0f));
		float lonRad = (float) (lon * (Math.PI / 180.0f));
		float y = (float) (radius * Math.sin(latRad));
		return y;
	}

	public static float getLatLonZ(float radius, float lat, float lon) {

		float latRad = (float) (lat * (Math.PI / 180.0f));
		float lonRad = (float) (lon * (Math.PI / 180.0f));
		float z = (float) (radius * Math.cos(latRad) * Math.sin(lonRad));
		return z;
	}

	public void loadHDF5RStitchList(ArrayList wfl, int a, int b,
			ArrayList paramList) {

		int storeHDRvals = 1; // TODO pass param

		int mode = WC.THREAD_LOAD_HDF5R;
		// int mode = WC.THREAD_LOAD_HDF5R_STITCH;

		int tempMax = 0;


		int linesReversed = 0;
		int channelsReversed = 0;

		//int coordSet = WC.COORDINATES_GLOBE;// /WC.COORDINATES_MERCATOR;//WC.COORDINATES_SENSOR;//

		
	
		
		try {
			int arrayOffset = 0;
			int startTimeSecs = a;
			int stopTimeSecs = b;
			int framesToLoad = 0;
			int skipSeconds = 1;
			int snippetSeconds = WC.SNIPPET_SECONDS_LOAD;
			int errorHandlingCode = 0;
			int autoContrastFromMetadata = 0;
			// int minCalIntensityFile = -1;//0;
			// int maxCalIntensityFile = -1;//4096;
			// String fName = (String) paramList.get(2);
			int scaID = (Integer) paramList.get(0); // must be 0-7, not 1-8
			int satID = -1;
			int[][] scanSeqIndexMask = null;
			int WORKAROUND_GPU_HDR = 0;
			int WORKAROUND_AUTO_CONTRAST=0;
			int[] COORDINATE_SPACE_LOAD_MASK = {1,1,1};
			int TILE_SIZE_X = 12;
			int TILE_SIZE_Y = 12;
			if (paramList.size() > 1) {
				satID = (Integer) paramList.get(1);
				arrayOffset = (Integer) paramList.get(3);
				startTimeSecs = (Integer) paramList.get(4);
				stopTimeSecs = (Integer) paramList.get(5);
				skipSeconds = (Integer) paramList.get(6);
				snippetSeconds = (Integer) paramList.get(7);
				errorHandlingCode = (Integer) paramList.get(8);

				// minCalIntensityFile = (Integer) paramList.get(8);
				// maxCalIntensityFile = (Integer) paramList.get(9);
				autoContrastFromMetadata = (Integer) paramList.get(11);
				scanSeqIndexMask = (int[][]) paramList.get(12);
				WORKAROUND_GPU_HDR = (Integer)paramList.get(13);
				WORKAROUND_AUTO_CONTRAST = (Integer)paramList.get(14);
				
				COORDINATE_SPACE_LOAD_MASK = (int[]) paramList.get(15);
				
				TILE_SIZE_X = (Integer)paramList.get(16);
				TILE_SIZE_Y = (Integer)paramList.get(17);
			}

			StringBuilder strBdr = new StringBuilder();
			// strBdr.append("SCA incoming - ");
			// strBdr.append(scaID);
			// System.out.println(strBdr);
			// System.out.println("   LOAD RC+GL - " + fName);
			// h5 = null;
			HDF5_R h5 = (HDF5_R) paramList.get(2);

			int contrastMode = WC.CONTRAST_OFF;

			int curF = 0;
			int prevF = 0;
			int nextF = 0;

			int frameLoaderCount = 0;
			
			FrameMetaData frameMetaData = h5.getFrameMetaData();
			if (frameMetaData != null) {
				FrameMetaData.MetaData theData = frameMetaData.getMetaData();

				int lengthHint = theData.beginLine.length;
				// System.out.println("LENGTH HINT "+lengthHint);

				// int lastLoadSeconds = 0;

				int geolocationExists = 0;

				CalRawData calRawData = null;
				GeoLocationData geolocationData = null;

				calRawData = h5.getCalRawData();

				try {
					geolocationData = h5.getGeolocationData();
					geolocationExists = 1;
				} catch (Exception e) {
					geolocationExists = 0;
				}

				for (int passNo = 0; passNo < 10; passNo++) {
					
					if (frameLoaderCount <= lengthHint){
					
					for (int j = 0; j < lengthHint; j++) { // !! examine
						if (frameLoaderCount <= lengthHint){
						
						if (theData.beginLine[j] == passNo*WC.SCA_SCAN_SEGMENT_LINES) {
							
							frameLoaderCount++;
							
							// if ((theData.beginLine[j] == 0 &&
							// reconstructFullScans == 0) ||
							// reconstructFullScans == 1) {

							double frameIndexSecondsOfDay = theData.secondsOfDay[j];

							if (errorHandlingCode == 1) { // catch foobarred
															// timing
								// data
								// System.out.println("DETECTED ERROR HANDLING CODE FOR MISSING TIME DATA");
								// loadIndexSecondsOfDay = j;
								// targetSecondsOfDay = 0;
							}
							
							

							if (frameIndexSecondsOfDay >= startTimeSecs
									&& frameIndexSecondsOfDay < stopTimeSecs ) {
								
								// do skip frame logic
								
							//	if (frameIndexSecondsOfDay % skipSeconds == 0 || frameIndexSecondsOfDay % skipSeconds == 1){
								double loadFlagModulo = ((frameIndexSecondsOfDay-startTimeSecs)% skipSeconds);
								if (loadFlagModulo < snippetSeconds){	
								
								
								// addFlag=1;
								WITFrame loadFrame = new WITFrame();
								
								loadFrame.tileSizeX = TILE_SIZE_X;
								loadFrame.tileSizeY = TILE_SIZE_Y;

								int targetTimestampSecOfDay = (int) theData.secondsOfDay[j];
								int targetTimestampDay = theData.day[j];

								if (errorHandlingCode == 1) { // catch foobarred
									// timing data
									targetTimestampDay = 0;
									targetTimestampSecOfDay = (int) frameIndexSecondsOfDay;
								}

								loadFrame.scaID = scaID;

								if (errorHandlingCode == 1) {
									loadFrame.missingDataItems[WC.MISSING_ITEM_GEOLOCATION] = 1;
								}

								String secStr = theData.secondsOfDay[j] + "";

								int lapseFlag = 1;

								loadFrame.scanDirection = theData.scanDir[j];
								loadFrame.scanSeqIndex = theData.sosSeqIndex[j];
								loadFrame.numLines = theData.numLines[j];
								loadFrame.numChannels = theData.numChannels[j];
								loadFrame.beginLine = theData.beginLine[j];
								loadFrame.endLine = theData.endLine[j];
								loadFrame.satID = satID;

								loadFrame.hdrValsRaw = new short[loadFrame.numChannels+1][loadFrame.numLines+1];

								loadFrame.linesReversed = theData.linesReversed[j];
								loadFrame.chansReversed = theData.chansReversed[j];

								loadFrame.maxCalIntensityFrame = theData.maxCalIntensity[j];
								loadFrame.minCalIntensityFrame = theData.minCalIntensity[j];

								loadFrame.scanBounds[WC.GEODATA_LAT][WC.GEODATA_UL] = theData.UL_lat[j];
								loadFrame.scanBounds[WC.GEODATA_LAT][WC.GEODATA_UR] = theData.UR_lat[j];
								loadFrame.scanBounds[WC.GEODATA_LAT][WC.GEODATA_LR] = theData.LR_lat[j];
								loadFrame.scanBounds[WC.GEODATA_LAT][WC.GEODATA_LL] = theData.LL_lat[j];

								loadFrame.scanBounds[WC.GEODATA_LON][WC.GEODATA_UL] = theData.UL_lon[j];
								loadFrame.scanBounds[WC.GEODATA_LON][WC.GEODATA_UR] = theData.UR_lon[j];
								loadFrame.scanBounds[WC.GEODATA_LON][WC.GEODATA_LR] = theData.LR_lon[j];
								loadFrame.scanBounds[WC.GEODATA_LON][WC.GEODATA_LL] = theData.LL_lon[j];
								
								for (int convj=0; convj<4; convj++){
									
									loadFrame.scanBoundsEcf[WC.X][convj] =getLatLonX(
											WC.GLOBE_RADIUS,
											loadFrame.scanBounds[WC.GEODATA_LAT][convj],
											loadFrame.scanBounds[WC.GEODATA_LON][convj]);
									loadFrame.scanBoundsEcf[WC.Y][convj] =getLatLonY(
											WC.GLOBE_RADIUS,
											loadFrame.scanBounds[WC.GEODATA_LAT][convj],
											loadFrame.scanBounds[WC.GEODATA_LON][convj]);
									loadFrame.scanBoundsEcf[WC.Z][convj] =getLatLonZ(
											WC.GLOBE_RADIUS,
											loadFrame.scanBounds[WC.GEODATA_LAT][convj],
											loadFrame.scanBounds[WC.GEODATA_LON][convj]);
								}
								
								loadFrame.satPosECF = theData.satPosECF[j];
								loadFrame.satVelECF = theData.satVelECF[j];

								loadFrame.offEarthFlag = 0; // good unless -9999
															// is
								// found
								for (int gx = 0; gx < 2; gx++) {
									for (int gy = 0; gy < 4; gy++) {
										if (loadFrame.scanBounds[gx][gy] == WC.INVALID_GEOLOCATION) {
											loadFrame.offEarthFlag = 1;
										}
									}
								}

								// TODO determine HDR drop strategy

								if (storeHDRvals == 1) { // !! HDR
									// loadFrame.hdrValsRaw = new
									// int[staticFrameW][staticFrameH];

								}

								loadFrame.width = loadFrame.numChannels;
								loadFrame.height = loadFrame.numLines + 1;// staticFrameH;
								// tf[i].totalPixels = tf[i].width*tf[i].height;
								loadFrame.totalPixels = 1
										* loadFrame.numChannels
										* loadFrame.numLines; // need to
								// exclude blank
								// regions

								loadFrame.layerOffet[mode][WC.X] = 0;
								loadFrame.layerOffet[mode][WC.Y] = 0;

								int hours = (int) ((frameIndexSecondsOfDay / 60) / 60);
								int minutes = (int) (frameIndexSecondsOfDay / 60) % 60;
								int seconds = (int) frameIndexSecondsOfDay - (60 * 60 * hours + 60 * minutes);
								// float secFrac = (float)
								// (theData.secondsOfDay[j]-seconds);

								String hStr = hours + "";
								if (hStr.length() == 1)
									hStr = "0" + hStr;
								String mStr = minutes + "";
								if (mStr.length() == 1)
									mStr = "0" + mStr;
								String sStr = seconds + "";
								if (sStr.length() == 1)
									sStr = "0" + sStr;
								// String secFracStr = secFrac+"";

								loadFrame.timeStampHour = hours;
								loadFrame.timeStampMin = minutes;
								loadFrame.timeStampSec = seconds;

								loadFrame.timeStampSecOfDay = (int) frameIndexSecondsOfDay;

								String hmsStr = hStr + ":" + mStr + ":" + sStr;// +"."+secFracStr;
								if (secStr.length() > 8) {
									secStr = (String) secStr.subSequence(0, 8);
								}

								String dayStr = theData.day[j] + "";
								if (dayStr.length() == 1) {
									dayStr = "00" + dayStr;
								} else if (dayStr.length() == 2) {
									dayStr = "0" + dayStr;
								}
								strBdr = new StringBuilder();
								strBdr.append(theData.year[j]);
								strBdr.append(":");
								strBdr.append(dayStr);
								strBdr.append(":");
								strBdr.append(hmsStr);
								loadFrame.timeStampStr = strBdr.toString();

								// loadFrame.layerStatus[WC.THREAD_LOAD_METADATA]
								// =
								// WC.STATUS_COMPLETE;

								// geolocation copy

								WITFrame tFrame = new WITFrame();

								// !! todo - only need sparse grid for 1 SCA
								if (geolocationExists == 1) {
									tFrame.geoLocDataSparse = geolocationData
											.getGeolocationLonLat(j,
													loadFrame.scanDirection,
													scaID);
								}

								if (loadFrame.geoLocDataSparse == null) {
									loadFrame.geoLocDataSparse = new float[tFrame.geoLocDataSparse.length][tFrame.geoLocDataSparse[0].length][2]; // TODO
									// cleanup
								}

								for (int x = 0; x < tFrame.geoLocDataSparse.length; x++) {
									for (int y = 0; y < tFrame.geoLocDataSparse[0].length; y++) {

										int xg = x;
										int yg = tFrame.geoLocDataSparse[0].length
												- 1 - y; // set to the max Y
															// extent

										if (tFrame.geoLocDataSparse != null) {
											xg = tFrame.geoLocDataSparse.length
													- 1 - x;

											if (xg < 0) {
												xg = 0;
											}
											loadFrame.geoLocDataSparse[xg][yg][WC.GEODATA_LON] = tFrame.geoLocDataSparse[x][y][WC.GEODATA_LON];
											loadFrame.geoLocDataSparse[xg][yg][WC.GEODATA_LAT] = tFrame.geoLocDataSparse[x][y][WC.GEODATA_LAT];
										}
									}
								}

								try { // catch per frame so we can skip over
										// errors
									WITFrame tempFrame = new WITFrame();
									
						
									
									int H = frameMetaData.getMetaData().numLines[j];
									int W = WC.SCA_CHANNELS;//calRawData.getNumCols();
									
									tempFrame.hdrValsRaw = calRawData
									.getShortFrame(j,0);
									
									int WORKAROUND_GPU_HDR_taps = 6;
									int WORKAROUND_GPU_HDR_cutoff[] = new int[WORKAROUND_GPU_HDR_taps];
									int WORKAROUND_GPU_HDR_target[] = new int[WORKAROUND_GPU_HDR_taps];
									
									WORKAROUND_GPU_HDR_cutoff[0] = 0;
									WORKAROUND_GPU_HDR_cutoff[1] = 256; 
									WORKAROUND_GPU_HDR_cutoff[2] = 1024; 
									WORKAROUND_GPU_HDR_cutoff[3] = 2048; 
									WORKAROUND_GPU_HDR_cutoff[4] = 4096;
									WORKAROUND_GPU_HDR_cutoff[5] = 6000; 
									
									WORKAROUND_GPU_HDR_target[0] = 0; 
									WORKAROUND_GPU_HDR_target[1] = 128; 
									WORKAROUND_GPU_HDR_target[2] = 180; 
									WORKAROUND_GPU_HDR_target[3] = 210; 
									WORKAROUND_GPU_HDR_target[4] = 240; 
									WORKAROUND_GPU_HDR_target[5] = 255;
									
									float WORKAROUND_GPU_HDR_scale[] = new float[WORKAROUND_GPU_HDR_taps];

									for (int tap=0; tap<WORKAROUND_GPU_HDR_taps-1; tap++){
										float targetDiff = (WORKAROUND_GPU_HDR_target[tap+1]-WORKAROUND_GPU_HDR_target[tap]);
										float inputDiff =(WORKAROUND_GPU_HDR_cutoff[tap+1]-WORKAROUND_GPU_HDR_cutoff[tap]);
										WORKAROUND_GPU_HDR_scale[tap] = targetDiff/inputDiff;
									}
									
									//int val = 0;
									//int rgba = 0;
									for (int y = 0; y < H; y++) {
										for (int x = 0; x < W; x++) {
											// priorFillFlag = 0;

											int edgeFlag = 0;

											int destX = x;
											destX = W - 1 - x;

											if (destX < WC.SCA_X_OVERLAP / 2) {
												edgeFlag = 1;
											}
											if (destX > W - WC.SCA_X_OVERLAP
													/ 2) {
												edgeFlag = 1;
											}

											int yf = H - 1 - y;

											//if (storeHDRvals == 1) val = tempFrame.hdrValsRaw[x][y];
											
											int hdrVal = tempFrame.hdrValsRaw[x][y];

											//val = tempFrame.hdrValsRaw[x][y];

											if (WORKAROUND_GPU_HDR == 1){
											if (hdrVal>WORKAROUND_GPU_HDR_cutoff[5]){
												hdrVal = 255;
											} else {
											for (int tap=0; tap<WORKAROUND_GPU_HDR_taps-1; tap++){
												if (hdrVal>=WORKAROUND_GPU_HDR_cutoff[tap] && hdrVal<WORKAROUND_GPU_HDR_cutoff[tap+1]){
													int orig = hdrVal;
													float diff = hdrVal-WORKAROUND_GPU_HDR_cutoff[tap];
													hdrVal = (int)(WORKAROUND_GPU_HDR_target[tap]+(diff*WORKAROUND_GPU_HDR_scale[tap]));
													
													//System.out.println("IN "+orig+" DIFF "+diff+" CUTOFF "+ WORKAROUND_GPU_HDR_cutoff[tap]+" OUT "+hdrVal);
												}
											}
											}
											
											}
											
											if (hdrVal > Short.MAX_VALUE)
												hdrVal = Short.MAX_VALUE; // clamp
											if (hdrVal < 0)
												hdrVal = 0;
											//rgba = (255 << 24) | (val << 16)	| (val << 8) | val;
												
											loadFrame.hdrValsRaw[destX][yf] = (short) hdrVal;

										}
									} 

								} catch (Exception e) { // catch for the frames
									e.printStackTrace();
								}

								loadFrame.layerSCAstatus[scaID] = WC.STATUS_COMPLETE;
								loadFrame.layerStatus[mode] = WC.STATUS_COMPLETE;
								loadFrame.scaID = scaID;
								
								
								//loadFrame = histogramSingleBiIncStats(loadFrame);

								if (passNo == 0 && scanSeqIndexMask[satID][loadFrame.scanSeqIndex] == WC.STATUS_ON) {// && addFlag ==
																// 1){

									loadFrame.layerStatus[WC.THREAD_HISTOGRAM] = WC.THREAD_STATUS_READY;
									loadFrame.layerStatus[WC.THREAD_PREFILTER] = WC.THREAD_STATUS_READY;

									loadFrame.histogram = new int[WC.CONTRAST_UI_HARD_LIMIT];
									loadFrame = histogramSingleBiInc(loadFrame);
									
									loadFrame = generateTiles(loadFrame,COORDINATE_SPACE_LOAD_MASK);
									
									wfl.add(loadFrame);
																		
									// System.out.println("frame added");
									
								} else if (passNo >= 1 && scanSeqIndexMask[satID][loadFrame.scanSeqIndex] == WC.STATUS_ON){// if (addFlag == 1){ //append
									// System.out.println("frame modified");
									BufferedImage bUpdate = new BufferedImage(
											loadFrame.width, loadFrame.endLine, 
											BufferedImage.TYPE_INT_ARGB);
									Graphics2D gUpdate = (Graphics2D) bUpdate
											.getGraphics();
									
									// find the last segment
									int appendedFrame = -1;
									int minTimeDelta = Integer.MAX_VALUE;
									int timeThresh = 5;
									for (int wi = 0; wi < wfl.size(); wi++) {
										WITFrame w = (WITFrame) wfl.get(wi);
										if (loadFrame.scanDirection == w.scanDirection) {
											if (loadFrame.timeStampSecOfDay >= w.timeStampSecOfDay) {
												int tempDiff = loadFrame.timeStampSecOfDay
														- w.timeStampSecOfDay;
												if (tempDiff < 5) {
													if (tempDiff < minTimeDelta) {
														minTimeDelta = tempDiff;
														appendedFrame = wi;
													}
												}
											}
										}
									}

									if (appendedFrame != -1) { // incoming
																// interrupt
																// placeholder
										WITFrame w = (WITFrame) wfl
												.get(appendedFrame);
										// System.out.println("APPENDING - TIME DELTA "+minTimeDelta+
										// " SCAN STARTS AT "+w.beginLine);

										if (w.scanDirection == loadFrame.scanDirection
												&& w.beginLine < loadFrame.beginLine) {
											if (w.beginLine < loadFrame.beginLine) {
												
												
												if (loadFrame.scanDirection == WC.SCAN_DIR_EVEN) {
													// System.out.println("append even");
													w.maxCalIntensityFrame = Math
															.max(w.maxCalIntensityFrame,
																	loadFrame.maxCalIntensityFrame);
													w.minCalIntensityFrame = Math
															.min(w.minCalIntensityFrame,
																	loadFrame.minCalIntensityFrame);

													int tempScanLength = loadFrame.endLine;
													

													// geolocation append
													WITFrame appendFrame = new WITFrame();
													
													appendFrame.tileSizeX = TILE_SIZE_X;
													appendFrame.tileSizeY = TILE_SIZE_Y;
													
													int totalGeolocSparseRows = w.geoLocDataSparse[0].length
															+ loadFrame.geoLocDataSparse[0].length;
													appendFrame.geoLocDataSparse = new float[w.geoLocSparseCols][totalGeolocSparseRows][2];
													
													for (int x = 0; x < w.geoLocSparseCols; x++) {
														for (int y = 0; y < w.geoLocDataSparse[x].length; y++) {
															for (int k = 0; k < 2; k++) {
																appendFrame.geoLocDataSparse[x][y][k] = w.geoLocDataSparse[x][y][k];
															}
														}

														for (int y = 0; y < loadFrame.geoLocDataSparse[x].length; y++) {
															int y2 = w.geoLocDataSparse[x].length + y;

															for (int k = 0; k < 2; k++) {
																appendFrame.geoLocDataSparse[x][y2][k] = loadFrame.geoLocDataSparse[x][y][k];
															}
														}
													}

													w.geoLocSparseRows = totalGeolocSparseRows;
													w.geoLocDataSparse = appendFrame.geoLocDataSparse;

													// end geolocation append

													
													
													// hdr vals append
													int totalHdrValRows = w.numLines + loadFrame.numLines;
													appendFrame.hdrValsRaw = new short[loadFrame.numChannels][totalHdrValRows];
														
													for (int x = 0; x < w.numChannels; x++) {
														for (int y = 0; y < loadFrame.numLines; y++) {
															appendFrame.hdrValsRaw[x][y] = loadFrame.hdrValsRaw[x][y]; // 1/11/11
															// 1
															// removes
															// border
														}
														for (int y = 0; y < w.numLines; y++) {
															int y2 = loadFrame.numLines
																	+ y;
															appendFrame.hdrValsRaw[x][y2] = w.hdrValsRaw[x][y];
														}
													}
													w.hdrValsRaw = appendFrame.hdrValsRaw;
													w.numLines = totalHdrValRows;
													w.endLine = loadFrame.endLine;
													w.scanSeqIndex = loadFrame.scanSeqIndex;
													
													// end hdr vals append

													for (int m = 0; m < WC.MODE_COUNT; m++) {
														if (m != WC.THREAD_LOAD_HDF5R) {
															w.layerStatus[m] = WC.STATUS_READY;
														}
													}

												

													for (int k=0; k<WC.COORDINATES_MODE_MAX; k++){
														w.glDrawListStatusPerCoordinateSystem[k] = WC.STATUS_READY;
													}
													
													w.glTexStatus = WC.STATUS_READY;
													//w.glDrawListID = WC.STATUS_ERROR;
													w.histogram = new int[WC.CONTRAST_UI_HARD_LIMIT];
													w = histogramSingleBiInc(w);
													w = generateTiles(w,
															COORDINATE_SPACE_LOAD_MASK);
													wfl.set(appendedFrame, w);
													appendedFrame = 0; // break
													loadFrame = null;

												} else if (loadFrame.scanDirection == WC.SCAN_DIR_ODD) {
													// System.out.println("append odd");
													w.maxCalIntensityFrame = Math
															.max(
																	w.maxCalIntensityFrame,
																	loadFrame.maxCalIntensityFrame);
													w.minCalIntensityFrame = Math
															.min(
																	w.minCalIntensityFrame,
																	loadFrame.minCalIntensityFrame);

													int tempScanLength = loadFrame.endLine;
													

													// geolocation append
													WITFrame appendFrame = new WITFrame();

													appendFrame.tileSizeX = TILE_SIZE_X;
													appendFrame.tileSizeY = TILE_SIZE_Y;
													
													int totalGeolocSparseRows = w.geoLocDataSparse[0].length
															+ loadFrame.geoLocDataSparse[0].length;
													appendFrame.geoLocDataSparse = new float[w.geoLocSparseCols][totalGeolocSparseRows][2];

													for (int x = 0; x < w.geoLocSparseCols; x++) {
														for (int y = 0; y < w.geoLocDataSparse[x].length; y++) {
															// for (int y=0;
															// y<loadFrame.geoLocSparseRows;
															// y++){
															for (int k = 0; k < 2; k++) {
																appendFrame.geoLocDataSparse[x][y][k] = w.geoLocDataSparse[x][y][k];
															}
														}

														for (int y = 0; y < loadFrame.geoLocDataSparse[x].length; y++) {
															int y2 = w.geoLocDataSparse[x].length
																	+ y;
															for (int k = 0; k < 2; k++) {

																appendFrame.geoLocDataSparse[x][y2][k] = loadFrame.geoLocDataSparse[x][y][k];

															}
														}
													}

													w.geoLocSparseRows = totalGeolocSparseRows;
													w.geoLocDataSparse = appendFrame.geoLocDataSparse;
													// end geolocation append

													// hdr vals append
													int totalHdrValRows = w.numLines
															+ loadFrame.numLines;
													//int totalHdrValRows = w.hdrValsRaw[0].length
													//+ loadFrame.hdrValsRaw[0].length;
													appendFrame.hdrValsRaw = new short[loadFrame.numChannels][totalHdrValRows];

													for (int x = 0; x < w.numChannels; x++) {
														for (int y = 0; y < loadFrame.numLines; y++) {
															int y2 = y
																	+ w.numLines;
															appendFrame.hdrValsRaw[x][y2] = loadFrame.hdrValsRaw[x][y]; // 1/11/11
															// -1
															// removes
															// border
														}
														for (int y = 0; y < w.numLines; y++) {
															appendFrame.hdrValsRaw[x][y] = w.hdrValsRaw[x][y];
														}
													}
													w.hdrValsRaw = appendFrame.hdrValsRaw;
													w.numLines = totalHdrValRows;
													w.endLine = loadFrame.endLine;
													w.scanSeqIndex = loadFrame.scanSeqIndex;
													// end hdr vals append
													
													for (int m = 0; m < WC.MODE_COUNT; m++) {
														if (m != WC.THREAD_LOAD_HDF5R) {
															w.layerStatus[m] = WC.STATUS_READY;
														}
													}

												
													for (int k=0; k<WC.COORDINATES_MODE_MAX; k++){
														w.glDrawListStatusPerCoordinateSystem[k] = WC.STATUS_READY;
													}
													
													w.glTexStatus = WC.STATUS_READY;
													//w.glDrawListID = WC.STATUS_ERROR;
													w.histogram = new int[WC.CONTRAST_UI_HARD_LIMIT];
													w = histogramSingleBiInc(w);
													w = generateTiles(w,
															COORDINATE_SPACE_LOAD_MASK);
													wfl.set(appendedFrame, w);
													appendedFrame = 0; // break
													loadFrame = null;

												}

											}
											}
										}
									}
								}

							}// end beginLine check
						}
					}
					}
					}

				}
			}

			// }
			// !!!
			h5.finalize();

		} catch (Exception e) { // catch for the file
			e.printStackTrace();
		} catch (Throwable e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		}
	}

	public void renderGeoFeatures(WITFrame[] tf, int a, int b,
			ArrayList paramList) {

	}

	public void rawImage(WITFrame[] tf, int a, int b, ArrayList paramList) {
		for (int i = a; i < b; i++) {

			if (tf[i].layerStatus[WC.THREAD_LOAD] == WC.STATUS_READY) {
				tf[i].layerStatus[WC.THREAD_LOAD] = WC.STATUS_WORKING;
				if (verbosity > 0)
					System.out.println("EXEC LOAD FRAME " + i);
				
				// loadImage("C:/DEV_DATA/input_seq_1/uav1_"+padFrameID((i+1),3)+".png",
				// tf[i]);
				// loadImage(importLocation+importName+padFrameID((i+1),3)+formatToFileExt(importMode),
				// tf[i]);
				loadImage(importLocation + importName + i
						+ formatToFileExt(importMode), tf[i]);

				tf[i].layerStatus[WC.THREAD_LOAD] = WC.STATUS_COMPLETE;
			}
		}
	}

	public void markReceipt() {

	}

	// need to propagate to tivoframes

	// verified against flight 33 - should check with 34
	public static int[][] initSCAoffsets(int mag) {
		int baseYoffset = mag * WC.SCA_Y_OFFSET;// //*208;//-208;
		int overlapX = WC.SCA_X_OVERLAP;// 4;

		int offsets[][] = new int[8][2];

		offsets[0][WC.X] = 0;
		offsets[0][WC.Y] = 0;

		offsets[1][WC.X] = 768 * 1 - overlapX;
		offsets[1][WC.Y] = baseYoffset;

		offsets[2][WC.X] = 768 * 2 - overlapX * 2;
		offsets[2][WC.Y] = 0;

		offsets[3][WC.X] = 768 * 3 - overlapX * 3;
		offsets[3][WC.Y] = baseYoffset;

		offsets[4][WC.X] = 768 * 4 - overlapX * 4;
		offsets[4][WC.Y] = 0;

		offsets[5][WC.X] = 768 * 5 - overlapX * 5;
		offsets[5][WC.Y] = baseYoffset;

		// bump the non-SWIR SCAs over
		offsets[6][WC.X] = 768 * 6 - overlapX * 6 + 100;
		offsets[6][WC.Y] = baseYoffset;

		offsets[7][WC.X] = 768 * 7 - overlapX * 7 + 200;
		offsets[7][WC.Y] = baseYoffset;

		return offsets;

	}

	public String formatToFileExt(int format) {
		String ext = "";

		if (format == WC.FORMAT_MP4) {
			ext = ".mp4";
		} else if (format == WC.FORMAT_PNG) {
			ext = ".png";
		} else if (format == WC.FORMAT_WMV) {
			ext = ".wmv";
		}

		return ext;
	}

	public void rawData(WITFrame[] tf, int a, int b, ArrayList paramList) {
		for (int i = a; i < b; i++) {

			if (tf[i].layerStatus[WC.THREAD_LOAD] == WC.STATUS_READY) {
				tf[i].layerStatus[WC.THREAD_LOAD] = WC.STATUS_WORKING;
				if (verbosity > 0)
					System.out.println("EXEC LOAD FRAME " + i);
				
				// loadImage("C:/DEV_DATA/input_seq_1/uav1_"+padFrameID((i+1),3)+".png",
				// tf[i]);
				// loadImage(importLocation+importName+padFrameID((i+1),3)+formatToFileExt(importMode),
				// tf[i]);
				// loadHDF5(importLocation+importName+i+formatToFileExt(importMode),
				// tf[i]);

				// h5rData(importLocation+importName+i+formatToFileExt(importMode),
				// tf[i]);
				tf[i].layerStatus[WC.THREAD_LOAD] = WC.STATUS_COMPLETE;
			}
		}
	}

	public void h5rData(WITFrame[] tf, int a, int b, ArrayList paramList) {

		// start filling WIT buffer from tf

	}

	// public void determineLOS

	public void determineScanDirYOffset2(ArrayList wfl, int a, int b,
			ArrayList paramList) {
		// int mode = WC.THREAD_SCAN_DIR_Y_OFFSET;

		int inputSrc = (Integer) paramList.get(0);
		// System.out.println("FINDING Y OFFSET " + opIDtoName(inputSrc));

		// int minX = (Integer) paramList.get(1);
		// int maxX = (Integer) paramList.get(2);
		// int minY = (Integer) paramList.get(3);
		// int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);

		int scanDir = (Integer) paramList.get(7);

		// determination of the neighborhood
		// 1) based on motion within this scan direction
		// 2) based on motion from last scan of opposite scan direction

		// compares bound the comparison area
		int yCompareStart = 300;
		int yCompareSwath = 10;
		int yCompareStop = yCompareStart + yCompareSwath;
		int xCompareStart = 20;
		int xCompareStop = WC.SCA_CHANNELS - 40;
		// search limit defines the search neighborhood
		int xSearchLimitMin = 0;
		int xSearchLimitMax = 0;
		int ySearchLimitMin = -60;
		int ySearchLimitMax = 60;
		// find the last sca

		int anchorScanDir = 0;

		for (int i = 0; i < wfl.size(); i++) {

			WITFrame wTemp = (WITFrame) wfl.get(i);

			if (wTemp.scanDirection != anchorScanDir) {
				if (i > 0) {
					WITFrame wAnchor = (WITFrame) wfl.get(i - 1);
					if (wTemp.layerStatus[inputSrc] == WC.STATUS_READY
							&& wAnchor.layerStatus[inputSrc] == WC.STATUS_READY
							&& wAnchor.timeStampSecOfDay > minT
							&& wAnchor.timeStampSecOfDay < maxT) {

						wTemp.layerStatus[mode] = WC.STATUS_WORKING;
						wfl.set(i, wTemp);

						int xAlign = 0;
						int yAlign = 0;
						int minDelta = Integer.MAX_VALUE;

						for (int xn = xSearchLimitMin; xn <= xSearchLimitMax; xn++) {
							for (int yn = ySearchLimitMin; yn <= ySearchLimitMax; yn++) {
								int delta = 0;
								for (int x = xCompareStart; x < xCompareStop; x++) {
									for (int y = yCompareStart; y < yCompareStop; y++) {

										int xa = xn + x;
										int xb = x;

										int ya = yn + y;
										int yb = y;

										delta += (wTemp.hdrValsRaw[xb][yb] - wAnchor.hdrValsRaw[xa][ya]);
										if (delta < minDelta) {
											minDelta = delta;
											xAlign = xn;
											yAlign = yn;
										}
									}
								}
							}
						}
						wTemp.layerStatus[mode] = WC.STATUS_COMPLETE;
						wTemp.yAlignGross = yAlign;
						wfl.set(i, wTemp);
						System.out.println("Y OFFSET IS " + yAlign);
					}
				}

			}

		}

	}

	public void determineScanDirYOffset(ArrayList wfl, int a, int b,
			ArrayList paramList) {
		// int mode = WC.THREAD_SCAN_DIR_Y_OFFSET;

		int inputSrc = (Integer) paramList.get(0);
		// System.out.println("FINDING Y OFFSET " + opIDtoName(inputSrc));

		// int minX = (Integer) paramList.get(1);
		// int maxX = (Integer) paramList.get(2);
		// int minY = (Integer) paramList.get(3);
		// int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);

		int scanDir = (Integer) paramList.get(7);

		// determination of the neighborhood
		// 1) based on motion within this scan direction
		// 2) based on motion from last scan of opposite scan direction

		int anchorScanDir = 0;

		for (int i = 0; i < wfl.size(); i++) {

			WITFrame wTemp = (WITFrame) wfl.get(i);

			if (wTemp.scanDirection != anchorScanDir) {
				if (i > 0) {
					WITFrame wAnchor = (WITFrame) wfl.get(i - 1);
					if (wTemp.layerStatus[inputSrc] == WC.STATUS_READY
							&& wAnchor.layerStatus[inputSrc] == WC.STATUS_READY
							&& wAnchor.timeStampSecOfDay > minT
							&& wAnchor.timeStampSecOfDay < maxT) {

						wTemp.layerStatus[mode] = WC.STATUS_WORKING;
						wfl.set(i, wTemp);

						int xAlign = 0;
						int yAlign = 0;
						int minDelta = Integer.MAX_VALUE;

						// grab lat/lon in center pixel

						// find lat/lon in opposite scan direction

						// propagate y difference

						wTemp.layerStatus[mode] = WC.STATUS_COMPLETE;
						wTemp.yAlignGross = yAlign;
						wfl.set(i, wTemp);
						System.out.println("Y OFFSET IS " + yAlign);
					}
				}

			}

		}

	}

	/*
	public void registerSubFrame(ArrayList wfl, int a, int b,
			ArrayList paramList) {
		System.out.println(threadIndentStr + "REGISTER SUB-FRAME " + a + "-"
				+ b);

		int inputSrc = (Integer) paramList.get(0);

		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);

		int scanDir = (Integer) paramList.get(7);

		int w = maxX - minX;
		int h = maxY - minY;

		for (int k = 0; k < 1; k++) {
			// for (int k=0; k<WC.SCAN_DIR_BOTH; k++){

			// if (k==scanDir || scanDir==WC.SCAN_DIR_BOTH){
			if (true) {
				int awaitingRefFrame = WC.STATUS_ON;

				int mode = WC.THREAD_REGISTRATION;

				// 2 passes, even/odd frames - or both?

				// frame coordinates
				// int totalControlPoints=5;

				ArrayList refCoordsList = new ArrayList();// float[totalControlPoints][2];
															// // 4 corners,
															// lat/lon
				ArrayList refFrameXYList = new ArrayList();// new
															// int[totalControlPoints][2];

				int xy1[] = { minX, minY };
				refFrameXYList.add(xy1);

				int xy2[] = { minX, maxY };
				refFrameXYList.add(xy2);

				int xy3[] = { maxX, maxY };
				refFrameXYList.add(xy3);

				int xy4[] = { maxX, minY };
				refFrameXYList.add(xy4);

				int xy5[] = { maxX - w / 2, maxY - h / 2 };
				refFrameXYList.add(xy5);

				//
				for (int i = 0; i < 4; i++) {
					int[] prevXy = (int[]) refFrameXYList.get(i);
					int xyAve[] = { (prevXy[WC.X] / 2 + xy5[WC.X] / 2),
							(prevXy[WC.Y] / 2 + xy5[WC.Y] / 2) };
					refFrameXYList.add(xyAve);
				}

				for (int i = 0; i < 4; i++) {
					int[] prevXy = (int[]) refFrameXYList.get(i);
					int[] prevXy2 = (int[]) refFrameXYList.get((i + 1) % 4);
					int xyAve[] = { (prevXy[WC.X] / 2 + prevXy2[WC.X] / 2),
							(prevXy[WC.Y] / 2 + prevXy2[WC.Y] / 2) };
					refFrameXYList.add(xyAve);
				}

				int comparisonCorner = 0;

				// find nearest pixel coords in subsequent frames

				for (int i = 0; i < wfl.size(); i++) {
					// for (int i = a; i < b; i++) {

					WITFrame wTemp = (WITFrame) wfl.get(i);
					if (wTemp.timeStampSecOfDay >= minT
							&& wTemp.timeStampSecOfDay <= maxT) {// &&
																	// wTemp.scanDirection
																	// == k) {
						if (wTemp.layerStatus[inputSrc] == WC.STATUS_COMPLETE
								&& (wTemp.layerStatus[mode] == WC.STATUS_READY || (awaitingRefFrame == WC.STATUS_ON))) {

							// System.out.println("REG ATTEMPT FRAME "+i+
							// " REF "+awaitingRefFrame);
							if (awaitingRefFrame == WC.STATUS_ON
									&& wTemp.scanDirection == scanDir) {
								WITFrame wfRef = (WITFrame) wfl.get(i);
								// WITFrame wfRef = (WITFrame) wfl.get(i);
								// find lat/lon of corners and center of frame0
								for (int j = 0; j < refFrameXYList.size(); j++) {
									float coords[] = interpolateLonLatFramePointFast(
											wfRef,
											wfRef.scaID,
											((int[]) refFrameXYList.get(j))[WC.X],
											((int[]) refFrameXYList.get(j))[WC.Y]);
									refCoordsList.add(coords);
								}
								awaitingRefFrame = WC.STATUS_OFF;

								wfRef.layerStatus[mode] = WC.STATUS_COMPLETE;
								wfl.set(i, wfRef);
								// System.out.println("SCAN "+i+" DIR "+k+" REF center XY "+refFrameXY[comparisonCorner][WC.X]+","+refFrameXY[comparisonCorner][WC.Y]+" LON/LAT "+refCoords[comparisonCorner][WC.GEODATA_LON]+","+refCoords[comparisonCorner][WC.GEODATA_LAT]);
							} else if (awaitingRefFrame == WC.STATUS_OFF) {

								WITFrame wfObs = (WITFrame) wfl.get(i);

								wfObs.layerStatus[mode] = WC.STATUS_WORKING;
								wfl.set(i, wfObs);

								if (wfObs.layerStatus[inputSrc] == WC.STATUS_COMPLETE) {

									ArrayList obsCoordsList = new ArrayList();// float[totalControlPoints][2];
									ArrayList obsFrameXYList = new ArrayList();// int[totalControlPoints][2];

									// match the points
					

									obsFrameXYList = findFrameXYList(
											refCoordsList, wfObs);

									// System.out.println("OBS corner 1 "+obsFrameXY[0][WC.X]);

									// System.out.println("OBS FRAMES "+i);

									// find frame extents
									int obsMinX = Integer.MAX_VALUE;
									int obsMaxX = Integer.MIN_VALUE;
									int obsMinY = Integer.MAX_VALUE;
									int obsMaxY = Integer.MIN_VALUE;
									for (int j = 0; j < obsFrameXYList.size(); j++) {
										int[] xyTemp = (int[]) obsFrameXYList
												.get(j);
										if (xyTemp[WC.X] < obsMinX) {
											obsMinX = xyTemp[WC.X];
										}
										if (xyTemp[WC.Y] < obsMinY) {
											obsMinY = xyTemp[WC.Y];
										}
										if (xyTemp[WC.X] > obsMaxX) {
											obsMaxX = xyTemp[WC.X];
										}
										if (xyTemp[WC.Y] > obsMaxY) {
											obsMaxY = xyTemp[WC.Y];
										}
									}
									int obsW = obsMaxX - obsMinX;
									int obsH = obsMaxY - obsMinY;

									// System.out.println("SCAN "+i+" DIR "+k+" OBS center XY "+obsFrameXY[comparisonCorner][WC.X]+","+obsFrameXY[comparisonCorner][WC.Y]+" LON/LAT "+obsCoords[comparisonCorner][WC.GEODATA_LON]+","+obsCoords[comparisonCorner][WC.GEODATA_LAT]+" DIMS "+w+"x"+h+"..."+obsW+"x"+obsH);

									// wfObs.layerOffet[mode][WC.X] =
									// obsMinX;//minX;
									// wfObs.layerOffet[mode][WC.Y] =
									// obsMinY;//minY
									wfObs.layerOffet[mode][WC.X] = minX;// -(w-obsW);
									wfObs.layerOffet[mode][WC.Y] = minY;// -(h-obsH);

									// AffineTransform affineTransform =
									// setupAffine(refCoords, refFrameXY);
									AffineTransform affineTransform = setupAffine(
											refFrameXYList, obsFrameXYList);
									AffineTransformOp affineTransformOp = new AffineTransformOp(
											affineTransform,
											AffineTransformOp.TYPE_BILINEAR);
									BufferedImage tempImage = new BufferedImage(
											w, h, BufferedImage.TYPE_INT_ARGB);// wfObs.biRay[inputSrc].getColorModel());
									Graphics2D g = (Graphics2D) tempImage
											.getGraphics();
									

									wfObs.layerStatus[mode] = WC.STATUS_COMPLETE;

									wfl.set(i, wfObs);
								}
							}
						}
					}
				}
			}
		}

	}*/
	

	/*
	private AffineTransform setupAffine(ArrayList refFrameXYlist,
			ArrayList obsFrameXYlist) {
		// private AffineTransform setupAffine(float[][] refCoords, int
		// refFrameXY[][]) {

		int numCtrlPoints = refFrameXYlist.size();
		double[][] xVals = new double[numCtrlPoints][3];
		double[][] uVals = new double[numCtrlPoints][3];

		for (int n = 0; n < numCtrlPoints; n++) {
			// note that we swap the row and column values to conform to the
			// definition of the affine transform as given in the referenced
			// text
			xVals[n][0] = ((int[]) refFrameXYlist.get(n))[WC.X];
			xVals[n][1] = ((int[]) refFrameXYlist.get(n))[WC.Y];
			xVals[n][2] = 1.0;

			uVals[n][0] = ((int[]) obsFrameXYlist.get(n))[WC.X];
			uVals[n][1] = ((int[]) obsFrameXYlist.get(n))[WC.Y];
			uVals[n][2] = 1.0;
		}

		//
		// Find the transform coefficient matrix using least-squares
		// minimization
		//
		// [a00 a10 0]
		// [x y 1] = [u v 1] [a10 a11 0]
		// [a20 a21 1]
		//
		// X = U * A
		//
		// where X,U are N-by-3
		//
		// A = pseudo-inverse(U)*X
		//
		//Matrix X = new Matrix(xVals);
		//Matrix U = new Matrix(uVals);
		//Matrix A = U.solve(X);

		// compute the residual for diagnostic purposes
		//Matrix r = U.times(A).minus(X);
		double rnorm = r.normInf();

		//
		// The Java Affine class definition is the transpose of the above, i.e.
		//
		// [x] [m00 m01 m02] [u]
		// [y] = [m10 m11 m12] [v]
		// [1] [0 0 1 ] [1]
		//
		// X' = M * U', where ' is the transpose operator
		//
		// But (X = U * A)' -> X' = A' * U'
		// So M = A'
		//
		

		double[][] M = A.transpose().getArrayCopy();
		AffineTransform affineTransform = new AffineTransform(M[0][0], M[1][0],
				M[0][1], M[1][1], M[0][2], M[1][2]);
	
		return affineTransform;
	}*/
	

	public ArrayList findFrameXYList(ArrayList refCoordsList, WITFrame w) {
		ArrayList frameXYList = new ArrayList();

		for (int j = 0; j < refCoordsList.size(); j++) {
			int[] frameXY = new int[2];
			frameXY[WC.X] = WC.STATUS_ERROR;
			frameXY[WC.Y] = WC.STATUS_ERROR;

			// create full geoloc field

			WITFrame wTemp = interpolateLonLatFrame(w);

			float[] refCoords = (float[]) refCoordsList.get(j);

			// find closest
			float minDist = Float.MAX_VALUE;
			int minX = -1;
			int minY = -1;
			int threshDist = 0;
			for (int x = 0; x < w.numChannels; x++) {
				for (int y = 0; y < w.numLines; y++) {
					float dist = (refCoords[WC.GEODATA_LON] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LON])
							* (refCoords[WC.GEODATA_LON] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LON])
							+ (refCoords[WC.GEODATA_LAT] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LAT])
							* (refCoords[WC.GEODATA_LAT] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LAT]);
					if (dist < minDist) {
						minDist = dist;
						minX = x;
						minY = y;
					}
				}
			}

			frameXY[WC.X] = minX;
			frameXY[WC.Y] = minY;

			frameXYList.add(frameXY);
		}
		return frameXYList;
	}

	public int[] findFrameXY(float refCoords[], WITFrame w) {
		int[] frameXY = new int[2];
		frameXY[WC.X] = WC.STATUS_ERROR;
		frameXY[WC.Y] = WC.STATUS_ERROR;

		// create full geoloc field

		WITFrame wTemp = interpolateLonLatFrame(w);

		// find closest
		float minDist = Float.MAX_VALUE;
		int minX = -1;
		int minY = -1;
		int threshDist = 0;
		for (int x = 0; x < w.numChannels; x++) {
			for (int y = 0; y < w.numLines; y++) {
				float dist = (refCoords[WC.GEODATA_LON] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LON])
						* (refCoords[WC.GEODATA_LON] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LON])
						+ (refCoords[WC.GEODATA_LAT] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LAT])
						* (refCoords[WC.GEODATA_LAT] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LAT]);
				if (dist < minDist) {
					minDist = dist;
					minX = x;
					minY = y;
				}
			}
		}

		frameXY[WC.X] = minX;
		frameXY[WC.Y] = minY;

		return frameXY;
	}

	public void preFilterData(ArrayList wfl, int a, int b, ArrayList paramList) {

		// use loaded HDF5 now, then metadata next version
		int inputSrc = (Integer) paramList.get(0);
		System.out.println("PREFILTERING " + opIDtoName(inputSrc));

		int triggerMagnitude = 400000;
		int triggerDelta = 4000;
		int deltaTimeSecs = 10;
		int searchWindowSecs = 5;

		int mode = WC.THREAD_PREFILTER;

		// for (int sat = 0; sat < 2; sat++) {
		// int sat=userFlight;

		for (int j = 0; j < WC.SEC_IN_DAY; j++) {
			// add start/stop time bounds
			int time1 = j;

			int ix1 = getIndexFromTime(time1, searchWindowSecs, wfl,
					WC.SCAN_DIR_BOTH);

			if (ix1 >= 0) {

				WITFrame wf1 = (WITFrame) wfl.get(ix1);

				if (wf1.layerStatus[inputSrc] == WC.STATUS_COMPLETE
						&& wf1.layerStatus[mode] == WC.STATUS_READY) {
					// wf1.layerSCAstatus[mode] = WC.STATUS_WORKING;
					int time2 = wf1.timeStampSecOfDay - deltaTimeSecs;
					int ix2 = getIndexFromTime(time2, searchWindowSecs, wfl,
							wf1.scanDirection); // match scan dir for deltas
					WITFrame wf2 = null;
					if (ix2 >= 0) {
						wf2 = (WITFrame) wfl.get(ix2);
					}

					int maxIntensity1 = wf1.maxCalIntensityFrame;
					// int minIntensity1=wf1.minCalIntensity;

					BookmarkEvent b1 = new BookmarkEvent();
					int bookmarkTriggers = 0;

					if (maxIntensity1 > triggerMagnitude) {
						b1.eventDetectors[WC.EVENT_DETECTOR_AUTO_METADATA_MAGNITUDE] = true;
						bookmarkTriggers++;
					}

					if (wf2 != null) {

						int maxIntensity2 = wf2.maxCalIntensityFrame;
						// int minIntensity2=wf2.minCalIntensity;
						// System.out.println("SCA "+wf1.scaID+"  MAX "+maxIntensity1+"/"+(maxIntensity2)+" FRAMES: "+ix1+" "+ix2+"   TIMES: "+j+" "+(wf1.timeStampSecOfDay-deltaTimeSecs)+" "+wf1.timeStampSecOfDay+
						// " "+wf2.timeStampSecOfDay);
						if (Math.abs(maxIntensity1 - maxIntensity2) > triggerDelta) {
							b1.eventDetectors[WC.EVENT_DETECTOR_AUTO_METADATA_DELTA] = true;
							bookmarkTriggers++;
						}
					}
					if (bookmarkTriggers > 0) {
						// System.out.println("BOOKMARK CREATED ");
						b1.eventLabel = "INTENSITY CHANGE IN FRAME METADATA";
						b1.scaID = wf1.scaID;
						b1.satID = wf1.satID;
						b1.eventDesc = "max_intensity increased in HDF5 metadata";
						b1.triggerCount = bookmarkTriggers;
						b1.timeStampSecOfDay = wf1.timeStampSecOfDay;
						b1.eventType = WC.EVENT_UNKNOWN;
						b1.statusCheckedByOperator = WC.STATUS_OFF;
						b1.statusCheckedByAuto = WC.STATUS_ON;
						wf1.bookmarkList.add(b1);

					}
					wf1.layerStatus[mode] = WC.STATUS_COMPLETE;
					wfl.set(ix1, wf1);

				}
			}

			// }
		}
	}

	// private static void loadImage(String name, BufferedImage bi){
	private static void loadImage(String name, WITFrame tf) {
		System.out.println("LOAD FILE " + name);
		Image imageRay = Toolkit.getDefaultToolkit().getImage(name);
		MediaTracker mediaTracker = new MediaTracker(new Container());
		mediaTracker.addImage(imageRay, 0);
		try {
			mediaTracker.waitForID(0);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		int width = imageRay.getWidth(null);
		int height = imageRay.getHeight(null);

		
		imageRay = null;
	}

	private static BufferedImage loadImageBI(String name) {
		System.out.println("LOAD FILE " + name);
		Image imageRay = Toolkit.getDefaultToolkit().getImage(name);
		MediaTracker mediaTracker = new MediaTracker(new Container());
		mediaTracker.addImage(imageRay, 0);
		try {
			mediaTracker.waitForID(0);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		int width = imageRay.getWidth(null);
		int height = imageRay.getHeight(null);

		BufferedImage b = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_ARGB);

		return b;
	}

	public void macroFilter(BufferedImage fi) {

		int tileAreaX = 100;
		int tileAreaY = 200;

		int ww = 1;
		int hh = 1;

		int w = fi.getWidth();
		int h = fi.getHeight();

		int offsetX = tileAreaX / ww;
		int offsetY = tileAreaY / hh;

		BufferedImage ave[][] = new BufferedImage[ww][hh];

		for (int i = 0; i < ww; i++) {
			for (int j = 0; j < hh; j++) {
				ave[i][j] = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
				Graphics gTemp = ave[i][j].getGraphics();
				gTemp.drawImage(fi, 0, 0, null);

				applyRegionEQ(ave[i][j], 10.5f, tileAreaX, tileAreaY, i
						* offsetX, j * offsetY);
			}
		}

		// average
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {

				int sum = 0;// [] = new int[ww*hh];
				for (int i = 0; i < ww; i++) {
					for (int j = 0; j < hh; j++) {

						int rgba = ave[i][j].getRGB(x, y);
						// vals[WC.A] += ((rgba >> 24) & 0xff);
						sum += ((rgba >> 16) & 0xff);
						// vals[WC.G] += ((rgba >> 8) & 0xff);
						// vals[WC.B] += ((rgba ) & 0xff);

					}
				}

				int val = sum / (ww * hh);
				if (val > 255)
					val = 255;
				if (val < 0)
					val = 0;

				int rgba = (val << 24) | (val << 16) | (val << 8) | val;

				fi.setRGB(x, y, rgba);

			}
		}

	}

	public void applyRegionEQ(BufferedImage b, float expansionLimit,
			int channels, int scanlines, int offX, int offY) {

		int w = b.getWidth();
		int h = b.getHeight();

		int data[][] = new int[w][h];

		int pxCount = 0;

		for (int wc = offX; wc < w / channels + offX; wc++) {

			for (int hc = offY; hc < h / scanlines + offY; hc++) {

				pxCount = 0;

				int valDist[] = new int[256];

				for (int x = wc * channels; x < wc * channels + channels; x++) {

					for (int y = hc * scanlines; y < hc * scanlines + scanlines; y++) {

						if (x < w && y < h) {

							int vals[] = new int[4];
							int rgba = b.getRGB(x, y);
							// vals[WC.A] += ((rgba >> 24) & 0xff);
							vals[WC.R] += ((rgba >> 16) & 0xff);
							// vals[WC.G] += ((rgba >> 8) & 0xff);
							// vals[WC.B] += ((rgba ) & 0xff);

							data[x][y] = vals[WC.R];

							valDist[data[x][y]]++;

							pxCount++;
						}
					}

				}

				// statistics
				int accum = 0;

				int q1 = (int) (.1f * (float) pxCount);
				int q2 = (int) (.5f * (float) pxCount);
				int q3 = (int) (.9f * (float) pxCount);

				//
				// int q1 = (int)(.25f*pxCount);
				// int q3 = (int)(.75f*pxCount);

				int q1Val = 0;
				int q2Val = 0;
				int q3Val = 0;

				for (int i = 0; i < 256; i++) {
					accum += valDist[i];

					if (accum < q1) {
						q1Val = i + 1;
					}
					if (accum < q2) {
						q2Val = i + 1;
					}

					if (accum < q3) {
						q3Val = i + 1;
					}

				}
				System.out.println("   q1 " + q1Val + "   q3 " + q3Val
						+ "   MED " + q2Val);

				float span = 255f / (float) (q3Val - q1Val);

				if (span > expansionLimit)
					span = expansionLimit;

				// System.out.println("SPAN "+span);
				// alter values

				int medSpan = 50;
				int medNudge = 128 - q2Val;
				float medNudgeF = .5f - ((float) q2Val / 255f);

				// for (int wc=0; wc<w/channels; wc++){
				for (int x = wc * channels; x < wc * channels + channels; x++) {
					for (int y = hc * scanlines; y < hc * scanlines + scanlines; y++) {

						if (x < w && y < h) {

							int val1 = (int) ((data[x][y] + medNudge) * 1.0);

							int val6 = data[x][y] - q1Val; // translate to
							// origin
							val6 = (int) ((float) val6 * (span));
							val6 += medNudge;

							int val2 = (int) (((float) data[x][y]) * span);
							int val3 = 0;

							int val = val2;

							if (q2Val > 50) {
								val = data[x][y]; // if bright, set to original

							}
							// val = (val+data[WC.X][WC.Y])/2; // average EQ'd
							// val and
							// original
							if (val > 255)
								val = 255;
							if (val < 0)
								val = 0;

							int rgba = (val << 24) | (val << 16) | (val << 8)
									| val;

							b.setRGB(x, y, rgba);

						}
					}
				}
			}
		}

	}

	public void dynContrastImage(ArrayList wfl, int a, int b,
			ArrayList paramList) {

		System.out.println(threadIndentStr + "DYNAMIC CONTRAST " + a + "-" + b);

		int inputSrc = (Integer) paramList.get(0);
		int mode = WC.THREAD_CONTRAST;

		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int w = maxX - minX;
		int h = maxY - minY;

		float expansionLimit = 10.5f;

		for (int i = a; i < b; i++) {
			WITFrame wfi = (WITFrame) wfl.get(i);

			if (wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE
					&& wfi.layerStatus[mode] == WC.STATUS_READY) { // expensive
				// to
				// double-compute

				wfi.layerStatus[mode] = WC.STATUS_WORKING;

				int tileAreaX = 10;
				int tileAreaY = 10;


				wfi.layerOffet[mode][WC.X] = minX;
				wfi.layerOffet[mode][WC.Y] = minY;

				for (int x = 0; x < w / tileAreaX; x++) {
					for (int y = 0; y < h / tileAreaY; y++) {

						int offX = x * tileAreaX;
						int offY = y * tileAreaY;
						int valDist[] = new int[256]; // clamped bins
						int data[][] = new int[tileAreaX][tileAreaY];
						int pxCount = 0;
						for (int wc = 0; wc < tileAreaX; wc++) {
							for (int hc = 0; hc < tileAreaY; hc++) {

								int srcX = offX + wc + minX;
								int srcY = offY + hc + minY;
								data[wc][hc] = wfi.hdrValsRaw[srcX][srcY];// was
								// final

								// TODO - change to raster input option?

								int binID = data[wc][hc];
								binID = validate8bitVal(binID);// clamp
								valDist[binID]++;

								pxCount++;
							}
						}

						// local statistics obtained...

						int accum = 0;
						int q1 = (int) (.1f * (float) pxCount);
						int q2 = (int) (.5f * (float) pxCount);
						int q3 = (int) (.9f * (float) pxCount);

						int q1Val = 0;
						int q2Val = 0;
						int q3Val = 0;

						for (int v = 0; v < 256; v++) {
							accum += valDist[v];

							if (accum < q1) {
								q1Val = v + 1;
							}
							if (accum < q2) {
								q2Val = v + 1;
							}

							if (accum < q3) {
								q3Val = v + 1;
							}

						}
						float span = 255f / (float) (q3Val - q1Val);

						if (span > expansionLimit)
							span = expansionLimit;

						for (int wc = 0; wc < tileAreaX; wc++) {
							for (int hc = 0; hc < tileAreaY; hc++) {

								int dstX = offX + wc;
								int dstY = offY + hc;

								int val = (int) (((float) data[wc][hc] - q1Val) * span);

								val = validate8bitVal(val);

								int rgba = (val << 24) | (val << 16)
										| (val << 8) | val;

							}
						}
						// end tile
					}

				}

				wfi.layerStatus[mode] = WC.STATUS_COMPLETE; // end frame
			}
		}
	}

	// intercept and pass to various contrast methods
	public void wrapperContrastImage(ArrayList wfl, int a, int b,
			ArrayList paramList) {
		int contrastMode = (Integer) paramList.get(7);
		// int scaID = ((WITFrame)wfl.get(a)).scaOriginator;

		if (contrastMode == WC.CONTRAST_AUTO) {
			autoContrastImage(wfl, a, b, paramList);
		} else if (contrastMode == WC.CONTRAST_WINDOW) {

			dynContrastImage(wfl, a, b, paramList);
		} else if (contrastMode == WC.CONTRAST_USER) {

			userContrastImage(wfl, a, b, paramList);
		}
		
		//oclMath(wfl, a, b, paramList);
	}

	public static void initStripeBiasCorrections() {

	}

	public void userContrastImageColor(ArrayList wfl, int a, int b,
			ArrayList paramList) {

		Random r = new Random();
		int procID = r.nextInt();

		int inputSrc = (Integer) paramList.get(0);

		// bounding region
		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);

		int userMinIntensity = (Integer) paramList.get(8);
		int userMaxIntensity = (Integer) paramList.get(9);

		initStripeBiasCorrections();

		ArrayList userControlPoints = (ArrayList) paramList.get(10);

		ArrayList completeCP = new ArrayList();

		UserContrastCP u1 = new UserContrastCP();
		u1.intensity = userMinIntensity;
		u1.rasterIntensity = 0;

		UserContrastCP u2 = new UserContrastCP();
		u2.intensity = userMaxIntensity;
		u2.rasterIntensity = 255 * 2;

		completeCP.add(u1);
		for (int i = 0; i < userControlPoints.size(); i++) {
			UserContrastCP ux = (UserContrastCP) userControlPoints.get(i);
			completeCP.add(ux);
		}
		completeCP.add(u2);

		int w = maxX - minX;
		int h = maxY - minY;

		int baseIntensities[] = new int[completeCP.size() + 1];
		int ceilIntensities[] = new int[completeCP.size() + 1];
		int baseRasterIntensities[] = new int[completeCP.size() + 1];
		int ceilRasterIntensities[] = new int[completeCP.size() + 1];
		float scaleIntensities[] = new float[completeCP.size() + 1];
		int binMap[] = new int[WITFrame.histBins];

		int lastBinIndex = completeCP.size() - 1;
		// lower vals
		for (int j = 0; j < userMinIntensity; j++) {
			binMap[j] = 0;
		}
		// upper vals
		for (int j = userMaxIntensity; j < WITFrame.histBins; j++) {
			binMap[j] = lastBinIndex;
		}

		for (int i = 0; i < binMap.length; i++) {
			// binMap[i]=
		}

		UserContrastCP cpf = (UserContrastCP) completeCP.get(lastBinIndex);
		baseIntensities[lastBinIndex] = 0;// cpf.intensity;
		ceilIntensities[lastBinIndex] = 255;// cpf.intensity;
		scaleIntensities[lastBinIndex] = 1.0f;
		for (int j = 0; j < WITFrame.histBins; j++) {
			// for (int j=cpf.intensity; j<WITFrame.histBins; j++){
			binMap[j] = lastBinIndex;
		}

		for (int i = 0; i < completeCP.size() - 1; i++) {
			UserContrastCP cp1 = (UserContrastCP) completeCP.get(i);
			UserContrastCP cp2 = (UserContrastCP) completeCP.get(i + 1);

			baseIntensities[i] = cp1.intensity;
			ceilIntensities[i] = cp2.intensity;
			baseRasterIntensities[i] = cp1.rasterIntensity * 2;
			ceilRasterIntensities[i] = cp2.rasterIntensity * 2;
			float diffInput = (float) (ceilIntensities[i] - baseIntensities[i]);
			float diffOutput = (float) (ceilRasterIntensities[i] - baseRasterIntensities[i]);

			scaleIntensities[i] = (float) (diffOutput / diffInput);

			for (int j = baseIntensities[i]; j <= ceilIntensities[i]; j++) {
				binMap[j] = i;
			}
		}

		int mode = WC.THREAD_CONTRAST;
		for (int i = a; i < b; i++) {

			WITFrame wfi = (WITFrame) wfl.get(i);

			if (wfi.timeStampSecOfDay >= minT && wfi.timeStampSecOfDay <= maxT) {

				// System.out.println(procID+
				// " CONTRAST EXEC "+minX+" "+maxX+" FRAME "+i+" SCA "+wfi.scaID);
				// System.out.println("CONTRAST SCA "+wfi.scaID+" COORD "+minX+","+maxX+" "+a);

				int bins = wfi.histBins;

				if (wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE
						&& wfi.layerStatus[mode] == WC.STATUS_READY && w > 0
						&& h > 0) { // expensive
					// to
					// double-compute
					wfi.layerStatus[mode] = WC.STATUS_WORKING;
					wfl.set(i, wfi);


					wfi.layerOffet[mode][WC.X] = minX;
					wfi.layerOffet[mode][WC.Y] = minY;

					if (wfi.layerStatus[WC.THREAD_HISTOGRAM] == WC.STATUS_READY) {
						// do histogram
						ArrayList delegateList = new ArrayList();
						delegateList.add(minT);
						delegateList.add(maxT);
						histogramImage(wfl, a, b, delegateList);
					}

					// set raster
					int val = 0;
					int rgba = 0;

					for (int x = 0; x < w - 1; x++) {
						for (int y = 0; y < h - 1; y++) {

							int srcX = minX + x;
							int srcY = minY + y;

							if (srcX >= 0 && srcY >= 0
									&& srcX < wfi.hdrValsRaw.length
									&& srcY < wfi.hdrValsRaw[srcX].length) {
								// if (srcX >=0 && srcY >= 0 && srcX
								// <wfi.biRay[WC.THREAD_LOAD_HDF5R].getWidth()
								// && srcY
								// <wfi.biRay[WC.THREAD_LOAD_HDF5R].getHeight()){

								// int rgba1 =
								// wfi.biRay[WC.THREAD_LOAD_HDF5R].getRGB(srcX,
								// srcY);
								// int val2 = ((rgba1 >> 16) & 0xff);
								int valOrig = wfi.hdrValsRaw[srcX][srcY];

								int val2 = 0;

								int valR = 0;
								int valG = 0;
								int valB = 0;

								if (valOrig < userMinIntensity) {
									val2 = 0;
								} else if (valOrig > userMaxIntensity) {
									val2 = 255 * 2;
								} else {

									val2 = (int) ((float) (valOrig - baseIntensities[binMap[valOrig]]) * scaleIntensities[binMap[valOrig]]);// +
									// baseRasterIntensities[binMap[valOrig]];

									val2 += baseRasterIntensities[binMap[valOrig]];

									if (val2 < 0)
										val2 = 0;
									if (val2 > 255 * 2)
										val2 = 255 * 2;

									valR = val2 / 2 - 255;
									valG = 0;// Math.abs(((val2/2)-255));
									valB = 255 - (val2 / 2);
								}

								rgba = (255 << 24) | (valR << 16) | (valG << 8)
										| valB;
							
							}
						}
					}

					wfi.layerStatus[mode] = WC.STATUS_COMPLETE;

				}

				wfl.set(i, wfi);
			}
		}

	}

	public void userContrastImage(ArrayList wfl, int a, int b,
			ArrayList paramList) {

		Random r = new Random();
		int procID = r.nextInt();

		int inputSrc = (Integer) paramList.get(0);

		// bounding region
		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);

		int userMinIntensity = (Integer) paramList.get(8);
		int userMaxIntensity = (Integer) paramList.get(9);

		initStripeBiasCorrections();

		ArrayList userControlPoints = (ArrayList) paramList.get(10);

		ArrayList completeCP = new ArrayList();

		UserContrastCP u1 = new UserContrastCP();
		u1.intensity = userMinIntensity;
		u1.rasterIntensity = 0;

		UserContrastCP u2 = new UserContrastCP();
		u2.intensity = userMaxIntensity;
		u2.rasterIntensity = 255;

		completeCP.add(u1);
		for (int i = 0; i < userControlPoints.size(); i++) {
			UserContrastCP ux = (UserContrastCP) userControlPoints.get(i);
			completeCP.add(ux);
		}
		completeCP.add(u2);

		int w = maxX - minX;
		int h = maxY - minY;

		int baseIntensities[] = new int[completeCP.size() + 1];
		int ceilIntensities[] = new int[completeCP.size() + 1];
		int baseRasterIntensities[] = new int[completeCP.size() + 1];
		int ceilRasterIntensities[] = new int[completeCP.size() + 1];
		float scaleIntensities[] = new float[completeCP.size() + 1];
		int binMap[] = new int[WITFrame.histBins];

		int lastBinIndex = completeCP.size() - 1;
		// lower vals
		for (int j = 0; j < userMinIntensity; j++) {
			binMap[j] = 0;
		}
		// upper vals
		for (int j = userMaxIntensity; j < WITFrame.histBins; j++) {
			binMap[j] = lastBinIndex;
		}

		for (int i = 0; i < binMap.length; i++) {
			// binMap[i]=
		}

		UserContrastCP cpf = (UserContrastCP) completeCP.get(lastBinIndex);
		baseIntensities[lastBinIndex] = 0;// cpf.intensity;
		ceilIntensities[lastBinIndex] = 255;// cpf.intensity;
		scaleIntensities[lastBinIndex] = 1.0f;
		for (int j = 0; j < WITFrame.histBins; j++) {
			// for (int j=cpf.intensity; j<WITFrame.histBins; j++){
			binMap[j] = lastBinIndex;
		}

		for (int i = 0; i < completeCP.size() - 1; i++) {
			UserContrastCP cp1 = (UserContrastCP) completeCP.get(i);
			UserContrastCP cp2 = (UserContrastCP) completeCP.get(i + 1);

			baseIntensities[i] = cp1.intensity;
			ceilIntensities[i] = cp2.intensity;
			baseRasterIntensities[i] = cp1.rasterIntensity;
			ceilRasterIntensities[i] = cp2.rasterIntensity;
			float diffInput = (float) (ceilIntensities[i] - baseIntensities[i]);
			float diffOutput = (float) (ceilRasterIntensities[i] - baseRasterIntensities[i]);

			scaleIntensities[i] = (float) (diffOutput / diffInput);

			for (int j = baseIntensities[i]; j <= ceilIntensities[i]; j++) {
				binMap[j] = i;
			}
		}

		int mode = WC.THREAD_CONTRAST;
		for (int i = a; i < b; i++) {

			WITFrame wfi = (WITFrame) wfl.get(i);

			if (wfi.timeStampSecOfDay >= minT && wfi.timeStampSecOfDay <= maxT) {

				// System.out.println(procID+
				// " CONTRAST EXEC "+minX+" "+maxX+" FRAME "+i+" SCA "+wfi.scaID);
				// System.out.println("CONTRAST SCA "+wfi.scaID+" COORD "+minX+","+maxX+" "+a);

				int bins = wfi.histBins;

				if (wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE
						&& wfi.layerStatus[mode] == WC.STATUS_READY && w > 0
						&& h > 0) { // expensive
					// to
					// double-compute
					wfi.layerStatus[mode] = WC.STATUS_WORKING;
					wfl.set(i, wfi);


					wfi.layerOffet[mode][WC.X] = minX;
					wfi.layerOffet[mode][WC.Y] = minY;

					if (wfi.layerStatus[WC.THREAD_HISTOGRAM] == WC.STATUS_READY) {
						// do histogram
						ArrayList delegateList = new ArrayList();
						delegateList.add(minT);
						delegateList.add(maxT);
						histogramImage(wfl, a, b, delegateList);
					}

					// set raster
					int val = 0;
					int rgba = 0;

					for (int x = 0; x < w - 1; x++) {
						for (int y = 0; y < h - 1; y++) {

							int srcX = minX + x;
							int srcY = minY + y;

							if (srcX >= 0 && srcY >= 0
									&& srcX < wfi.hdrValsRaw.length
									&& srcY < wfi.hdrValsRaw[srcX].length) {
								// if (srcX >=0 && srcY >= 0 && srcX
								// <wfi.biRay[WC.THREAD_LOAD_HDF5R].getWidth()
								// && srcY
								// <wfi.biRay[WC.THREAD_LOAD_HDF5R].getHeight()){

								// int rgba1 =
								// wfi.biRay[WC.THREAD_LOAD_HDF5R].getRGB(srcX,
								// srcY);
								// int val2 = ((rgba1 >> 16) & 0xff);
								int valOrig = wfi.hdrValsRaw[srcX][srcY];

								int val2 = 0;

								if (valOrig < userMinIntensity) {
									val2 = 0;
								} else if (valOrig > userMaxIntensity) {
									val2 = 255;
								} else {

									val2 = (int) ((float) (valOrig - baseIntensities[binMap[valOrig]]) * scaleIntensities[binMap[valOrig]]);// +
									// baseRasterIntensities[binMap[valOrig]];

									val2 += baseRasterIntensities[binMap[valOrig]];

									if (val2 < 0)
										val2 = 0;
									if (val2 > 255)
										val2 = 255;
								}

								rgba = (255 << 24) | (val2 << 16) | (val2 << 8)
										| val2;
							
							}
						}
					}

					wfi.layerStatus[mode] = WC.STATUS_COMPLETE;

				}

				wfl.set(i, wfi);
			}
		}

	}

	public void autoContrastImage(ArrayList wfl, int a, int b,
			ArrayList paramList) {

		System.out.println(threadIndentStr + "AUTO DYNAMIC CONTRAST " + a + "-"
				+ b);

		int inputSrc = (Integer) paramList.get(0);

		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);

		int w = maxX - minX;
		int h = maxY - minY;

		// int userLowerBound = 100;
		// int userUpperBound = 50;
		// int userMidPoint = 0;

		int mode = WC.THREAD_CONTRAST;
		for (int i = a; i < b; i++) {

			WITFrame wfi = (WITFrame) wfl.get(i);

			if (wfi.timeStampSecOfDay >= minT && wfi.timeStampSecOfDay <= maxT) {
				if (wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE
						&& wfi.layerStatus[mode] == WC.STATUS_READY) { // expensive
					// to
					// double-compute
					wfi.layerStatus[mode] = WC.STATUS_WORKING;

					wfi.layerOffet[mode][WC.X] = minX;
					wfi.layerOffet[mode][WC.Y] = minY;

					if (wfi.layerStatus[WC.THREAD_HISTOGRAM] != WC.STATUS_COMPLETE) {
						// do histogram
						histogramImage(wfl, a, b, null);
					}

					int minSpan = 0;
					int maxSpan = 0;

					// set raster
					int val = 0;
					int rgba = 0;

					int tileX = 20;
					int tileY = 20;

					int localMax = 0;
					int localMin = 0;

					int localSearchSize = 7;

					for (int x = 0; x < w - 1; x++) {
						for (int y = 0; y < h - 1; y++) {
							int deltaMedian = 128 - wfi.histStats[WC.STATS_Q2];

							int srcX = minX + x;
							int srcY = minY + y;

							float span = localMax - localMin;

							val = (int) wfi.hdrValsRaw[srcX][srcY] - localMin;

							float multiplier = 255f / span;
							if (multiplier > 80)
								multiplier = 80;
							val *= multiplier;

							if (val < 0)
								val = 0;
							if (val > 255)
								val = 255;

							rgba = (255 << 24) | (val << 16) | (val << 8) | val;

						}
					}

					wfi.layerStatus[mode] = WC.STATUS_COMPLETE;
				}
			}
		}

	}

	// use the current raster data, then trigger the use of HDR data
	public void interactiveContrast() {

	}

	public void histogramImage(ArrayList wfl, int a, int b, ArrayList paramList) {

		System.out.println("HISTOGRAM STARTED");
		int inputSrc = WC.THREAD_LOAD_HDF5R;
		int mode = WC.THREAD_HISTOGRAM;

		int minT = (Integer) paramList.get(0);
		int maxT = (Integer) paramList.get(1);

		for (int i = a; i < b; i++) {

			WITFrame wfi = (WITFrame) wfl.get(i);

			if (wfi.timeStampSecOfDay >= minT && wfi.timeStampSecOfDay <= maxT) {

				int w = wfi.width;
				int h = wfi.height;

				if (wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE
						&& wfi.layerStatus[mode] != WC.STATUS_COMPLETE) {
					wfi.layerStatus[mode] = WC.STATUS_WORKING;

					// int bins = (int) Math.pow(2, 11) - 1; // 2047
					//int bins = (int) Math.pow(2, 14) - 1; // 65535
					int bins = WC.CONTRAST_UI_HARD_LIMIT; // 65535
					// int bins = (int) Math.pow(2, 8) - 1;

					int[] valDist = new int[bins]; // bins for contrast - clamp
					// dynamic range

					int totalPix = 0;

					// System.out.println("size "+tf[i].hdrValsRaw.length+
					// " "+tf[i].hdrValsRaw[0].length);
					for (int x = 0; x < w - 1; x++) {
						for (int y = 0; y < h - 1; y++) {
							int binID = 0;

							binID = wfi.hdrValsRaw[x][y];
							if (binID >= bins) {
								binID = bins - 1;

							}
							if (binID == WC.INVALID_DATA_MASK || binID < 0) { // don't
								// contribute
								// to
								// any
								// bin,
								// we're
								// using
								// -99999
								// to
								// key
								// empty
								// regions

								binID = 0; // error pix
							} else {

								totalPix++;
								valDist[binID]++;
							}

						}
					}

					wfi.histogram = new int[bins];
					for (int m = 0; m < bins; m++) {
						wfi.histogram[m] = valDist[m];
					}

					// stats
					int accum = 0;

					// int totalPix = tf[i].totalPixels;

					for (int m = 0; m < wfi.histogram.length; m++) {

						// determine which bins correspond to quartiles
						accum += wfi.histogram[m];
						if (accum <= .25 * totalPix) {
							wfi.histStats[WC.STATS_Q1] = m;
						}
						if (accum <= .5 * totalPix) {
							wfi.histStats[WC.STATS_Q2] = m;
						}
						if (accum <= .75 * totalPix) {
							wfi.histStats[WC.STATS_Q3] = m;
						}
					}
					// end stats

					// min/max for rendering

					int maxVal = -1;
					int minVal = Integer.MAX_VALUE;
					for (int m = 0; m < bins; m++) {
						if (wfi.histogram[m] > maxVal) {
							maxVal = wfi.histogram[m];
						}
						if (wfi.histogram[m] < minVal) {
							minVal = wfi.histogram[m];
						}
					}
					wfi.histStats[WC.STATS_MIN_BIN] = minVal;
					wfi.histStats[WC.STATS_MAX_BIN] = maxVal;

					wfi.layerStatus[mode] = WC.STATUS_COMPLETE;

					// new 12.1

					wfl.set(i, wfi);
				}
			}
		}
	}

	public WITFrame histogramSingleBiInc(WITFrame wfi) {

		//System.out.println("HISTOGRAM SingleBiInc STARTED");
		int inputSrc = WC.THREAD_LOAD_HDF5R;
		int mode = WC.THREAD_HISTOGRAM;

	
				int w = wfi.width;
				int h = wfi.height;

		

					// int bins = (int) Math.pow(2, 11) - 1; // 2047
					int bins = WC.CONTRAST_UI_HARD_LIMIT;
					// int bins = (int) Math.pow(2, 8) - 1;

					int[] valDist = new int[bins]; // bins for contrast - clamp
					// dynamic range

					int totalPix = 0;

					// System.out.println("size "+tf[i].hdrValsRaw.length+
					// " "+tf[i].hdrValsRaw[0].length);
					for (int x = 0; x < w - 1; x++) {
						for (int y = 0; y < h - 1; y++) {
							int binID = 0;

							binID = wfi.hdrValsRaw[x][y];
							//binID = wfi.hdrValsRaw[x][y];
							if (binID >= bins) {
								binID = bins - 1;

							}
							if (binID == WC.INVALID_DATA_MASK || binID < 0) { // don't
								// contribute
								// to
								// any
								// bin,
								// we're
								// using
								// -99999
								// to
								// key
								// empty
								// regions

								binID = 0; // error pix
							} else {

								totalPix++;
								valDist[binID]++;
							}

						}
					}

					
					for (int m = 0; m < bins; m++) {
						wfi.histogram[m] += valDist[m];
					}

					// stats
					int accum = 0;
					int accumPrev =0;
					// int totalPix = tf[i].totalPixels;

					for (int m = 0; m < wfi.histogram.length; m++) {

						// determine which bins correspond to quartiles
						accumPrev = accum;
						accum += wfi.histogram[m];
						if (accumPrev == 0 && accum >0) {
							wfi.histStats[WC.STATS_MIN] = m;
						}
						if (accum <= .25 * totalPix) {
							wfi.histStats[WC.STATS_Q1] = m;
						}
						if (accum <= .5 * totalPix) {
							wfi.histStats[WC.STATS_Q2] = m;
						}
						if (accum <= .75 * totalPix) {
							wfi.histStats[WC.STATS_Q3] = m;
						}
						if (m>=1 && wfi.histogram[m] == 0 && wfi.histogram[m-1]>0) {
							wfi.histStats[WC.STATS_MAX] = m-1;
						}
					}
				// end stats

					// min/max for rendering

					int maxVal = -1;
					int minVal = Integer.MAX_VALUE;
					for (int m = 0; m < bins; m++) {
						if (wfi.histogram[m] > maxVal) {
							maxVal = wfi.histogram[m];
						}
						if (wfi.histogram[m] < minVal) {
							minVal = wfi.histogram[m];
						}
					}
					wfi.histStats[WC.STATS_MIN_BIN] = minVal;
					wfi.histStats[WC.STATS_MAX_BIN] = maxVal;

					//wfi.layerStatus[mode] = WC.STATUS_COMPLETE;

					// new 12.1

				
				return wfi;
	}

	// different for products versus processing
	public String opIDtoName(int op) {
		String opStr = "[UNKNOWN_OP]";

		if (op == WC.THREAD_LOAD) {
			opStr = "RAW";
		} else if (op == WC.THREAD_LOAD_HDF5R) {

			opStr = "RAW";
		} else if (op == WC.THREAD_HISTOGRAM) {

			opStr = "HISTOGRAM";
		} else if (op == WC.THREAD_CONTRAST) {

			opStr = "CONTRAST";

		} else if (op == WC.THREAD_DIFF) {

			opStr = "DIFFS";
		} else if (op == WC.THREAD_TIMELAPSE) {

			opStr = "TIMELAPSE";
		} else if (op == WC.THREAD_TEMPORAL) {

			opStr = "TEMPORAL1";
		} else if (op == WC.THREAD_REGISTRATION) {

			opStr = "REGISTRATION";
		}

		return opStr;
	}

	public WITFrame prepFrameGPU(WITFrame w, int layer, int sca) {
		// WITFrame tempFrame = w;
		// interpolate geolocation

		w = interpolateLonLatFrame((WITFrame) w);

		return w;

	}

	public int adjustContrastCurvePixel(int inputIntensity, ArrayList paramList) {
		int finalIntensity = 0;

		int userMinIntensity = (Integer) paramList.get(0); // 6
		int userMaxIntensity = (Integer) paramList.get(1); // 7

		ArrayList userControlPoints = (ArrayList) paramList.get(2); // 8

		ArrayList completeCP = new ArrayList();

		UserContrastCP u1 = new UserContrastCP();
		u1.intensity = userMinIntensity;
		u1.rasterIntensity = 0;

		UserContrastCP u2 = new UserContrastCP();
		u2.intensity = userMaxIntensity;
		u2.rasterIntensity = 255;

		completeCP.add(u1);
		for (int i = 0; i < userControlPoints.size(); i++) {
			UserContrastCP ux = (UserContrastCP) userControlPoints.get(i);
			completeCP.add(ux);
		}
		completeCP.add(u2);

		int baseIntensities[] = new int[completeCP.size() + 1];
		int ceilIntensities[] = new int[completeCP.size() + 1];
		int baseRasterIntensities[] = new int[completeCP.size() + 1];
		int ceilRasterIntensities[] = new int[completeCP.size() + 1];
		float scaleIntensities[] = new float[completeCP.size() + 1];
		int binMap[] = new int[WITFrame.histBins];

		int lastBinIndex = completeCP.size() - 1;
		// lower vals
		for (int j = 0; j < userMinIntensity; j++) {
			binMap[j] = 0;
		}
		// upper vals
		for (int j = userMaxIntensity; j < WITFrame.histBins; j++) {
			binMap[j] = lastBinIndex;
		}

		UserContrastCP cpf = (UserContrastCP) completeCP.get(lastBinIndex);
		baseIntensities[lastBinIndex] = 0;// cpf.intensity;
		ceilIntensities[lastBinIndex] = 255;// cpf.intensity;
		scaleIntensities[lastBinIndex] = 1.0f;
		for (int j = 0; j < WITFrame.histBins; j++) {
			// for (int j=cpf.intensity; j<WITFrame.histBins; j++){
			binMap[j] = lastBinIndex;
		}

		for (int i = 0; i < completeCP.size() - 1; i++) {
			UserContrastCP cp1 = (UserContrastCP) completeCP.get(i);
			UserContrastCP cp2 = (UserContrastCP) completeCP.get(i + 1);

			baseIntensities[i] = cp1.intensity;
			ceilIntensities[i] = cp2.intensity;
			baseRasterIntensities[i] = cp1.rasterIntensity;
			ceilRasterIntensities[i] = cp2.rasterIntensity;
			// scaleIntensities[i] =
			// (float)(ceilIntensities[i]-baseIntensities[i])/(float)(cp2.rasterIntensity-cp1.rasterIntensity);
			float diffInput = (float) (ceilIntensities[i] - baseIntensities[i]);
			float diffOutput = (float) (ceilRasterIntensities[i] - baseRasterIntensities[i]);
			// if (diffIntensities == 0){
			// diffIntensities = .01f;
			// }

			scaleIntensities[i] = (float) (diffOutput / diffInput);

			// need to map the difference between input intensities to raster
			// range

			for (int j = baseIntensities[i]; j <= ceilIntensities[i]; j++) {
				binMap[j] = i;
			}

			// System.out.println("FILTER CP "+i+" INPUT "+baseIntensities[i]+"-"+ceilIntensities[i]+" OUTPUT "+baseRasterIntensities[i]+"-"+ceilRasterIntensities[i]+" scale "+scaleIntensities[i]);
		}

		int valOrig = inputIntensity;

		int val2 = 0;

		val2 = (int) ((float) (valOrig - baseIntensities[binMap[valOrig]]) * scaleIntensities[binMap[valOrig]]);

		val2 += baseRasterIntensities[binMap[valOrig]];

		if (val2 < 0)
			val2 = 0;
		if (val2 > 255)
			val2 = 255;

		finalIntensity = val2;
		return finalIntensity;
	}
	
	public void oclMath(ArrayList wfl, int a, int b, ArrayList paramList) {

		Random r = new Random();
		int procID = r.nextInt();
		int inputSrc = (Integer) paramList.get(0);

		int minT = (Integer) paramList.get(1);
		int maxT = (Integer) paramList.get(2);
		int framesPerOclDispatch = (Integer) paramList.get(3);
		
		int framesToSum = (Integer) paramList.get(4);
		
		int scanExportMode = (Integer) paramList.get(5);
		seqIndexMask = (int[][]) paramList.get(6);
		
		int searchWindow = 2;
		int searchWindowDiff = 10;
		
	// set up (uses default CLPlatform and creates context for all devices)
    CLContext context = CLContext.create();
    
    CLDevice device = context.getMaxFlopsDevice();
    

    // create command queue on device.
    CLCommandQueue queue = device.createCommandQueue();

    
    try{
        
    	 if (wfl.size()>1){
    		 String summaryStr = "";
    		 String summaryEndStr = "";
    
    		 long time = nanoTime();
    		 
    		 int dispatchCount=0;

    		 int lastSumRayIndex =0;

    		 WITFrame[] wfSumRay = new WITFrame[framesToSum];
    		 
    			for (int i = a; i < b; i++) {
    				
    				WITFrame tempFrame = (WITFrame)wfl.get(i);
    				int tempTime = tempFrame.timeStampSecOfDay;
    				
    				int index = i;
    				
    				if (index != -1){
 						wfSumRay[0] = (WITFrame)wfl.get(index);
 						

    					 if (wfSumRay[0].layerStatus[inputSrc] == WC.STATUS_COMPLETE && wfSumRay[0].layerStatus[mode] != WC.STATUS_COMPLETE){
    						 
    						 wfSumRay[0].layerStatus[mode] = WC.STATUS_WORKING;
    		                 
    		                 wfl.set(index, wfSumRay[0]);
    					 
    					
    		                 if (dispatchCount == 0){
    		            		 summaryStr = " SCA: "+wfSumRay[0].scaID+ " FRAMES: "+index;
    		            		 
    		            		 out.println("     using "+device+ " for task on "+summaryStr+"-["+(index+framesPerOclDispatch-1)+"]");
    		            	 }
    		            	 
    		            		
    						
    						lastSumRayIndex=1;
    						
    						int nudge = -1;
    						for (int sumIndex=1; sumIndex<framesToSum; sumIndex++){
    						int index2 = getIndexFromTime(i + nudge, searchWindowDiff, wfl, wfSumRay[0].scanDirection);

    						while (index2 == index && index2 < wfl.size() && index2 != -1) {
    							nudge--;
    							index2 = getIndexFromTime(i + nudge, searchWindowDiff, wfl,
    									wfSumRay[0].scanDirection);
    							
    						}
    						if (index2 != -1 && index2 < wfl.size()) {
    							
    							wfSumRay[sumIndex] = (WITFrame)wfl.get(index2);
    							lastSumRayIndex++;
    						}
    						
    						}
    						
                 
            	
             System.out.println("          ENQUEUE OPENCL COMMANDS FOR SCA: "+wfSumRay[0].scaID+ " - FRAME: "+index+" - TIMESTAMP: "+wfSumRay[0].timeStampStr);

             
             
        // select fastest device
        

        int elementCount = wfSumRay[0].width*wfSumRay[0].height;                     // Length of arrays to process
        //int elementCount = 1444477;                                // Length of arrays to process
        
       // System.out.println(" WG SIZE "+device.getMaxWorkGroupSize());
        int localWorkSize = min(device.getMaxWorkGroupSize(), 256);  // Local work size dimensions
        int globalWorkSize = roundUp(localWorkSize, elementCount);   // rounded up to the nearest multiple of the localWorkSize

        // load sources, create and build program
        CLProgram program = context.createProgram(ImProcThread.class.getResourceAsStream("VectorAdd.cl")).build();

        // A, B are input buffers, C is for the result
       // CLBuffer<FloatBuffer> clBufferRay[];// = new clBuffer[lastPopulatedIndex+1];
        
        //CLBuffer<FloatBuffer> clBufferRay = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferA = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS1 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS2 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        /*
        CLBuffer<FloatBuffer> clBufferS3 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS4 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS5 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS6 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS7 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS8 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS9 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS10 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS11 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS12 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS13 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS14 = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferS15 = context.createFloatBuffer(globalWorkSize, READ_ONLY);*/
        
        CLBuffer<FloatBuffer> clBufferSR = context.createFloatBuffer(globalWorkSize, WRITE_ONLY);
        
        for (int wf=0; wf<3; wf++){
            //for (int wf=0; wf<lastSumRayIndex; wf++){
        	if (wf == 0){
        		fillBufferPixelData(clBufferA.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 1){
        		fillBufferPixelData(clBufferS1.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 2){
        		fillBufferPixelData(clBufferS2.getBuffer(), wfSumRay[wf], inputSrc);
        	}/* else if (wf == 3){
        		fillBufferPixelData(clBufferS3.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 4){
        		fillBufferPixelData(clBufferS4.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 5){
        		fillBufferPixelData(clBufferS5.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 6){
        		fillBufferPixelData(clBufferS6.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 7){
        		fillBufferPixelData(clBufferS7.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 8){
        		fillBufferPixelData(clBufferS8.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 9){
        		fillBufferPixelData(clBufferS9.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 10){
        		fillBufferPixelData(clBufferS10.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 11){
        		fillBufferPixelData(clBufferS11.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 12){
        		fillBufferPixelData(clBufferS12.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 13){
        		fillBufferPixelData(clBufferS13.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 14){
        		fillBufferPixelData(clBufferS14.getBuffer(), wfSumRay[wf], inputSrc);
        	} else if (wf == 15){
        		fillBufferPixelData(clBufferS15.getBuffer(), wfSumRay[wf], inputSrc);
        	} */
        }
        
        
        //out.println("used device memory: "+ (clBufferA.getCLSize()+clBufferB.getCLSize()+clBufferC.getCLSize())/1000000 +"MB");

        // fill input buffers with random numbers
        // (just to have test data; seed is fixed -> results will not change between runs).
        
       
        
        //fillBuffer(clBufferA.getBuffer(), 12345);
        //fillBuffer(clBufferB.getBuffer(), 67890);

        // get a reference to the kernel function with the name 'VectorAdd'
        // and map the buffers to its input parameters.
        CLKernel kernel = program.createCLKernel("VectorAdd");
        kernel.putArgs(clBufferA, clBufferS1, clBufferS2, clBufferSR).putArg(elementCount);
// kernel.putArgs(clBufferA, clBufferS1, clBufferS2, clBufferS3, clBufferS4, clBufferS5, clBufferS6, clBufferS7, clBufferS8, clBufferS9, clBufferS10, clBufferS11, clBufferS12, clBufferS13, clBufferS14, clBufferS15, clBufferSR).putArg(elementCount);

        // asynchronous write of data to GPU device,
        // followed by blocking read to get the computed results back.
        
        queue.putWriteBuffer(clBufferA, false)
             .putWriteBuffer(clBufferS1, false)
             .putWriteBuffer(clBufferS2, false)
             .put1DRangeKernel(kernel, 0, globalWorkSize, localWorkSize)
             .putReadBuffer(clBufferSR, true);
        
        /*
         *     queue.putWriteBuffer(clBufferA, false)
             .putWriteBuffer(clBufferS1, false)
             .putWriteBuffer(clBufferS2, false)
             .putWriteBuffer(clBufferS3, false)
             .putWriteBuffer(clBufferS4, false)
             .putWriteBuffer(clBufferS5, false)
             .putWriteBuffer(clBufferS6, false)
             .putWriteBuffer(clBufferS7, false)
             .putWriteBuffer(clBufferS8, false)
             .putWriteBuffer(clBufferS9, false)
             .putWriteBuffer(clBufferS10, false)
             .putWriteBuffer(clBufferS11, false)
             .putWriteBuffer(clBufferS12, false)
             .putWriteBuffer(clBufferS13, false)
             .putWriteBuffer(clBufferS14, false)
             .putWriteBuffer(clBufferS15, false)
             .put1DRangeKernel(kernel, 0, globalWorkSize, localWorkSize)
             .putReadBuffer(clBufferSR, true);
         */
        
        
        int width = wfSumRay[0].width;
        int height = wfSumRay[0].height;
        
        wfSumRay[0].hdrValsClResults = new short[width][height];
        
        readBufferPixelData(clBufferSR.getBuffer(), wfSumRay[0], mode);

        // copy results to WITFrame
        
        updateFrameTileTextureDataFromClResults(wfSumRay[0]);
        
        // write the results back to the frames
        wfSumRay[0].layerStatus[mode] = WC.STATUS_COMPLETE;
        
        wfl.set(index, wfSumRay[0]);
        
    			}
             }
    	//}
    		 }
    		 time = nanoTime() - time;
    	     
    		 out.println("     computation took: "+(time/1000000)+"ms - "+summaryStr+summaryEndStr);
    		 
    		// this.threadStatus = WC.THREAD_STATUS_COMPLETE;
    	 }
    		 
    	 
    } catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
		// replace frame for second try
	
	} finally{
        // cleanup all resources associated with this context.
        context.release();
    }

}
	
	
private void readBufferPixelData(FloatBuffer buffer, WITFrame wf, int outputMode) {
		
		int pxIndex =0;
		float restoreScaleFactor = (float)Short.MAX_VALUE;
					
		if (wf.hdrValsClResults != null){
							
			for (int y=0; y<wf.height; y++){
				for (int x=0; x<wf.width; x++){
				
					if(buffer.remaining() != 0 && pxIndex<buffer.limit()){	
						float result = buffer.get(pxIndex);
										
						 
						short val = (short)(result*restoreScaleFactor);
						
										
						wf.hdrValsClResults[x][y] = val;
									
						pxIndex++;
					
					}
				}
			}
		}
		
	}
	
	private void fillBufferPixelData(FloatBuffer buffer, WITFrame wf, int inputMode) {
	    //Random rnd = new Random(seed);
		
		int pxIndex =0;
		
			if (wf!=null){
						
				if(wf.hdrValsRaw != null){
					if (wf.layerStatus[inputMode] == WC.STATUS_COMPLETE){
						

						for (int y=0; y<wf.height; y++){
							for (int x=0; x<wf.width; x++){
							
					
								buffer.put((float)wf.hdrValsRaw[x][y]/((float)Short.MAX_VALUE));
			       
						
							}
						}
					}
				}
			}		
	   
	    buffer.rewind();
	}
	
	
	public void oclMathOld(ArrayList wfl, int a, int b, ArrayList paramList) {

		Random r = new Random();
		int procID = r.nextInt();

		int inputSrc = (Integer) paramList.get(0);

		// bounding region
		/*
		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);
		*/

		

		int minT = (Integer) paramList.get(1);
		int maxT = (Integer) paramList.get(2);
		
		//int skipT =  (Integer) paramList.get(3);
		
		int framesPerOclDispatch = (Integer) paramList.get(3);
		
		int framesToSum = (Integer) paramList.get(4);
		
		int scanExportMode = (Integer) paramList.get(5);
		seqIndexMask = (int[][]) paramList.get(6);
		
		int searchWindow = 2;
		int searchWindowDiff = 10;
			

		//int userMinIntensity = (Integer) paramList.get(8);
		//int userMaxIntensity = (Integer) paramList.get(9);
		
	// set up (uses default CLPlatform and creates context for all devices)
    CLContext context = CLContext.create();
    out.println("created "+context);
    
    // always make sure to release the context under all circumstances
    // not needed for this particular sample but recommented
    try{
        
        // select fastest device
        CLDevice device = context.getMaxFlopsDevice();
        out.println("using "+device);

        // create command queue on device.
        CLCommandQueue queue = device.createCommandQueue();

        int elementCount = 1444477;                                  // Length of arrays to process
        int localWorkSize = min(device.getMaxWorkGroupSize(), 256);  // Local work size dimensions
        int globalWorkSize = roundUp(localWorkSize, elementCount);   // rounded up to the nearest multiple of the localWorkSize

        // load sources, create and build program
        CLProgram program = context.createProgram(ImProcThread.class.getResourceAsStream("VectorAdd.cl")).build();

        // A, B are input buffers, C is for the result
        CLBuffer<FloatBuffer> clBufferA = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferB = context.createFloatBuffer(globalWorkSize, READ_ONLY);
        CLBuffer<FloatBuffer> clBufferC = context.createFloatBuffer(globalWorkSize, WRITE_ONLY);

        out.println("used device memory: "
            + (clBufferA.getCLSize()+clBufferB.getCLSize()+clBufferC.getCLSize())/1000000 +"MB");

        // fill input buffers with random numbers
        // (just to have test data; seed is fixed -> results will not change between runs).
        fillBuffer(clBufferA.getBuffer(), 12345);
        fillBuffer(clBufferB.getBuffer(), 67890);

        // get a reference to the kernel function with the name 'VectorAdd'
        // and map the buffers to its input parameters.
        CLKernel kernel = program.createCLKernel("VectorAdd");
        kernel.putArgs(clBufferA, clBufferB, clBufferC).putArg(elementCount);

        // asynchronous write of data to GPU device,
        // followed by blocking read to get the computed results back.
        long time = nanoTime();
        queue.putWriteBuffer(clBufferA, false)
             .putWriteBuffer(clBufferB, false)
             .put1DRangeKernel(kernel, 0, globalWorkSize, localWorkSize)
             .putReadBuffer(clBufferC, true);
        time = nanoTime() - time;

        // print first few elements of the resulting buffer to the console.
        out.println("a+b=c results snapshot: ");
        for(int i = 0; i < 10; i++)
            out.print(clBufferC.getBuffer().get() + ", ");
        out.println("...; " + clBufferC.getBuffer().remaining() + " more");

        out.println("computation took: "+(time/1000000)+"ms");
        
    } catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
        // cleanup all resources associated with this context.
        context.release();
    }

}

private static void fillBuffer(FloatBuffer buffer, int seed) {
    Random rnd = new Random(seed);
    while(buffer.remaining() != 0)
        buffer.put(rnd.nextFloat()*100);
    buffer.rewind();
}

private static int roundUp(int groupSize, int globalSize) {
    int r = globalSize % groupSize;
    if (r == 0) {
        return globalSize;
    } else {
        return globalSize + groupSize - r;
    }
}


	public void applyEQ(BufferedImage b, float expansionLimit) {

		int w = b.getWidth();
		int h = b.getHeight();

		int data[][] = new int[w][h];

		int valDist[] = new int[256];

		int pxCount = 0;

		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int vals[] = new int[4];
				int rgba = b.getRGB(x, y);
				// vals[WC.A] += ((rgba >> 24) & 0xff);
				vals[WC.R] += ((rgba >> 16) & 0xff);
				// vals[WC.G] += ((rgba >> 8) & 0xff);
				// vals[WC.B] += ((rgba ) & 0xff);

				data[x][y] = vals[WC.R];

				valDist[data[x][y]]++;

				pxCount++;
			}
		}

		// statistics
		int accum = 0;

		int q1 = (int) (.1f * pxCount);
		int q3 = (int) (.9f * pxCount);

		//
		// int q1 = (int)(.25f*pxCount);
		// int q3 = (int)(.75f*pxCount);

		int q1Val = 0;
		int q3Val = 0;

		for (int i = 0; i < 256; i++) {
			accum += valDist[i];
			if (accum < q1) {
				q1Val = i;
			}
			if (accum < q3) {
				q3Val = i;
			}
		}
		System.out.println("   q1 " + q1Val + "   q3 " + q3Val);

		float span = 255f / (float) (q3Val - q1Val);

		if (span > expansionLimit)
			span = expansionLimit;

		System.out.println("SPAN " + span);
		// alter values

		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {

				int val = (int) (((float) data[x][y] - q1Val) * span);

				// val = (val+data[WC.X][WC.Y])/2; // average EQ'd val and
				// original
				if (val > 255)
					val = 255;
				if (val < 0)
					val = 0;

				int rgba = (val << 24) | (val << 16) | (val << 8) | val;

				b.setRGB(x, y, rgba);
			}
		}

	}

	public void exportKMLIntensities(ArrayList wfl, int a, int b,
			ArrayList paramList) {

	}

	// public void exportKMLRaster() // todo

	public void exportKMLFootprint(ArrayList wfl, int a, int b,
			ArrayList paramList) {

		// final destination

		String destStr = (String) paramList.get(4);
		String extStr = ".kml";// (String) paramList.get(5);

		// int scanExportMode = (Integer) paramList.get(7);

		int inputSrc = WC.THREAD_LOAD_HDF5R;

		// handle temporal bounds checking
		int fa = a;
		int fb = b;
		if (fa < 0)
			fa = 0;
		if (fb > wfl.size())
			fb = wfl.size();

		// handle even/odd/all frame output
		int startFrame = fa;
		int skipFrame = 1;
		int frameIndex = 0;

		String kmlDirStr = destStr + "_KML";
		File kmlDir = new File(kmlDirStr);
		boolean mk = kmlDir.mkdir();

		if (mk) {

			for (int i = startFrame; i < fb; i += skipFrame) {
				System.out.println("GEN KML FRAME " + i);
				WITFrame wfi = (WITFrame) wfl.get(i);
				int fNo = i - fa;

				// even frames
				// if ((scanExportMode == WC.SCAN_DIR_EVEN || scanExportMode ==
				// WC.SCAN_DIR_BOTH) && wfi.scanDirection == 0 &&
				// wfi.biRay[inputSrc] != null) {
				// if ((scanExportMode == WC.SCAN_DIR_EVEN || scanExportMode ==
				// WC.SCAN_DIR_BOTH) && wfi.scanDirection == 0 &&
				// wfi.biRay[inputSrc] != null) {
				String kmlStr = createKMLFootprintSnapshot(wfi);
				File kmlFile = new File(kmlDirStr + "/" + wfi.timeStampStr
						+ ".kml");

				try {
					BufferedWriter bout = new BufferedWriter(new FileWriter(
							kmlFile));
					bout.write(" " + kmlStr);
					bout.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				System.out.println("WC.END KML FRAME " + i);
				// }

				/*
				 * // odd frames if ((scanExportMode == WC.SCAN_DIR_ODD ||
				 * scanExportMode == WC.SCAN_DIR_BOTH) && wfi.scanDirection == 1
				 * && wfi.biRay[inputSrc] != null) { //if ((scanExportMode ==
				 * WC.SCAN_DIR_ODD || scanExportMode == WC.SCAN_DIR_BOTH) &&
				 * wfi.scanDirection == 1 && wfi.biRay[inputSrc] != null) {
				 * String kmlStr = createKMLFootprintSnapshot(wfi); File kmlFile
				 * = new File(kmlDirStr+""+wfi.timeStampStr+".kml");
				 * 
				 * try { BufferedWriter bout = new BufferedWriter(new
				 * FileWriter(kmlFile)); bout.write(""+kmlStr); bout.close(); }
				 * catch (IOException e) { // TODO Auto-generated catch block
				 * e.printStackTrace(); } }
				 */

			}

			System.out.println("KML EXPORT COMPLETE");
		}
	}

	// todo add status/return logic
	public void createKMLSCABounds(WITFrame w) {

		for (int scaID = 0; scaID < 8; scaID++) {
			w.SCAcoordBounds[scaID] = new ArrayList();

			int geoLocW = w.geoLocSparseCols;
			int geoLocH = w.geoLocSparseRows;

			// find bounds for up, down, left, right
			int scaU[] = new int[geoLocW];
			int scaD[] = new int[geoLocW];

			int scaL[] = new int[geoLocH];
			int scaR[] = new int[geoLocH];
		}

	}

	public String createKMLFootprintSnapshot(WITFrame w) {

		StringBuilder sb = new StringBuilder();

		// detect the edges - deal with missing regions with "OFF EARTH" or 0.0
		// values

		int stepSizeX = w.geoLocXskip;
		int stepSizeY = w.geoLocYskip;

		if (w.SCAcoordBounds[0] == null) {
			// createKMLSCABounds(w);

			int scaID = w.scaID;
			// for (int scaID=0; scaID<8; scaID++){
			w.SCAcoordBounds[scaID] = new ArrayList();

			int geoLocW = w.geoLocSparseCols;
			int geoLocH = w.geoLocSparseRows;

			// find index of bounds for up, down, left, right
			int scaU[] = new int[geoLocW];
			int scaD[] = new int[geoLocW];

			int scaL[] = new int[geoLocH];
			int scaR[] = new int[geoLocH];

			// init to -1 for exception handling
			for (int i = 0; i < scaU.length; i++) {
				scaU[i] = -1;
			}
			for (int i = 0; i < scaD.length; i++) {
				scaD[i] = -1;
			}
			for (int i = 0; i < scaL.length; i++) {
				scaL[i] = -1;
			}
			for (int i = 0; i < scaR.length; i++) {
				scaR[i] = -1;
			}

			// populate the indices

			// top
			for (int x = 0; x < geoLocW; x++) {
				for (int y = 0; y < geoLocH; y++) {
					int valid = 1;
					if (w.geoLocDataSparse[x][y][WC.GEODATA_LON] == 0.0
							&& w.geoLocDataSparse[x][y][WC.GEODATA_LAT] == 0.0) {
						valid = -1;
					}
					if (w.geoLocDataSparse[x][y][WC.GEODATA_LON] == WC.INVALID_GEOLOCATION) {
						valid = -1;
					}
					if (w.geoLocDataSparse[x][y][WC.GEODATA_LAT] == WC.INVALID_GEOLOCATION) {
						valid = -1;
					}
					if (valid == 1) {
						scaU[x] = y;
						y = geoLocH; // break
					}
				}
			}
			// bottom
			for (int x = 0; x < geoLocW; x++) {
				for (int y = geoLocH - 1; y >= 0; y--) {
					int valid = 1;
					if (w.geoLocDataSparse[x][y][WC.GEODATA_LON] == 0.0
							&& w.geoLocDataSparse[x][y][WC.GEODATA_LAT] == 0.0) {
						valid = -1;
					}
					if (w.geoLocDataSparse[x][y][WC.GEODATA_LON] == WC.INVALID_GEOLOCATION) {
						valid = -1;
					}
					if (w.geoLocDataSparse[x][y][WC.GEODATA_LAT] == WC.INVALID_GEOLOCATION) {
						valid = -1;
					}
					if (valid == 1) {
						scaD[x] = y;
						y = -1; // break
					}
				}
			}

			// left
			for (int y = 0; y < geoLocH; y++) {
				for (int x = 0; x < geoLocW; x++) {
					int valid = 1;
					if (w.geoLocDataSparse[x][y][WC.GEODATA_LON] == 0.0
							&& w.geoLocDataSparse[x][y][WC.GEODATA_LAT] == 0.0) {
						valid = -1;
					}
					if (w.geoLocDataSparse[x][y][WC.GEODATA_LON] == WC.INVALID_GEOLOCATION) {
						valid = -1;
					}
					if (w.geoLocDataSparse[x][y][WC.GEODATA_LAT] == WC.INVALID_GEOLOCATION) {
						valid = -1;
					}
					if (valid == 1) {
						scaL[y] = x;
						x = geoLocW; // break
					}
				}
			}
			// right
			for (int y = geoLocH - 1; y >= 0; y--) {
				for (int x = 0; x < geoLocW; x++) {
					int valid = 1;
					if (w.geoLocDataSparse[x][y][WC.GEODATA_LON] == 0.0
							&& w.geoLocDataSparse[x][y][WC.GEODATA_LAT] == 0.0) {
						valid = -1;
					}
					if (w.geoLocDataSparse[x][y][WC.GEODATA_LON] == WC.INVALID_GEOLOCATION) {
						valid = -1;
					}
					if (w.geoLocDataSparse[x][y][WC.GEODATA_LAT] == WC.INVALID_GEOLOCATION) {
						valid = -1;
					}
					if (valid == 1) {
						scaR[y] = x;
						x = -1; // break
					}
				}
			}

			// populate the ArrayList\
			String coordStr = "";
			// top edge
			for (int i = 0; i < scaU.length; i++) {
				if (scaU[i] != -1) {
					int tabID = 0; // find the appropriate vertical offset

					int ok = -1;
					// while (ok)
					// int tab = scaL[0];
					// if (tab != -1 && scaU[i] != -1 ){
					// coordStr =
					// w.geoLocDataSparse[scaID][scaU[i]][tab][WC.GEODATA_LAT]+","+w.geoLocDataSparse[scaID][scaU[i]][tab][WC.GEODATA_LON]+",0 ";
					// w.SCAcoordBounds[scaID].add(coordStr);
					// }
				}
			}

			// bottom edge
			for (int i = scaD.length - 1; i >= 0; i--) {
				/*
				 * int tabID = scaR.length-1;
				 * 
				 * while (scaR[tabID] == -1 && tabID >0){
				 * 
				 * }
				 * 
				 * int tab = scaR[0]; if (tab != -1 && scaU[i] != -1 ){ coordStr
				 * =
				 * w.geoLocDataSparse[scaID][scaU[i]][tab][WC.GEODATA_LAT]+","+
				 * w.
				 * geoLocDataSparse[scaID][scaU[i]][tab][WC.GEODATA_LON]+",0 ";
				 * w.SCAcoordBounds[scaID].add(coordStr); }
				 */

			}

			// left edge

			// right edge

			// }
		}

		// SECRET REL
		sb.append("<?xml version= '1.0' encoding = 'UTF-8'?>");
		sb.append("<kml xmlns='http://earth.google.com/kml/2.1'>");
		sb.append("<Document>");

		sb.append("<name>SHEO_Sensor_Coverage.kml</name>");
		sb.append("<open>1</open>");
		sb.append("<ScreenOverlay>");
		sb.append("<name>Overlay.kml</name>");
		sb
				.append("<Icon><href>http://www.intelink.ic.gov/sites/afspc-bati/Common%20Documents/Icons/TeamBanner.gif</href></Icon>");
		sb
				.append("<overlayXY x='0' y='1' xunits='fraction' yunits='fraction'/>");
		sb
				.append("<screenXY x='0' y='1' xunits='fraction' yunits='fraction'/>");
		sb
				.append("<rotationXY x='0.5' y='0.5' xunits='fraction' yunits='fraction'/>");
		sb.append("<size x='-1' y='-1' xunits='pixels' yunits='pixels'/>");
		sb.append("</ScreenOverlay>");
		sb.append("<ScreenOverlay>");
		sb.append("<name>Current Sensors Legend</name>");
		sb.append("<Icon>");
		sb
				.append("<href>http://www.intelink.ic.gov/sites/afspc-bati/Common%20Documents/Icons/CurrentSensorsLegend.png</href>");
		sb
				.append("<overlayXY x='0' y='0.22' xunits='fraction' yunits='fraction'/>");
		sb
				.append("<screenXY x='0' y='0.22' xunits='fraction' yunits='fraction'/>");
		sb
				.append("<rotationXY x='0.5' y='0.5' xunits='fraction' yunits='fraction'/>");
		sb.append("<size x='-1' y='-1' xunits='pixels' yunits='pixels'/>");
		sb.append("</Icon>");
		sb.append("</ScreenOverlay>");
		sb.append("<Placemark>");
		sb.append("<name>SHEO Footprint</name>");
		sb.append("<Style id='SHEO_Style'>");
		sb.append("<LineStyle>");
		sb.append("<color>800000ff</color>");
		sb.append("<width>3</width>");
		sb.append("</LineStyle>");
		sb.append("<PolyStyle>");
		sb.append("<color>800000ff</color>");
		sb.append("<fill>0</fill>");
		sb.append("</PolyStyle>");

		sb.append("<TimeSpan>");
		sb.append("<begin>" + w.timeStampStrKML + "</begin>");
		sb.append("<end>" + w.timeStampStrKMLExpire + "</end>");
		sb.append("</TimeSpan>");
		sb.append("</Style>");

		sb.append("<MultiGeometry>");

		for (int scaID = 0; scaID < 8; scaID++) {
			if (w.SCAcoordBounds[scaID] != null) {
				if (w.SCAcoordBounds[scaID].size() > 0) {
					sb.append("<Polygon>");
					sb.append("<tesselate>1</tesselate");
					sb.append("<outerBoundaryIs>");
					sb.append("<linearRing>");
					sb.append("<coordinates>");

					for (int c = 0; c < w.SCAcoordBounds[scaID].size(); c++) {
						sb.append((String) w.SCAcoordBounds[scaID].get(c));
					}
					// close the loop
					sb.append((String) w.SCAcoordBounds[scaID].get(0));

					sb.append("</coordinates>");
					sb.append("</linearRing>");
					sb.append("</outerBoundaryIs>");
					sb.append("</Polygon>");
				}
			}
		}

		sb.append("</MultiGeometry>");
		sb.append("</Placemark>");
		sb.append("</Document>");
		sb.append("</KML>");

		System.out.println(sb);

		return sb.toString();
	}

	public void initFormatExt() {
		// formatExtensions
	}

	// find the index of the most recent frame
	public int getIndexFromTime(int secs, int searchSecs, ArrayList wl,
			int scanDir) {
		int index = -1;
		int threshDelta = searchSecs;// 5;
		int minDelta = threshDelta;

		// System.out.println("SCA "+scaID+" SEEKING TIME "+secs);
		// find the frame per SCA closest to the secs parameter, or grab the
		// next frame after

		int timeResult = 0;
		for (int i = 0; i < wl.size(); i++) {

			WITFrame w = (WITFrame) wl.get(i);
			int tDelta = Math.abs(w.timeStampSecOfDay - secs);
			// System.out.println(scaID+ " TIME SECS "+w.timeStampSecOfDay+
			// " "+secs+ " "+tDelta);
			if (tDelta < threshDelta) {

				if (tDelta <= minDelta) {
					/*
					 * minDelta = tDelta; index=i; timeResult =
					 * w.timeStampSecOfDay;
					 */

					if (scanDir == WC.SCAN_SELECT_ALL) {
						minDelta = tDelta;
						index = i;
						timeResult = w.timeStampSecOfDay;
						// System.out.println("UPDATE");
					} else if (scanDir == WC.SCAN_SELECT_EVEN) {

						if (w.scanDirection == WC.SCAN_SELECT_EVEN) {
							minDelta = tDelta;
							index = i;
							timeResult = w.timeStampSecOfDay;
						}
					} else if (scanDir == WC.SCAN_SELECT_ODD) {
						if (w.scanDirection == WC.SCAN_SELECT_ODD) {
							minDelta = tDelta;
							index = i;
							timeResult = w.timeStampSecOfDay;
						}
					}

					// System.out.println("       i = "+index+" minD "+minDelta+"/"+tDelta+" SCAN DIR "+w.scanDirection+"/"+playbackModeDir);
				}
				// System.out.println("TIME COMPARE "+w.timeStampSecOfDay+" "+secs);

				// i=witFrameList[scaID].size();
			}
		}

		// System.out.println("SCA "+scaID+" FOUND TIME "+timeResult+"/"+secs+"  INDEX "+index);
		return index;
	}

	public String secondsOfDayToReadable(int seconds) {

		int tPos = seconds;
		int hour = tPos / (WC.SEC_IN_HOUR);
		String hourStr = hour + "";
		if (hour < 10) {
			hourStr = "0" + hour;
		}
		int min = (tPos - hour * WC.SEC_IN_HOUR) / (60);
		String minStr = "" + min;
		if (min < 10)
			minStr = "0" + minStr;

		int sec = (tPos - hour * WC.SEC_IN_HOUR - min * 60);
		String secStr = "" + sec;
		if (sec < 10)
			secStr = "0" + secStr;

		hourStr += ":" + minStr + ":" + secStr;

		return hourStr;
	}

	public boolean deleteDir(File dir) {
		if (dir.isDirectory()) {
			String children[] = dir.list();
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteDir(new File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}

		return dir.delete();
	}

	public int validate8bitVal(int vIn) {
		int vOut = vIn;
		if (vOut > 255)
			vOut = 255;
		if (vOut < 0)
			vOut = 0;
		return vOut;
	}


	public Composite makeComposite(float a) {
		Composite c = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, a);

		return c;

	}


}
