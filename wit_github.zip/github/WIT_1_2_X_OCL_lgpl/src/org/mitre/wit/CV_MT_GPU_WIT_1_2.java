/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

/** @author Adrian Johnson **/
 
package org.mitre.wit;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.CheckboxMenuItem;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.MenuShortcut;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.FileDialog;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.media.opengl.*;
import javax.media.opengl.awt.*;
import javax.media.opengl.glu.*;
import javax.media.opengl.fixedfunc.*;
import javax.media.opengl.glu.gl2.*;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

import com.jogamp.*;
import com.jogamp.opengl.util.Animator;
import com.jogamp.opengl.util.awt.Overlay;
import com.jogamp.opengl.util.awt.Screenshot;
import com.jogamp.opengl.util.awt.TextRenderer;
import com.jogamp.opengl.util.gl2.GLUT;
import com.jogamp.opengl.util.glsl.*;
import com.jogamp.opengl.util.texture.Texture;
import com.jogamp.opengl.util.texture.TextureData;
import com.jogamp.opengl.util.texture.TextureIO;
import com.jogamp.opengl.util.texture.awt.AWTTextureIO;
import com.jogamp.common.*;
import com.jogamp.common.nio.Buffers;
import com.jogamp.opengl.*;

// This class coordinates processing and provides the visualization
public class CV_MT_GPU_WIT_1_2 extends Frame implements MouseListener,
		MouseMotionListener, KeyListener, GLEventListener, MouseWheelListener,
		ComponentListener {

	static {
		GLProfile.initSingleton(false);
	}

	// Wx items
	ArrayList wxPolyList = new ArrayList();

	int firstRenderPass = WC.STATUS_READY; // start collecting statistics from
	// first render call
	int timelineStatus = WC.STATUS_ERROR; // starts as unpopulated

	TimelineDrawThread timelineDrawThread;
	
	int openOnLaunch = WC.STATUS_OFF;
	
	static GLProfile glProfile;
	static final GLU glu = new GLU();
	static final GLUT glut = new GLUT();

	static int GPU_CONFIG_DISPLAY_LIST = WC.STATUS_OFF; // cache draw commands with drawlist

	float globe_opacity = .5f;
	
	long timeAtBoot;

	// buffer objects
	int maxTiles = 100000;// 180000; // per flight

	int tileBufferFills = 0;
	int texBufferFills = 0;
	int shaderProgram = 0;

	int gpuMaxBufferSteps[] = new int[5]; // need to cycle the temporal window
	// differently per filter
	int dwtBufferStepGpu = 0;
	int dwtBufferStep = 0;
	int dwtBufferStepPrev = 0;
	int dwtBufferStepTrigger = 0;
	int dwtTexIds[] = new int[WC.DWT_BUFFER_COUNT];
	int dwtTexIdsGpuConst[] = new int[WC.DWT_BUFFER_COUNT];
	float dwtKernel[] = new float[WC.DWT_BUFFER_COUNT];
	BufferedImage dwtBi[] = new BufferedImage[WC.DWT_BUFFER_COUNT];

	static int TILE_SIZE_X = 48;
	static int TILE_SIZE_Y = 48;

	static float brightnessScaleGpu = 1f; // can use to scale pre/post transfer
											// to GPU...
	static float intensityScaleGpu = (float) (1.0f / (float) (Math.pow(2, 8) - 1f));

	int gpuHistBins[] = new int[WC.HIST_BINS];

	int glCurrentBufferStepCount = 2;

	float gpuAccumAmount = .35f;

	int glContrastColorBands = 8;

	int glContrastControlExpoH = 25;
	float glContrastControlLinearH = 32; // rendered pixels between ticks
	float glContrastControlLinearDiffH = 32; // intensity deltas between ticks
	int glContrastControlW = 20;
	float glContrastControlH = 800;
	int glContrastControlX = 90;
	int glContrastControlLabelX = 40;
	int glContrastControlLabelTouchX = glContrastControlLabelX
			+ glContrastControlW * 2;
	float glContrastControlY = 300;// 10;
	int glContrastControlPointIntensityValue[] = new int[glContrastColorBands];
	int glContrastControlPointX[] = new int[glContrastColorBands];
	int glContrastControlPointY[] = new int[glContrastColorBands];
	int currentTouchContrastIntensity = 0;

	int glKernelEditorX = 100;
	int glKernelEditorY = 100;
	int glKernelEditorW = 200;
	int glKernelEditorH = 80;
	
	int uiRenderMiniTimeline = WC.STATUS_OFF;

	TextRenderer tr = null;
	TextRenderer tr2 = null;

	float colorRampYpos[][] = new float[2][glContrastColorBands];

	int glColorScheme = WC.COLOR_SCHEME_GRAYSCALE;
	int glColorLimits[][] = new int[WC.COLOR_SCHEME_COUNT][glContrastColorBands];
	int glColorLimitDiffs[][] = new int[WC.COLOR_SCHEME_COUNT][glContrastColorBands];
	float glColorLimitsRGB[][][] = new float[WC.COLOR_SCHEME_COUNT][glContrastColorBands][3];

	int lastEditedContrastNode = WC.STATUS_ERROR;
	int contrastCollapseLevel = 0;
	int contrastCollapseSpacing = 40;

	int fboIdsDwt[] = new int[WC.DWT_BUFFER_COUNT]; // frame buffer creation
	int texIdsDwt[] = new int[WC.DWT_BUFFER_COUNT];

	GLPbuffer glPBuffer[] = new GLPbuffer[WC.DWT_BUFFER_COUNT];

	public static String[] fragSourceAggregate = { " " };
	ArrayList fragSourceAggregator = new ArrayList();
	private static int[] programObject = new int[WC.FRAG_PROGRAM_COUNT];
	private static int fragmentShader;
	private static int[] sampler = new int[WC.DWT_BUFFER_COUNT];
	private static boolean[] glslSubroutineFlags = new boolean[WC.FRAG_PROGRAM_COUNT];

	public int externalGLSLNeedsCompile = WC.STATUS_ERROR;

	ShaderState glslState;
	ShaderProgram[] glslSp = new ShaderProgram[WC.FRAG_PROGRAM_COUNT];
	GLUniformData[] glud = new GLUniformData[WC.DWT_BUFFER_COUNT];
	int[] bufferFillOrder = new int[WC.DWT_BUFFER_COUNT];
	float[] dwtKernelCoefficients = new float[WC.DWT_BUFFER_COUNT];

	GLUniformData[] gludHistBins = new GLUniformData[WC.HIST_BINS];
	GLUniformData[] gludDwtKernelCoefficients = new GLUniformData[WC.DWT_BUFFER_COUNT];
	GLUniformData[] gludBufferFillOrder = new GLUniformData[WC.DWT_BUFFER_COUNT];
	GLUniformData[] gludSubroutineFlags = new GLUniformData[WC.FRAG_PROGRAM_COUNT];
	GLUniformData[] gludContrastIntensities = new GLUniformData[glContrastColorBands];
	GLUniformData[][] gludContrastFalseColors = new GLUniformData[glContrastColorBands][3];

	Texture glTextures[] = new Texture[WC.DWT_BUFFER_COUNT];

	int renderClearBypass = 0; // to accumulate bright items
	int renderAccumBuffer = 0; // to accumulate bright items

	int glRenderContrastControls = WC.GLUI_CONTROLS_CONTRAST;
	int glRenderFlightScaControls;

	// / FBO items
	private int frameBufferObject1 = -1;
	private int frameBufferTexture1 = -1;

	private int frameBufferObject2 = -1;
	private int frameBufferTexture2 = -1;

	boolean drawSatDetails = false;
	boolean drawPerformanceDetails = false;
	boolean lockViewToSat = false;

	int finalTileBufferSizeCol = 4;
	int finalTileBufferSizePos = 4;
	int posBufferName[] = new int[maxTiles];
	int colBufferName[] = new int[maxTiles];
	int texBufferName[] = new int[maxTiles];

	float coordProxSq = .005f; // if coords are greater than this dist,
	// assume new list

	BufferedImage knobImage1;
	BufferedImage knobImage2;
	BufferedImage knobImage3;
	BufferedImage knobImage4;
	Texture knobT1;
	Texture knobT2;
	Texture knobT3;
	Texture knobT4;

	float knobPulseLoad[] = new float[2];
	float knobPulseSkip[] = new float[2];
	float knobPulseBurst[] = new float[2];
	float knobPulseReloadTimer[] = new float[2];
	float knobPulseReloadBuffer[] = new float[2];
	float knobPulseStartIntensity = .9f;

	float knobRotLoad[] = new float[2];
	float knobRotSkip[] = new float[2];
	float knobRotBurst[] = new float[2];
	float knobRotReloadTimer[] = new float[2];
	float knobRotReloadBuffer[] = new float[2];

	float knobPulseFadeRate = .15f;
	float knobRotRate = .5f;

	float knobStartDeg = 20f;
	float knobSweepDeg = 360f - 2f * knobStartDeg;

	// float knobStartDeg = -30f;
	// float knobSweepDeg = -360f + 2*knobStartDeg;

	Texture tileCollection[] = new Texture[maxTiles];

	int maxBytes = 128 * 1000000;

	int maxFloatBufferColElements = maxTiles * 4 * WC.VBO_COLOR_COMPONENTS;
	int maxFloatBufferPosElements = maxTiles * 4 * WC.VBO_VERTEX_COMPONENTS;

	int tileFloatBufferColElements = 4 * WC.VBO_COLOR_COMPONENTS;
	int tileFloatBufferPosElements = 4 * WC.VBO_VERTEX_COMPONENTS;

	int maxBufferSize = maxFloatBufferPosElements * Buffers.SIZEOF_FLOAT
			* WC.VBO_VERTEX_COMPONENTS;

	int tileBufferSize = 4 * Buffers.SIZEOF_FLOAT * WC.VBO_VERTEX_COMPONENTS;

	FloatBuffer colDataBuffer = Buffers
			.newDirectFloatBuffer(maxFloatBufferColElements);
	FloatBuffer posDataBuffer = Buffers
			.newDirectFloatBuffer(maxFloatBufferPosElements);

	FloatBuffer colDataBufferTile = Buffers
			.newDirectFloatBuffer(tileFloatBufferColElements);
	FloatBuffer posDataBufferTile = Buffers
			.newDirectFloatBuffer(tileFloatBufferPosElements);
	// end buffers

	float user_view_rot[] = new float[2]; // allow user to flip data 90, 180,
	// 270 degrees
	float user_view_rot_inc = 5f;

	float overlayGlobeRot[][] = new float[WC.TOTAL_FLIGHTS][3];
	float overlayGlobeTrack[][] = new float[WC.TOTAL_FLIGHTS][3];
	ArrayList satTrackList = new ArrayList();

	float los_error_rot[][] = new float[WC.TOTAL_FLIGHTS][3];
	float view_rot[][] = new float[WC.COORDINATES_MODE_MAX][3]; // per
	float view_rot_auto[][] = new float[WC.COORDINATES_MODE_MAX][3];

	// coordinate
	// space, XYZ
	float view_trans[][] = new float[WC.COORDINATES_MODE_MAX][3]; // per
	// coordinate
	// space,
	// XYZ
	float view_scale[] = new float[WC.COORDINATES_MODE_MAX]; // per coordinate
	// space
	int prevMouse3dX, prevMouse3dY;
	float dragSpeed = 8.5f;// 4.2f;
	float viewTransIncSensorPerspective = .001f;
	float viewTransIncMultiplier = 10f;
	// GLCapabilities capabilities;

	static GLCanvas glCanvas;

	// static Frame frame;
	// static GLCanvas glCanvas;
	// Frame glFrame;

	float userScale3DMin = .01f;
	float userScale3DMax = 100.0f;

	int renderTime3D = 0;

	// resource status
	int mapResourcesExist = 0;

	int mercatorMapList = 0;
	int globeMapList = 1;
	int globeLineList = 4;
	int coordinateMode = WC.COORDINATES_SENSOR;// WC.COORDINATES_MERCATOR;COORDINATES_GLOBE
	boolean trackViewToSensor = true;
	float globeRadius = 1.0f;

	// master config file location
	String masterConfigFileStr = "WIT_CONFIG.txt";

	String productClassificationLabelStr = "// SECRET // OT&E PRODUCT //";
	String productTitleLabelStr = "";
	String defaultLoadDirStr = "/export/data/hdf5/r/";
	String defaultSaveDirStr = "/export/WIT_PRODUCTS/";
	String defaultSaveDemoVideoDirStr = "/export/WIT_DEV/DEMO_VIDEO_FRAMES/";
	String defaultResourceDirStr = "/export/WIT_DEPLOY/RESOURCES/";
	String defaultMapDataDirStr = "/export/WIT_DEPLOY/RESOURCES/MAP_DATA/";
	String defaultMapGraphicStr = "/export/WIT_DEV/mapImage_320_10.png";
	String defaultFfmpegScratchDirStr = "/export/WIT_DEV/ffmpeg_scratch/";
	String defaultResourceImageDirStr = "/export/WIT_DEPLOY/RESOURCES/images/";

	String intensityBiasFileStr = "/export/WIT_DEV/channel_biases.txt";
	String webHelpLocation = "";

	String batchFfmpegScratchDirStr = "";
	String videoExportFileStr = "";

	float defaultGlobeLineLonSpacing = 30;
	float defaultGlobeLineLatSpacing = 30;

	// workaround flags - goal is to eliminate these!
	int WORKAROUND_GPU_HDR = 0;
	int WORKAROUND_AUTO_CONTRAST = 0;

	int GPU_INTERPOLATE_PIXELS = 0;

	// allow server/client modes
	int HEADLESS_MODE = 0; // 0 is standard, 1 is headless, 2 is distributed
	int DISPLAY_MODE = 0; // 0 is classic, 1 is remote

	// biases used to correct channels
	int intensityBiasPerScaPerChannel[][][][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS][WC.SCA_CHANNELS][2]; // per
	// scan
	// direction

	int masterOverlayToggle = 1;
	// mini-map
	int miniMapPos[][] = new int[2][2]; // goal/current and X/Y
	int miniMapSize[][] = new int[2][2]; // goal/current and W/H
	float miniMapScale = .05f;
	// draw the view area
	int miniMapInsetPos[][] = new int[2][2]; // goal/current and X/Y
	int miniMapInsetSize[][] = new int[2][2]; // goal/current and W/H

	int drawMiniMapSCALabels = 1;
	int miniGlobePos[][] = new int[2][2];
	int miniGlobeSize[][] = new int[2][2];
	float miniGlobeScale = 1.12f;// .5f;
	BufferedImage miniGlobeImage;

	// optimize the graphic elements
	int pointerH1 = 40;
	int pointerH2 = 26;
	int pointerH3 = -12;
	int pointerW1 = 2;
	BasicStroke stroke1;
	BasicStroke stroke2;
	BasicStroke strokeWidth1;
	BasicStroke strokeWidth2;
	BasicStroke strokeWidth3;
	Graphics2D gMain;
	// Graphics2D gh;
	int graphicsStatus = WC.STATUS_ERROR;
	//
	int uiState = WC.UI_STATE_VIEW;

	boolean overlayStates[] = new boolean[WC.OVERLAY_GLOBE_COUNT];

	int SCA_FOCUS = 2; // default pan location

	//
	int widgetVisibility[] = new int[WC.MAX_WIDGETS];

	// contrast ui items
	int contrastCurveDotRadius = 8;
	int contrastCurveDotOffsetRadius = contrastCurveDotRadius / 2;

	// allow user to choose flight 33 (0) or 34 (1)
	int userFlight = 0;
	int loadedFlight = -1;

	int loadSource = WC.LOAD_FILE_CHOOSER;// WC.LOAD_FILE_RECENT;
	// int loadSource = WC.LOAD_FILE_RECENT;//;

	String loadWindowStr = "";
	String loadSkipStr = "";
	String loadBurstStr = "";
	String loadReloadTimerStr = "";
	String loadReloadBufferStr = "";

	// int userDataChunkIndex[] = new int[2];
	// int userDataChunkCount[] = new int[2];
	int timelineCenterX; // allow this to center in the view

	float satPosEcf[][] = new float[WC.TOTAL_FLIGHTS][3];

	String lastLoadedFileStr = "";
	String lastLoadedDirStr = "";
	
	// threading
	int MAX_THREADS_ACTIVE = 4;// 2;//2;
	int MAX_THREADS_QUEUED = 64;
	int activeThreadCount = 0;
	int queuedThreadCount = 0;
	ImProcThread imprRay[] = new ImProcThread[MAX_THREADS_QUEUED];
	// ImpContrastThread imprContrastRay[];
	int maxLoaderThreads = 100;
	int loaderThreadIndex = 0;

	int maxGenericThreads = 100;
	int genericThreadIndex = 0;

	// ImpBufferThread imprBufferRay[] = new ImpBufferThread[maxLoaderThreads];

	int maxContrastThreads = 100;
	int contrastThreadIndex = 0;
	int loaderProgressFrames[] = new int[WC.TOTAL_FLIGHTS];
	int loaderProgressFramesPrev[] = new int[WC.TOTAL_FLIGHTS];

	int loaderInfoFrames = 0;
	int loaderInfoFramesPrev = 0;


	int userPriorities[] = new int[8]; // allow users to specify
	// importance of filters, but
	// cannot override some system
	// constraints

	int uiCompassRotationState = WC.STATUS_OFF;

	int threadMode;

	int threadPriorities[] = new int[WC.MODE_COUNT];
	int threadTimeouts[] = new int[WC.MODE_COUNT];

	int threadScheme = WC.THREAD_SCHEME_BATCH;// WC.THREAD_SCHEME_BATCH;
	int systemState = WC.SYSTEM_STATE_ONLINE;
	int dataState = WC.STATUS_READY;
	int exportDemoVideoState = WC.STATUS_OFF;// WC.STATUS_OFF;
	int exportBounceVideoState = WC.STATUS_OFF;
	int demoVideoFrameCount = 0;
	int bounceVideoFrameCount = 0;

	int exportDemoVideoStateFrameSkipperInitVal = 3;// save every 4th frame
	int exportDemoVideoStateFrameSkipper = exportDemoVideoStateFrameSkipperInitVal;

	// video threads
	int newThreadEncodeVideo = 1;
	int newThreadExportVideo = 0;
	int newThreadExportVideoMaxPixels = 200 * 200; // smaller and new thread,
	// bigger and inline
	VideoEncodeThread vet;

	// today's timeline

	int minTimeOffset = -WC.SEC_IN_DAY + 2000;
	int maxTimeOffset = 0;// -WC.SEC_IN_DAY;

	int reconstructFullScans = 1;

	float userTimelineZoom[] = { 1f, 1f };
	float userTimelineZoomMin = .1f;
	float userTimelineZoomMax = 10f;
	float userTimelineOffset[] = { 0, 0 };
	int loadSeconds = 120; // seconds of data to load
	int skipSeconds = 1;
	int burstSeconds = WC.SNIPPET_SECONDS_LOAD;

	float MAX_LOAD_SECONDS = 60 * 60 * 4; // 4 hrs
	float MAX_SKIP_SECONDS = 60 * 60 * 1; // 1 hrs
	float MAX_BURST_SECONDS = 60;
	float MAX_RELOAD_TIMER_SECONDS = 60 * 60;
	float MAX_RELOAD_BUFFER_SECONDS = 60 * 60;

	float MIN_LOAD_SECONDS = 1f;
	float MIN_SKIP_SECONDS = 1f;
	float MIN_BURST_SECONDS = 1f;
	float MIN_RELOAD_TIMER_SECONDS = 10f;
	float MIN_RELOAD_BUFFER_SECONDS = 0f;

	float MID_BURST_SECONDS = 5f;
	float MID_SKIP_SECONDS = 60f;
	float MID_LOAD_SECONDS = 300f;
	float MID_RELOAD_TIMER_SECONDS = 60f;
	float MID_RELOAD_BUFFER_SECONDS = 60f;

	float INC_LOAD_SECONDS1 = 3f;
	float INC_LOAD_SECONDS2 = 120f;
	float INC_SKIP_SECONDS1 = 1f;
	float INC_SKIP_SECONDS2 = 60f;
	float INC_BURST_SECONDS1 = 1f;
	float INC_BURST_SECONDS2 = 2f;
	
	float INC_RELOAD_TIMER_SECONDS1 = 1f;
	float INC_RELOAD_TIMER_SECONDS2 = 60f;
	float INC_RELOAD_BUFFER_SECONDS1 = 1f;
	float INC_RELOAD_BUFFER_SECONDS2 = 60f;

	int jumpLoadStart = -1;
	int jumpLoadDistance = -1;
	int uiLoadTriggerTimer = 0;
	int loadTriggerState = WC.STATUS_OFF;
	long loadStartTimer = 0;
	long loadEndTimer = 0;
	long loadEndTimerLastUpdate = 0;
	long postLoadDelayAutoPlay = 10 * 1000;
	long autoUnpauseMinDelayMs = 0;// 1000;
	int autoUnpauseMinDelayPerFile = 1000;
	int autoUnpauseAfterLoad = 1;
	int needsToAutoResumeFlag = 0;
	
	int enableAutoRoaming = 1;// scroll across the screen
	// data
	// availability
	// for
	// all
	// minutes
	// of
	// the
	// day
	// per
	// SCA
	int dataArrayRef[] = new int[WC.SEC_IN_DAY]; // for every second of
	// data, reference them
	// WITFrame object
	// associated with it
	
	int dataLoadStatus[][][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS][WC.SEC_IN_DAY]; // flight,
	// sca,
	// minutes
	
	int dataLoadInfo[][][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS][WC.SEC_IN_DAY];
	int dataFramesInFile[][] = new int[WC.TOTAL_SCAS][WC.SEC_IN_DAY];
	int dataRefWITFile[][][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS][WC.SEC_IN_DAY];
	int dynamicLoadStatus = WC.STATUS_ERROR;
	int dynamicLoadTaskCreatorStatus = WC.STATUS_ERROR;
	int flightSelected = 0;
	ArrayList wFileListTimeline = new ArrayList();

	// 
	int northArrowRasters[][] = new int[2][2]; // sca, start/stop, x/y
	float compassAngle = 0;
	float compassIsValid = 0;
	BufferedImage compassImage;
	BufferedImage compassImageRot;
	// error handling flags
	int ERROR_STATE_COUNT = 5;
	int dataErrorHandling[][][][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS][WC.SEC_IN_DAY][ERROR_STATE_COUNT];
	int MISSING_ITEM_GEOLOCATION = 0;
	int[] missingDataItems = new int[ERROR_STATE_COUNT]; // flag missing


	ArrayList bookmarkList = new ArrayList(); 

	int bookmarkListIndex[] = new int[WC.TOTAL_FLIGHTS];
	int bookmarkSyncFlag = WC.STATUS_ON;
	long bookmarkSyncTime = 0;
	int timelineMouseoverX = -1;

	// sca selector
	int scaSelectorGraphic[][] = new int[WC.TOTAL_SCAS][4]; // x, y, w, h
	int scaSelectorBand[] = new int[WC.TOTAL_SCAS];
	String scaSelectorString[] = new String[WC.TOTAL_SCAS];

	int viewportY = 1500;
	int viewportX = 2560;

	int viewportGlY = viewportY - 60;// 100;//300;
	int viewportGlX = viewportX;
	float aspectRatio = (float) viewportGlY / (float) viewportGlX;

	// int viewportTileX = 768 * 6;// 360;
	// int viewportTileY = 400 + ImpExecs.SCA_Y_OFFSET;// 244; 1920x1200

	// int viewportTileY = 764 + WC.SCA_Y_OFFSET;// 244;
	// geolocation
	int GEODATA_LON = 0;
	int GEODATA_LAT = 1;

	static int GEODATA_UL = 0;
	static int GEODATA_UR = 1;
	static int GEODATA_LR = 2;
	static int GEODATA_LL = 3;

	int latLonOverlayEnabled = 1;
	float overlayMapScale = 32.0f;

	int cursorX = 0; // using only the frame as the reference
	int cursorY = 0;
	int cursorUnblockX = -8; // grab a slight offset so the cursor does
	// not block the pixel being checked
	int cursorUnblockY = -8;
	int cursorOverWidget = WC.STATUS_OFF;

	int mouseOverSCA = -1;
	int histogramSCAselector = -1;
	int histogramSCAselectorPrev = -1;
	int histogramZoomEnabled = 0;

	int histogramZoomLevel = 1;
	int histogramMinZoomLevel = 1;
	int histogramMaxZoomLevel = 8;  

	int mouseX = 0; // using the frame plus SCA pan as the reference
	// frame
	int mouseY = 0;
	int mousePanoramaX = 0; // just using the panorama coords, not SCA
	int mousePanoramaY = 0; 
	int mouseIntensity = 0;
	float mouseLon;
	float mouseLat;
	float mouseLonFast;
	float mouseLatFast;
	int mouseOverSCAprev = -1;
	int lensTextColorMode = 0;
	int userEventFlashDefault = 100;
	int userEventFlash = WC.STATUS_OFF;

	int mouseState = WC.STATUS_READY; // keep mouse events manipulating the
	// correct
	// item...ie allow dragging between UI
	// elements
	int mouseStateContrastNode = WC.STATUS_ERROR;

	int LAT_LON_COLOR_AUTO = 0;
	int LAT_LON_COLOR_DARK = 1;
	int LAT_LON_COLOR_LIGHT = 2;

	int scaOffsets[][] = new int[8][2];

	// String defaultLoadDirStr = "/export/WIT_PRODUCTS/";
	// String defaultLoadDirStr = "/export/data/hdf5";

	// default number of files to attempt to read
	int inputFileSeqCount = 2;// 9; // 3 usually works, 2 to be safe, 1
	// to allow processing

	int autoReloadState = 0;
	int autoReloadTimerSeconds = 30;
	int autoReloadBufferSeconds = 30;

	long autoReloadTime1 = 0;
	long autoReloadTime2 = 0;
	// long autoReloadTimeD = 1000 * 30 ; // reload every 5 minutes

	String lastFileLoaded = "";

	String invalidPathStr = "INVALID_FILE_PATH";
	// int witFileListRoot = 0; // location of first file to read from
	// array

	// lenses
	int lensFilterActive = 0;
	int lensMagnifyActive = 0;

	// map assets
	int drawMapImageActive = 0;
	BufferedImage mapImage;
	BufferedImage mapImageLive;
	int mapImageRasterX;
	int mapImageRasterY;

	// plot assets
	int drawPlotImageActive = 0;
	BufferedImage plotImage;
	int plotImageRasterX;
	int plotImageRasterY;

	// georeference cues
	int drawNorthArrowsStatus = 1; // show NORTH arrows
	int drawPoliticalOverlay = 1; // nation boundaries

	// masks
	short INVALID_DATA_MASK = (short) -1;
	int INVALID_GEOLOCATION = -9999;

	//
	static VideoExportUI vidExportUI;
	static KernelEditorUI kernelEditorUI;
	static GLSLEditorUI glslEditorUI;

	int SCAN_SELECT_ALL = 2;
	int SCAN_SELECT_EVEN = 0;
	int SCAN_SELECT_ODD = 1;
	int scanSelectionMode = SCAN_SELECT_ALL;
	int scanExportMode = SCAN_SELECT_ALL;

	int SCAN_DIR_UNKNOWN = -1;
	int SCAN_DIR_EVEN = 0;
	int SCAN_DIR_ODD = 1;
	int SCAN_DIR_BOTH = 2;
	int playbackModeDir[] = { SCAN_DIR_EVEN, SCAN_DIR_EVEN };

	int SCAN_SEGMENT_ONE = 0;
	int SCAN_SEGMENT_ALL = 0;
	int playbackModeSeg = SCAN_SEGMENT_ONE;

	int playbackScanSeqIndexMask[][] = new int[WC.TOTAL_FLIGHTS][WC.SCAN_SEQ_INDEX_MAX_VAL]; // mask
	// overscans,
	// or
	// do
	// overscans
	// onl
	String sosScanSeqIndexLabel[] = new String[WC.SCAN_SEQ_INDEX_MAX_VAL];
	int playbackScanSeqIndexPrev[] = { -1, -1 };

	int scanLength = 0;
	int scanPosYStartPointer = 0;
	int scanPosYEndPointer = 0;

	//
	int CURRENT = 0;
	int GOAL = 1;

	int rasterLayerOrder[] = new int[WC.MODE_COUNT];
	int timelineLayerOrder[][] = new int[WC.MODE_COUNT][3]; // op, Y, Z
	float rasterLayerOpa[][] = new float[WC.MODE_COUNT][2]; // allow
	// goal/current
	// for fades
	float defaultOpOpacity[] = new float[WC.MODE_COUNT]; // allow user to
	// configure
	// desired
	// opacity
	int RASTER_OMIT = -1;
	float rasterOpaFadeRate = .5f;

	int playbackPaused = 0;
	int drawCyclePaused = 0;
	float playbackStepSeconds = 1.0f;
	BufferedImage contrastPrevBI;

	BufferedImage lensMagImage;
	int lensW = 100;
	int lensH = 100;
	int lensScale = 4;// 4; !! 4,8,16
	int lensPosX = 0;
	int lensPosY = 0;

	// buffer the drawing of the timeline and available data
	float texCoordRayTimelineImage[][] = new float[4][3];
	int timelineImageTexId = WC.STATUS_ERROR;
	int timelineImageTexSyncGlFlag = WC.STATUS_COMPLETE;
	int timelineImageTexSyncGlDrawListFlag = WC.STATUS_COMPLETE;
	int timelineGlDrawListId = WC.STATUS_ERROR;
	Texture timelineImageTextureGl;
	
	int timelineImageUpdateFlag = 0;

	int timelineImageW = WC.SEC_IN_DAY;
	int timelineImageH = 100;

	int latLonOverlayUpdateFlag = 1;
	int mapOverlayUpdateFlag = 1;

	static CV_MT_GPU_WIT_1_2 cvt = new CV_MT_GPU_WIT_1_2();
	// UI

	String tivoRootDir = "/export/WIT_DEV/";
	// String tivoRootDir = "/Volumes/Areca/tivo/";

	String tivoLoadFile = "wit_previous_session.xml";
	String tivoSaveFile = "wit_previous_session.xml";

	// stats
	int STATS_MIN = 0;
	int STATS_Q1 = 1;
	int STATS_Q2 = 2;
	int STATS_Q3 = 3;
	int STATS_MAX = 4;
	int STATS_MIN_BIN = 5;
	int STATS_MAX_BIN = 6;

	// contrast
	int CONTRAST_OFF = 0;
	int CONTRAST_GAIN = 1;
	int CONTRAST_CURVES = 2;
	int CONTRAST_AUTO = 3;
	int CONTRAST_WINDOW = 4;
	int CONTRAST_USER = 5;
	int contrastMode = CONTRAST_USER;
	float loadTimeGain = 1.0f;
	float loadTimeBoost = 0.0f;

	// distributed computing / sharing

	int NODE_STATE_MASTER = 1;
	int NODE_STATE_SLAVE = 2;
	int NODE_STATE_INACTIVE = -1;
	int nodeState = NODE_STATE_MASTER;// NODE_STATE_SLAVE;
	int nodeStateLabel = 1;// show the state of each node
	int nodePlayheadLocked = 0;
	int nodePlayheadShared = 0;
	int peerPlayheadListening = 1;
	int tivoPlayheadPeer = 0;

	// int witFramePlayhead = 0;

	// sync the playback of each SCA to this master timestamp (secs after
	// midnight)
	int witTimePlayhead = 0;
	int lockPlayhead = 1;
	float witTimePlayheadFloat = 0;
	String witTimePlayheadTimestampStr = "";
	String witTimePlayheadTimestampOutputStr = "";
	String witScanPlayheadTimestampStr = "";
	int scanDirAgreementDrawFlag[][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];
	int timeAgreementDrawFlag[][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];
	int scanSeqAgreementDrawFlag[][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];
	ArrayList lastDrawIndexList[][] = new ArrayList[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];

	// use to sync array indices across SCAs
	int witSCAPlayhead[][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS]; // index
	// for
	// each
	// SCA's
	// playback

	// min and max determined from user's load preferences
	int minLoadSeconds = 0;
	int maxLoadSeconds = 0;

	int userScid = 33;

	float userPanOffset[][] = { { 0, 0 }, { 0, 0 } };
	float vaRate = .45f; // view animation rate
	float taRate = .35f; // view animation rate
	float tzRate = .35f; // view animation rate
	float viewFlipRate = .4f;
	int minPanX;// (int)(-768f * 4.85f);
	int maxPanX;
	int minPanY;
	int maxPanY;
	float timelineZoomUiRate = 1.05f;

	int yAlignUser = 0;

	// state restoration

	int RESTORE_STATE_MANUAL = 0;
	int RESTORE_STATE_ON_LAUNCH = 1;
	int RESTORE_STATE_DIALOG_BOX = 2;
	int restoreStateMode = RESTORE_STATE_MANUAL;

	int SAVE_STATE_MANUAL = 0;
	int SAVE_STATE_ON_EXIT = 1;
	int SAVE_STATE_DIALOG_BOX = 2;
	int saveStateMode = SAVE_STATE_ON_EXIT;

	ArrayList nodeList = new ArrayList();
	//

	int T_RASTER = 3;
	int T_SECS = 3;
	// user selection

	int CHECK_BOUNDS_LOCK = 1;
	int CHECK_BOUNDS_LOOP = 0;

	int SELECTION_READY = 0;
	int SELECTION_WORKING = 1;
	int SELECTION_COMPLETE = 2;

	// based on loaded data
	int loopStart = 0;
	int loopEnd = 0;
	int loopStartPrev = 0;
	int loopEndPrev = 0;
	
	
	int userSelection[][] = new int[2][4]; // start/end x/y/t/index - for
	int userSelectionSCA[][][] = new int[WC.TOTAL_SCAS][2][4]; // start/end
	int userSelectionReloader[][] = new int[2][4]; // start/end x/y/t/index - for
	// x/y/t/index - for
	// playback and export
	// int userFilter[][] = new int[2][3]; // start/end x/y/t - only
	// process a selection of data for memory management
	int userSelectionSCAtouched[] = new int[WC.TOTAL_SCAS];
	int userContrast[] = new int[2]; // start/end ...modes - select
	ArrayList userContrastCPList;
	ArrayList userContrastCPListSorted;
	int userContrastCPStatus = SELECTION_READY;
	int userContrastRangeStatus = SELECTION_READY;
	int userContrastCPmodID = -1;
	// the region of the dynamic
	// range
	// int contrastSpanSelection[] = new int[2];
	int userSelectionArea = 0; // use to prompt interactive updates

	int selectionStatus = SELECTION_READY;
	int selectionTimeStatus = SELECTION_READY;

	int handleFlagW = 8; // flags for grabbing the selectors
	int handleFlagH = 22;
	int histogramZoomButtonSize = 20;

	// playback mode
	int LOOP_MODE_ALL = 0;
	int LOOP_MODE_SELECTION = 1;
	int loopMode = LOOP_MODE_ALL;

	int PAUSED = 0;
	int UNPAUSED = 1;
	int pauseFlag = UNPAUSED;

	int dejitterPlaybackX = 0;
	int dejitterPlaybackY = 0;
	//
	Canvas tivoCanvas;
	// GLJPanel tivoCanvas;

	int latLonRenderEnabled = 0;

	BufferedImage viewportImage;
	BufferedImage resizedView;
	BufferedImage viewportImageRot; // for rotated viewport
	BufferedImage viewportImageOverlay;
	// BufferedImage missingDataImage;
	Graphics2D g;
	Graphics2D gb;
	Graphics2D gwc;

	Composite graphicComposites[];
	static int c_WORKING;
	static int c_WIDGET;
	static int c_LOOP_SELECTION;
	static int c_COMPLETE;
	static int c_LATLON_OVERLAY;
	int c_raster;

	int tivoPlayheadBuffer = 2;
	int witOpBuffers[]; // buffer each process intelligently
	int WIT_OP_BUFFER_DEFAULT = tivoPlayheadBuffer;

	int witLoopBoundsMinSecs = 0;
	int witLoopBoundsMaxSecs = 0;

	int SECONDS_IN_DAY = 24 * 60 * 60;

	int viewMask[] = new int[4]; // configurable views
	boolean opMask[] = new boolean[WC.MODE_COUNT]; // toggle active/inactive
	boolean opReqCPU[] = new boolean[WC.MODE_COUNT]; // toggle active/inactive
	int filterRegionReqMask[] = new int[WC.MODE_COUNT]; // toggle

	boolean outputModeMask[] = new boolean[WC.MODE_COUNT];
	boolean outputFormatMask[] = new boolean[WC.FORMAT_COUNT];
	String outputFormatExtStr[] = new String[WC.FORMAT_COUNT];
	boolean outputOptionMask[] = new boolean[WC.OPTION_COUNT];
	float userVideoMagnification = 1f;
	float userVideoSpeed = 1f;
	float userVideoExportSpeed = 1f;
	// active/inactive

	// information overlays
	float tivoSpeedOverlayAlpha = 0f;
	float tivoSpeedOverlayAlphaReset = 10f;
	float tivoInfoOverlayAlpha = 0f;
	float regionHintAlpha = 0f;
	float alphaFadeRate = .95f;
	float contrastOverlayAlpha = 0f;

	String userInterfaceInfoStr = "";
	String regionHintStr = " ";
	String fontNameStr = "";

	int basePlaybackSpeed = 16;// 640;//16; // 1000 // 1 second refresh

	// ui anim
	long guiTime1 = 0;
	long guiTime2 = 0;
	int guiTimeDeltaPlaybackMS = 40;// 1600;//40;

	// dwt editor anim
	long dwtEditorTime1 = 0;
	long dwtEditorTime2 = 0;
	int dwtEditorTimeDeltaPlaybackMS = 1000;

	// timeline refresh (status)
	long timelineRefreshStatusTime1 = 0;
	long timelineRefreshStatusTime2 = 0;
	int timelineRefreshStatusTimeDelta = 200;// 4000;//200;

	long timelineCheckNewFilesTime1 = 0;
	long timelineCheckNewFilesTime2 = 0;
	long timelineCheckNewFilesTimeDelta = 30000;
	
	int timelineCheckEnabled = WC.STATUS_OFF;
	String incomingDataDirStr = "";
	int timelineCheckTimezoneOffset = 7; // hours of offset
	int timelineCheckPrerollSeconds = 60*10; // hours of offset

	// timeline refresh (info)
	long timelineRefreshInfoTime1 = 0;
	long timelineRefreshInfoTime2 = 0;
	int timelineRefreshInfoTimeDelta = 500;// 10000;//500;

	// bookmark refresh (info)
	long bookmarkRefreshInfoTime1 = 0;
	long bookmarkRefreshInfoTime2 = 0;
	int bookmarkRefreshInfoTimeDelta = 500;

	// new playhead for Arraylist
	long playheadTime1 = 0;
	long playheadTime2 = 0;
	int playheadTimeDelta = basePlaybackSpeed;// 1000;
	int playheadDir = 1;
	int playheadDirPrev = 1; // for pause

	// playback anim
	long time1 = 0;
	long time2 = 0;
	int timeDeltaPlaybackMS = 16;// 30;// 33; //

	long restartTime1 = 0;
	long restartTime2 = 0;
	long restartMS = 1000 * 60 * 5;

	// process time - kick off new threads
	long processTime1 = 0;
	long processTime2 = 0;
	long processTimeMS = 1200;

	// finalization tim
	long finalizationTime1 = 0;
	long finalizationTime2 = 0;
	long finalizationTimeMS = 30000;

	// int frameCount = 900;//300//255;
	int frameCountAlloc = 0;

	int tivoMaxFrame = 300;

	int DEFAULT_FILE_LIMIT = 10000;
	int witFileCount = 0; // current file to load
	// WITFrame tff[] = new WITFrame[frameCount]; // track each SCA
	// independently
	// WITFrame tf[] = new WITFrame[frameCount]; // per SCA
	WITFrame tfMWIR[];
	WITFrame tfSTG[];

	ArrayList timeCentricLists[][] = new ArrayList[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];

	ArrayList witFrameList[][] = new ArrayList[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];
	ArrayList witFileList[][] = new ArrayList[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];
	
	ArrayList wFileListSCA[] = new ArrayList[WC.TOTAL_SCAS];
	int witFileListRootSCA[] = new int[WC.TOTAL_SCAS];
	// int[][] scaLoadMask = {{0,1,1,0,0,0,0,0},{0,1,1,1,0,0,0,0}};
	int[][] scaLoadMask = { { 1, 1, 1, 1, 1, 1, 1, 1 },
			{ 1, 1, 1, 1, 1, 1, 1, 1 } };
	int[][] scaOclMask = { { 1, 1, 1, 1, 1, 1, 1, 1 },
			{ 1, 1, 1, 1, 1, 1, 1, 1 } }; // 1 complete/blocked
	float[][] histOpaBoost = { { 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0 } };
	int[] coordinateSpaceLoadMask = { 1, 1, 1 }; // !! TODO tie to
													// sensor/mercator/globe
	float histOpaBoostAmount = 1f;
	int histOpaBoostTimer = 0;
	int histOpaBoostTimerInit = 20;
	float histOpaBoostFadeRate = .35f;
	int[] flightLoadMask = { 1, 1 };
	int[] indexSca = { 0, 0 };


	// forward
	int SYSTEM_PLAYBACK_RATE_F1X = 0;
	int SYSTEM_PLAYBACK_RATE_F2X = 1;
	int SYSTEM_PLAYBACK_RATE_F4X = 2;
	int SYSTEM_PLAYBACK_RATE_F8X = 3;
	int SYSTEM_PLAYBACK_RATE_F16X = 4;
	// reverse
	int SYSTEM_PLAYBACK_RATE_R1X = 10;
	int SYSTEM_PLAYBACK_RATE_R2X = 11;
	int SYSTEM_PLAYBACK_RATE_R4X = 12;
	int SYSTEM_PLAYBACK_RATE_R8X = 13;
	int SYSTEM_PLAYBACK_RATE_R16X = 14;
	int SYSTEM_PLAYBACK_RATE_PAUSE = 20;

	int systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F1X;
	int systemPlaybackRatePause = SYSTEM_PLAYBACK_RATE_F1X; 
	
	int HISTOGRAM_DISPLAY_LINEAR = 0;
	int HISTOGRAM_DISPLAY_EXPONENTIAL = 1;
	int histogramDisplayState = HISTOGRAM_DISPLAY_EXPONENTIAL;
	BufferedImage histogramImage;

	int tivoStatusBarX;// viewportTileX;
	int scaOpMaskX;
	int scaOpMaskW;

	int knobBarX;
	int knobLabelY;
	int knobValueY;

	int knobDeltaX1;
	int knobDeltaX2;
	int knobDeltaX3;
	int knobDeltaX4;
	int knobDeltaX5;

	int knobPixelW = 30;

	// contrast slider bars
	int contrastBarTickX;
	int contrastBarSpaceX;

	int[] histClusterCutoffs = { (int) (Math.pow(2, 8)),
			(int) (Math.pow(2, 12)), (int) (Math.pow(2, 14)),
			(int) (Math.pow(2, 16)) };
	int[] histClusterSizes = { 1, 8, 32, 128 };
	int histClusterSize = 8;
	int histBins = (int) (Math.pow(2, 13) - 1);
	// int histBins = (int) (Math.pow(2, 14) - 1);
	int histBinsWindow;

	int histWindowW;

	int contrastBarX;

	int histX;// tivoInfoBarX;
	int histY;// h -10;
	int histAdjustHandleSize;

	int tivoInfoBarX;
	int tivoStatusBarY;
	int userSelectionLowerBoundary;
	int tivoStatusBarTickX;// 5;
	int tivoStatusBarTickYmaster;// 5;
	int tivoStatusBarTickY;// 5;
	int tivoStatusBarTickYsliver;// 5;
	// int tivoStatusBarTickYData = 10;//5;
	int tivoBarYSeparation;

	int tivoGraphicsH2;
	int tivoGraphicsY2; // where
	// the
	// playhead
	// lives

	float glShimScale = 1.39f;//.835f;

	// loop handles
	int loopSelectorHeight;
	int loopSelectorYtop;
	int loopSelectorYbottom;
	int loopSelectorYhandle;
	int loopBoundStartX;
	int loopBoundEndX;

	// individual status bars
	int tivoStatusBarYRay[];

	// tivo status overlay
	int tivoInfoBarY;

	Color statusColors[] = new Color[WC.MODE_COUNT];
	Color uiColors[] = new Color[WC.UI_COLOR_COUNT];

	float uiGlContrastColors[][] = new float[WC.UI_GL_COLOR_COUNT][3];
	// params

	ArrayList paramLists[][];
	int defaultInputSrc = WC.THREAD_LOAD_HDF5R;

	int diffSkip = 2;
	int timelapseSkip = 2;
	int timelapseHistory = 30; // 20
	int timelapseSource = WC.THREAD_DIFF;// WC.THREAD_LOAD_HDF5R;

	int showHistogram = 1;

	// lens - temporary until openGL zoom
	int lensStatus = WC.STATUS_READY;
	int lensX;
	int lensY;
	int magnifierToggle = 0; // flip flop based on cursor
	int magTogYTop;
	int magTogYBottom;

	// map data
	MapLoader map = new MapLoader()

	// GPU

	int inputSrcGPU = WC.THREAD_LOAD_HDF5R;

	int gpuRastPosX = 0;
	int gpuRastPosY = 0;
	int gpuState = 0;

	int GLOBE_DATA_GEODATA = 0; // only render the SCA outlines
	int GLOBE_DATA_INTENSITY = 1; // only render the SCA outlines
	int globeDataMode = GLOBE_DATA_GEODATA;

	// end GPU

	public static void main(String args[]) {

		cvt = new CV_MT_GPU_WIT_1_2();
		cvt.timeAtBoot = System.currentTimeMillis();

		// do this init first
		String conf = null;
		if (args.length > 0) {
			for (int i = 0; i < args.length; i++) {
				if (args[i].equalsIgnoreCase("-conf")) {
					if (args.length > i) {
						conf = args[i + 1];
					}
				}
			}
		}
		// strBdr = "LOADING WIT - RECEIVED ";
		StringBuilder strBdr = new StringBuilder();
		strBdr.append("LOADING WIT - RECEIVED ");
		strBdr.append(args.length);
		strBdr.append(" ARGS");
		System.out.println(strBdr);

		cvt.initMasterConfig(conf);
		cvt.initUIDims();
		cvt.setSize(cvt.viewportX, cvt.viewportY);

		GLProfile.initSingleton(false); // required for running in eclipse
		glProfile = GLProfile.getDefault();

		GLCapabilities c = new GLCapabilities(GLProfile.get(GLProfile.GL2));// new
		// GLCapabilities(p);
		c.setPbufferFloatingPointBuffers(true);
		c.setPbufferRenderToTexture(true);
		// c.setNumSamples(16);
		// c.setRedBits(16);
		// c.setBlueBits(16);
		// c.setGreenBits(16);
		c.setSampleBuffers(true);

		// GLWindow w = GLWindow.create(c);

		cvt.glCanvas = new GLCanvas(c);
		// cvt.glCanvas.set
		cvt.tivoCanvas = new Canvas();

		cvt.glCanvas.addGLEventListener(cvt);

		cvt.loadMapData();

		cvt.loadPlaybackState();
		cvt.loadUserState(); // can override the default config
		// cvt.initMiniMap();
		cvt.initFormats();
		cvt.initWidgets();
		cvt.initPlaybackParams();
		cvt.initOpMasks();
		// cvt.initBiasPerChannel();
		cvt.initSCAselectorGraphics();
		cvt.initOverlayStates();
		cvt.initColorRamps();
		cvt.initWxPolys();

		// cvt.setDefaultCloseOperation();

		cvt.setTitle("Wideband Imagery Tool 1.2.x");

		// cvt.tivoCanvas = new GLJPanel();

		// cvt.tivoCanvas = new GLCanvas();

		cvt.glCanvas.addKeyListener(cvt);
		// cvt.tivoCanvas.addKeyListener(cvt);
		cvt.tivoCanvas.addMouseListener(cvt);
		cvt.tivoCanvas.addMouseMotionListener(cvt);

		cvt.addComponentListener(cvt);

		cvt.initVidExportUI();
		//cvt.initKernelEditorUI();
		cvt.initGLSLEditorUI();

		cvt.setLoadFrames(60, 1, 5);
		
		cvt.setAutoReload(WC.STATUS_OFF,30,30);
		
		cvt.resetLastDrawIndex();

		// cvt.addWindowListener(witWIndowListener);

		GraphicsEnvironment ge = GraphicsEnvironment
				.getLocalGraphicsEnvironment();

		String[] fontNames = ge.getAvailableFontFamilyNames();

		for (int i = 0; i < fontNames.length; i++) {
			// System.out.println(fontNames[i]);
		}

		// fontNameStr = fontNames[9];

		cvt.tivoCanvas.requestFocus();

		cvt.viewportImage = new BufferedImage(cvt.viewportX, cvt.viewportY,
				BufferedImage.TYPE_INT_RGB);
		cvt.viewportImageRot = new BufferedImage(cvt.viewportX, cvt.viewportY,
				BufferedImage.TYPE_INT_RGB);

		cvt.viewportImageOverlay = new BufferedImage(cvt.viewportX,
				cvt.viewportY, BufferedImage.TYPE_INT_ARGB);

		// optimizations
		cvt.g = (Graphics2D) cvt.viewportImage.getGraphics();
		cvt.gb = (Graphics2D) cvt.viewportImageOverlay.getGraphics();
		cvt.gwc = (Graphics2D) cvt.tivoCanvas.getGraphics();

		cvt.graphicComposites = new Composite[12];
		cvt.graphicComposites[c_WORKING] = makeComposite(.6f);
		cvt.graphicComposites[c_LOOP_SELECTION] = makeComposite(.45f);
		cvt.graphicComposites[c_COMPLETE] = makeComposite(1.0f);

		cvt.graphicComposites[c_LATLON_OVERLAY] = makeComposite(.50f);
		cvt.graphicComposites[c_WIDGET] = makeComposite(.8f);

		// imprContrastRay = new ImpContrastThread[maxLoaderThreads];

		// construct idle threads

		cvt.resetThreads();

		cvt.restoreState(cvt.restoreStateMode);

		// thread params

		cvt.initTimeline();
		cvt.initTimelineRefs();
		cvt.initPriorities();
		cvt.initTimeouts();
		cvt.initOpBuffers();
		cvt.initLayerProperties();
		cvt.initParamLists();
		cvt.initTivoBars();
		cvt.initUserContrast();
		cvt.initGraphicsElements();
		cvt.initFrameLists();


		cvt.scaOffsets = ImProcThread.initSCAoffsets(1);

		// UI - with enabled ops
		cvt.populateMenus(cvt);
		cvt.initGlItems();

		// init UI bits

		// default color

		for (int i = 0; i < WC.MODE_COUNT; i++) {
			cvt.statusColors[i] = new Color(40, 80, 255);
		}

		cvt.initColors();

		cvt.userFlight = 0; // initially focus on flight 33 - don't reset this,
		// only
		// user toggles

		cvt.initUserElements();

		final Animator a = new Animator();
		a.setRunAsFastAsPossible(true);
		a.add(cvt.glCanvas);

		cvt.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				a.stop();
				cvt.tivoExit();
			}
		});

		cvt.add(cvt.glCanvas);
		cvt.glCanvas.setVisible(true);

		cvt.tivoCanvas.setVisible(true);
		cvt.add(cvt.tivoCanvas);

		a.start();

		cvt.setVisible(true);
		cvt.validate();

		if (cvt.openOnLaunch == WC.STATUS_ON){
			cvt.openFiles();
		}
		// cvt.display(cvt.glCanvas);


		cvt.userInterfaceInfoStr = "WIT INITIALIZED";

		cvt.glCanvas.requestFocus();
	}

	public void writeBiasPerChannel() {
		String biasFileStr = "";

		String flightTagStr = "<FLIGHT>";
		String flightEndTagStr = "</FLIGHT>";
		String scaTagStr = "<SCA>";
		String scaEndTagStr = "</SCA>";
		String scanDirTagStr = "<SCAN_DIR>";
		String scanDirEndTagStr = "</SCAN_DIR>";
		String channelTagStr = "<CHANNEL>";
		String channelEndTagStr = "</CHANNEL>";
		String biasTagStr = "<BIAS>";
		String biasEndTagStr = "</BIAS>";

		for (int f = 0; f < WC.TOTAL_FLIGHTS; f++) {

			biasFileStr += flightTagStr;
			biasFileStr += f;
			biasFileStr += flightEndTagStr;
			biasFileStr += "/n";

			for (int s = 0; s < WC.TOTAL_SCAS; s++) {

				biasFileStr += scaTagStr;
				biasFileStr += s;
				biasFileStr += scaEndTagStr;
				biasFileStr += "/n";

				for (int d = 0; d < 2; d++) {

					biasFileStr += scanDirTagStr;
					biasFileStr += d;
					biasFileStr += scanDirEndTagStr;
					biasFileStr += "/n";

					for (int c = 0; c < WC.SCA_CHANNELS; c++) {

						biasFileStr += channelTagStr;
						biasFileStr += c;
						biasFileStr += channelEndTagStr;
						biasFileStr += "/n";

						biasFileStr += biasTagStr;
						biasFileStr += "intensityBiasPerScaPerChannel[f][s][c][d]";
						biasFileStr += biasEndTagStr;
						biasFileStr += "/n";
					}
				}
			}
		}

		// save file
	}

	public void initBiasPerChannel() {
		System.out.println("LOADING CHANNEL BIASES");

		File loadFile = new File(intensityBiasFileStr);
		BufferedReader bin;

		ArrayList tagList = new ArrayList();

		tagList.add("<FLIGHT>");
		tagList.add("<SCA>");
		tagList.add("<SCAN_DIR>");
		tagList.add("<CHANNEL>");
		tagList.add("<BIAS>");

		try {
			bin = new BufferedReader(new FileReader(loadFile));

			// load the file
			String fileContents = "";

			while (bin.ready()) {
				String ln = bin.readLine();
				fileContents = ln;

				int currFlight = WC.STATUS_ERROR;
				int currSca = WC.STATUS_ERROR;
				int currChannel = WC.STATUS_ERROR;
				int currScanDir = WC.STATUS_ERROR;
				int currBias = WC.STATUS_ERROR;

				int writeValue = WC.STATUS_ERROR;

				for (int i = 0; i < tagList.size(); i++) {

					String identifier = (String) tagList.get(i);
					String closure = identifier.substring(0, 1) + "/"
							+ identifier.substring(1);
					int itemStart = fileContents.indexOf(identifier)
							+ identifier.length();
					int itemEnd = fileContents.indexOf(closure);
					String dataStr = fileContents.substring(itemStart, itemEnd);

					dataStr.trim();

					if (identifier.equalsIgnoreCase("<FLIGHT>")) {
						currFlight = (Integer.parseInt(dataStr));
					} else if (identifier.equalsIgnoreCase("<SCA>")) {
						currSca = (Integer.parseInt(dataStr));
					} else if (identifier.equalsIgnoreCase("<CHANNEL>")) {
						currChannel = (Integer.parseInt(dataStr));
					} else if (identifier.equalsIgnoreCase("<SCAN_DIR>")) {
						currScanDir = (Integer.parseInt(dataStr));
					} else if (identifier.equalsIgnoreCase("<BIAS>")) {
						currBias = (Integer.parseInt(dataStr));
						writeValue = WC.STATUS_READY;
					}

					if (writeValue == WC.STATUS_READY
							&& currFlight != WC.STATUS_ERROR
							&& currSca != WC.STATUS_ERROR
							&& currScanDir != WC.STATUS_ERROR
							&& currChannel != WC.STATUS_ERROR) {
						writeValue = WC.STATUS_ERROR;
						intensityBiasPerScaPerChannel[currFlight][currSca][currChannel][currScanDir] = currBias;
					}
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void initUIDims() {

		if (viewportY < 1200) {
			glContrastControlExpoH = 25;
			glContrastControlLinearH = 16;
			glContrastControlH = 400;
			
			glContrastControlLinearH = (float) glContrastControlH
			/ (float) (glContrastColorBands + 1);
			
			glContrastControlLinearDiffH = glContrastControlLinearH
			* ((float) WC.CONTRAST_UI_HARD_LIMIT / (float) glContrastControlH);
	
		} else {
			glContrastControlExpoH = 50;
			glContrastControlH = 1100;

			glContrastControlLinearH = (float) glContrastControlH
					/ (float) (glContrastColorBands + 1);
			// glContrastControlLinearDiffH = glContrastControlLinearH *
			// ((float) WC.DATA_RANGE_HARD_LIMIT / (float) glContrastControlH);
			glContrastControlLinearDiffH = glContrastControlLinearH
					* ((float) WC.CONTRAST_UI_HARD_LIMIT / (float) glContrastControlH);
			// glContrastControlLinearH = WC.CONTRAST_UI_HARD_LIMIT
		}

		minPanX = (int) (-768f * 8.2f + viewportX);// (int)(-768f * 4.85f);
		maxPanX = 0;
		minPanY = -4000 + viewportY;
		maxPanY = 0;

		timelineCenterX = viewportX / 4;

		userPanOffset[GOAL][WC.X] = -WC.SCA_CHANNELS * (SCA_FOCUS - 1); // default
		// to
		// SCAs 3+4
		if (minPanX > userPanOffset[GOAL][WC.X]) {
			userPanOffset[GOAL][WC.X] = minPanX;
		}

		tivoStatusBarY = viewportY - 240;// viewportTileY*1 + 80;
		tivoStatusBarX = 160;// viewportTileX;
		tivoInfoBarX = 20;
		tivoInfoBarY = viewportY - 60;

		knobBarX = 558;//580; //1200; 2560

		knobLabelY = 80;
		knobValueY = 60;
		knobDeltaX1 = 0;
		knobDeltaX2 = 118;
		knobDeltaX3 = 214;
		knobDeltaX4 = 317;
		knobDeltaX5 = 418;
		
		float knobScale = 1.0f;

		scaOpMaskX = tivoStatusBarX - 32;
		scaOpMaskW = 30;

		// contrast slider bars
		contrastBarTickX = 1;
		contrastBarSpaceX = 1;

		// loop handles
		loopSelectorHeight = 18;
		loopSelectorYbottom = viewportY-160; // !! AFWA
		loopSelectorYtop = viewportY-200; // !! AFWA
		loopSelectorYhandle = loopSelectorYbottom + loopSelectorHeight;
		loopBoundStartX = tivoStatusBarX + (int) userTimelineOffset[CURRENT]
				+ userSelection[WC.START][WC.T];
		loopBoundEndX = tivoStatusBarX + (int) userTimelineOffset[CURRENT]
				+ userSelection[WC.END][WC.T];

		// histogram / contrast

		contrastBarX = tivoInfoBarX;
		histWindowW = histBins / histClusterSize;
		histY = viewportY - 80;// viewportY - 120;// h -10;
		histX = contrastBarX;// tivoInfoBarX;

		histAdjustHandleSize = 20;
		// contrastBarX = viewportX - histWindowW - 30;
		histBinsWindow = histBins; // modify for smaller window

		tivoGraphicsH2 = 80;
		tivoGraphicsY2 = tivoStatusBarY + tivoGraphicsH2 - 3; // where
		userSelectionLowerBoundary = tivoStatusBarY - 10;
		tivoStatusBarTickX = 1;
		tivoStatusBarTickYmaster = 24;
		tivoStatusBarTickY = 8;
		tivoStatusBarTickYsliver = 3;
		tivoBarYSeparation = tivoStatusBarTickY + 1 + 5;

		// lens
		lensX = 200;
		lensY = 200;
		magTogYTop = 500;
		magTogYBottom = 800;
		
		// coordSpace
		for (int i=0; i<WC.COORDINATES_MODE_MAX; i++){
			if (coordinateSpaceLoadMask[i] == WC.STATUS_ON){
				coordinateMode = i;
			}
		}
	}

	public void initMasterConfig(String confFile) {
		// 
		if (confFile == null) {
			confFile = masterConfigFileStr;
		}
		File loadFile = new File(confFile);

		ArrayList tagList = new ArrayList();

		tagList.add("<MAX_THREADS_QUEUED>");
		tagList.add("<MAX_THREADS_ACTIVE>");
		tagList.add("<DISPLAY_WIDTH>");
		tagList.add("<DISPLAY_HEIGHT>");
		tagList.add("<SCA_FOCUS>");
		tagList.add("<INPUT_DIR>");
		tagList.add("<INCOMING_DIR>");
		tagList.add("<OUTPUT_DIR>");
		tagList.add("<RESOURCE_DIR>");
		tagList.add("<MAP_DATA_DIR>");
		tagList.add("<MAP_GRAPHIC>");

		tagList.add("<OPEN_ON_LAUNCH>");
		
		tagList.add("<FFMPEG_SCRATCH_DIR>");
		tagList.add("<GPU_INTERPOLATE_PIXELS>");
		tagList.add("<DEFAULT_CLASSIFICATION_LABEL>");
		tagList.add("<DEFAULT_TITLE_LABEL>");
		tagList.add("<WEB_HELP_LOCATION>");
		tagList.add("<GLOBE_LINE_SPACING_LON>");
		tagList.add("<GLOBE_LINE_SPACING_LAT>");
		tagList.add("<WORKAROUND_GPU_HDR>");
		tagList.add("<WORKAROUND_AUTO_CONTRAST");
		tagList.add("<TILE_SIZE_X>");
		tagList.add("<TILE_SIZE_Y>");
		tagList.add("<UI_AUTO_SCROLL>");

		tagList.add("<AUTO_RELOAD_ENABLED>");
		tagList.add("<AUTO_RELOAD_TIMER_SECONDS>");
		tagList.add("<AUTO_RELOAD_BUFFER_SECONDS>");
		tagList.add("<INCOMING_DATA_MONITOR_LOCAL_TIME_OFFSET>");
		tagList.add("<INCOMING_DATA_MONITOR_ENABLED>");
		tagList.add("<INCOMING_DATA_MONITOR_PREROLL_SECONDS>");
		tagList.add("<INCOMING_DATA_MONITOR_UPDATE_MS>");

		tagList.add("<COORDINATES_GLOBE>");
		tagList.add("<COORDINATES_MERCATOR>");
		tagList.add("<COORDINATES_SENSOR>");
		
		tagList.add("<DEFAULT_GLOBE_OPACITY>");

		int loadedItemChecklist[] = new int[tagList.size()];
		String loadedItemStr[] = new String[tagList.size()];

		try {
			if (loadFile != null) {
				System.out.println("LOADING WIT CONFIG FILE... "
						+ loadFile.getAbsoluteFile());
				BufferedReader bin = new BufferedReader(
						new FileReader(loadFile));

				// load the file
				String fileContents = "";

				while (bin.ready()) {
					String ln = bin.readLine();
					fileContents += ln;
				}

				for (int i = 0; i < tagList.size(); i++) {

					String identifier = (String) tagList.get(i);
					String closure = identifier.substring(0, 1) + "/"
							+ identifier.substring(1);
					int itemStart = fileContents.indexOf(identifier)
							+ identifier.length();
					int itemEnd = fileContents.indexOf(closure);
					
					if (itemStart>=0 && itemEnd >=0){
					String dataStr = fileContents.substring(itemStart, itemEnd);

					dataStr.trim();

					// need to clean up matching of tags and WIT variables
					if (identifier.equalsIgnoreCase("<MAX_THREADS_QUEUED>")) {
						MAX_THREADS_QUEUED = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<MAX_THREADS_ACTIVE>")) {
						MAX_THREADS_ACTIVE = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<DISPLAY_WIDTH>")) {
						viewportX = (Integer.parseInt(dataStr));
						viewportGlX = viewportX;

						aspectRatio = (float) viewportGlY / (float) viewportGlX;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<DISPLAY_HEIGHT>")) {
						viewportY = (Integer.parseInt(dataStr));
						viewportGlY = viewportY;// -300;

						aspectRatio = (float) viewportGlY / (float) viewportGlX;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<SCA_FOCUS>")) {
						SCA_FOCUS = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<DEFAULT_CLASSIFICATION_LABEL>")) {
						productClassificationLabelStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<DEFAULT_TITLE_LABEL>")) {
						productTitleLabelStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<FFMPEG_SCRATCH_DIR>")) {
						defaultFfmpegScratchDirStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<INCOMING_DIR>")) {
						incomingDataDirStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<INPUT_DIR>")) {
						defaultLoadDirStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<OUTPUT_DIR>")) {
						productTitleLabelStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<RESOURCE_DIR>")) {
						defaultResourceDirStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<MAP_DATA_DIR>")) {
						defaultMapDataDirStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<MAP_GRAPHIC>")) {
						defaultMapGraphicStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<GLOBE_LINE_SPACING_LON>")) {
						defaultGlobeLineLonSpacing = Float.parseFloat(dataStr);
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<GLOBE_LINE_SPACING_LAT>")) {
						defaultGlobeLineLatSpacing = Float.parseFloat(dataStr);
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<WEB_HELP_LOCATION>")) {
						webHelpLocation = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<WORKAROUND_GPU_HDR>")) {
						WORKAROUND_GPU_HDR = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<WORKAROUND_AUTO_CONTRAST>")) {
						WORKAROUND_AUTO_CONTRAST = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<UI_AUTO_SCROLL>")) {
						lockPlayhead = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<COORDINATES_SENSOR>")) {
						coordinateSpaceLoadMask[WC.COORDINATES_SENSOR] = (Integer
								.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<COORDINATES_MERCATOR>")) {
						coordinateSpaceLoadMask[WC.COORDINATES_MERCATOR] = (Integer
								.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<COORDINATES_GLOBE>")) {
						coordinateSpaceLoadMask[WC.COORDINATES_GLOBE] = (Integer
								.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<OPEN_ON_LAUNCH>")) {
						openOnLaunch = (Integer
								.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<TILE_SIZE_X>")) {
						TILE_SIZE_X = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<TILE_SIZE_Y>")) {
						TILE_SIZE_Y = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<GPU_INTERPOLATE_PIXELS>")) {
						GPU_INTERPOLATE_PIXELS = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<AUTO_RELOAD_ENABLED>")) {
						autoReloadState = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<AUTO_RELOAD_BUFFER_SECONDS>")) {
						autoReloadBufferSeconds = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<AUTO_RELOAD_TIMER_SECONDS>")) {
						autoReloadTimerSeconds = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<INCOMING_DATA_MONITOR_ENABLED>")) {
						timelineCheckEnabled = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					}  else if (identifier
							.equalsIgnoreCase("<INCOMING_DATA_MONITOR_PREROLL_SECONDS>")) {
						timelineCheckPrerollSeconds = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<INCOMING_DATA_MONITOR_UPDATE_MS>")) {
						timelineCheckNewFilesTimeDelta = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<INCOMING_DATA_MONITOR_LOCAL_TIME_OFFSET>")) {
						timelineCheckTimezoneOffset = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<DEFAULT_GLOBE_OPACITY>")) {
						globe_opacity = (Float.parseFloat(dataStr));
						loadedItemChecklist[i] = 1;
					}

					if (loadedItemChecklist[i] == 1) {
						loadedItemStr[i] = dataStr;
					}
					
					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		for (int i = 0; i < loadedItemChecklist.length; i++) {
			System.out.println("   LOADED SETTINGS FOR "
					+ (String) tagList.get(i) + " - " + loadedItemStr[i]);
		}
	}

	public void histogramZoom(int dir) {
		if (dir == 1) { // in
			histogramZoomLevel *= 2;
		} else if (dir == -1) { // out
			histogramZoomLevel /= 2;
		}
		if (histogramZoomLevel < histogramMinZoomLevel) {
			histogramZoomLevel = histogramMinZoomLevel;
		}
		if (histogramZoomLevel > histogramMaxZoomLevel) {
			histogramZoomLevel = histogramMaxZoomLevel;
		}
		System.out.println("histogram zoom level " + histogramZoomLevel);
		contrastBarSpaceX = histogramZoomLevel;
		histClusterSize = histogramMaxZoomLevel / histogramZoomLevel;
	}

	public void initColors() {
		statusColors[WC.THREAD_LOAD] = new Color(190, 180, 180);
		statusColors[WC.THREAD_LOAD_HDF5R] = new Color(170, 180, 190);
		statusColors[WC.THREAD_CONV] = new Color(80, 120, 255);// new
		// Color(255,20,0);
		statusColors[WC.THREAD_SEGMENT] = new Color(40, 80, 255);
		statusColors[WC.THREAD_DIFF] = new Color(40, 80, 255);
		statusColors[WC.THREAD_TIMELAPSE] = new Color(40, 80, 255);
		statusColors[WC.THREAD_FILT] = new Color(255, 100, 255);
		statusColors[WC.THREAD_THRS] = new Color(0, 200, 50);
		statusColors[WC.THREAD_CONTRAST] = new Color(0, 140, 250);// new
		// Color(110,200,0);
		statusColors[WC.THREAD_HISTOGRAM] = new Color(0, 140, 250);
		statusColors[WC.THREAD_REGISTRATION] = new Color(0, 140, 250);
		statusColors[WC.THREAD_EXPORT_VIDEO] = new Color(110, 0, 0);
		statusColors[WC.THREAD_EXPORT_IMAGES] = new Color(110, 0, 0);
		// statusColors[WC.THREAD_HISTOGRAM] = new Color(200,100,0);
		// statusColors[WC.THREAD_INTERNAL] = new Color(0, 200, 50);
		// statusColors[WC.THREAD_LOAD] = Color.WHITE;

		uiColors[WC.COLOR_TIVO_TEXT_HEADER] = new Color(255, 255, 255);

		uiColors[WC.COLOR_TIVO_PLAYHEAD] = new Color(255, 255, 255);
		uiColors[WC.COLOR_TIVO_SELECTION_WORKING] = new Color(255, 20, 0);
		uiColors[WC.COLOR_TIVO_SELECTION_COMPLETE] = new Color(190, 0, 0);

		uiColors[WC.COLOR_TIVO_PLAYHEAD_PEER] = new Color(255, 255, 255);
		uiColors[WC.COLOR_TIVO_PLAYHEAD_LOCKED] = new Color(255, 255, 100);

		// uiColors[WC.COLOR_HIST_IN] = new Color(255,255,0);
		// uiColors[WC.COLOR_HIST_OUT] = new Color(255,100,0);
		uiColors[WC.COLOR_HIST_IN] = new Color(0, 140, 250);
		uiColors[WC.COLOR_HIST_OUT] = new Color(40, 80, 255);

		uiGlContrastColors[WC.COLOR_GL_HIST_FOCUS][WC.R] = 0;
		uiGlContrastColors[WC.COLOR_GL_HIST_FOCUS][WC.G] = 1f;
		uiGlContrastColors[WC.COLOR_GL_HIST_FOCUS][WC.B] = 0;

		uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.R] = 0;
		uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.G] = .313f;// .55f;
		uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.B] = 1f;

		uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.R] = .3f;// .157f;
		uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.G] = 0f;// .3f;
		uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.B] = .7f;// .9f;

		uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.R] = 0f;// .9f;
		uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.G] = 1f;// .9f;
		uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.B] = 0f;// .9f;

		uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.R] = 0f;// .9f;
		uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.G] = .55f;// .9f;
		uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.B] = 1f;// .9f;

		uiGlContrastColors[WC.COLOR_GL_ACCENT3][WC.R] = 0f;// .9f;
		uiGlContrastColors[WC.COLOR_GL_ACCENT3][WC.G] = .3f;// .9f;
		uiGlContrastColors[WC.COLOR_GL_ACCENT3][WC.B] = 1f;// .9f;

		uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.R] = .6f;// .9f;
		uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.G] = .1f;// .9f;
		uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.B] = 1f;// .9f;
		

		uiColors[WC.COLOR_TIVO_FILTER_REGION_COMPLETE] = new Color(0, 200, 0);
		uiColors[WC.COLOR_TIVO_FILTER_REGION_WORKING] = new Color(0, 200, 0);

		uiColors[WC.COLOR_TIVO_TIMELINE_EMPTY] = new Color(60, 60, 70); // can't
		// load
		// here
		uiColors[WC.COLOR_TIVO_TIMELINE_READY] = new Color(40, 80, 255); // can
		// load
		// here
		uiColors[WC.COLOR_TIVO_TIMELINE_WORKING] = new Color(0, 140, 250); // loading
		uiColors[WC.COLOR_TIVO_TIMELINE_COMPLETE] = new Color(0, 255, 0); // loaded
		uiColors[WC.COLOR_TIVO_TIMELINE_CALLOUT1] = new Color(80, 0, 200); // non
		// segment0

		uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_OLD] = new Color(0, 90, 0);
		uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_INFO] = new Color(0, 255, 0);
		uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_NEW] = new Color(200, 200, 200);
		uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_SELECTED_REAL] = new Color(255,
				50, 0);
		uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_SELECTED_INFO] = new Color(0,
				255, 0);

		// missing data in the files
		uiColors[WC.COLOR_TIVO_TIMELINE_MISSING_GEOLOCATION] = new Color(255,
				30, 0);
		uiColors[WC.COLOR_TIVO_TIMELINE_MISSING_TIME] = new Color(255, 30, 0);
		uiColors[WC.COLOR_TIVO_TIMELINE_MISSING_INTENSITIES] = new Color(255,
				30, 0);

		uiColors[WC.COLOR_TIVO_SCA_SELECT_ON] = new Color(0, 230, 0);
		uiColors[WC.COLOR_TIVO_SCA_SELECT_OFF] = new Color(80, 80, 80);
		uiColors[WC.COLOR_TIVO_SCA_SELECT_SWIR] = new Color(255, 255, 255);
		uiColors[WC.COLOR_TIVO_SCA_SELECT_MWIR] = new Color(0, 0, 250);
		uiColors[WC.COLOR_TIVO_SCA_SELECT_STG] = new Color(80, 0, 200);
	}

	public void initFrameLists() {
		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				witFrameList[flight][k] = new ArrayList();
			}
		}
	}

	public void initMiniMap() {

		miniMapSize[CURRENT][WC.X] = (int) (miniMapScale * (8.2f * 768f));
		miniMapSize[CURRENT][WC.Y] = (int) (miniMapScale * 4000f);
		miniMapPos[CURRENT][WC.X] = viewportX - miniMapSize[CURRENT][WC.X] - 20;
		miniMapPos[CURRENT][WC.Y] = viewportY - miniMapSize[CURRENT][WC.Y] - 80;

		miniMapInsetPos[CURRENT][WC.X] = 0;
		miniMapInsetPos[CURRENT][WC.Y] = 0;
		miniMapInsetSize[CURRENT][WC.X] = (int) (miniMapScale * viewportX);
		;
		miniMapInsetSize[CURRENT][WC.Y] = (int) (miniMapScale * viewportY);
		;

		// globe
		miniGlobeSize[CURRENT][WC.X] = (int) (miniGlobeScale * (360f));
		miniGlobeSize[CURRENT][WC.Y] = (int) (miniGlobeScale * 180f);
		miniGlobePos[CURRENT][WC.X] = viewportX - miniMapSize[CURRENT][WC.X]
				- 20 - miniGlobeSize[CURRENT][WC.X] - 20;
		miniGlobePos[CURRENT][WC.Y] = viewportY - miniGlobeSize[CURRENT][WC.Y]
				- 80;

		BufferedImage tempImage = loadImageBI(defaultMapGraphicStr);
		miniGlobeImage = new BufferedImage((int) (miniGlobeScale * (360f)),
				(int) (miniGlobeScale * (180f)), BufferedImage.TYPE_INT_RGB);
		Graphics2D gmini = (Graphics2D) miniGlobeImage.getGraphics();

		gmini.setRenderingHint(RenderingHints.KEY_RENDERING,
				RenderingHints.VALUE_RENDER_QUALITY);
		gmini.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
				RenderingHints.VALUE_INTERPOLATION_BICUBIC);

		int nudge = 1;
		for (int yOff = -nudge; yOff <= nudge; yOff++) {
			for (int xOff = -nudge; xOff <= nudge; xOff++) {
				gmini.drawImage(tempImage, 0, 0,
						(int) (miniGlobeScale * (360f)) + xOff,
						(int) (miniGlobeScale * (180f)) + yOff, null);
			}
		}
	}

	public void initOverlayStates() {
		for (int i = 0; i < WC.OVERLAY_GLOBE_COUNT; i++) {
			overlayStates[i] = false;
		}

		overlayStates[WC.OVERLAY_GLOBE_BOUNDARIES] = true;
		
		overlayStates[WC.OVERLAY_GLOBE_LINES] = true;
	}

	public void initWidgets() {
		for (int i = 0; i < WC.MAX_WIDGETS; i++) {
			widgetVisibility[i] = 0;
		}

		widgetVisibility[WC.WIDGET_MINIMAP] = 0;
		widgetVisibility[WC.WIDGET_MINIGLOBE] = 0;

		widgetVisibility[WC.WIDGET_HISTOGRAM] = 1;
	}

	public void initPlaybackParams() {
		for (int f = 0; f < WC.TOTAL_FLIGHTS; f++) {
			for (int i = 0; i < WC.SCAN_SEQ_INDEX_MAX_VAL; i++) {
				playbackScanSeqIndexMask[f][i] = WC.STATUS_ON;

				sosScanSeqIndexLabel[i] = "";
			}
		}
	}

	public void initFormats() {
		for (int i = 0; i < outputFormatExtStr.length; i++) {
			outputFormatExtStr[i] = new String("");
		}

		for (int i = 0; i < outputOptionMask.length; i++) {
			outputOptionMask[i] = false;
		}

		outputOptionMask[WC.OPTION_VIDEO_LOOP] = true;

		outputFormatExtStr[WC.FORMAT_PNG] = ".png";
		outputFormatExtStr[WC.FORMAT_JPG] = ".jpg";
		outputFormatExtStr[WC.FORMAT_MP4] = ".mp4";
		outputFormatExtStr[WC.FORMAT_MPG] = ".mpg";
		outputFormatExtStr[WC.FORMAT_WMV] = ".wmv";

		outputFormatMask[WC.FORMAT_MPG] = true;
		outputFormatMask[WC.FORMAT_WMV] = true;
		outputFormatMask[WC.FORMAT_PNG] = true;
	}

	public void initGraphicsElements() {
		stroke1 = new BasicStroke(pointerW1 * 2 + 1);
		stroke2 = new BasicStroke(1);

		strokeWidth1 = new BasicStroke(1);
		strokeWidth2 = new BasicStroke(2);
		strokeWidth3 = new BasicStroke(3);

		// gMain = (Graphics2D) viewportImage.getGraphics();

		graphicComposites[c_WORKING] = makeComposite(.6f);
		graphicComposites[c_LOOP_SELECTION] = makeComposite(.45f);
		graphicComposites[c_COMPLETE] = makeComposite(1.0f);

		graphicsStatus = WC.STATUS_READY;
	}

	public void initVidExportUI() {
		vidExportUI = new VideoExportUI();

		vidExportUI.init();
		vidExportUI.securityLabel.setText(productClassificationLabelStr);
		vidExportUI.titleLabel.setText(productTitleLabelStr);

		vidExportUI.setLocation(400, 400);

		vidExportUI.cvt = cvt;
	}

	public void initKernelEditorUI() {
		kernelEditorUI = new KernelEditorUI();

		kernelEditorUI.init();

		kernelEditorUI.setLocation(400, 400);

		kernelEditorUI.cvt = cvt;
		kernelEditorUI.paintCanvas();
	}

	public void initGLSLEditorUI() {
		glslEditorUI = new GLSLEditorUI();

		glslEditorUI.init();

		glslEditorUI.setLocation(400, 400);

	}

	public void initSCAselectorGraphics() {
		int selectorGraphicW = 200;
		int selectorGraphicH = 200;
		int selectorGraphicMargin = 20;
		int selectorGraphicEvenOddOffset = -100;
		int selectorGraphicMBoffset = selectorGraphicH + selectorGraphicMargin; // offset
		// STG
		// and
		// MWIR
		// using dimensions for 30" monitor - revise to make dynamic if needed
		int selectorGraphicWcenter = viewportX / 2
				- (3 * (selectorGraphicW + selectorGraphicMargin));
		int selectorGraphicHcenter = viewportY / 2 - (2 * (selectorGraphicH));
		for (int i = 0; i < 6; i++) {
			scaSelectorGraphic[i][WC.X] = i
					* (selectorGraphicW + selectorGraphicMargin)
					+ selectorGraphicWcenter;
			scaSelectorGraphic[i][WC.Y] = (selectorGraphicH + selectorGraphicMargin)
					+ selectorGraphicHcenter;
			if (i % 2 == 0) {
				scaSelectorGraphic[i][WC.Y] += selectorGraphicEvenOddOffset;
			}
		}
		scaSelectorGraphic[6][WC.X] = scaSelectorGraphic[1][WC.X];
		scaSelectorGraphic[6][WC.Y] = scaSelectorGraphic[1][WC.Y]
				- selectorGraphicMBoffset;

		scaSelectorGraphic[7][WC.X] = scaSelectorGraphic[3][WC.X];
		scaSelectorGraphic[7][WC.Y] = scaSelectorGraphic[3][WC.Y]
				- selectorGraphicMBoffset;

		for (int i = 0; i < WC.TOTAL_SCAS; i++) {
			scaSelectorGraphic[i][2] = selectorGraphicW;
			scaSelectorGraphic[i][3] = selectorGraphicH;
		}

		// set bands and strings
		for (int i = 0; i < 6; i++) {
			scaSelectorBand[i] = WC.COLOR_TIVO_SCA_SELECT_SWIR;
			scaSelectorString[i] = "SCA " + (i + 1) + " - SWIR";
		}
		scaSelectorBand[6] = WC.COLOR_TIVO_SCA_SELECT_STG;
		scaSelectorString[6] = "SCA " + (7) + " - STG";

		scaSelectorBand[7] = WC.COLOR_TIVO_SCA_SELECT_MWIR;
		scaSelectorString[7] = "SCA " + (8) + " - MWIR";
	}

	public void initUserElements() {

		userContrastCPList = new ArrayList();

		int compassSize = 50;
		compassImage = new BufferedImage(compassSize, compassSize,
				BufferedImage.TYPE_INT_ARGB);
		compassImageRot = new BufferedImage(compassSize, compassSize,
				BufferedImage.TYPE_INT_ARGB);

		Graphics2D g = (Graphics2D) compassImage.getGraphics();

		g.setColor(statusColors[WC.THREAD_DIFF]);
		g.fillRect(compassSize / 2 - 1, 1, 2, compassSize - 1);
		g.fillRect(1, compassSize / 2 - 1, compassSize - 1, 2);

		g.setColor(Color.GREEN);
		g.fillRect(compassSize / 2 - 2, compassSize / 2, 4, compassSize - 1);

		int radiusComp = 12;
		
		g.setColor(statusColors[WC.THREAD_DIFF]);
		g.fillOval(compassSize / 2 - radiusComp, compassSize / 2 - radiusComp,
				radiusComp * 2, radiusComp * 2);

		g.setColor(Color.WHITE);
		g.drawString("N", compassSize / 2 - 4, 30);
		g.drawString("N", compassSize / 2 - 5, 30);

		
		
	}

	public void initOpMasks() {
		// opMask determines processing done dynamically during playback
		for (int i = 0; i < opMask.length; i++) {
			opMask[i] = false; // default is all off
			filterRegionReqMask[i] = 0; // by default, a filter region is NOTE
			// required to keep from execution on
			// entire image
			// if (i< WC.THREAD_GPU_FRAG_DIFF){
			// opReqCPU[i] = true;
			// } else {
			opReqCPU[i] = false;
			// }
		}
		opMask[WC.THREAD_LOAD] = false;
		opMask[WC.THREAD_DIFF] = false; // 1
		opMask[WC.THREAD_FEAT] = false;
		opMask[WC.THREAD_THRS] = false;
		opMask[WC.THREAD_CONV] = false;
		opMask[WC.THREAD_DEJITTER] = false;
		opMask[WC.THREAD_SEGMENT] = false;// 1;
		opMask[WC.THREAD_FILT] = false;
		opMask[WC.THREAD_MON] = false;
		opMask[WC.THREAD_HISTOGRAM] = false;
		opMask[WC.THREAD_HISTOGRAM_EQ] = false;
		opMask[WC.THREAD_TEMPORAL] = false;// 1;
		opMask[WC.THREAD_HISTOGRAM] = false;
		opMask[WC.THREAD_HISTOGRAM_EQ] = false;
		opMask[WC.THREAD_DEJITTER_ADV] = false;
		opMask[WC.THREAD_CONTRAST] = false;
		opMask[WC.THREAD_PREFILTER] = false;

		filterRegionReqMask[WC.THREAD_DIFF] = 1;
		filterRegionReqMask[WC.THREAD_FEAT] = 1;
		filterRegionReqMask[WC.THREAD_DEJITTER] = 1;
		filterRegionReqMask[WC.THREAD_TEMPORAL] = 1;
		filterRegionReqMask[WC.THREAD_CONTRAST] = 1;
		filterRegionReqMask[WC.THREAD_HISTOGRAM] = 1;
		filterRegionReqMask[WC.THREAD_REGISTRATION] = 1;
		filterRegionReqMask[WC.THREAD_PREFILTER] = 0;
		filterRegionReqMask[WC.THREAD_SCAN_DIR_Y_OFFSET] = 0;
	}



	// set which processed images are used for video out
	public int[] getVideoExportSelection() {

		int channels[] = new int[WC.MODE_COUNT];

		return channels;
	}

	public void resetContrastEtc() {

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {

			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				for (int i = 0; i < witFrameList[flight][k].size(); i++) {

					WITFrame wfi = (WITFrame) witFrameList[flight][k].get(i);
					wfi.layerStatus[WC.THREAD_CONTRAST] = WC.THREAD_STATUS_READY;
					// wfi.biRay[WC.THREAD_CONTRAST] = null;

					// reset any layers which depend upon it - need to automate
					wfi.layerStatus[WC.THREAD_DIFF] = WC.THREAD_STATUS_READY;
					// wfi.biRay[WC.THREAD_DIFF] = null;
					wfi.layerStatus[WC.THREAD_TIMELAPSE] = WC.THREAD_STATUS_READY;
					// wfi.biRay[WC.THREAD_TIMELAPSE] = null;
					wfi.layerStatus[WC.THREAD_REGISTRATION] = WC.THREAD_STATUS_READY;
					// wfi.biRay[WC.THREAD_REGISTRATION] = null;

					witFrameList[flight][k].remove(i);
					witFrameList[flight][k].add(i, wfi);
				}
			}
		}
	}


	public void populateMenus(CV_MT_GPU_WIT_1_2 cvt) {

		MenuBar menuBar = new MenuBar();
		// JMenuBar menuBar = new JMenuBar();
		cvt.setMenuBar(menuBar);

		// JMenu menuSession = new JMenu("Session");
		Menu menuSession = new Menu("Session");
		Menu menuFile = new Menu("File");
		Menu menuPlayback = new Menu("Playback");
		Menu menuContrast = new Menu("Contrast");
		Menu menuEdit = new Menu("Edit");
		Menu menuFilter = new Menu("Filter");
		Menu menuGlobe = new Menu("3D Globe");
		Menu menuStream = new Menu("Stream");
		Menu menuShare = new Menu("Sharing");
		Menu menuHelp = new Menu("Help");

		ItemListener actionListenerGlobeCityData = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int layer = WC.OVERLAY_GLOBE_CITIES;
				if (overlayStates[layer] == false) {
					overlayStates[layer] = true;
				} else {
					overlayStates[layer] = false;
				}
			}
		};

		ItemListener actionListenerGlobeBoundaryData = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int layer = WC.OVERLAY_GLOBE_BOUNDARIES;
				if (overlayStates[layer] == false) {
					overlayStates[layer] = true;
				} else {
					overlayStates[layer] = false;
				}
			}
		};

		

		ItemListener actionListenerGlobeTransportData = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int layer = WC.OVERLAY_GLOBE_TRANSPORT;
				if (overlayStates[layer] == false) {
					overlayStates[layer] = true;
				} else {
					overlayStates[layer] = false;
				}

			}
		};

		// gain controls
		ActionListener actionListenerLTGainButton = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doGain();
			}
		};

		// HELP
		ActionListener actionListenerHelpWeb = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showWebHelp();
			}
		};
		ActionListener actionListenerHelpKeyboard = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showKeyboardHelp();
			}
		};

		ActionListener actionListenerFilterMetadata = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				toggleOpMask(WC.THREAD_PREFILTER);
			}
		};

		ActionListener actionListenerFilterDiffs = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				toggleOpMask(WC.THREAD_GPU_FRAG_DIFF);
			}
		};
		ActionListener actionListenerFilterKernel = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				toggleOpMask(WC.THREAD_GPU_FRAG_DWT);
			}
		};
		ActionListener actionListenerFilterTimelapse = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				toggleOpMask(WC.THREAD_GPU_FRAG_TIMELAPSE);
			}
		};

		ActionListener actionListenerFilterSlowwalker = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (opMask[WC.THREAD_GPU_FRAG_TIMELAPSE] == false) {
					toggleOpMask(WC.THREAD_GPU_FRAG_TIMELAPSE);
				}

				if (opMask[WC.THREAD_GPU_FRAG_CONTRAST] == false) {
					toggleOpMask(WC.THREAD_GPU_FRAG_CONTRAST);
				}

				glColorLimits[glColorScheme][1] = 2;
				glColorLimits[glColorScheme][2] = 8;
				glColorLimits[glColorScheme][3] = 20;
				glColorLimits[glColorScheme][4] = 32;
				glColorLimits[glColorScheme][5] = 64;
				glColorLimits[glColorScheme][6] = 128;
				checkColorLimits();
				determineGlContrastControlPointRasterPosLinear();

			}
		};

		ActionListener actionListenerEditKernel = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editKernel();
			}
		};

		ActionListener actionListenerEditGLSLCode = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editGLSL();
			}
		};

		ItemListener actionListenerFilterLatLonOverlay = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				toggleOpMask(WC.THREAD_MAP_OVERLAY);

				if (opMask[WC.THREAD_MAP_OVERLAY] == true) {
					latLonOverlayUpdateFlag = 1;
				}
			}
		};

		ItemListener actionListenerAutoContrast = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				toggleOpMask(WC.THREAD_CONTRAST);
			}
		};
		ItemListener actionListenerManualContrast = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				toggleOpMask(WC.THREAD_CONTRAST);
			}
		};
		ItemListener actionListenerFilterDejitterAdv = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				toggleOpMask(WC.THREAD_DEJITTER_ADV);
			}
		};
		ItemListener actionListenerFilterPriorities = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				showFilterPriorities();
			}
		};

		// LOAD settings

		// FILE I/O
		ActionListener actionListenerLoadFrames2 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(2, 1, -1);
			}
		};
		ActionListener actionListenerLoadFrames10 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(2, 1, -1);
			}
		};
		ActionListener actionListenerLoadFrames60 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(60, 1, -1);
			}
		};
		ActionListener actionListenerLoadFrames120 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(120, 1, -1);
			}
		};
		ActionListener actionListenerLoadFrames180 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(180, 1, -1);
			}
		};
		ActionListener actionListenerLoadFrames300 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(300, 1, -1);
			}
		};

		ActionListener actionListenerLoadFrames600 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(600, 1, -1);
			}
		};

		ActionListener actionListenerLoadFrames900 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(900, 1, -1);
			}
		};
		ActionListener actionListenerLoadFrames1200 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(1200, 30, -1);
			}
		};

		ActionListener actionListenerLoadFrames1800 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(1800, 30, -1);
			}
		};

		ActionListener actionListenerLoadFrames3600 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(3600, 120, -1);
			}
		};

		ActionListener actionListenerLoadFrames7200 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(7200, 120, -1);
			}
		};

		ActionListener actionListenerLoadFrames10800 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(10800, 120, -1);
			}
		};

		ActionListener actionListenerLoadFrames14400 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(14400, 120, -1);
			}
		};

		ActionListener actionListenerLoadFrames36000 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(36000, 300, -1);
			}
		};

		ActionListener actionListenerSkipSeconds1 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, 1, -1);
			}
		};
		ActionListener actionListenerSkipSeconds5 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, 5, -1);
			}
		};
		ActionListener actionListenerSkipSeconds10 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, 10, -1);
			}
		};
		ActionListener actionListenerSkipSeconds15 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, 15, -1);
			}
		};
		ActionListener actionListenerSkipSeconds30 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, 30, -1);
			}
		};
		ActionListener actionListenerSkipSeconds60 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, 60, -1);
			}
		};

		ActionListener actionListenerSkipSeconds120 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, 120, -1);
			}
		};

		ActionListener actionListenerSkipSeconds300 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, 300, -1);
			}
		};

		ActionListener actionListenerSkipSeconds600 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, 600, -1);
			}
		};

		ActionListener actionListenerSkipSeconds1800 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, 1800, -1);
			}
		};

		ActionListener actionListenerSkipSeconds3600 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, 3600, -1);
			}
		};

		ActionListener actionListenerSkipShortScans = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadSkipShortScans();
			}
		};

		ActionListener actionListenerSkipOverscans = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadSkipOverscans();
			}
		};

		ActionListener actionListenerSetBurstSeconds2 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, -1, 2);
			}
		};
		ActionListener actionListenerSetBurstSeconds5 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, -1, 5);
			}
		};
		ActionListener actionListenerSetBurstSeconds10 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, -1, 10);
			}
		};
		ActionListener actionListenerSetBurstSeconds30 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, -1, 30);
			}
		};
		ActionListener actionListenerSetBurstSeconds60 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1, -1, 60);
			}
		};

		ActionListener actionListenerSetAutoReload15 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_ON, 15, 10);
			}
		};

		ActionListener actionListenerSetAutoReload30 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_ON, 30, 15);
			}
		};

		ActionListener actionListenerSetAutoReload60 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_ON, 60, 30);
			}
		};
		ActionListener actionListenerSetAutoReload120 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_ON, 120, 60);
			}
		};
		ActionListener actionListenerSetAutoReload300 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_ON, 300, 150);
			}
		};
		ActionListener actionListenerSetAutoReload600 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_ON, 600, 300);
			}
		};
		ActionListener actionListenerSetAutoReloadOff = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_OFF, -1, -1);
			}
		};

		ActionListener actionListenerLoadSCAs = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (uiState == WC.UI_STATE_SCA_SELECT) {
					uiState = WC.UI_STATE_VIEW;
				} else {
					uiState = WC.UI_STATE_SCA_SELECT;
				}
				System.out.println("SHOW SCA SELECTOR");
			}

		};
		// FILE IO

		// open the stream
		ActionListener actionListenerSetInputSource = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setInputSource();
			}
		};
		// open the files
		ActionListener actionListenerOpenFiles = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openFiles();
			}
		};

		ActionListener actionListenerSetInputAppend = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setInputAppend();
			}
		};

		ActionListener actionListenerExportImageSeq = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportImageSeq(".png");
			}
		};

		ActionListener actionListenerExportMarkedImageSeq = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportMarkedImageSeq(".png");
			}
		};

		ActionListener actionListenerExportWeatherImageSeq = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportWeatherImageSeq(".png");
			}
		};

		ActionListener actionListenerExportVideo = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				recordVideo();
			}
		};

		ActionListener actionListenerExportFootprintKml = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tilesToKml();
			}
		};

		ActionListener actionListenerExportReport = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportReport();
			}
		};


		// PLAYBACK THROTTLE
		ActionListener actionListenerPlaybackSlower = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showKeyboardHelp();
			}
		};

		ActionListener actionListenerPlaybackFaster = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showKeyboardHelp();
			}
		};

		// PLAYBACK SPECIFIC
		ActionListener actionListenerPlayback1X = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showKeyboardHelp();
			}
		};

		ActionListener actionListenerPlayback2X = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showKeyboardHelp();
			}
		};

		// PLAYBACK LOOP MODE
		ActionListener actionListenerPlaybackLoop = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				toggleLoopMode();
			}
		};
		ActionListener actionListenerPlaybackSelectionClear = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearSelection();
			}
		};
		ActionListener actionListenerCoordinateMode = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				changeCoordinateMode();
			}
		};
		ActionListener actionListenerPlaybackSelectionAll = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				allSelection();
			}
		};
		ActionListener actionListenerPlaybackSelectionGrow = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				growUserSelectionT();
			}
		};


		// SESSION
		ActionListener actionListenerOpenSession = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				restoreState(RESTORE_STATE_DIALOG_BOX);
			}
		};
		ActionListener actionListenerSaveSession = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveState(SAVE_STATE_DIALOG_BOX);
			}
		};
		ActionListener actionListenerRestoreSession = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				restoreState(RESTORE_STATE_ON_LAUNCH);
			}
		};
		ActionListener actionListenerQuitSession = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tivoExit();
			}
		};

		// contrast
		ActionListener actionListenerContrastOff = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		};
		ActionListener actionListenerContrastGain = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		};

		// handle the events for the contrast modes
		ActionListener actionListenerContrastAuto = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleContrastModeChange(CONTRAST_AUTO);
			}
		};
		ActionListener actionListenerContrastUser = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleContrastModeChange(CONTRAST_USER);

				/*
				 * if (uiState == WC.UI_STATE_VIEW){ uiState =
				 * WC.UI_STATE_CONTRAST; } else if (uiState ==
				 * WC.UI_STATE_CONTRAST){ uiState = WC.UI_STATE_VIEW; }
				 */

			}
		};
		ActionListener actionListenerContrastColorScheme = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleContrastColorChange();

			}
		};
		ActionListener actionListenerContrastWindow = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleContrastModeChange(CONTRAST_WINDOW);
			}
		};
		ActionListener actionListenerContrastClearCPs = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				userContrastCPList = new ArrayList();
			}
		};

		ActionListener actionListenerContrastReset = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				initColorRamps();
			}
		};

		ActionListener actionListenerContrastCollapse = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				collapseContrast();
			}
		};

		ActionListener actionListenerContrastEditor = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				contrastEditorUI();
			}
		};

		ActionListener actionListenerContrastCurves = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		};
		ActionListener actionListenerHistogram = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// toggleOpMask(WC.THREAD_HISTOGRAM);

				/*
				 * if (uiState == WC.UI_STATE_VIEW){ uiState =
				 * WC.UI_STATE_CONTRAST; } else if (uiState ==
				 * WC.UI_STATE_CONTRAST){ uiState = WC.UI_STATE_VIEW; }
				 */

				toggleOpMask(WC.THREAD_HISTOGRAM);
				toggleWidgetVisibility(WC.WIDGET_HISTOGRAM);

			}
		};

		ActionListener actionListenerHistogramDisplayToggle = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				histogramDisplayState = toggleBinaryItem(histogramDisplayState);
			}
		};

		// throttle
		ActionListener actionListenerArrowR = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				witFrameListStep(1, 1f);
				// tivoStepFrame(1);
				// panView(1);

				syncDrawSegments();
			}
		};
		ActionListener actionListenerArrowL = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				witFrameListStep(-1, 1f);
				// tivoStepFrame(-1);
				// panView(-1);

				syncDrawSegments();
			}
		};
		ActionListener actionListenerArrowU = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// tivoStepPlaybackSpeed(1);
				tivoStepPlaybackSeconds(1);
			}
		};
		ActionListener actionListenerArrowD = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// tivoStepPlaybackSpeed(-1);
				tivoStepPlaybackSeconds(-1);
			}
		};

		ActionListener actionListenerPanL = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panViewX(1);
			}
		};
		ActionListener actionListenerPanR = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panViewX(-1);
			}
		};

		ActionListener actionListenerTimelineR = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panTime(-1);
			}
		};
		ActionListener actionListenerTimelineL = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panTime(1);
			}
		};

		// reconstruct timeline from the metadata
		ActionListener actionListenerReloadTimeline = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		};

		// create a bookmark
		ActionListener actionListenerAddBookmarkEvent = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				addBookmarkEvent();
			}
		};

		// scroll between bookmarks
		ActionListener actionListenerMoveBookmarkR = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				panBookmarkEvent(-1);
			}
		};
		ActionListener actionListenerMoveBookmarkL = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				panBookmarkEvent(1);
			}
		};
		ActionListener actionListenerMoveBookmarkC = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				panBookmarkEvent(0);
			}
		};

		ActionListener actionListenerSwapFlights = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				toggleFlight();

				// auto re-center
				panBookmarkEvent(0);
			}
		};

		ActionListener actionListenerToggleSca1 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int scaID = 0;
				scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;
			}
		};
		ActionListener actionListenerToggleSca2 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int scaID = 1;
				scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;
			}
		};
		ActionListener actionListenerToggleSca3 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int scaID = 2;
				scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;
			}
		};
		ActionListener actionListenerToggleSca4 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int scaID = 3;
				scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;
			}
		};
		ActionListener actionListenerToggleSca5 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int scaID = 4;
				scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;
			}
		};
		ActionListener actionListenerToggleSca6 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int scaID = 5;
				scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;
			}
		};
		ActionListener actionListenerToggleSca7 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int scaID = 6;
				scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;
			}
		};
		ActionListener actionListenerToggleSca8 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int scaID = 7;
				scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;
			}
		};

		ActionListener actionListenerToggleSatDetails = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				drawSatDetails = toggleBoolean(drawSatDetails);
				System.out.println("SAT DETAILS - " + drawSatDetails);
			}
		};
		ActionListener actionListenerTogglePerformanceDetails = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				drawPerformanceDetails = toggleBoolean(drawPerformanceDetails);
			}
		};

		ActionListener actionListenerScanDir0 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetLastDrawIndex();
				setPlaybackScanMode(SCAN_DIR_EVEN);
			}
		};
		ActionListener actionListenerScanDir1 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetLastDrawIndex();
				setPlaybackScanMode(SCAN_DIR_ODD);
			}
		};

		ActionListener actionListenerPlaybackDirection = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				playheadDir *= -1;
			}
		};

		ActionListener actionListenerPlaybackScanSeqToggle = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int seqIndex = playbackScanSeqIndexPrev[userFlight];
				;
				if (playbackScanSeqIndexMask[userFlight][seqIndex] == 0) {
					playbackScanSeqIndexMask[userFlight][seqIndex] = 1;
				} else {
					playbackScanSeqIndexMask[userFlight][seqIndex] = 0;
				}
				userInterfaceInfoStr = "LOAD/PLAY SCAN SEQ " + seqIndex;
			}
		};

		ActionListener actionListenerPlaybackScanSeqAll = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (int i = 0; i < WC.SCAN_SEQ_INDEX_MAX_VAL; i++) {
					playbackScanSeqIndexMask[userFlight][i] = WC.STATUS_ON;
				}
				userInterfaceInfoStr = "LOAD/PLAY ALL SCAN SEQS";
			}
		};

		ActionListener actionListenerPlaybackPause = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doPlaybackPause();
			}
		};

		ActionListener actionListenerScanDir3 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetLastDrawIndex();
				setPlaybackScanMode(SCAN_DIR_BOTH);
			}
		};

		ActionListener actionListenerScanYOffsetPlus = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				yAlignUser++;
			}
		};
		ActionListener actionListenerScanYOffsetMinus = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				yAlignUser--;
			}
		};

		ActionListener actionListenerLensMagnify = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				toggleLensM();
			}
		};
		ActionListener actionListenerCompassRotation = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				toggleCompassRotation();
			}
		};
		ActionListener actionListenerLensFilter = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				toggleLensF();
			}
		};
		ActionListener actionListenerLensInfo = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				toggleLensInfo();
			}
		};

		ActionListener actionListenerLoadNextStep = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				reloadNewData(1,0);

			}
		};

		// arrows

		MenuItem itemArrowR = new MenuItem();
		itemArrowR.setLabel("Step Forward");
		// itemArrowR.setShortcut(new MenuShortcut(KeyEvent.VK_RIGHT));
		// itemArrowR.addActionListener(actionListenerArrowR);

		MenuItem itemArrowL = new MenuItem();
		itemArrowL.setLabel("Step Backwards");
		// itemArrowL.setShortcut(new MenuShortcut(KeyEvent.VK_LEFT));
		// itemArrowL.addActionListener(actionListenerArrowL);

		MenuItem itemArrowU = new MenuItem();
		itemArrowU.setLabel("Faster");
		// itemArrowU.setShortcut(new MenuShortcut(KeyEvent.VK_UP));
		// itemArrowU.addActionListener(actionListenerArrowU);

		MenuItem itemArrowD = new MenuItem();
		itemArrowD.setLabel("Slower");
		// itemArrowD.setShortcut(new MenuShortcut(KeyEvent.VK_DOWN));
		// itemArrowD.addActionListener(actionListenerArrowD);

		MenuItem itemToggleScanDir0 = new MenuItem();
		itemToggleScanDir0.setLabel("Toggle Scan Dir 0 (,)");
		// itemToggleScanDir0.setShortcut(new MenuShortcut(KeyEvent.VK_COMMA));
		// itemToggleScanDir0.addActionListener(actionListenerPanL);
		// itemToggleScanDir0.addActionListener(actionListenerScanDir0);

		MenuItem itemToggleScanDir1 = new MenuItem();
		itemToggleScanDir1.setLabel("Toggle Scan Dir 1 (.)");
		// itemToggleScanDir1.setShortcut(new MenuShortcut(KeyEvent.VK_PERIOD));
		// itemToggleScanDir1.addActionListener(actionListenerPanR);
		// itemToggleScanDir1.addActionListener(actionListenerScanDir1);

		MenuItem itemPlaybackDirection = new MenuItem();
		itemPlaybackDirection.setLabel("Toggle Playback Direction (l)");
		// itemPlaybackDirection.setShortcut(new MenuShortcut(KeyEvent.VK_L));
		// itemToggleScanDir0.addActionListener(actionListenerPanL);
		// itemPlaybackDirection.addActionListener(actionListenerPlaybackDirection);

		MenuItem itemPlaybackPause = new MenuItem();
		itemPlaybackPause.setLabel("Toggle Playback Pause (spacebar)");
		// itemPlaybackPause.setShortcut(new MenuShortcut(KeyEvent.VK_SPACE));
		// itemPlaybackPause.addActionListener(actionListenerPlaybackPause);

		MenuItem itemPlaybackScanSeqToggle = new MenuItem();
		itemPlaybackScanSeqToggle
				.setLabel("Toggle Current Scan Seq ON/OFF (x)");
		// itemPlaybackScanSeqToggle.addActionListener(actionListenerPlaybackScanSeqToggle);
		// itemPlaybackScanSeqToggle.setShortcut(new
		// MenuShortcut(KeyEvent.VK_X));

		MenuItem itemPlaybackScanSeqAll = new MenuItem();
		itemPlaybackScanSeqAll.setLabel("Enable All Scan Seqs (shift-x)");
		// itemToggleScanDir0.addActionListener(actionListenerPanL);
		// itemPlaybackScanSeqAll.addActionListener(actionListenerPlaybackScanSeqAll);

		MenuItem itemLoadNextStep = new MenuItem();
		itemLoadNextStep.setLabel("Jump to next timeline region (j)");

		MenuItem itemLoadPrevStep = new MenuItem();
		itemLoadNextStep.setLabel("Jump to prev timeline region (shift-j)");

		MenuItem itemTimelineL = new MenuItem();
		itemTimelineL.setLabel("Scroll Timeline Forward (shift-right)");
		// itemTimelineL.setShortcut(new MenuShortcut(KeyEvent.VK_9));
		// itemTimelineL.addActionListener(actionListenerTimelineL);

		MenuItem itemTimelineR = new MenuItem();
		itemTimelineR.setLabel("Scroll Timeline Backward (shift-left)");
		// itemTimelineR.setShortcut(new MenuShortcut(KeyEvent.VK_0));
		// itemTimelineR.addActionListener(actionListenerTimelineR);

		MenuItem itemMoveBookmarkL = new MenuItem();
		itemMoveBookmarkL.setLabel("data region - next");
		// itemMoveBookmarkL.setShortcut(new MenuShortcut(KeyEvent.VK_8));
		itemMoveBookmarkL.addActionListener(actionListenerMoveBookmarkL);

		MenuItem itemMoveBookmarkC = new MenuItem();
		itemMoveBookmarkC.setLabel("data region - re-center");
		// itemMoveBookmarkC.setShortcut(new MenuShortcut(KeyEvent.VK_7));
		itemMoveBookmarkC.addActionListener(actionListenerMoveBookmarkC);

		MenuItem itemMoveBookmarkR = new MenuItem();
		itemMoveBookmarkR.setLabel("data region - prev");
		// itemMoveBookmarkR.setShortcut(new MenuShortcut(KeyEvent.VK_6));
		itemMoveBookmarkR.addActionListener(actionListenerMoveBookmarkR);

		MenuItem itemAddBookmarkEvent = new MenuItem();
		itemAddBookmarkEvent.setLabel("bookmark region - prev");
		// itemAddBookmarkEvent.setShortcut(new MenuShortcut(KeyEvent.VK_B));
		itemAddBookmarkEvent.addActionListener(actionListenerAddBookmarkEvent);

		// MenuItem itemReloadTimeline = new MenuItem();
		// itemReloadTimeline.setLabel("Reload Timeline");
		// itemReloadTimeline.setShortcut(new MenuShortcut(KeyEvent.VK_R));
		// itemReloadTimeline.addActionListener(actionListenerReloadTimeline);

		MenuItem itemSwapFlights = new MenuItem();
		itemSwapFlights.setLabel("Toggle Flight (f)");
		// itemSwapFlights.setShortcut(new MenuShortcut(KeyEvent.VK_F));
		itemSwapFlights.addActionListener(actionListenerSwapFlights);

		// SCA toggles
		MenuItem itemToggleSca1 = new MenuItem();
		itemToggleSca1.setLabel("Toggle SCA 1");
		// itemToggleSca1.setShortcut(new MenuShortcut(KeyEvent.VK_1));
		// itemToggleSca1.addActionListener(actionListenerToggleSca1);

		MenuItem itemToggleSca2 = new MenuItem();
		itemToggleSca2.setLabel("Toggle SCA 2");
		// itemToggleSca2.setShortcut(new MenuShortcut(KeyEvent.VK_2));
		// itemToggleSca2.addActionListener(actionListenerToggleSca2);

		MenuItem itemToggleSca3 = new MenuItem();
		itemToggleSca3.setLabel("Toggle SCA 3");
		// itemToggleSca3.setShortcut(new MenuShortcut(KeyEvent.VK_3));
		// itemToggleSca3.addActionListener(actionListenerToggleSca3);

		MenuItem itemToggleSca4 = new MenuItem();
		itemToggleSca4.setLabel("Toggle SCA 4");
		// itemToggleSca4.setShortcut(new MenuShortcut(KeyEvent.VK_4));
		// itemToggleSca4.addActionListener(actionListenerToggleSca4);

		MenuItem itemToggleSca5 = new MenuItem();
		itemToggleSca5.setLabel("Toggle SCA 5");
		// itemToggleSca5.setShortcut(new MenuShortcut(KeyEvent.VK_5));
		// itemToggleSca5.addActionListener(actionListenerToggleSca5);

		MenuItem itemToggleSca6 = new MenuItem();
		itemToggleSca6.setLabel("Toggle SCA 6");
		// itemToggleSca6.setShortcut(new MenuShortcut(KeyEvent.VK_6));
		// itemToggleSca6.addActionListener(actionListenerToggleSca6);

		MenuItem itemToggleSca7 = new MenuItem();
		itemToggleSca7.setLabel("Toggle SCA 7");
		// itemToggleSca7.setShortcut(new MenuShortcut(KeyEvent.VK_7));
		// itemToggleSca7.addActionListener(actionListenerToggleSca7);

		MenuItem itemToggleSca8 = new MenuItem();
		itemToggleSca8.setLabel("Toggle SCA 8");
		// itemToggleSca8.setShortcut(new MenuShortcut(KeyEvent.VK_8));
		// itemToggleSca8.addActionListener(actionListenerToggleSca8);

		MenuItem itemTogglePerformanceDetails = new MenuItem();
		itemTogglePerformanceDetails.setLabel("Toggle Performance Details");
		itemTogglePerformanceDetails
				.setShortcut(new MenuShortcut(KeyEvent.VK_P));
		itemTogglePerformanceDetails
				.addActionListener(actionListenerTogglePerformanceDetails);

		MenuItem itemToggleSatDetails = new MenuItem();
		itemToggleSatDetails.setLabel("Toggle Sat Details");
		// itemToggleSatDetails.setShortcut(new MenuShortcut(KeyEvent.VK_S));
		itemToggleSatDetails.addActionListener(actionListenerToggleSatDetails);

		MenuItem itemLensMagnify = new MenuItem();
		itemLensMagnify.setLabel("Lens - Magnification");
		// itemLensMagnify.setShortcut(new MenuShortcut(KeyEvent.VK_M));
		itemLensMagnify.addActionListener(actionListenerLensMagnify);


		// AWT
		MenuItem itemOpenSession = new MenuItem();
		// itemOpenSession.setShortcut(new MenuShortcut(KeyEvent.VK_O));
		itemOpenSession.setLabel("Open Session");
		itemOpenSession.addActionListener(actionListenerOpenSession);

		MenuItem itemSaveSession = new MenuItem();
		// itemSaveSession.setShortcut(new MenuShortcut(KeyEvent.VK_S));
		itemSaveSession.setLabel("Save Session");
		itemSaveSession.addActionListener(actionListenerSaveSession);

		MenuItem itemRestoreSession = new MenuItem();
		itemRestoreSession.setLabel("Restore Previous Session");
		// itemRestoreSession.setShortcut(new MenuShortcut(KeyEvent.VK_R));
		itemRestoreSession.addActionListener(actionListenerRestoreSession);

		MenuItem itemQuitSession = new MenuItem();
		itemQuitSession.setShortcut(new MenuShortcut(KeyEvent.VK_Q));
		itemQuitSession.setLabel("Quit Session");
		itemQuitSession.addActionListener(actionListenerQuitSession);

		// menuSession.add(itemOpenSession);
		// menuSession.add(itemSaveSession);
		// menuSession.addSeparator();
		// menuSession.add(itemRestoreSession);
		// menuSession.addSeparator();
		menuSession.add(itemQuitSession);

		MenuItem itemContrastGain = new MenuItem();
		itemContrastGain.setLabel("Manual");
		itemContrastGain.addActionListener(actionListenerContrastGain);

		MenuItem itemContrastOff = new MenuItem();
		itemContrastOff.setLabel("Reset");
		itemContrastOff.addActionListener(actionListenerContrastOff);

		MenuItem itemContrastAuto = new MenuItem();
		itemContrastAuto.setLabel("Auto-Scale");
		itemContrastAuto.addActionListener(actionListenerContrastAuto);

		MenuItem itemContrastUser = new MenuItem();
		itemContrastUser.setLabel("Manual Contrast");
		// itemContrastUser.setShortcut(new MenuShortcut(KeyEvent.VK_C));
		itemContrastUser.addActionListener(actionListenerContrastUser);

		MenuItem itemContrastColorScheme = new MenuItem();
		itemContrastColorScheme.setLabel("Change Contrast Colors");
		itemContrastColorScheme
				.addActionListener(actionListenerContrastColorScheme);

		MenuItem itemContrastEditor = new MenuItem();
		itemContrastEditor.setLabel("Edit Contrast Points");
		itemContrastEditor.setShortcut(new MenuShortcut(KeyEvent.VK_E));
		itemContrastEditor.addActionListener(actionListenerContrastEditor);

		MenuItem itemContrastReset = new MenuItem();
		itemContrastReset.setLabel("Reset Contrast");
		itemContrastReset.addActionListener(actionListenerContrastReset);
		// itemContrastReset.setShortcut(new MenuShortcut(KeyEvent.VK_R));

		MenuItem itemContrastCollapse = new MenuItem();
		itemContrastCollapse.setLabel("Collapse Contrast (h)");
		itemContrastCollapse.addActionListener(actionListenerContrastCollapse);
		// itemContrastCollapse.setShortcut(new MenuShortcut(KeyEvent.VK_H));

		MenuItem itemContrastExpand = new MenuItem();
		itemContrastExpand.setLabel("Expand Contrast");
		itemContrastExpand.addActionListener(actionListenerContrastCollapse);
		// itemContrastExpand.setShortcut(new MenuShortcut(KeyEvent.VK_G));

		MenuItem itemContrastWindow = new MenuItem();
		itemContrastWindow.setLabel("Auto-Scale (Region)");
		// itemContrastWindow.setShortcut(new MenuShortcut(KeyEvent.VK_6));
		itemContrastWindow.addActionListener(actionListenerContrastWindow);

		MenuItem itemHistogram = new MenuItem();
		itemHistogram.setLabel("Histogram / Contrast Selector");
		// itemHistogram.setShortcut(new MenuShortcut(KeyEvent.VK_H));
		itemHistogram.addActionListener(actionListenerHistogram);

		MenuItem itemHistogramDisplayToggle = new MenuItem();
		itemHistogramDisplayToggle
				.setLabel("Toggle Histogram Scale (linear/log)");
		itemHistogramDisplayToggle
				.addActionListener(actionListenerHistogramDisplayToggle);

		MenuItem itemContrastCurves = new MenuItem();
		itemContrastCurves.setLabel("Curves");
		itemContrastCurves.addActionListener(actionListenerContrastCurves);

		menuContrast.add(itemHistogram);
		menuContrast.add(itemHistogramDisplayToggle);
		menuContrast.addSeparator();
		// menuContrast.add(itemContrastOff);
		// menuContrast.add(itemContrastGain);
		menuContrast.add(itemContrastUser);
		menuContrast.add(itemContrastColorScheme);
		menuContrast.add(itemContrastEditor);
		menuContrast.add(itemContrastCollapse);
		menuContrast.add(itemContrastExpand);

		menuContrast.add(itemContrastReset);

		MenuItem itemCoordinateMode = new MenuItem();
		itemCoordinateMode.setLabel("Change Coordinate System");
		itemCoordinateMode.addActionListener(actionListenerCoordinateMode);
		// itemCoordinateMode.setShortcut(new MenuShortcut(KeyEvent.VK_G));

		MenuItem itemPlaybackSelectionAll = new MenuItem();
		itemPlaybackSelectionAll.setLabel("Select All");
		itemPlaybackSelectionAll
				.addActionListener(actionListenerPlaybackSelectionAll);
		itemPlaybackSelectionAll.setShortcut(new MenuShortcut(KeyEvent.VK_A));

		MenuItem itemPlaybackSelectionGrow = new MenuItem();
		itemPlaybackSelectionGrow.setLabel("Grow Selection Time");
		itemPlaybackSelectionGrow
				.addActionListener(actionListenerPlaybackSelectionGrow);


		menuPlayback.add(itemCoordinateMode);
		menuPlayback.addSeparator();

		menuPlayback.add(itemPlaybackDirection);
		menuPlayback.add(itemPlaybackPause);
		menuPlayback.add(itemArrowR);
		menuPlayback.add(itemArrowL);
		menuPlayback.add(itemArrowU);
		menuPlayback.add(itemArrowD);

		menuPlayback.addSeparator();
		// menuPlayback.add(itemReloadTimeline);
		menuPlayback.add(itemLoadNextStep);
		menuPlayback.add(itemLoadPrevStep);

		menuPlayback.addSeparator();
		menuPlayback.add(itemToggleScanDir0);
		menuPlayback.add(itemToggleScanDir1);

		menuPlayback.addSeparator();
		menuPlayback.add(itemPlaybackScanSeqToggle);
		menuPlayback.add(itemPlaybackScanSeqAll);
		// menuPlayback.addSeparator();
		// menuPlayback.add(itemCompassRotation);

		menuPlayback.addSeparator();
		menuPlayback.add(itemTimelineL);
		menuPlayback.add(itemTimelineR);

		menuPlayback.addSeparator();
		menuPlayback.add(itemMoveBookmarkL);
		menuPlayback.add(itemMoveBookmarkC);
		menuPlayback.add(itemMoveBookmarkR);

		menuPlayback.addSeparator();
		menuPlayback.add(itemAddBookmarkEvent);

		menuPlayback.addSeparator();
		menuPlayback.add(itemSwapFlights);

		menuPlayback.addSeparator();
		menuPlayback.add(itemLensMagnify);
		// menuPlayback.add(itemLensFilter);
		// menuPlayback.add(itemLensInfo);

		menuPlayback.addSeparator();
		menuPlayback.add(itemToggleSca1);
		menuPlayback.add(itemToggleSca2);
		menuPlayback.add(itemToggleSca3);
		menuPlayback.add(itemToggleSca4);
		menuPlayback.add(itemToggleSca5);
		menuPlayback.add(itemToggleSca6);
		menuPlayback.add(itemToggleSca7);
		menuPlayback.add(itemToggleSca8);

		menuPlayback.addSeparator();
		menuPlayback.add(itemToggleSatDetails);
		menuPlayback.add(itemTogglePerformanceDetails);

		MenuItem itemFilterDiffs = new MenuItem();
		itemFilterDiffs.setLabel("Toggle Diffs (shift-t)");
		itemFilterDiffs.addActionListener(actionListenerFilterDiffs);

		MenuItem itemFilterKernel = new MenuItem();
		itemFilterKernel.setLabel("Toggle DWT (t)");
		itemFilterKernel.addActionListener(actionListenerFilterKernel);

		MenuItem itemFilterTimelapse = new MenuItem();
		itemFilterTimelapse.setLabel("Toggle Temporal Blur (b)");
		itemFilterTimelapse.addActionListener(actionListenerFilterTimelapse);

		MenuItem itemFilterSlowwalker = new MenuItem();
		itemFilterSlowwalker.setLabel("Setup Slowwalker Mode");
		itemFilterSlowwalker.addActionListener(actionListenerFilterSlowwalker);
		// itemFilterSlowwalker.setShortcut(new MenuShortcut(KeyEvent.VK_W));


		MenuItem itemEditKernel = new MenuItem();
		itemEditKernel.setLabel("Edit DWT Kernel");
		itemEditKernel.addActionListener(actionListenerEditKernel);
		itemEditKernel.setShortcut(new MenuShortcut(KeyEvent.VK_K));

		MenuItem itemEditGLSLCode = new MenuItem();
		itemEditGLSLCode.setLabel("Edit GLSL Code");
		itemEditGLSLCode.addActionListener(actionListenerEditGLSLCode);

		CheckboxMenuItem itemFilterLatLonOverlay = new CheckboxMenuItem();
		itemFilterLatLonOverlay.setLabel("Lat/Lon Features");
		itemFilterLatLonOverlay
				.addItemListener(actionListenerFilterLatLonOverlay);
		// itemFilterLatLonOverlay.setShortcut(new MenuShortcut(KeyEvent.VK_G));
		itemFilterLatLonOverlay.setState(opMask[WC.THREAD_MAP_OVERLAY]);

		CheckboxMenuItem itemFilterDejitterAdv = new CheckboxMenuItem();
		itemFilterDejitterAdv.setLabel("Dejitter Method2");
		itemFilterDejitterAdv.addItemListener(actionListenerFilterDejitterAdv);
		itemFilterDejitterAdv.setState(opMask[WC.THREAD_DEJITTER_ADV]);

		CheckboxMenuItem itemAutoContrast = new CheckboxMenuItem();
		itemAutoContrast.setLabel("Auto-Contrast");
		itemAutoContrast.addItemListener(actionListenerAutoContrast);

		itemAutoContrast.setState(opMask[WC.THREAD_CONTRAST]);

		CheckboxMenuItem itemManualContrast = new CheckboxMenuItem();
		itemManualContrast.setLabel("Manual Contrast");
		itemManualContrast.addItemListener(actionListenerManualContrast);
		itemManualContrast.setState(opMask[WC.THREAD_CONTRAST]);


		CheckboxMenuItem itemGlobeToggleDataPoliticalBoundaries = new CheckboxMenuItem();
		itemGlobeToggleDataPoliticalBoundaries
				.setLabel("Enable Political Boundary Overlay");
		// itemGlobeToggleData.setShortcut(new MenuShortcut(KeyEvent.VK_G));
		itemGlobeToggleDataPoliticalBoundaries
				.addItemListener(actionListenerGlobeBoundaryData);
		itemGlobeToggleDataPoliticalBoundaries.setState(true);

		CheckboxMenuItem itemGlobeToggleDataCity = new CheckboxMenuItem();
		itemGlobeToggleDataCity.setLabel("Enable City Overlay");
		// itemGlobeToggleData.setShortcut(new MenuShortcut(KeyEvent.VK_G));
		itemGlobeToggleDataCity.addItemListener(actionListenerGlobeCityData);
		itemGlobeToggleDataCity.setEnabled(false);

		CheckboxMenuItem itemGlobeToggleDataTransport = new CheckboxMenuItem();
		itemGlobeToggleDataTransport.setLabel("Enable Transport Route Overlay");
		// itemGlobeToggleData.setShortcut(new MenuShortcut(KeyEvent.VK_G));
		itemGlobeToggleDataTransport
				.addItemListener(actionListenerGlobeTransportData);
		itemGlobeToggleDataTransport.setEnabled(false);
		
		menuGlobe.add(itemGlobeToggleDataPoliticalBoundaries);
		menuGlobe.add(itemGlobeToggleDataCity);
		menuGlobe.add(itemGlobeToggleDataTransport);
		menuGlobe.addSeparator();
		
		// menuFilter.add(itemFilterMetadata);
		menuFilter.add(itemFilterDiffs);
		menuFilter.add(itemFilterKernel);
		menuFilter.add(itemFilterTimelapse);
		// menuFilter.add(itemFilterDejitter);

		menuFilter.addSeparator();
		menuFilter.add(itemEditKernel);
		menuFilter.add(itemEditGLSLCode);

		menuFilter.addSeparator();
		menuFilter.add(itemFilterSlowwalker);

		MenuItem itemHelpWeb = new MenuItem();
		itemHelpWeb.setLabel("Launch HTML User Guide");
		itemHelpWeb.addActionListener(actionListenerHelpWeb);
		// itemHelpWeb.setShortcut(new MenuShortcut(KeyEvent.VK_H));

		menuHelp.add(itemHelpWeb);

		MenuItem itemExportVideo = new MenuItem();
		itemExportVideo.setLabel("Start/Stop Video Export (v)");
		// itemExportVideo.setShortcut(new MenuShortcut(KeyEvent.VK_V));
		itemExportVideo.addActionListener(actionListenerExportVideo);

		MenuItem itemExportFootprintKml = new MenuItem();
		itemExportFootprintKml.setLabel("Export Footprint KML");
		itemExportFootprintKml
				.addActionListener(actionListenerExportFootprintKml);

		MenuItem itemExportReport = new MenuItem();
		itemExportReport.setLabel("Export Report");
		itemExportReport.addActionListener(actionListenerExportReport);
		// itemExportReport.setShortcut(new MenuShortcut(KeyEvent.VK_E));

		MenuItem itemSetInputSource = new MenuItem();
		itemSetInputSource.setLabel("Connect to Input Stream");
		itemSetInputSource.addActionListener(actionListenerSetInputSource);
		itemSetInputSource.setShortcut(new MenuShortcut(KeyEvent.VK_I));

		MenuItem itemOpenFiles = new MenuItem();
		itemOpenFiles.setLabel("Open File(s)");
		itemOpenFiles.addActionListener(actionListenerOpenFiles);
		// itemOpenFiles.setShortcut(new MenuShortcut(KeyEvent.VK_O));

		MenuItem itemSetLoadSCAs = new MenuItem();
		itemSetLoadSCAs.setLabel("Load - Select Input SCAs");
		itemSetLoadSCAs.addActionListener(actionListenerLoadSCAs);
		// itemSetLoadSCAs.setShortcut(new MenuShortcut(KeyEvent.VK_L));

		MenuItem itemSetSkipSeconds1 = new MenuItem();
		itemSetSkipSeconds1.setLabel("Load - Skip 1 Seconds");
		itemSetSkipSeconds1.addActionListener(actionListenerSkipSeconds1);

		MenuItem itemSetSkipSeconds5 = new MenuItem();
		itemSetSkipSeconds5.setLabel("Load - Skip 5 Seconds");
		itemSetSkipSeconds5.addActionListener(actionListenerSkipSeconds5);

		MenuItem itemSetSkipSeconds10 = new MenuItem();
		itemSetSkipSeconds10.setLabel("Load - Skip 10 Seconds");
		itemSetSkipSeconds10.addActionListener(actionListenerSkipSeconds10);

		MenuItem itemSetSkipSeconds15 = new MenuItem();
		itemSetSkipSeconds15.setLabel("Load - Skip 15 Seconds");
		itemSetSkipSeconds15.addActionListener(actionListenerSkipSeconds15);

		MenuItem itemSetSkipSeconds30 = new MenuItem();
		itemSetSkipSeconds30.setLabel("Load - Skip 30 Seconds");
		itemSetSkipSeconds30.addActionListener(actionListenerSkipSeconds30);

		MenuItem itemSetSkipSeconds60 = new MenuItem();
		itemSetSkipSeconds60.setLabel("Load - Skip 1 Minute");
		itemSetSkipSeconds60.addActionListener(actionListenerSkipSeconds60);

		MenuItem itemSetSkipSeconds120 = new MenuItem();
		itemSetSkipSeconds120.setLabel("Load - Skip 2 Minutes");
		itemSetSkipSeconds120.addActionListener(actionListenerSkipSeconds120);

		MenuItem itemSetSkipSeconds300 = new MenuItem();
		itemSetSkipSeconds300.setLabel("Load - Skip 5 Minutes");
		itemSetSkipSeconds300.addActionListener(actionListenerSkipSeconds300);

		MenuItem itemSetSkipSeconds600 = new MenuItem();
		itemSetSkipSeconds600.setLabel("Load - Skip 10 Minutes");
		itemSetSkipSeconds600.addActionListener(actionListenerSkipSeconds600);

		MenuItem itemSetSkipSeconds1800 = new MenuItem();
		itemSetSkipSeconds1800.setLabel("Load - Skip 30 Minutes");
		itemSetSkipSeconds1800.addActionListener(actionListenerSkipSeconds1800);

		MenuItem itemSetSkipSeconds3600 = new MenuItem();
		itemSetSkipSeconds3600.setLabel("Load - Skip 1 Hour");
		itemSetSkipSeconds3600.addActionListener(actionListenerSkipSeconds3600);

		MenuItem itemSetSkipShortScans = new MenuItem();
		itemSetSkipShortScans.setLabel("Load - Skip Short Scans");
		itemSetSkipShortScans.addActionListener(actionListenerSkipShortScans);

		MenuItem itemSetSkipOverscans = new MenuItem();
		itemSetSkipOverscans.setLabel("Load - Skip Overscans");
		itemSetSkipOverscans.addActionListener(actionListenerSkipOverscans);

		MenuItem itemSetBurstSeconds2 = new MenuItem();
		itemSetBurstSeconds2.setLabel("Load - Burst 2 Seconds");
		itemSetBurstSeconds2.addActionListener(actionListenerSetBurstSeconds2);

		MenuItem itemSetBurstSeconds5 = new MenuItem();
		itemSetBurstSeconds5.setLabel("Load - Burst 5 Seconds");
		itemSetBurstSeconds5.addActionListener(actionListenerSetBurstSeconds5);

		MenuItem itemSetBurstSeconds10 = new MenuItem();
		itemSetBurstSeconds10.setLabel("Load - Burst 10 Seconds");
		itemSetBurstSeconds10
				.addActionListener(actionListenerSetBurstSeconds10);

		MenuItem itemSetBurstSeconds30 = new MenuItem();
		itemSetBurstSeconds30.setLabel("Load - Burst 30 Seconds");
		itemSetBurstSeconds30
				.addActionListener(actionListenerSetBurstSeconds30);

		MenuItem itemSetBurstSeconds60 = new MenuItem();
		itemSetBurstSeconds60.setLabel("Load - Burst 60 Seconds");
		itemSetBurstSeconds60
				.addActionListener(actionListenerSetBurstSeconds60);

		MenuItem itemSetLoadFrames2 = new MenuItem();
		itemSetLoadFrames2.setLabel("Load - 2 Seconds (Skip 1 Second1 - F1)");
		itemSetLoadFrames2.addActionListener(actionListenerLoadFrames2);

		// itemSetLoadFrames10.setShortcut(new MenuShortcut(KeyEvent.VK_F1));
		MenuItem itemSetLoadFrames60 = new MenuItem();
		itemSetLoadFrames60.setLabel("Load - 1 Minute (Skip 1 Second - F2)");
		itemSetLoadFrames60.addActionListener(actionListenerLoadFrames60);
		// itemSetLoadFrames60.setShortcut(new MenuShortcut(KeyEvent.VK_F2));
		MenuItem itemSetLoadFrames120 = new MenuItem();
		itemSetLoadFrames120.setLabel("Load - 2 Minutes (Skip 1 Second - F3)");
		itemSetLoadFrames120.addActionListener(actionListenerLoadFrames120);
		// itemSetLoadFrames120.setShortcut(new MenuShortcut(KeyEvent.VK_F3));
		MenuItem itemSetLoadFrames180 = new MenuItem();
		itemSetLoadFrames180.setLabel("Load - 3 Minutes (Skip 1 Second - F4)");
		itemSetLoadFrames180.addActionListener(actionListenerLoadFrames180);
		// itemSetLoadFrames180.setShortcut(new MenuShortcut(KeyEvent.VK_F4));
		MenuItem itemSetLoadFrames300 = new MenuItem();
		itemSetLoadFrames300.setLabel("Load - 5 Minutes (Skip 1 Second - F5)");
		itemSetLoadFrames300.addActionListener(actionListenerLoadFrames300);
		// itemSetLoadFrames300.setShortcut(new MenuShortcut(KeyEvent.VK_F5));

		MenuItem itemSetLoadFrames600 = new MenuItem();
		itemSetLoadFrames600.setLabel("Load - 10 Minutes (Skip 1 Second - F6)");
		itemSetLoadFrames600.addActionListener(actionListenerLoadFrames600);
		// itemSetLoadFrames600.setShortcut(new MenuShortcut(KeyEvent.VK_F6));

		MenuItem itemSetLoadFrames900 = new MenuItem();
		itemSetLoadFrames900.setLabel("Load - 15 Minutes (Skip 1 Second - F7)");
		itemSetLoadFrames900.addActionListener(actionListenerLoadFrames900);
		// itemSetLoadFrames900.setShortcut(new MenuShortcut(KeyEvent.VK_F7));

		MenuItem itemSetLoadFrames1200 = new MenuItem();
		itemSetLoadFrames1200
				.setLabel("Load - 20 Minutes (Skip 30 Seconds - F8)");
		itemSetLoadFrames1200.addActionListener(actionListenerLoadFrames1200);
		// itemSetLoadFrames1200.setShortcut(new MenuShortcut(KeyEvent.VK_F8));

		MenuItem itemSetLoadFrames1800 = new MenuItem();
		itemSetLoadFrames1800
				.setLabel("Load - 30 Minutes (Skip 30 Seconds - F9)");
		itemSetLoadFrames1800.addActionListener(actionListenerLoadFrames1800);
		// itemSetLoadFrames1800.setShortcut(new MenuShortcut(KeyEvent.VK_F9));

		MenuItem itemSetLoadFrames3600 = new MenuItem();
		itemSetLoadFrames3600.setLabel("Load - 1 Hour (Skip 2 Minutes - F10)");
		itemSetLoadFrames3600.addActionListener(actionListenerLoadFrames3600);
		// itemSetLoadFrames3600.setShortcut(new MenuShortcut(KeyEvent.VK_F10));

		MenuItem itemSetLoadFrames7200 = new MenuItem();
		itemSetLoadFrames7200.setLabel("Load - 2 Hours (Skip 2 Minutes - F11)");
		itemSetLoadFrames7200.addActionListener(actionListenerLoadFrames7200);
		// itemSetLoadFrames7200.setShortcut(new MenuShortcut(KeyEvent.VK_F11));

		MenuItem itemSetLoadFrames10800 = new MenuItem();
		itemSetLoadFrames10800.setLabel("Load - 3 Hours (Skip 2 Minutes)");
		itemSetLoadFrames10800.addActionListener(actionListenerLoadFrames10800);
		// itemSetLoadFrames10800.setShortcut(new
		// MenuShortcut(KeyEvent.VK_F12));

		MenuItem itemSetLoadFrames14400 = new MenuItem();
		itemSetLoadFrames14400
				.setLabel("Load - 4 Hours (Skip 5 Minutes  - F12)");
		itemSetLoadFrames14400.addActionListener(actionListenerLoadFrames14400);

		MenuItem itemSetLoadFrames36000 = new MenuItem();
		itemSetLoadFrames36000.setLabel("Load - 10 Hours (Skip 5 Minutes)");
		itemSetLoadFrames36000.addActionListener(actionListenerLoadFrames36000);

		MenuItem itemSetInputAppend = new MenuItem();
		itemSetInputAppend.setLabel("Append Timeline");
		itemSetInputAppend.addActionListener(actionListenerSetInputAppend);

		MenuItem itemSetAutoReload15 = new MenuItem();
		itemSetAutoReload15.setLabel("Auto-Reload - 15 Seconds");
		itemSetAutoReload15.addActionListener(actionListenerSetAutoReload15);

		MenuItem itemSetAutoReload30 = new MenuItem();
		itemSetAutoReload30.setLabel("Auto-Reload - 30 Seconds");
		itemSetAutoReload30.addActionListener(actionListenerSetAutoReload30);

		MenuItem itemSetAutoReload60 = new MenuItem();
		itemSetAutoReload60.setLabel("Auto-Reload - 1 Minute");
		itemSetAutoReload60.addActionListener(actionListenerSetAutoReload60);

		MenuItem itemSetAutoReload120 = new MenuItem();
		itemSetAutoReload120.setLabel("Auto-Reload - 2 Minutes");
		itemSetAutoReload120.addActionListener(actionListenerSetAutoReload120);

		MenuItem itemSetAutoReload300 = new MenuItem();
		itemSetAutoReload300.setLabel("Auto-Reload - 5 Minutes");
		itemSetAutoReload300.addActionListener(actionListenerSetAutoReload300);

		MenuItem itemSetAutoReload600 = new MenuItem();
		itemSetAutoReload600.setLabel("Auto-Reload - 10 Minutes");
		itemSetAutoReload600.addActionListener(actionListenerSetAutoReload600);

		MenuItem itemSetAutoReloadOff = new MenuItem();
		itemSetAutoReloadOff.setLabel("Auto-Reload - Off");
		itemSetAutoReloadOff.addActionListener(actionListenerSetAutoReloadOff);

		menuFile.add(itemOpenFiles);
		// menuFile.add(itemSetInputAppend);
		menuFile.addSeparator();

		menuFile.add(itemSetLoadSCAs);
		menuFile.add(itemSetLoadFrames2);
		// menuFile.add(itemSetLoadFrames10);
		menuFile.add(itemSetLoadFrames60);
		menuFile.add(itemSetLoadFrames120);
		menuFile.add(itemSetLoadFrames180);
		menuFile.add(itemSetLoadFrames300);
		menuFile.add(itemSetLoadFrames600);
		menuFile.add(itemSetLoadFrames900);
		menuFile.add(itemSetLoadFrames1200);
		menuFile.add(itemSetLoadFrames1800);
		menuFile.add(itemSetLoadFrames3600);
		menuFile.add(itemSetLoadFrames7200);
		menuFile.add(itemSetLoadFrames10800);
		menuFile.add(itemSetLoadFrames14400);
		menuFile.add(itemSetLoadFrames36000);

		menuFile.addSeparator();

		menuFile.add(itemSetSkipSeconds1);
		menuFile.add(itemSetSkipSeconds5);
		menuFile.add(itemSetSkipSeconds10);
		menuFile.add(itemSetSkipSeconds15);
		menuFile.add(itemSetSkipSeconds30);
		menuFile.add(itemSetSkipSeconds60);
		menuFile.add(itemSetSkipSeconds120);
		menuFile.add(itemSetSkipSeconds300);
		menuFile.add(itemSetSkipSeconds600);
		menuFile.add(itemSetSkipSeconds1800);
		menuFile.add(itemSetSkipSeconds3600);

		menuFile.addSeparator();

		menuFile.add(itemSetBurstSeconds2);
		menuFile.add(itemSetBurstSeconds5);
		menuFile.add(itemSetBurstSeconds10);
		menuFile.add(itemSetBurstSeconds30);
		menuFile.add(itemSetBurstSeconds60);

		menuFile.addSeparator();

		menuFile.add(itemSetAutoReload15);
		menuFile.add(itemSetAutoReload30);
		menuFile.add(itemSetAutoReload60);
		menuFile.add(itemSetAutoReload120);
		menuFile.add(itemSetAutoReload300);
		menuFile.add(itemSetAutoReload600);
		menuFile.add(itemSetAutoReloadOff);

		menuFile.addSeparator();

		menuFile.add(itemExportVideo);
		menuFile.addSeparator();
		menuFile.add(itemExportFootprintKml);

		MenuItem itemHelpKeyboard = new MenuItem();
		itemHelpKeyboard.setLabel("Show Keyboard Shortcuts");
		MenuItem itemHelpDocs = new MenuItem();
		itemHelpDocs.setLabel("Open HTML User Guide");

		menuBar.add(menuSession);

		menuBar.add(menuFile);
		menuBar.add(menuPlayback);
		menuBar.add(menuContrast);
		menuBar.add(menuFilter);

		menuBar.add(menuGlobe);
		menuBar.add(menuHelp);

	}

	public void doGain() {

	}

	public void refreshFilterMenuItems() {

	}

	public void handleContrastColorChange() {
		if (glColorScheme == WC.COLOR_SCHEME_HEATMAP) {
			glColorScheme = WC.COLOR_SCHEME_GRAYSCALE;
		} else {
			glColorScheme = WC.COLOR_SCHEME_HEATMAP;
		}

		determineGlContrastControlPointRasterPosLinear();
	}

	public void handleContrastModeChange(int cMode) {

		toggleOpMask(WC.THREAD_GPU_FRAG_CONTRAST);

	}

	public boolean toggleBoolean(boolean b) {

		if (b == true) {
			return false;
		} else {
			return true;
		}
	}

	public void toggleLensF() {
		lensFilterActive++;
		lensFilterActive = lensFilterActive % 2;

	}

	public void toggleFlight() {
		userFlight++;
		userFlight = userFlight % 2;

	}

	public void toggleGeoMouse() {

	}

	public void toggleCompassRotation() {
		uiCompassRotationState++;
		uiCompassRotationState = uiCompassRotationState % 2;

		if (uiCompassRotationState == 1) {

			userInterfaceInfoStr = "COMPASS ROTATION ON";
		} else {

			userInterfaceInfoStr = "COMPASS ROTATION OFF";
		}
	}

	public void toggleLensM() {
		lensMagnifyActive++;
		lensMagnifyActive = lensMagnifyActive % 2;

		if (lensMagnifyActive == 1) {

			userInterfaceInfoStr = "MAGNIFIER ON";
		} else {

			userInterfaceInfoStr = "MAGNIFIER OFF";
		}
		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
	}

	public void toggleLensInfo() {
		lensTextColorMode++;
		lensTextColorMode = lensTextColorMode % 3;

		if (lensTextColorMode == LAT_LON_COLOR_AUTO) {

			userInterfaceInfoStr = "OVERLAY COLOR: AUTO";
		} else if (lensTextColorMode == LAT_LON_COLOR_DARK) {

			userInterfaceInfoStr = "OVERLAY COLOR: DARK";
		} else if (lensTextColorMode == LAT_LON_COLOR_LIGHT) {

			userInterfaceInfoStr = "OVERLAY COLOR: LIGHT";
		}
		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
	}

	public void setPlaybackScanMode(int scanDir) {

		if (scanDir == WC.SCAN_DIR_ODD) {
			if (playbackModeDir[userFlight] == WC.SCAN_DIR_ODD) {

			} else if (playbackModeDir[userFlight] == WC.SCAN_DIR_EVEN) {
				playbackModeDir[userFlight] = WC.SCAN_DIR_BOTH;
			} else if (playbackModeDir[userFlight] == WC.SCAN_DIR_BOTH) {
				playbackModeDir[userFlight] = WC.SCAN_DIR_ODD;
			}
		} else if (scanDir == WC.SCAN_DIR_EVEN) {
			if (playbackModeDir[userFlight] == WC.SCAN_DIR_ODD) {
				playbackModeDir[userFlight] = WC.SCAN_DIR_BOTH;
			} else if (playbackModeDir[userFlight] == WC.SCAN_DIR_EVEN) {

			} else if (playbackModeDir[userFlight] == WC.SCAN_DIR_BOTH) {
				playbackModeDir[userFlight] = WC.SCAN_DIR_EVEN;
			}
		} else if (scanDir == WC.SCAN_DIR_BOTH) {
			if (playbackModeDir[userFlight] == WC.SCAN_DIR_ODD) {
				playbackModeDir[userFlight] = WC.SCAN_DIR_BOTH;
			} else if (playbackModeDir[userFlight] == WC.SCAN_DIR_EVEN) {
				playbackModeDir[userFlight] = WC.SCAN_DIR_BOTH;
			} else if (playbackModeDir[userFlight] == WC.SCAN_DIR_BOTH) {

			}
		}

		System.out.println("SCAN DIR " + scanDir);
	}

	public void setPlaybackScanSeg(int scanSeg) {
		playbackModeSeg = scanSeg;
		System.out.println("SCAN SEG " + scanSeg);
	}

	public void panViewX(int dir) {
		userPanOffset[GOAL][WC.X] += (dir * 768.0 / 2f);

		if (userPanOffset[GOAL][WC.X] < minPanX) {
			userPanOffset[GOAL][WC.X] = minPanX;
		}
		if (userPanOffset[GOAL][WC.X] > maxPanX) {
			userPanOffset[GOAL][WC.X] = maxPanX;
		}

	}

	public void panViewY(int dir) {
		userPanOffset[GOAL][WC.Y] += (dir * 768.0 / 2f);

		if (userPanOffset[GOAL][WC.Y] < minPanY) {
			userPanOffset[GOAL][WC.Y] = minPanY;
		}
		if (userPanOffset[GOAL][WC.Y] > maxPanY) {
			userPanOffset[GOAL][WC.Y] = maxPanY;
		}

	}

	public void checkTimelineOffet() {
		if (userTimelineOffset[GOAL] < minTimeOffset) {
			userTimelineOffset[GOAL] = minTimeOffset;
		}
		if (userTimelineOffset[GOAL] > maxTimeOffset) {
			userTimelineOffset[GOAL] = maxTimeOffset;
		}
	}

	public void panTime(int dir) {
		userTimelineOffset[GOAL] += (dir * WC.TEN_MIN_TICK_OFFSET / 2)
				* (1f / userTimelineZoom[GOAL]);
		// userTimelineOffset[CURRENT] += (dir*100);

		checkTimelineOffet();
	}

	public void addBookmarkEvent() {

		if (mouseOverSCA != WC.STATUS_ERROR) {
			// nudge the items
			String eventStr = "USER DETECTED EVENT";
			int eventIndex = (int) userTimelineOffset[CURRENT]
					+ timelineCenterX;

			int markPrev = 0;
			int markNext = 0;

			BookmarkEvent be = new BookmarkEvent();
			be.satID = userFlight;
			be.scaID = mouseOverSCA;
			be.rasterX = cursorX;
			be.rasterY = cursorY;
			be.lat = mouseLat;
			be.lon = mouseLon;
			// be.el
			be.intensity = mouseIntensity;

			WITFrame rasterFrame = (WITFrame) witFrameList[userFlight][mouseOverSCA]
					.get(witSCAPlayhead[userFlight][mouseOverSCA]);
			be.timeStampSecOfDay = rasterFrame.timeStampSecOfDay;
			be.eventLabel = eventStr;
			be.eventDetectors[WC.EVENT_DETECTOR_OPERATOR] = true;

			bookmarkList.add(be);
			userEventFlash = userEventFlashDefault;

			System.out.println("ADD BOOKMARK");
		} else {
			System.out.println("BOOKMARK ERROR");
		}
	}

	public void panBookmarkEvent(int dir) {

		int minDelta = Integer.MAX_VALUE;
		int minDeltaIndex = WC.STATUS_ERROR;
		int deltaDir = 0;

		int filterOkFlag = WC.STATUS_ON;

		BookmarkEvent currBe = (BookmarkEvent) bookmarkList
				.get(bookmarkListIndex[userFlight]);

		for (int i = 0; i < bookmarkList.size(); i++) {
			if (i != bookmarkListIndex[userFlight]) {
				BookmarkEvent be = (BookmarkEvent) bookmarkList.get(i);

				if (be.satID == userFlight) {

					// filter
					if (filterOkFlag == WC.STATUS_ON) {

						int delta = currBe.timeStampSecOfDay
								- be.timeStampSecOfDay;

						if (delta > 0) {
							deltaDir = -1;
						} else {
							deltaDir = 1;
						}

						if (delta == 0) {
							deltaDir = 0;
							if (dir == -1) {
								if ((be.scaID > currBe.scaID)
										|| (be.scaID < currBe.scaID && dir == 1)) {
									deltaDir = dir;
								}
							} else if (dir == 1) {
								if ((be.scaID > currBe.scaID)
										|| (be.scaID < currBe.scaID && dir == -1)) {
									deltaDir = dir;
								}
							}
						}

						if (deltaDir == dir) {
							int deltaAbs = Math.abs(delta);

							if (deltaAbs < minDelta) {
								minDelta = deltaAbs;
								minDeltaIndex = i;
							}
						}

					}
				}
			}
		}

		if (dir != 0 && minDeltaIndex != WC.STATUS_ERROR) {
			bookmarkListIndex[userFlight] = minDeltaIndex;
		}

		BookmarkEvent be = (BookmarkEvent) bookmarkList
				.get(bookmarkListIndex[userFlight]);

		if (be.rasterX != WC.STATUS_ERROR && be.rasterY != WC.STATUS_ERROR) {
			// userEventFlash = userEventFlashDefault;
		}

		userTimelineOffset[GOAL] = -be.timeStampSecOfDay + timelineCenterX;

		if (be.timeStampSecOfDay < userSelection[WC.END][WC.T]
				&& be.timeStampSecOfDay > userSelection[WC.START][WC.T]) {
			witFrameListJump(be.timeStampSecOfDay);
			syncDrawSegments();
		}
	}

	public int toggleBinaryItem(int item) {
		int i = item;
		i++;
		i = i % 2;
		return i;
	}

	public void setRasterLayer(int mode) {
		if (opMask[mode] == true) {
			rasterLayerOpa[mode][GOAL] = defaultOpOpacity[mode];
		} else {
			rasterLayerOpa[mode][GOAL] = 0.0f;
		}
	}

	public void toggleOpMask(int mode) {

		if (opMask[mode] == false) {
			opMask[mode] = true;
		} else {
			opMask[mode] = false;
		}

		// cue rendering
		if (opMask[mode] == true) {
			rasterLayerOpa[mode][GOAL] = defaultOpOpacity[mode];
		} else {
			rasterLayerOpa[mode][GOAL] = 0.0f;
		}

		// choose one of these exclusively
		if (mode == WC.THREAD_GPU_FRAG_DIFF) {
			resolveExclusiveOpMask(mode, WC.THREAD_GPU_FRAG_DWT);
		}
		if (mode == WC.THREAD_GPU_FRAG_DWT) {
			resolveExclusiveOpMask(mode, WC.THREAD_GPU_FRAG_DIFF);
		}
	}

	public void resolveExclusiveOpMask(int mode1, int mode2) {

		if (opMask[mode1] == true) {
			if (opMask[mode2] == true) {
				opMask[mode2] = false;
			}
		}
	}

	public void toggleOutputOptionMask(int mode) {
		if (outputOptionMask[mode] == false) {
			outputOptionMask[mode] = true;
		} else {
			outputOptionMask[mode] = false;
		}
	}

	public void toggleOutputFormatMask(int mode) {
		if (outputFormatMask[mode] == false) {
			outputFormatMask[mode] = true;
		} else {
			outputFormatMask[mode] = false;
		}
	}

	public void toggleOutputModeMask(int mode) {
		if (outputModeMask[mode] == false) {
			outputModeMask[mode] = true;
		} else {
			outputModeMask[mode] = false;
		}
	}

	public void toggleWidgetVisibility(int mode) {
		widgetVisibility[mode] += 1;
		widgetVisibility[mode] = widgetVisibility[mode] % 2;
	}

	
	public void unloadTimeline() {
		for (int sat = 0; sat < 2; sat++) {
			for (int i = 0; i < WC.TOTAL_SCAS; i++) {
				for (int j = 0; j < WC.SEC_IN_DAY; j++) {
					if (dataLoadStatus[sat][i][j] == WC.STATUS_WORKING
							|| dataLoadStatus[sat][i][j] == WC.STATUS_COMPLETE) {
						dataLoadStatus[sat][i][j] = WC.STATUS_READY;
						dataLoadInfo[sat][i][j] = WC.INFO_ERROR;
						// dataLoadScanSegment[sat][i][j] =WC.STATUS_ERROR;
					}
				}
			}
		}
	}
	
	public void unloadTimelinePartial(int beginTime, int endTime) {
		for (int sat = 0; sat < 2; sat++) {
			for (int i = 0; i < WC.TOTAL_SCAS; i++) {
				for (int j = 0; j < WC.SEC_IN_DAY; j++) {
					if (dataLoadStatus[sat][i][j] == WC.STATUS_WORKING
							|| dataLoadStatus[sat][i][j] == WC.STATUS_COMPLETE) {
						
						if (j>= beginTime && j <= endTime){
							
						} else {
							dataLoadStatus[sat][i][j] = WC.STATUS_READY;
							dataLoadInfo[sat][i][j] = WC.INFO_ERROR;
							// dataLoadScanSegment[sat][i][j] =WC.STATUS_ERROR;
						}
					}
				}
			}
		}
	}

	public void initTimelineImage() {
		// init the image

		timelineDrawThread = new TimelineDrawThread();
	}
	
	public void initTimelineRefs() {
		for (int sat = 0; sat < WC.TOTAL_FLIGHTS; sat++) {
			for (int i = 0; i < WC.TOTAL_SCAS; i++) {
				witFileList[sat][i] = new ArrayList();

				for (int j = 0; j < WC.SEC_IN_DAY; j++) {
					dataRefWITFile[sat][i][j] = WC.STATUS_ERROR;
				}

			}
		}
	}

	public void initTimeline() {
		for (int sat = 0; sat < WC.TOTAL_FLIGHTS; sat++) {
			for (int i = 0; i < WC.TOTAL_SCAS; i++) {
				// witFileList[i] = new ArrayList();
				for (int j = 0; j < WC.SEC_IN_DAY; j++) {
					dataLoadStatus[sat][i][j] = WC.STATUS_ERROR;
					dataLoadInfo[sat][i][j] = WC.INFO_ERROR;

					for (int e = 0; e < ERROR_STATE_COUNT; e++) {
						dataErrorHandling[sat][i][j][e] = 0;
					}
				}
			}
		}
	}

	
	public void loadMapData() {
		System.out.println("LOADING MAP DATA ");
		map = new MapLoader();
		String dir = defaultMapDataDirStr;
		File mapDataDir = new File(dir);

		String mapSegStr[] = mapDataDir.list();
		for (int i = 0; i < mapSegStr.length; i++) {
			if (!mapSegStr[i].contains("riv.txt")) {
				System.out.println("   " + mapSegStr[i]);
				map.loadBoundaryList(dir + mapSegStr[i]);
			}
		}

		// System.out.print(" - COMPLETE");

		System.out.println(map.coordList.size() + " SEGMENTS");
		for (int i = 0; i < map.coordList.size(); i++) {
			ArrayList a = (ArrayList) map.coordList.get(i);

			String sName = ((MapCoord) a.get(0)).segmentName;
			System.out.println("   SEGMENT COORDS: " + a.size() + " (" + sName
					+ ")");
		}

	}

	// load last state of the tivo
	public void loadPlaybackState() {

	}

	// load user settings
	public void loadUserState() {

	}

	public String getModeStr(int mode) {
		String str = "";

		if (mode == WC.THREAD_LOAD) {
			str = "WC.THREAD_LOAD";
		} else if (mode == WC.THREAD_DIFF) {
			str = "WC.THREAD_DIFF";
		} else if (mode == WC.THREAD_SEGMENT) {
			str = "WC.THREAD_SEGMENT";
		} else if (mode == WC.THREAD_CONV) {
			str = "WC.THREAD_CONV";
		} else if (mode == WC.THREAD_THRS) {
			str = "WC.THREAD_THRS";
		} else if (mode == WC.THREAD_FILT) {
			str = "WC.THREAD_FILT";
		} else if (mode == WC.THREAD_FEAT) {
			str = "WC.THREAD_FEAT";
		} else if (mode == WC.THREAD_MON) {
			str = "WC.THREAD_MON";
		} else if (mode == WC.THREAD_IDLE) {
			str = "WC.THREAD_IDLE";
		}

		return str;
	}

	public void getTimeMetaData() {

	}

	public void doPlaybackPause() {
		if (playheadDir == 0) {
			playheadDir = playheadDirPrev;
			playbackPaused = 0;
			userInterfaceInfoStr = "UNPAUSED";
		} else {
			playheadDirPrev = playheadDir;
			playheadDir = 0;
			playbackPaused = 1;
			userInterfaceInfoStr = "PAUSED";
		}
	}

	public int getNumValidFramesInHDF5R(String localPathStr) {
		HDF5_R h5;
		int numFrames = 0;
		try {
			h5 = new HDF5_R(localPathStr);

			CalRawData calRawData = h5.getCalRawData();
			FileMetaData fileMetaData = h5.getFileMetaData();

			int tempFrames = fileMetaData.getNumberOfFrames();

			FrameMetaData frameMetaData = h5.getFrameMetaData();

			if (frameMetaData != null) {
				FrameMetaData.MetaData theData = frameMetaData.getMetaData();

				for (int i = 0; i < tempFrames; i++) {
					if (theData.beginLine[i] == 0) {
						numFrames++;
					}
				}
			}

			h5.finalize();

			h5 = null;
			System.out.println("   FILE " + localPathStr + " CONTAINS "
					+ tempFrames + " FRAMES - " + numFrames
					+ " BEGIN WITH SCANLINE 0");
		} catch (Exception e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return numFrames;
	}

	public int getNumTotalFramesInHDF5R(String localPathStr) {
		HDF5_R h5;
		int numFrames = 0;
		try {
			h5 = new HDF5_R(localPathStr);

			FileMetaData fileMetaData = h5.getFileMetaData();

			numFrames = fileMetaData.getNumberOfFrames();

			h5.finalize();
			h5 = null;
		} catch (Exception e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return numFrames;
	}

	public void checkForNewHDF5RFiles() {

	}

	public void printFileOrderNext(ArrayList w, int loc) {
		try {
			if (loc != -1 && loc < w.size()) {
				WITFile wfa = (WITFile) w.get(loc);

				System.out.println(" " + wfa.minYear + " " + wfa.minDay + " "
						+ wfa.minSeconds);
				if (wfa != null && w != null) {
					if (wfa.nextID != -1) {
						printFileOrderNext(w, wfa.nextID);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(WC.STATUS_ERROR);
		}

	}

	public void printFileOrderPrev(ArrayList w, int loc) {

		try {
			if (loc != -1 && loc < w.size()) {
				WITFile wfa = (WITFile) w.get(loc);

				System.out.println(" " + wfa.minYear + " " + wfa.minDay + " "
						+ wfa.minSeconds);
				if (wfa != null && w != null) {
					if (wfa.prevID != -1) {
						printFileOrderPrev(w, wfa.prevID);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(WC.STATUS_ERROR);
		}

	}

	public void createFileOrderNext(ArrayList w, int loc, int stackDepth) {

		if (loc >= 0) { // catch IDs which haven't been toggled to valid
			// locations
			WITFile wfa = (WITFile) w.get(loc);

			if (wfa.prepNextCompleted == -1) {

				wfa.prepNextCompleted = 1;
				w.set(loc, wfa); // replace object with modifications

				// find next
				if (wfa.nextID == -1) { // prevent redundant computation
					int aYear = wfa.minYear;
					int aDay = wfa.minDay;
					int aSec = (int) wfa.minSeconds;

					long diffN = Long.MAX_VALUE;
					// System.out.println("DEPTH "+stackDepth+" - TRAVERSING "+loc+" NEXT");
					for (int b = 0; b < w.size(); b++) {
						if (b != loc) {

							WITFile wfb = (WITFile) w.get(b);
							int bYear = wfb.minYear;
							int bDay = wfb.minDay;
							int bSec = (int) wfb.minSeconds;

							if (bYear >= aYear) {
								if (bDay >= aDay) {
									if (bSec >= aSec) {
										int dYear = bYear - aYear;
										int dDay = bDay - aDay;
										int dSec = (int) (bSec - aSec);

										long diff = SECONDS_IN_DAY * dDay
												+ dSec;
										if (diff < diffN) {
											diffN = diff;
											wfa.nextID = b;
										}
									}
								}
							}
						}
					}
					w.set(loc, wfa); // replace object with modifications

					if (wfa.nextID >= 0) {
						stackDepth++;
						createFileOrderNext(w, wfa.nextID, stackDepth);
						stackDepth--;
					}
				}
			}
		}
	}

	public void createFileOrderPrev(ArrayList w, int loc, int stackDepth) {

		if (loc >= 0) { // catch IDs which haven't been toggled to valid
			// locations
			WITFile wfa = (WITFile) w.get(loc);

			if (wfa.prepPrevCompleted == -1) {

				wfa.prepPrevCompleted = 1;
				w.set(loc, wfa); // replace object with modifications

				if (wfa.prevID == -1) { // prevent redundant computation

					int aYear = wfa.minYear;
					int aDay = wfa.minDay;
					int aSec = (int) wfa.minSeconds;
					long diffP = Long.MAX_VALUE;
					for (int b = 0; b < w.size(); b++) {
						if (b != loc) {

							WITFile wfb = (WITFile) w.get(b);
							int bYear = wfb.minYear;
							int bDay = wfb.minDay;
							int bSec = (int) wfb.minSeconds;

							if (bYear <= aYear) {
								if (bDay <= aDay) {
									if (bSec <= aSec) {
										int dYear = aYear - bYear;
										int dDay = aDay - bDay;
										int dSec = (int) (aSec - bSec);
										long diff = SECONDS_IN_DAY * dDay
												+ dSec;

										if (diff < diffP) {
											diffP = diff;
											wfa.prevID = b;
										}
									}
								}
							}

						}
					}
					// wfa.prepPrevCompleted = 1;
					w.set(loc, wfa); // replace object with modifications
					if (wfa.prevID >= 0) {
						stackDepth++;
						createFileOrderPrev(w, wfa.prevID, stackDepth);
						stackDepth--;
					}
				}
			}
		}
	}

	public void createFileOrder(ArrayList w, int loc, int stackDepth) {

		if (true) {
			// if (stackDepth < 100000){

			if (loc >= 0) { // catch IDs which haven't been toggled to valid
				// locations
				WITFile wfa = (WITFile) w.get(loc);

				if (wfa.preprocessCompleted == -1) {
					// find prev

					wfa.preprocessCompleted = 1;

					long diffN = Long.MAX_VALUE;
					long diffP = Long.MAX_VALUE;

					int aYear = wfa.minYear;
					int aDay = wfa.minDay;
					int aSec = (int) wfa.minSeconds;

					// find next
					if (wfa.nextID == -1) { // prevent redundant computation

						for (int b = 0; b < w.size(); b++) {
							if (b != loc) {

								WITFile wfb = (WITFile) w.get(b);
								int bYear = wfb.minYear;
								int bDay = wfb.minDay;
								int bSec = (int) wfb.minSeconds;

								if (bYear >= aYear) {
									if (bDay >= aDay) {
										if (bSec >= aSec) {

											int dYear = bYear - aYear;
											int dDay = bDay - aDay;
											int dSec = (int) (bSec - aSec);

											long diff = SECONDS_IN_DAY * dDay
													+ dSec;

											if (diff < diffN) {
												diffN = diff;
												wfa.nextID = b;
											}
										}
									}
								}
							}
						}
					}

					// find prev
					if (wfa.prevID == -1) { // prevent redundant computation

						for (int b = 0; b < w.size(); b++) {
							if (b != loc) {

								WITFile wfb = (WITFile) w.get(b);
								int bYear = wfb.minYear;
								int bDay = wfb.minDay;
								int bSec = (int) wfb.minSeconds;

								if (bYear <= aYear) {
									if (bDay <= aDay) {
										if (bSec <= aSec) {

											int dYear = aYear - bYear;
											int dDay = aDay - bDay;
											int dSec = (int) (aSec - bSec);

											long diff = SECONDS_IN_DAY * dDay
													+ dSec;

											if (diff < diffP) {
												diffP = diff;
												wfa.prevID = b;
											}
										}
									}
								}
							}
						}
					}


					if (wfa.prevID >= 0) {
						stackDepth++;
						createFileOrder(w, wfa.prevID, stackDepth);
						stackDepth--;
					}
					if (wfa.nextID >= 0) {
						stackDepth++;
						createFileOrder(w, wfa.nextID, stackDepth);
						stackDepth--;
					}

					w.set(loc, wfa); // replace object with modifications

				}

			}
		}
	}

	public int findListIndex(ArrayList w, String path) {
		// fetch the index in the ArrayList for the root node
		int index = -1;

		for (int a = 0; a < w.size(); a++) {
			WITFile wfa = (WITFile) w.get(a);
			if (wfa.path.equalsIgnoreCase(path)) {

				return a;
			}
		}

		return index;
	}

	public int findListIndexSCA(ArrayList w, int year, int day, int secs) {
		// fetch the index in the ArrayList for the root node
		int index = -1;

		for (int a = 0; a < w.size(); a++) {
			WITFile wfa = (WITFile) w.get(a);
			if (wfa.minYear == year && wfa.minDay == day
					&& (int) wfa.minSeconds == secs) {

				return a;
			}
		}

		return index;
	}

	public void getDataCacheInfo(String dir, int modYear, int modDay,
			int modSecs) {
		// public void getDataCacheInfo(String dir, long minModDate){

		String[] allList = new File(dir).list();

		ArrayList matchList = new ArrayList();

		for (int i = 0; i < allList.length; i++) {

			// SCID33_SCA5_2010_028_001665
			int b1 = allList[i].indexOf("_", 9);
			int b2 = allList[i].indexOf("_", b1 + 1);
			int b3 = allList[i].indexOf("_", b2 + 1);
			int b4 = allList[i].indexOf(".", b3 + 1);

			String sYear = allList[i].substring(b1 + 1, b2);
			String sDay = allList[i].substring(b2 + 1, b3);
			String sSecs = allList[i].substring(b3 + 1, b4);

			int fYear = Integer.parseInt(sYear);
			int fDay = Integer.parseInt(sDay);
			int fSecs = Integer.parseInt(sSecs);

			// parse filename and filter

			int addFlag = 1; // revisit - filter the data being added to the
			// queue

			if (addFlag == 1) {
				matchList.add(allList[i]);
			} else {
				System.out.println("(ignore file " + allList[i] + ")");
			}

		}

		long metaStartTime = System.currentTimeMillis();
		for (int a = 0; a < matchList.size(); a++) {
			HDF5_R h5;
			WITFile wf = new WITFile();
			wf.path = dir + "/" + (String) matchList.get(a);

			if (a % 50 == 0) {

				System.out.println("PARSING METADATA - FILE " + a + " of "
						+ matchList.size() + " - "
						+ ((System.currentTimeMillis() - metaStartTime) / 1000)
						+ " secs");
			}

			try {
				
				if (wf.path.endsWith(".h5")) {
					
					h5 = new HDF5_R(wf.path);

					int arrayIndexSca = -1;
					int satID = 0;

					if (h5 != null) {
						FileMetaData fileMetaData = h5.getFileMetaData();
						wf.minYear = fileMetaData.getMinYear();
						wf.maxYear = fileMetaData.getMaxYear();
						wf.minDay = fileMetaData.getMinDay();
						wf.maxDay = fileMetaData.getMaxDay();
						wf.minSeconds = fileMetaData.getMinSeconds();
						wf.maxSeconds = fileMetaData.getMaxSeconds();
						wf.SCA = fileMetaData.getSca() - 1;// !!
						arrayIndexSca = wf.SCA;
						wf.SCID = fileMetaData.getScid();

						wf.minMinutes = (int) ((float) wf.minSeconds / 60f);
						wf.maxMinutes = (int) ((float) wf.maxSeconds / 60f);
						
						if (wf.SCID == 33) {
							satID = 0;
						} else if (wf.SCID == 34) {
							satID = 1;
						}

						if (scaLoadMask[satID][(wf.SCA)] == 1) { // hacky
							// filtering
							// of the
							// data //
							// array at
							// -1 !!
							System.out.println("PARSE3");
							for (int tSec = (int) Math.floor(wf.minSeconds) - 1; tSec <= (int) Math
									.ceil(wf.maxSeconds) + 1; tSec++) { // handle
								// fractional
								// seconds
								dataLoadStatus[satID][(wf.SCA)][tSec] = WC.STATUS_READY;
								// dataFilenames[satID][(wf.SCA)][tSec] =
								// wf.path;
								if (arrayIndexSca >= 0) {
									// System.out.println("ADD TO FILE LIST 1");
									dataRefWITFile[satID][(wf.SCA)][tSec] = witFileList[satID][arrayIndexSca]
											.size();
								}

							}
						}

						if (arrayIndexSca >= 0) {
							witFileList[satID][arrayIndexSca].add(wf);
							
						}

					} else {
						wf.fileLoadStatus = WC.STATUS_ERROR;
					}

					h5.finalize();

					h5 = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			} catch (Throwable e) {
				e.printStackTrace();
			}

		}

	}

	public void getDataCacheFileList(String dir, ArrayList fList) {
		// public void getDataCacheInfo(String dir, long minModDate){

		String[] allList = new String[fList.size()];
		for (int i = 0; i < fList.size(); i++) {
			allList[i] = new String();
			allList[i] = ((File) fList.get(i)).getName();
		}

		ArrayList matchList = new ArrayList();

		for (int i = 0; i < allList.length; i++) {

			matchList.add(allList[i]);

		}
		// !! ADDRESS MISSING PL4

		long metaStartTime = System.currentTimeMillis();
		for (int a = 0; a < matchList.size(); a++) {
			HDF5_R h5;
			WITFile wf = new WITFile();
			wf.path = dir + "/" + (String) matchList.get(a);

			if (a % 50 == 0) {
				System.out.println("PARSING METADATA - FILE " + a + " of "
						+ matchList.size() + " - "
						+ ((System.currentTimeMillis() - metaStartTime) / 1000)
						+ " secs");
			}

			try {
				if (wf.path.endsWith(".h5")) {
					h5 = new HDF5_R(wf.path);
					int arrayIndexSca = -1;
					int satID = 0;

					if (h5 != null) {
						FileMetaData fileMetaData = h5.getFileMetaData();

						wf.minYear = fileMetaData.getMinYear();
						wf.maxYear = fileMetaData.getMaxYear();
						wf.minDay = fileMetaData.getMinDay();
						wf.maxDay = fileMetaData.getMaxDay();
						wf.minSeconds = fileMetaData.getMinSeconds();// Math.floor(fileMetaData.getMinSeconds());
				
						wf.maxSeconds = fileMetaData.getMaxSeconds();// Math.ceil(fileMetaData.getMaxSeconds());
						wf.SCA = fileMetaData.getSca() - 1;// !!
						arrayIndexSca = wf.SCA;
						wf.SCID = fileMetaData.getScid();

						wf.minMinutes = (int) ((float) wf.minSeconds / 60f);
						wf.maxMinutes = (int) ((float) wf.maxSeconds / 60f);

						if (wf.SCID == 33) {
							satID = 0;
						} else if (wf.SCID == 34) {
							satID = 1;
						}

					

						if ((wf.SCA) >= 0) {
							//if (scaLoadMask[satID][(wf.SCA)] == 1) { 
								for (int tSec = (int) Math.floor(wf.minSeconds) - 1; tSec < (int) Math
										.ceil(wf.maxSeconds) + 1; tSec++) { // handle
									
									if (dataLoadStatus[satID][(wf.SCA)][tSec] < WC.STATUS_READY){
										dataLoadStatus[satID][(wf.SCA)][tSec] = WC.STATUS_READY;
									
									
									// dataFilenames[satID][(wf.SCA)][tSec] =
									// wf.path;
									if (arrayIndexSca >= 0) {
										// System.out.println("ADD TO FILE LIST 2");
										dataRefWITFile[satID][(wf.SCA)][tSec] = witFileList[satID][arrayIndexSca]
												.size();
									}
									dataErrorHandling[satID][(wf.SCA)][tSec][MISSING_ITEM_GEOLOCATION] = wf.missingDataItems[MISSING_ITEM_GEOLOCATION];
							
									}
								}
							//}
						} else {
							System.out.println("INVALID SCA");
						}

						if (arrayIndexSca >= 0) {
							witFileList[satID][arrayIndexSca].add(wf);

							//if (wf.SCA == 4) {

								String infoCache = "CACHED SCA " + wf.SCA
										+ " - TIME " + wf.minSeconds + " "
										+ wf.maxSeconds;
						}

					} else {
						wf.fileLoadStatus = WC.STATUS_ERROR;
					}

					h5.finalize();

					h5 = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			} catch (Throwable e) {
				e.printStackTrace();
			}

		}

	}

	public void loadSingleSCAfromList() {

	}

	public String autoFetchRootRecent(String dir, int segs) {
		String path = "";

		// find the file #segs back in time...

		String[] allList = new File(dir + "/").list();

		System.out.println(allList.length + " FILES IN DIR");

		int fileAgeHint = segs + 0;

		String recStr[] = new String[fileAgeHint];
		int recDays[] = new int[fileAgeHint];
		long recSecs[] = new long[fileAgeHint];

		for (int i = 0; i < recStr.length; i++) {
			recStr[i] = "";
			recDays[i] = 0;
			recSecs[i] = 0;
		}

		for (int a = 0; a < allList.length; a++) {
			if (allList[a].contains("SCA4")) { // match on our popular
				// SCA...needs to be more robust

				int breakPos1 = allList[a].indexOf("_", 0);
				int breakPos2 = allList[a].indexOf("_", breakPos1 + 1);
				int breakPos3 = allList[a].indexOf("_", breakPos2 + 1);
				int breakPos4 = allList[a].indexOf("_", breakPos3 + 1);
				int breakPos5 = allList[a].indexOf(".", breakPos4 + 1);

				int thisDay = Integer.parseInt(allList[a].substring(
						breakPos3 + 1, breakPos4));
				long thisSec = Integer.parseInt(allList[a].substring(
						breakPos4 + 1, breakPos5));

				if (thisDay > recDays[0]
						|| (thisDay == recDays[0] && thisSec > recSecs[0])) {
					// nudge
					for (int k = recStr.length - 1; k > 0; k--) {
						recStr[k] = recStr[k - 1];
						recDays[k] = recDays[k - 1];
						recSecs[k] = recSecs[k - 1];
					}
					// new
					recStr[0] = allList[a];
					recDays[0] = thisDay;
					recSecs[0] = thisSec;
				}
			}
		}

		path = recStr[recStr.length - 1];
		// path = recStr[0];
		System.out.println("NEWEST FILE " + recStr[0]);

		System.out.println("STARTING FILE " + path);

		// String fNames[] =
		return path;
	}

	public void updateBookmarkScrollOrder() {

	}

	public void scrollBookmarks(int dir) {

	}

	public void copyBookmarksFromWF() {
		if (bookmarkSyncFlag == WC.STATUS_ON) {
			for (int sat = 0; sat < WC.TOTAL_FLIGHTS; sat++) {
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					for (int i = 0; i < witFrameList[sat][k].size(); i++) {

						WITFrame w = (WITFrame) witFrameList[sat][k].get(i);

						for (int j = 0; j < w.bookmarkList.size(); j++) {
							bookmarkList.add(w.bookmarkList.get(j));
							w.bookmarkList.remove(j);
							// optionally purge from wfl
						}
					}
				}
			}
		}
	}

	public void scrollTimelineAfterTimelineRefresh(int secs){
		userTimelineOffset[GOAL] = -secs;
	}
	
	public void findDataChunks() {

		int timeGap = 10;

		for (int sat = 0; sat < 2; sat++) {
			for (int i = 10; i < WC.SEC_IN_DAY; i++) {
				for (int s = 0; s < WC.TOTAL_SCAS; s++) {
					if (i >= timeGap) {
						if (dataLoadStatus[sat][s][i] == WC.STATUS_READY
								&& dataLoadStatus[sat][s][i - timeGap] == WC.STATUS_ERROR
								&& dataLoadStatus[sat][s][i - 1] == WC.STATUS_ERROR) {

							BookmarkEvent be = new BookmarkEvent();
							be.statusCheckedByAuto = WC.STATUS_ON;
							be.eventLabel = "DATA SEGMENT START";
							be.timeStampSecOfDay = i;
							be.satID = sat;
							be.scaID = s;
							be.eventType = WC.EVENT_DATA_FEED;
							bookmarkList.add(be);

							userTimelineOffset[GOAL] = -i;
						}
					}

					if (i < WC.SEC_IN_DAY - timeGap) {
						if (dataLoadStatus[sat][s][i] == WC.STATUS_READY
								&& dataLoadStatus[sat][s][i + timeGap] == WC.STATUS_ERROR
								&& dataLoadStatus[sat][s][i + 1] == WC.STATUS_ERROR) {

							BookmarkEvent be = new BookmarkEvent();
							be.statusCheckedByAuto = WC.STATUS_ON;
							be.eventLabel = "DATA SEGMENT STOP";
							be.timeStampSecOfDay = i;
							be.satID = sat;
							be.scaID = s;
							be.eventType = WC.EVENT_DATA_FEED;
							bookmarkList.add(be);
							
						}
					}
				}
			}
		}

		System.out.println("LOADED DATA CHUNKS "+userTimelineOffset[GOAL]);
	}

	public void addBookmark() {
		BookmarkEvent be = new BookmarkEvent();

		be.detectionConfidence[WC.EVENT_DETECTOR_OPERATOR] = 1.0f;
		be.statusCheckedByOperator = WC.STATUS_ON;

		be.scaID = mouseOverSCA;
		be.lat = mouseLat;
		be.lon = mouseLon;

		bookmarkList.add(be);
	}

	public void loadMetadataExplicitFileList() { // !! NULL ERROR IN THIS FUNC
		// choose the files explicitly
		long modDate = 0; // to avoid filtering all the data, only parse
		// metadata of files modified after this date

		System.out.println("LOADING METADATA");

		// update the UI
		userInterfaceInfoStr = "IMPORTING METADATA";
		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;

		long selectedModDate = 0;
		String localPathStr = "";
		String fNameStr = "";
		String selDir = "";
		int SCIDno = 33;

		int minYear = 0;
		int minDay = 0;
		int minSecs = 0;

		int modYear = 0;
		int modDay = 0;
		int modSecs = 0;

		systemState = WC.SYSTEM_STATE_OFFLINE; // cease animation and processing

		// while we queue data

		if (loadSource == WC.LOAD_FILE_CHOOSER) {

			JFileChooser fc = new JFileChooser();

			// tivoRootDir
			// fc.setCurrentDirectory(new File("/export/data/hdf5/"));
			String loadDir = new String(defaultLoadDirStr);

			fc.setCurrentDirectory(new File(loadDir)); // dev data - known
			// content

			fc.setMultiSelectionEnabled(true);
			fc.showOpenDialog(cvt);
			if (fc != null && fc.getSelectedFile() != null){
			// show the most recently created files

			localPathStr = fc.getSelectedFile().getAbsolutePath();

			selDir = fc.getSelectedFile().getParentFile().getAbsolutePath();

			File[] fileListRay = fc.getSelectedFiles();

			ArrayList fileList = new ArrayList();
			for (int i = 0; i < fileListRay.length; i++) {
				fileList.add(fileListRay[i]);
			}

			lastLoadedDirStr = selDir;

			System.out.println("DIR " + lastLoadedDirStr);
			getDataCacheFileList(lastLoadedDirStr, fileList); //

			findDataChunks();
			BookmarkEvent be = (BookmarkEvent) bookmarkList.get(0);
			userFlight = be.satID;
			
			}
		} else if (loadSource == WC.LOAD_FILE_RECENT) {
			JFileChooser fc = new JFileChooser();

			// tivoRootDir
			// 
			String loadDir = new String(defaultLoadDirStr);

			fc.setCurrentDirectory(new File(loadDir)); // dev data - known
			// content
			fc.setCurrentDirectory(new File("/export/data/hdf5/r/"));

			fc.setMultiSelectionEnabled(true);
			fc.showOpenDialog(cvt);

			// show the most recently created files

			localPathStr = fc.getSelectedFile().getAbsolutePath();

			selDir = fc.getSelectedFile().getParentFile().getAbsolutePath();

			File[] fileList = fc.getSelectedFiles();

			int filteredFileLimit = 8 * 2 * 25;
			ArrayList fileListFiltered = new ArrayList();

			long cutoffTime = System.currentTimeMillis() - 1000 * 60 * 20;
			int fileFilterCount = 0;
			for (int i = 0; i < fileList.length; i++) {
				if (fileFilterCount < filteredFileLimit) {
					if (fileList[i].lastModified() > cutoffTime) {
						if (!fileList[i].getName().contains(".tmp")
								&& !fileList[i].isDirectory()) {
							fileListFiltered.add(fileList[i]);
							fileFilterCount++;
							System.out.println("ADDED FILE "
									+ fileList[i].getName());
						}
					}
				}
			}

			lastLoadedDirStr = selDir;

			System.out.println("DIR " + lastLoadedDirStr);
			getDataCacheFileList(lastLoadedDirStr, fileListFiltered); //
		

		}

		systemState = WC.SYSTEM_STATE_ONLINE;
	}

	public void loadMetadataQuickpassAndScanCheck(int segments, int userPrompt) {

		long modDate = 0; // to avoid filtering all the data, only parse
		// metadata of files modified after this date

		System.out.println("LOADING METADATA");

		// update the UI
		userInterfaceInfoStr = "IMPORTING METADATA";
		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;

		long selectedModDate = 0;
		String localPathStr = "";
		String fNameStr = "";
		String selDir = "";
		int SCIDno = 33;

		int minYear = 0;
		int minDay = 0;
		int minSecs = 0;

		int modYear = 0;
		int modDay = 0;
		int modSecs = 0;

		systemState = WC.SYSTEM_STATE_OFFLINE; // cease animation and processing
		// while we queue data
		JFileChooser fc = new JFileChooser();
		// tivoRootDir
		// fc.setCurrentDirectory(new File("/export/data/hdf5/"));
		String loadDir = new String(defaultLoadDirStr);

		if (userPrompt == 1) {
			fc.setCurrentDirectory(new File(loadDir)); // dev data - known
			// content

			fc.showOpenDialog(cvt);

			localPathStr = fc.getSelectedFile().getAbsolutePath();

			selDir = fc.getSelectedFile().getParentFile().getAbsolutePath();

			fNameStr = fc.getSelectedFile().getName();
			selectedModDate = new File(localPathStr).lastModified();

			lastLoadedFileStr = localPathStr;
			lastLoadedDirStr = selDir;

			HDF5_R h5;

			WITFile rootFile = new WITFile();
			try {
				h5 = new HDF5_R(localPathStr);

				CalRawData calRawData = h5.getCalRawData();
				FileMetaData fileMetaData = h5.getFileMetaData();

				rootFile.minYear = fileMetaData.getMinYear();
				rootFile.maxYear = fileMetaData.getMaxYear();
				rootFile.minDay = fileMetaData.getMinDay();
				rootFile.maxDay = fileMetaData.getMaxDay();
				rootFile.minSeconds = fileMetaData.getMinSeconds();
				rootFile.maxSeconds = fileMetaData.getMaxSeconds();
				rootFile.SCA = fileMetaData.getSca();
				rootFile.SCID = fileMetaData.getScid();

				rootFile.path = localPathStr;

				h5.finalize();

				h5 = null;

				SCIDno = rootFile.SCID;

				minYear = rootFile.minYear;
				minDay = rootFile.minDay;
				minSecs = (int) rootFile.minSeconds;

				modYear = rootFile.minYear;
				modDay = rootFile.minDay;
				modSecs = (int) rootFile.minSeconds;

			} catch (Throwable e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		} else if (userPrompt == 0) {

			HDF5_R h5;

			WITFile rootFile = new WITFile();
			try {
				h5 = new HDF5_R(lastLoadedFileStr);

				CalRawData calRawData = h5.getCalRawData();
				FileMetaData fileMetaData = h5.getFileMetaData();

				rootFile.minYear = fileMetaData.getMinYear();
				rootFile.maxYear = fileMetaData.getMaxYear();
				rootFile.minDay = fileMetaData.getMinDay();
				rootFile.maxDay = fileMetaData.getMaxDay();
				rootFile.minSeconds = fileMetaData.getMinSeconds();
				rootFile.maxSeconds = fileMetaData.getMaxSeconds();
				rootFile.SCA = fileMetaData.getSca();
				rootFile.SCID = fileMetaData.getScid();

				rootFile.path = localPathStr;

				h5.finalize();

				h5 = null;

				SCIDno = rootFile.SCID;

				minYear = rootFile.minYear;
				minDay = rootFile.minDay;
				minSecs = (int) rootFile.minSeconds;

			} catch (Throwable e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		System.out.println("DIR " + lastLoadedDirStr);
		getDataCacheInfo(lastLoadedDirStr, modYear, modDay, modSecs); //

		systemState = WC.SYSTEM_STATE_ONLINE;

	}

	// use UI to designate a root file to span from in either direction
	public void dynamicLoadSingleEntry(String fName) {

	}

	public void loadNextStep(int phPos, int secsToLoad) {

	}

	public void tearDown3DGlobe() {

	}

	// start and stop are in seconds-after-midnight, skip is in seconds
	public void dynamicLoadSingleSCA(int scaID, int timeStart, int timeStop,
			int timeSkip) {

	}

	public void resetViews() {

		// zoom

		// rotations
		for (int f = 0; f < WC.TOTAL_FLIGHTS; f++) {
			for (int k = 0; k < 3; k++) {
				los_error_rot[f][k] = 0;
			}
		}

		for (int c = 0; c < WC.COORDINATES_MODE_MAX; c++) {
			for (int k = 0; k < 3; k++) {
				view_rot[c][k] = 0;
			}
		}

		userTimelineZoom[GOAL] = 1f;
		userTimelineOffset[GOAL] = -witTimePlayhead;

		// data shims
	}

	// multi-threaded load
	public void dynamicLoad3(int phPos, int secsToLoad, int resetTheFilters,
			int skipSeconds, int purgeAllData) {

		//witTimePlayheadFloat = loopEnd-1;
		systemState = WC.SYSTEM_STATE_OFFLINE; // cease animation and processing
		// while we queue data

		if (autoReloadState == WC.STATUS_OFF) {
			autoReloadTime2 = System.currentTimeMillis();
		}

		if (autoUnpauseAfterLoad == 1) {
			if (playbackPaused == 0) {
				doPlaybackPause();
			}
			needsToAutoResumeFlag = 1;

			loadEndTimerLastUpdate = Long.MAX_VALUE;// System.currentTimeMillis();
		}

		loadStartTimer = System.currentTimeMillis();

		loadEndTimer = System.currentTimeMillis();

		dataState = WC.STATUS_READY;

		//int startTimeSecs = phPos;
		//int stopTimeSecs = phPos + secsToLoad;

		loopStartPrev = loopStart;
		loopEndPrev = loopEnd;
		
		loopStart = phPos;
		loopEnd = phPos + secsToLoad;

		userSelection[WC.START][WC.T] = loopStart;
		userSelection[WC.END][WC.T] = loopEnd;

		tearDown3DGlobe();

		witTimePlayheadFloat = 0;
		witTimePlayhead = 0;

		for (int f = 0; f < WC.TOTAL_FLIGHTS; f++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				witSCAPlayhead[f][k] = 0;
			}
		}

		System.out.println("LOAD INITIATED " + phPos + " " + secsToLoad);

		resetThreads();

		

		// timelineImageUpdateFlag = TIMELINE_UPDATE_ALL;
		loadedFlight = userFlight;

		// begin purge all
		if (purgeAllData == 1){
		

			loopStartPrev = loopStart;
			loopEndPrev = loopEnd;
			
		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				witFrameList[flight][k].removeAll(witFrameList[flight][k]);
			}
		}

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				witFrameList[flight][k] = null;
			}
		}
		unloadTimeline();
		
		

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				witFrameList[flight][k] = new ArrayList();
			}
		}
		// end purge all data
		} else {
		// purge partial
		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				for (int i=0; i<witFrameList[flight][k].size(); i++){
				WITFrame w = (WITFrame)witFrameList[flight][k].get(i);
				
				if (w.timeStampSecOfDay>= loopStartPrev && w.timeStampSecOfDay<=loopEndPrev){
					
				} else {
					//witFrameList[flight][k].set(i, null);
					witFrameList[flight][k].remove(i);
					
					
				}
			} witFrameList[flight][k].trimToSize();
			}
		}

		
		unloadTimelinePartial(loopStart, loopEnd);
		
		// end purge partial
		}
		
		System.runFinalization();
		// end purge

		// System.gc();

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {

			if (flightLoadMask[flight] == 1) {
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					if (scaLoadMask[flight][k] == 1) {
						timeCentricLists[flight][k] = new ArrayList();
					}
				}
			}
		}

		// System.out.println("LOADING " + startTimeSecs + "-" + stopTimeSecs);

		// mark the frames as incoming

		checkThreadActivityLevel();
		
		int loaderStartTime = loopStart;
		int loaderEndTime = loopEnd;
		
		if(loopStart<loopStartPrev && loopStartPrev > 0){
			loaderEndTime = loopStartPrev;
		} else if(loopEnd>loopEndPrev && loopEndPrev > 0){
			loaderStartTime = loopEndPrev;
		} else {
			//resetLastDrawIndex();
		}
		
		int finalSecsToLoad = loaderEndTime-loaderStartTime;
		
		if (loaderStartTime < 0){
			
		} else {
		
		System.out.println("LOADING "+loaderStartTime+" "+loaderEndTime+" .. "+finalSecsToLoad);

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {

			if (flightLoadMask[flight] == 1) {
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					for (int t = 0; t <= finalSecsToLoad; t += skipSeconds) { // !!
						// for (int t = 0; t <= secsToLoad; t+=skipSeconds) { //
						// !!

						if (scaLoadMask[flight][k] == 1
								&& witFileList[flight][k].size() > 0) {
							int t1 = Math.min(loaderStartTime + t, SECONDS_IN_DAY);
							int t2 = Math.min(loaderStartTime + t + skipSeconds,SECONDS_IN_DAY);

							if (dataRefWITFile[flight][k][t1] != -1) {
								WITFile wf1 = (WITFile) witFileList[flight][k]
										.get(dataRefWITFile[flight][k][t1]);

								String name = wf1.path;
								String name2 = "";

								WITFile wf2 = null;
								if (dataRefWITFile[flight][k][t2] != -1) {
									wf2 = (WITFile) witFileList[flight][k]
											.get(dataRefWITFile[flight][k][t2]);
									name2 = wf2.path;
								}

								if (dataLoadStatus[flight][k][loaderStartTime + t] == WC.STATUS_READY) {
									dataLoadStatus[flight][k][loaderStartTime + t] = WC.STATUS_WORKING;
									// timelineImageUpdateFlag = 1;
								}

								// construct the list of files to load from
								if (!name.equalsIgnoreCase(name2)
										|| timeCentricLists[flight][k].size() == 0) {
									if (name2.length() > 1) {

										wf2.loadedToWit = WC.STATUS_READY;

										// WITFile wfToLoad = new WITFile();
										// wfToLoad.
										// timeCentricLists[flight][k].add(name2);
										timeCentricLists[flight][k].add(wf2);
										System.out.println("SCA " + k
												+ " RESOURCE: " + name2);
									}
								}

							}
						}
					}
				}
			}
		}

		// createLoaderTasks();

		systemState = WC.SYSTEM_STATE_ONLINE;
		timelineImageUpdateFlag = WC.TIMELINE_UPDATE_ALL;
		syncAndForceTimelineRefresh();
		dynamicLoadStatus = WC.STATUS_COMPLETE;
		dynamicLoadTaskCreatorStatus = WC.STATUS_READY;

		// tag the start/stop for histogram and other filters
		int scaID = 0;// get a loaded SCA

		minLoadSeconds = loaderStartTime;//phPos;
		maxLoadSeconds = loaderEndTime;//phPos + secsToLoad;

		dataState = WC.STATUS_COMPLETE;
		System.runFinalization();
		activateQueueThreads();
		
		}

	}

	public void createLoaderTasks() {
		int tasksCreated = 0;

		System.out.println("CREATE LOAD TASKS");

		int itemsRemaining = 0;

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			if (flightLoadMask[flight] == 1) {

				for (int k = 0; k < WC.TOTAL_SCAS; k += 1) {

					if (timeCentricLists[flight][k] != null) {
						frameCountAlloc = 0;
						if (scaLoadMask[flight][k] == 1
								&& timeCentricLists[flight][k].size() > 0) {
							// for (int ff = 0; ff < 1; ff++) {
							for (int ff = 0; ff < timeCentricLists[flight][k]
									.size(); ff++) {

								WITFile wfRef = (WITFile) timeCentricLists[flight][k]
										.get(ff);

								int threadID = getThreadID();

								if (wfRef.loadedToWit != WC.STATUS_COMPLETE) {
									itemsRemaining++;
								}

								if (wfRef.loadedToWit == WC.STATUS_READY
										&& threadID != WC.STATUS_ERROR) {

									tasksCreated++;

									wfRef.loadedToWit = WC.STATUS_COMPLETE;
									timeCentricLists[flight][k].set(ff, wfRef);
									// update the UI
									userInterfaceInfoStr = "IMPORTING DATA - SCA "
											+ (k + 1);
									tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;

									// System.out.println("DYNAMIC LOADER");

									long selectedModDate = 0;
									String localPathStr = "";
									String fNameStr = "";
									String selDir = "";

									int SCIDno = 33;
									if (flight == 0) {

									} else {
										SCIDno = 34;
									}

									int mode = WC.THREAD_LOAD_HDF5R;

									int listIndex = 0;
									int recListIndex = 0;

									System.out
											.println("LOADING HDF5R STITCHED - SCA "
													+ k + "(" + (k + 1) + ")");

									ArrayList pList = new ArrayList();

									HDF5_R h5 = null;

									try {

										h5 = new HDF5_R(wfRef.path);

									} catch (Throwable e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}

									int scid = userScid;

									pList.add(k); // 0
									pList.add(flight); // 1
									// pList.add(SCIDno); // 1
									pList.add(h5); // 2

									pList.add(frameCountAlloc); // start
									// injecting
									// here
									// // param 3

									
									pList.add(minLoadSeconds); // 4
									pList.add(maxLoadSeconds); // 5
									pList.add(skipSeconds); // 6
									pList.add(burstSeconds); // 7

									// !! add reference to GL context?

									int ref1 = dataRefWITFile[flight][k][minLoadSeconds];
									int ref2 = dataRefWITFile[flight][k][maxLoadSeconds];

									if (ref1 == -1) {
										if (ref2 != -1) {
											ref1 = ref2;
										}
									}

									if (ref1 != -1) {
										WITFile wf1 = (WITFile) witFileList[flight][k]
												.get(ref1);

										int errorHandlingCode = 0;
										// timeCentricLists[k].size()
										if (dataErrorHandling[SCIDno - 33][k][0][MISSING_ITEM_GEOLOCATION] == 1) {

											errorHandlingCode = 1;
										} else {

										}
										pList.add(errorHandlingCode); // 8

										System.out
												.println("PARAMS FOR CONTRAST "
														+ wf1.minCalIntensity
														+ " "
														+ wf1.minCalIntensity
														+ " " + wf1.path);
										pList.add(wf1.minCalIntensity); // 9
										pList.add(wf1.maxCalIntensity); // 10
										pList.add(WC.STATUS_OFF); // 11 - enable
										// auto-contrast
										// using metadata

										pList.add(playbackScanSeqIndexMask); // 12
										pList.add(WORKAROUND_GPU_HDR); // 13
										pList.add(WORKAROUND_AUTO_CONTRAST); // 14
										pList.add(coordinateSpaceLoadMask); // 15
										pList.add(TILE_SIZE_X); // 16
										pList.add(TILE_SIZE_Y); // 17

										// System.out.println("THREAD ID " +
										// threadID);

										if (threadID != -1) {

											// will have to revisit to fix
											// import/export
											// params
											createParamList(mode, k);
											// refresh params in case
											// GUI changes were made
											imprRay[threadID] = new ImProcThread(
													getModeStr(mode), mode,
													witFrameList[flight][k],
													getIndexFromTime(
															minLoadSeconds, flight,
															k, skipSeconds,
															SCAN_DIR_BOTH),
													getIndexFromTime(
															maxLoadSeconds, flight,
															k, skipSeconds,
															SCAN_DIR_BOTH),
													pList);

											// imprRay[threadID].glProfile =
											// cvt.glProfile;

											imprRay[threadID].threadStatus = WC.THREAD_STATUS_QUEUED;
											System.out
													.println("SETTING THREAD "
															+ threadID
															+ " AS QUEUED ");

											pList = null;
										}

									}

								}

							}
						}
					}

				}
			}
		}
		if (tasksCreated > 0) {
			System.out.println("CREATED " + tasksCreated + " LOADER TASKS");
			System.runFinalization();
		}

		if (itemsRemaining == 0) {
			dynamicLoadTaskCreatorStatus = WC.STATUS_COMPLETE;
		}
	}
	
	public void createOclTasks() {
		int tasksCreated = 0;

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			if (flightLoadMask[flight] == 1) {

				for (int k = 0; k < WC.TOTAL_SCAS; k += 1) {

						if (scaLoadMask[flight][k] == 1){
			
							if (scaOclMask[flight][k] == WC.STATUS_READY){
								
							
								int threadID = getThreadID();

						
										if (threadID != WC.STATUS_ERROR) {
											
											System.out.println("CREATE OpenCL TASK");

											scaOclMask[flight][k] = WC.STATUS_QUEUED;

									userInterfaceInfoStr = "GPGPUing DATA - SCA "
											+ (k + 1);
									tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;


									long selectedModDate = 0;
									String localPathStr = "";
									String fNameStr = "";
									String selDir = "";

									int mode = WC.THREAD_GPU_OPENCL_TEST;

									int listIndex = 0;
									int recListIndex = 0;

									ArrayList pList = new ArrayList();

									
									pList.add(WC.THREAD_LOAD); // input source
									

									pList.add(minLoadSeconds); // 1
									pList.add(maxLoadSeconds); // 2
									pList.add(skipSeconds); // 3
									pList.add(burstSeconds); // 4

										
										pList.add(TILE_SIZE_X); // 16
										pList.add(TILE_SIZE_Y); // 17

						
											// will have to revisit to fix
											// import/export
											// params
											//createParamList(mode, k);
											// refresh params in case
											// GUI changes were made
											imprRay[threadID] = new ImProcThread(
													getModeStr(mode), mode,
													witFrameList[flight][k],
													getIndexFromTime(
															minLoadSeconds, flight,
															k, skipSeconds,
															SCAN_DIR_BOTH),
													getIndexFromTime(
															maxLoadSeconds, flight,
															k, skipSeconds,
															SCAN_DIR_BOTH),
													pList);

											imprRay[threadID].threadStatus = WC.THREAD_STATUS_QUEUED;
											System.out
													.println("SETTING THREAD "
															+ threadID
															+ " AS QUEUED ");
											
											tasksCreated++;

											pList = null;
										}
							}
						}

				}
			}
		}
		
		if (tasksCreated > 0) {
			System.out.println("CREATED " + tasksCreated + " OpenCL TASKS");
			//System.runFinalization();
		}

	}

	public void startImageExport(String extStr, int channelMask[], int markings) {

		JFileChooser fc = new JFileChooser();
		// tivoRootDir
		fc.setCurrentDirectory(new File(defaultSaveDirStr));
		fc.showSaveDialog(cvt);
		String expFileStr = fc.getSelectedFile().getAbsolutePath();

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				// UI files

				int mode = WC.THREAD_EXPORT_IMAGES;

				System.out.println("EXPORTING IMAGES");
				int threadID = getThreadID();
				if (threadID != -1) {
					ArrayList pList = new ArrayList();

					pList.add(userSelection[WC.START][WC.X]);
					pList.add(userSelection[WC.END][WC.X]);
					pList.add(userSelection[WC.START][WC.Y]);
					pList.add(userSelection[WC.END][WC.Y]);
					pList.add(expFileStr);
					pList.add(extStr);
					pList.add(channelMask);
					pList.add(playbackModeDir[userFlight]); // pList.add(frameSelectionMode);
					// set flags for what channels to output

					pList.add(userVideoMagnification);

					imprRay[threadID] = new ImProcThread(getModeStr(mode),
							mode, witFrameList[flight][k],
							userSelection[WC.START][WC.T],
							userSelection[WC.END][WC.T], pList);

					new Thread(imprRay[threadID]).start();
				}
			}
		}
	}

	// new, post project
	public void startImageExportProj2(String extStr, int channelMask[],
			int markings, int[][] bounds, float scale, int addUnprojected) {

		ArrayList pList = new ArrayList();
		ImProcThread it2 = new ImProcThread(extStr, addUnprojected,
				bookmarkList, addUnprojected, addUnprojected, bookmarkList);

		BufferedImage reprojImages[] = new BufferedImage[WC.TOTAL_SCAS];

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {

			}
		}
	}

	public void startImageExportProj(String extStr, int channelMask[],
			int markings, int[][] bounds, float scale, int addUnprojected) {

		JFileChooser fc = new JFileChooser();
		// tivoRootDir
		fc.setCurrentDirectory(new File(defaultSaveDirStr));
		fc.showSaveDialog(cvt);
		String expFileStr = fc.getSelectedFile().getAbsolutePath();

		// UI files

		int mode = WC.THREAD_EXPORT_PROJ_IMAGES;

		for (int k = 0; k < WC.TOTAL_SCAS; k++) {

			System.out.println("EXPORTING REPROJECTED IMAGES");
			int threadID = getThreadID();
			if (threadID != -1) {
				ArrayList pList = new ArrayList();

				pList.add(userSelection[WC.START][WC.X]);
				pList.add(userSelection[WC.END][WC.X]);
				pList.add(userSelection[WC.START][WC.Y]);
				pList.add(userSelection[WC.END][WC.Y]);
				pList.add(userSelection[WC.START][WC.T]);
				pList.add(userSelection[WC.END][WC.T]);
				pList.add(expFileStr); // 4
				pList.add(extStr);
				pList.add(channelMask);
				pList.add(playbackModeDir[userFlight]); // pList.add(frameSelectionMode);
				// set flags for what channels to output

				pList.add(userVideoMagnification);
				pList.add(bounds); // 9
				pList.add(scale); // 10
				pList.add(addUnprojected); // 11

				ArrayList contrastParamList = new ArrayList();
				contrastParamList.add(userContrast[WC.START] * histClusterSize);
				contrastParamList.add(userContrast[WC.END] * histClusterSize);
				contrastParamList.add(userContrastCPList);
				pList.add(contrastParamList); // 12
				pList.add(productClassificationLabelStr);// 13

				imprRay[threadID] = new ImProcThread(getModeStr(mode), mode,
						witFrameList[userFlight][k], 0,
						witFrameList[userFlight][k].size(), pList);
				// imprRay[threadID].setPriority(threadPriorities[WC.THREAD_EXPORT_PROJ_IMAGES]);
				Thread t = new Thread(imprRay[threadID]);
				t.setPriority(threadPriorities[WC.THREAD_EXPORT_PROJ_IMAGES]);
				// threadAllocations[threadID] = 1;
				try {
					t.join(threadTimeouts[WC.THREAD_EXPORT_PROJ_IMAGES]);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				t.start();

			}
		}

	}


	public void nudgeGLwindow() { // keep the GPU processing aligned with
		// additional UI

	}

	public void completeVideoExportFromGpu() {
		userInterfaceInfoStr = "ENCODING VIDEO...";

		if (newThreadEncodeVideo == 1) {

			vet = new VideoEncodeThread(defaultFfmpegScratchDirStr,
					batchFfmpegScratchDirStr, outputFormatMask,
					videoExportFileStr);

			Thread t = new Thread(vet);

			t.start();
			userInterfaceInfoStr = "STARTED FFMPEG ENCODING PROCESS (CHECK TERMINAL FOR DETAILS)";
		} else {
			try {

				File batchScratchFile = new File(defaultFfmpegScratchDirStr
						+ batchFfmpegScratchDirStr);

				for (int i = 0; i < outputFormatMask.length; i++) {

					if (outputFormatMask[i] == true) {

						if (i != WC.FORMAT_PNG && i != WC.FORMAT_JPG) {
							// final destination

							String destStr = videoExportFileStr;
							destStr = destStr.replaceAll("\\\\", "/");

							String commandStr = "ffmpeg";
							String ffmpegStr = "";

							String extStr = "";
							String paramStr = " ";

							if (i == WC.FORMAT_MP4) {
								paramStr = " -vcodec mpeg4  ";
								extStr = ".mp4";
							} else if (i == WC.FORMAT_MP4_H264) {
								paramStr = " -vcodec libx264 ";
								// intercept extension
								extStr = "(h264).mp4";
							} else if (i == WC.FORMAT_WMV) {
								paramStr = " -vcodec wmv2 ";
								extStr = ".wmv";
							} else if (i == WC.FORMAT_MPG) {
								extStr = ".mpg";
							}
							if (!destStr.endsWith(extStr)) {
								destStr = destStr + extStr;

							}

							paramStr += " -sameq ";
							// float encodingFps =
							// 1000f/(float)timeDeltaPlaybackMS; // need to
							// reference FPS of current system
							float encodingFps = 30f;
							String fpsStr = " -r " + encodingFps + " ";// " -r 2 ";//
							// " -r 15";
							String fpsOutStr = " -r 24 ";

							String inputStr = " -i "
									+ batchScratchFile.getAbsolutePath()
									+ "/%d.png";

							if (extStr.equalsIgnoreCase(".mpg")) {
								ffmpegStr = commandStr + fpsStr + inputStr
										+ fpsOutStr + paramStr + destStr;
							} else {
								ffmpegStr = commandStr + fpsStr + inputStr
										+ paramStr + destStr;
							}

							Runtime rt = Runtime.getRuntime();
							Process p = null;

							// InputStream is = new InputStream();
							p = rt.exec(ffmpegStr);

							InputHandler errorHandler = new InputHandler(p
									.getErrorStream(), "Error Stream");
							errorHandler.start();
							InputHandler outputHandler = new InputHandler(p
									.getInputStream(), "Output Stream");
							outputHandler.start();

							System.out.println("   FFMPEG: " + ffmpegStr);

							userInterfaceInfoStr = "FFMPEG: " + ffmpegStr;

							int pVal = p.waitFor();
							System.out.println("   FFMPEG EXIT VALUE " + pVal);

							if (pVal != 0) {
								userInterfaceInfoStr = "VIDEO ENCODING ERROR DETECTED (SEE TERMINAL FOR DETAILS)";
							}

							String commandChmod = "chmod 777 " + destStr;
							System.out.println(commandChmod);
							Runtime rtChmod = Runtime.getRuntime();
							Process pChmod = null;
							pChmod = rtChmod.exec(commandChmod);

							InputHandler errorHandler2 = new InputHandler(
									pChmod.getErrorStream(), "Error Stream");
							errorHandler2.start();
							InputHandler outputHandler2 = new InputHandler(
									pChmod.getInputStream(), "Output Stream");
							outputHandler2.start();

							int pVal2 = pChmod.waitFor();
							System.out.println("   CHMOD EXIT VALUE " + pVal2);

						}
					}
				}

				// copy PNGs if need be
				if (outputFormatMask[WC.FORMAT_PNG] == true) {

					System.out.println("   MOVING PNGs");
					String destPngStr = videoExportFileStr;
					destPngStr = destPngStr.replaceAll("\\\\", "/");
					destPngStr = destPngStr + "_PNGs";
					File pngDir = new File(destPngStr);
					pngDir.mkdir();

					File[] pngFiles = batchScratchFile.listFiles();

					for (int i = 0; i < pngFiles.length; i++) {
						// File copyPng = new
						// File(pngDir+pngFiles[i].getName());
						// copyPng.
						pngFiles[i].renameTo(new File(pngDir + "/"
								+ pngFiles[i].getName()));
					}

				}

				// cleanup PNGs
				boolean dk = deleteDir(batchScratchFile);
				if (dk) {
					System.out.println("   DELETED SCRATCH FRAMES FROM "
							+ batchScratchFile.getAbsolutePath());
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			System.out.println("VIDEO ENCODING COMPLETE");
			userInterfaceInfoStr = "VIDEO ENCODING COMPLETE";
		}
	}

	public static boolean deleteDir(File dir) {
		if (dir.isDirectory()) {
			String children[] = dir.list();
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteDir(new File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}

		return dir.delete();
	}

	public void startVideoExportFromGpu() {

		userInterfaceInfoStr = "SAVING VIDEO SOURCE IMAGES...";

		batchFfmpegScratchDirStr = System.currentTimeMillis() + "/";

		File batchScratchFile = new File(defaultFfmpegScratchDirStr
				+ batchFfmpegScratchDirStr);
		batchScratchFile.mkdir();

		JFileChooser fc = new JFileChooser();
		// tivoRootDir
		fc.setCurrentDirectory(new File(defaultSaveDirStr));
		fc.showSaveDialog(cvt);
		videoExportFileStr = fc.getSelectedFile().getAbsolutePath();
		// grab the buffer

		// put playhead back to start
		exportBounceVideoState = WC.STATUS_ON;
		bounceVideoFrameCount = 0;

		witTimePlayheadFloat = userSelection[WC.START][WC.T];
		witFrameListStep(playheadDir, 0);

	}

	public void startVideoExport(boolean formatMask[], boolean channelMask[],
			int frameSelectionMode) {

		userInterfaceInfoStr = "EXPORTING VIDEO";
		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;

		// propmt for data versions to save

		JFileChooser fc = new JFileChooser();
		// tivoRootDir
		fc.setCurrentDirectory(new File(defaultSaveDirStr));
		fc.showSaveDialog(cvt);
		String expFileStr = fc.getSelectedFile().getAbsolutePath();

		// UI files

		int mode = WC.THREAD_EXPORT_VIDEO;

		System.out.println("EXPORTING VIDEO");
		int threadID = getThreadID();
		if (threadID != -1) {

			// ArrayList pListRay = new ArrayList();
			ArrayList selectedScaWitFrameList = new ArrayList();

			ArrayList pList = new ArrayList();
			pList.add(userSelectionSCA);
			pList.add(expFileStr);
			// pList.add(extStr);

			pList.add(formatMask);
			pList.add(channelMask);
			pList.add(playbackModeDir[userFlight]); // pList.add(frameSelectionMode);
			// set flags for what channels to output

			pList.add(userVideoMagnification);
			pList.add(userSelectionSCAtouched);
			pList.add(userVideoExportSpeed);
			// pListRay.add(pList);

			pList.add(userSelection[WC.START][WC.T]);
			pList.add(userSelection[WC.END][WC.T]);

			pList.add(productClassificationLabelStr);
			pList.add(productTitleLabelStr);

			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				// if (userSelectionSCAtouched[k]==1){
				selectedScaWitFrameList.add(witFrameList[userFlight][k]);
				// }
			}

			imprRay[threadID] = new ImProcThread(getModeStr(mode), mode,
					selectedScaWitFrameList, loopStart, loopEnd, pList);

			// threadAllocations[threadID] = 1;
			imprRay[threadID].threadStatus = WC.THREAD_STATUS_QUEUED;
			System.out.println("SETTING THREAD " + threadID + " AS QUEUED ");

		}

	}

	public void startWeatherVideoExport(String extStr, int channelMask[],
			int frameSelectionMode) {

		userInterfaceInfoStr = "EXPORTING WEATHER VIDEO - GLOBAL";
		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;

		// propmt for data versions to save

		JFileChooser fc = new JFileChooser();
		// tivoRootDir
		fc.setCurrentDirectory(new File(defaultSaveDirStr));
		fc.showSaveDialog(cvt);
		String expFileStr = fc.getSelectedFile().getAbsolutePath();

		// UI files

		int mode = WC.THREAD_EXPORT_WEATHER_VIDEO;

		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			System.out.println("EXPORTING WEATHER VIDEO");
			int threadID = getThreadID();
			if (threadID != -1) {
				ArrayList pList = new ArrayList();
				pList.add(userSelection[WC.START][WC.X]);
				pList.add(userSelection[WC.END][WC.X]);
				pList.add(userSelection[WC.START][WC.Y]);
				pList.add(userSelection[WC.END][WC.Y]);
				pList.add(expFileStr);
				pList.add(extStr);
				pList.add(channelMask);
				pList.add(playbackModeDir[userFlight]); // pList.add(frameSelectionMode);
				// set flags for what channels to output

				pList.add(userVideoMagnification);
				pList.add(-90); // min lat - 9
				pList.add(90); // max lat - 10
				pList.add(-180); // min lon - 11
				pList.add(180); // max lon - 12
				pList.add(13.0f); // scale - 13
				pList.add(1600); // video width limit
				pList.add(1200); // video height limit
				pList.add(3.0f); // downsample - 16
				pList.add(3.0f); // stroke - 17
				// pList.add(1.0f); // stroke - 17

				pList.add(1); // embedscale - 18
				pList.add(13 * 180 - 500); // embed Y pos - 19

				pList.add(500); // padding

				pList.add(0); // embed x nudge

				imprRay[threadID] = new ImProcThread(getModeStr(mode), mode,
						witFrameList[userFlight][k], 0,
						witFrameList[userFlight][k].size(), pList);

				new Thread(imprRay[threadID]).start();

			}
		}

	}

	public void returnThread() {

	}

	public String degreesDecimalToDegreesMinutes(float decDeg, int latLonToggle) {

		int wholeDeg = (int) decDeg;
		float fracDeg = Math.abs(decDeg - wholeDeg);

		float minDeg = fracDeg * 60f;
		int wholeMin = (int) minDeg;
		float fracMin = minDeg - wholeMin;
		float secDeg = fracMin * 60f;
		int wholeSec = (int) secDeg;
		float fracSec = secDeg - wholeSec;

		int lenReq = 0;
		if (latLonToggle == WC.GEODATA_LON) {
			lenReq = 3;
		} else if (latLonToggle == WC.GEODATA_LAT) {
			lenReq = 2;
		}

		String degStr = "" + wholeDeg;
		while (degStr.length() < lenReq) {
			degStr = "0" + degStr;
		}
		String minStr = "" + wholeMin;
		while (minStr.length() < 2) {
			minStr = "0" + minStr;
		}
		String secStr = "" + wholeSec;
		while (secStr.length() < 2) {
			secStr = "0" + secStr;
		}

		String secFracStr = "" + fracSec;
		while (secFracStr.length() < 2) {
			secFracStr = "0" + secFracStr;
		}
		secFracStr = secFracStr.substring(1);
		if (secFracStr.length() > 4) {
			secFracStr = secFracStr.substring(0, 4);
		}

		StringBuilder s = new StringBuilder();
		s.append(degStr);
		s.append((char) 0x00b0);
		s.append(minStr);
		s.append("'");
		s.append(secStr);
		s.append(secFracStr);
		s.append("''");

		if (latLonToggle == WC.GEODATA_LON) {
			if (decDeg < 0) {
				s.append("W");
			} else if (decDeg > 0) {
				s.append("E");
			}
		} else if (latLonToggle == WC.GEODATA_LAT) {
			if (decDeg < 0) {
				s.append("S");
			} else if (decDeg > 0) {
				s.append("N");
			}
		}

		return s.toString();
	}

	public void revisePriorities() {

	}

	
	public void reloadNewData(int reloadDir, int autoFlag) {
		int newStart = 0;

		int purgeFlag = WC.STATUS_OFF;
		
		// forward
		if (reloadDir == 1){
			newStart = loopEnd - autoReloadBufferSeconds;
			purgeFlag = WC.STATUS_OFF;
		} else if (reloadDir == -1){ // reverse
			newStart = loopStart - (loadSeconds-autoReloadBufferSeconds);
			purgeFlag = WC.STATUS_OFF;
		} else if (reloadDir == 0){ // reverse
			newStart = userSelection[WC.START][WC.T];
			
			loadSeconds = userSelection[WC.END][WC.T]-userSelection[WC.START][WC.T];
			purgeFlag = WC.STATUS_ON;
		}
		
		systemState = WC.SYSTEM_STATE_OFFLINE;
		cvt.resetLastDrawIndex();
		
		knobPulseReloadTimer[CURRENT] = knobPulseStartIntensity;
		knobPulseReloadTimer[GOAL] = 0;
		
		userInterfaceInfoStr = "RELOADING...";
		
		
		dynamicLoad3(newStart, loadSeconds, 0, skipSeconds, purgeFlag);

	}
	public void drawSCAselectorGL(GL2 gl) {

		int[] vp = new int[4];
		gl.glGetIntegerv(GL2.GL_VIEWPORT, vp, 0);

		gl.glMatrixMode(GL2.GL_PROJECTION);
		gl.glLoadIdentity();
		int bounds = 1;
		int zoom = 100;
		float ratio = (float) viewportGlX / (float) viewportGlY;
		gl.glOrtho(-ratio, ratio, -1, 1, zoom * bounds, -zoom * bounds);
		float h = (float) viewportGlX / (float) viewportGlY;
		// glu.gluPerspective(50f, 1f, 1f, 100f);
		gl.glMatrixMode(GL2.GL_MODELVIEW);

		gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);
		// gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);
		gl.glPushMatrix();
		gl.glLoadIdentity();
		float uiScale = .00001f;
		gl.glScalef(uiScale, uiScale, uiScale);

		gl.glBegin(GL2.GL_QUADS);
		// outer - band
		int borderWidth = 6;
		int halfBorder = borderWidth / 2;
		int uiZ = -10;
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			// g.setColor(uiColors[scaSelectorBand[k]]);

			gl.glColor3i(uiColors[scaSelectorBand[k]].getRed(),
					uiColors[scaSelectorBand[k]].getGreen(),
					uiColors[scaSelectorBand[k]].getBlue());


			int startX = scaSelectorGraphic[k][WC.X] - halfBorder;
			int startY = scaSelectorGraphic[k][WC.Y] - halfBorder;
			int endX = startX + scaSelectorGraphic[k][WC.W] + borderWidth;
			int endY = startY + scaSelectorGraphic[k][WC.H] + borderWidth;

			gl.glVertex3f(startX, startY, uiZ);
			gl.glVertex3f(startX, endY, uiZ);
			gl.glVertex3f(endX, endY, uiZ);
			gl.glVertex3f(endX, startY, uiZ);
		}
		// inner - on/off
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			if (scaLoadMask[userFlight][k] == 0) { // off

				gl.glColor3i(uiColors[WC.COLOR_TIVO_SCA_SELECT_OFF].getRed(),
						uiColors[WC.COLOR_TIVO_SCA_SELECT_OFF].getGreen(),
						uiColors[WC.COLOR_TIVO_SCA_SELECT_OFF].getBlue());
				// g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_OFF]);
			} else if (scaLoadMask[userFlight][k] == 1) {

				gl.glColor3i(uiColors[WC.COLOR_TIVO_SCA_SELECT_ON].getRed(),
						uiColors[WC.COLOR_TIVO_SCA_SELECT_ON].getGreen(),
						uiColors[WC.COLOR_TIVO_SCA_SELECT_ON].getBlue());
				// g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_ON]);
			}

			int startX = scaSelectorGraphic[k][WC.X];
			int startY = scaSelectorGraphic[k][WC.Y];
			int endX = startX + scaSelectorGraphic[k][WC.W];
			int endY = startY + scaSelectorGraphic[k][WC.H];

			gl.glColor3f(1f, 0f, 0f);

			gl.glVertex3f(startX, startY, uiZ);
			gl.glVertex3f(startX, endY, uiZ);
			gl.glVertex3f(endX, endY, uiZ);
			gl.glVertex3f(endX, startY, uiZ);
		}
		// labels
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			if (scaLoadMask[userFlight][k] == 1) {
				gl.glColor3i(0, 0, 0);
				// g.setColor(Color.black);
			} else if (scaLoadMask[userFlight][k] == 0) {
				gl.glColor3i(255, 255, 255);
				// g.setColor(Color.white);
			}
			// g.drawString(scaSelectorString[k],scaSelectorGraphic[k][WC.X] +
			// 20,scaSelectorGraphic[k][WC.Y] + 20);
		}
		gl.glEnd();

		gl.glPopMatrix();

	}

	public void drawSCAselector() {
		Graphics2D g = (Graphics2D) viewportImage.getGraphics();

		// outer - band
		int borderWidth = 6;
		int halfBorder = borderWidth / 2;
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			g.setColor(uiColors[scaSelectorBand[k]]);

			g.fillRect(scaSelectorGraphic[k][WC.X] - halfBorder,
					scaSelectorGraphic[k][WC.Y] - halfBorder,
					scaSelectorGraphic[k][WC.W] + borderWidth,
					scaSelectorGraphic[k][WC.H] + borderWidth);
		}
		// inner - on/off
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			if (scaLoadMask[userFlight][k] == 0) { // off

				g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_OFF]);
			} else if (scaLoadMask[userFlight][k] == 1) {

				g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_ON]);
			}
			g.fillRect(scaSelectorGraphic[k][WC.X],
					scaSelectorGraphic[k][WC.Y], scaSelectorGraphic[k][WC.W],
					scaSelectorGraphic[k][WC.H]);
		}
		// labels
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			if (scaLoadMask[userFlight][k] == 1) {
				g.setColor(Color.black);
			} else if (scaLoadMask[userFlight][k] == 0) {
				g.setColor(Color.white);
			}
			g.drawString(scaSelectorString[k],
					scaSelectorGraphic[k][WC.X] + 20,
					scaSelectorGraphic[k][WC.Y] + 20);
		}

	}

	public int intensityToContrastX(int intensity) {
		// non-linear mapping of the intensities to the histogram
		int xPos = intensity / histClusterSize;

		return xPos;
	}

	public void resetLastDrawIndex() {
		for (int f = 0; f < WC.TOTAL_FLIGHTS; f++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				for (int s = 0; s < WC.SCA_MAX_SCAN_SEGMENTS; s++) {

					// lastDrawIndex[f][k][s] = -1;
				}
				lastDrawIndexList[f][k] = new ArrayList();
			}
		}
	}

	public String secondsOfDayToReadableF(float seconds) {
		String secStr = "";
		int secInt = (int) Math.floor(seconds);

		secStr = secondsOfDayToReadable(secInt);

		float secsFrac = seconds - secInt;
		String secsFracStr = secsFrac + "";

		secsFracStr = secsFracStr.substring(2, secsFracStr.length()); // get rid
		// of
		// leading
		// "0."
		int fracStrLen = 3;
		while (secsFracStr.length() < fracStrLen) {
			secsFracStr = secsFracStr + "0";
		}
		if (secsFracStr.length() > fracStrLen) {
			secsFracStr = secsFracStr.substring(0, fracStrLen);
		}
		secStr = secStr + "." + secsFracStr;

		return secStr;

	}

	public String secondsOfDayToReadable(int seconds) {

		int tPos = seconds;
		int hour = tPos / (WC.SEC_IN_HOUR);
		String hourStr = hour + "";
		if (hour < 10) {
			hourStr = "0" + hour;
		}
		int min = (tPos - hour * WC.SEC_IN_HOUR) / (60);
		String minStr = "" + min;
		if (min < 10)
			minStr = "0" + minStr;

		int sec = (tPos - hour * WC.SEC_IN_HOUR - min * 60);
		String secStr = "" + sec;
		if (sec < 10)
			secStr = "0" + secStr;

		hourStr += ":" + minStr + ":" + secStr;

		return hourStr;
	}

	public void syncAndForceTimelineRefresh() {

		//System.out.println("TIMELINE STATUS "+timelineImageUpdateFlag+" "+timelineImageTexSyncGlDrawListFlag);
		
		//if (timelineDrawThread != null) {
			// timelineImageTexSyncGlFlag = WC.STATUS_COMPLETE;
			// ensure there's a pending update (this.timelineImageUpdateFlag)
			// and the draw thread is not in-progress
			// (timelineDrawThread.timelineImageUpdateFlag)

			if (timelineImageUpdateFlag != WC.TIMELINE_UPDATE_NONE){
					//&& timelineDrawThread.timelineImageUpdateFlag == WC.TIMELINE_UPDATE_NONE) {

				timelineDrawThread.dataLoadStatus = dataLoadStatus;
				timelineDrawThread.dataLoadInfo = dataLoadInfo;
				timelineDrawThread.witFrameList = witFrameList;
				//timelineDrawThread.timelineGraphics = timelineGraphics;
				timelineDrawThread.timelineImageUpdateFlag = timelineImageUpdateFlag;
				timelineDrawThread.drawTimelineImage();

				timelineImageUpdateFlag = WC.TIMELINE_UPDATE_NONE;
				// sync GPU texture

				// if (timelineImageTexSyncGlDrawListFlag ==
				// WC.STATUS_COMPLETE){
				timelineImageTexSyncGlDrawListFlag = WC.STATUS_READY;
				// }
			}
		//}
	}


	public static float getLatLonX(float radius, float lat, float lon) {

		float latRad = (float) (lat * (Math.PI / 180.0f));
		float lonRad = (float) (lon * (Math.PI / 180.0f));
		float x = (float) (-radius * Math.cos(latRad) * Math.cos(lonRad));
		return -x;
	}

	public static float getLatLonY(float radius, float lat, float lon) {

		float latRad = (float) (lat * (Math.PI / 180.0f));
		float lonRad = (float) (lon * (Math.PI / 180.0f));
		float y = (float) (radius * Math.sin(latRad));
		return y;
	}

	public static float getLatLonZ(float radius, float lat, float lon) {

		float latRad = (float) (lat * (Math.PI / 180.0f));
		float lonRad = (float) (lon * (Math.PI / 180.0f));
		float z = (float) (radius * Math.cos(latRad) * Math.sin(lonRad));
		return z;
	}

	public static float[] getLatLonFromXyz(float x, float y, float z,
			float radius) {

		float latRad = (float) Math.asin(y / radius);
		float lat = (float) (latRad / (Math.PI / 180.0f));

		float lonRad = (float) Math.asin(z / (radius * Math.cos(latRad)));
		float lon = (float) (lonRad / (Math.PI / 180.0f));

		float[] results = new float[2];

		results[WC.GEODATA_LON] = lon;
		results[WC.GEODATA_LAT] = lat;

		return results;
	}

	public void createGlobeMapList(GL2 gl) {
		System.out.println("CREATE MAP-GLOBE LIST");

		int pointCount = 0;

		// GL2 gl2 = gl.getGL2();

		globeMapList = gl.glGenLists(1);
		System.out.println("globe list ID " + globeMapList);

		gl.glNewList(globeMapList, GL2.GL_COMPILE);

		gl.glPushMatrix();
		// gl.glLoadIdentity();

		gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_LINE);

		gl.glColor3f(1.0f, 1.0f, 1.0f);
		float scaleTemp = .01f;
		// gl.glScalef(scaleTemp, scaleTemp, scaleTemp);

		for (int i = 0; i < map.coordList.size(); i++) {

			gl.glBegin(GL2.GL_LINE_STRIP);

			ArrayList segmentList = (ArrayList) map.coordList.get(i);
			String segName = ((MapCoord) segmentList.get(0)).segmentName;
			// System.out.println("NAME "+segName+ " i "+i);

			if (segName.contains("cil.txt")) {
				gl.glColor4f(0.0f, 0.30f, 1.0f, 1.0f);
			} else if (segName.contains("bdy.txt")) {
				gl.glColor4f(0.0f, 1.0f, 0.00f, 1.0f);
			} else {
				gl.glColor4f(0.0f, 1.0f, 0.00f, 1.0f);
			}

			int attempts = 0;
			int skipCoords = 1;
			for (int j = skipCoords; j < segmentList.size(); j += skipCoords) {
				attempts++;

				if (j < segmentList.size()) {
					MapCoord c1 = (MapCoord) segmentList.get(j - skipCoords);
					MapCoord c2 = (MapCoord) segmentList.get(j);

					float lat1i = c1.lat;// +90.0f;
					float lon1i = c1.lon;// +180.0f;

					float lat2i = c2.lat;// +90.0f;
					float lon2i = c2.lon;// +180.0f;

					float latD = (lat1i - lat2i);
					float lonD = (lon2i - lon1i);
					float distSq = latD * latD + lonD * lonD;
					if (distSq > coordProxSq) {
						gl.glEnd();
						gl.glBegin(GL2.GL_LINE_STRIP);
					} else {
						
						gl.glVertex3f(c1.projX, c1.projY, c1.projZ);
						pointCount++;
					}

				}
			}

			gl.glEnd();
		}

		gl.glPopMatrix();
		gl.glEndList();

		System.out.println("GLOBE POINTS: " + pointCount);
	}

	

	public void createGlobeLineList(GL2 gl) {
		System.out.println("CREATE GLOBE LINE LIST");

		int pointCount = 0;

		// GL2 gl2 = gl.getGL2();

		globeLineList = gl.glGenLists(1);

		gl.glNewList(globeLineList, GL2.GL_COMPILE);

		gl.glPushMatrix();
		// gl.glLoadIdentity();

		gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_LINE);
		//gl.glPolygonMode(GL2.GL_FRONT, GL2.GL_LINE);

		gl.glColor4f(1.0f, 1.0f, 1.0f, .15f);
		// gl.glColor4f(1.0f, 1.0f, 1.0f, .25f);

		gl.glPointSize(3.0f);

		float lonInc = .25f;
		float latInc = .25f;
		float lonJump = defaultGlobeLineLonSpacing;
		float latJump = defaultGlobeLineLatSpacing;

		for (float lat = -90; lat < 90; lat += latJump) {
			gl.glBegin(GL2.GL_LINE_STRIP);
			// gl.glBegin(GL2.GL_LINES);
			for (float lon = -180; lon <= 180; lon += lonInc) {
				float projX = 0;
				float projY = 0;
				float projZ = 0;

				projX = getLatLonX(globeRadius, lat, lon);
				projY = getLatLonY(globeRadius, lat, lon);
				projZ = getLatLonZ(globeRadius, lat, lon);
				gl.glVertex3f(projX, projY, projZ);

			}
			gl.glEnd();
		}

		for (float lon = -180; lon < 180; lon += lonJump) {
			gl.glBegin(GL2.GL_LINE_STRIP);
			// gl.glBegin(GL2.GL_LINES);
			for (float lat = -90; lat <= 90; lat += latInc) {
				float projX = 0;
				float projY = 0;
				float projZ = 0;

				projX = getLatLonX(globeRadius, lat, lon);
				projY = getLatLonY(globeRadius, lat, lon);
				projZ = getLatLonZ(globeRadius, lat, lon);
				gl.glVertex3f(projX, projY, projZ);

			}
			gl.glEnd();
		}

		gl.glPopMatrix();
		gl.glEndList();

	}


	public void createMapMercatorList(GL2 gl) {

		System.out.println("CREATE MAP-MERCATOR LIST");

		mercatorMapList = gl.glGenLists(1);

		gl.glNewList(mercatorMapList, GL2.GL_COMPILE);

		gl.glPushMatrix();
		// gl.glLoadIdentity();
		gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_LINE);

		gl.glColor3f(1.0f, 1.0f, 1.0f);

		for (int i = 0; i < map.coordList.size(); i++) {

			gl.glBegin(GL2.GL_LINE_STRIP);

			ArrayList segmentList = (ArrayList) map.coordList.get(i);
			String segName = ((MapCoord) segmentList.get(0)).segmentName;
			// System.out.println("NAME "+segName+ " i "+i);
			if (segName.contains("cil.txt")) {
				gl.glColor4f(0.0f, 0.30f, 1.0f, 1.0f);
			} else if (segName.contains("bdy.txt")) {
				gl.glColor4f(0.0f, 1.0f, 0.00f, 1.0f);
			} else {
				gl.glColor4f(0.0f, 1.0f, 0.00f, 1.0f);
			}

			int attempts = 0;
			int skipCoords = 1;

			for (int j = skipCoords; j < segmentList.size(); j += skipCoords) {
				attempts++;

				if (j < segmentList.size()) {
					MapCoord c1 = (MapCoord) segmentList.get(j - skipCoords);
					MapCoord c2 = (MapCoord) segmentList.get(j);

					float lat1i = c1.lat;// +90.0f;
					float lon1i = c1.lon;// +180.0f;

					float lat2i = c2.lat;// +90.0f;
					float lon2i = c2.lon;// +180.0f;

					float latD = (lat1i - lat2i);
					float lonD = (lon2i - lon1i);
					float distSq = latD * latD + lonD * lonD;
					if (distSq > coordProxSq) {
						gl.glEnd();
						gl.glBegin(GL2.GL_LINE_STRIP);
					} else {
						// keep similar size to globe
						gl.glVertex3f(lon1i / 180f, lat1i / 180f, 0);
					}

				}
			}

			gl.glEnd();
		}

		gl.glPopMatrix();
		gl.glEndList();

	}

	public void drawCurtain(GL2 gl) {
		int curtainSize = 100;

		// occlude the back portion of the globe

		gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);
		gl.glPushMatrix();
		gl.glLoadIdentity();
		gl.glBegin(GL2.GL_QUADS);

		gl.glColor4f(0, 0, 0, globe_opacity);
		gl.glVertex3i(curtainSize, curtainSize, 0);
		gl.glVertex3i(-curtainSize, curtainSize, 0);
		gl.glVertex3i(-curtainSize, -curtainSize, 0);
		gl.glVertex3i(curtainSize, -curtainSize, 0);
		gl.glEnd();
		gl.glPopMatrix();
	}

	public void drawCurtainTimeline(GL2 gl) {

		// blackout the control area
		float glTimelineScale = .0016f;
		gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);
		gl.glPushMatrix();
		gl.glLoadIdentity();
		gl.glScalef(glTimelineScale, -glTimelineScale, glTimelineScale);
		gl.glTranslatef(0, 422, 0);

		gl.glColor3f(0f, 0f, 0f);
		// gl.glDisable(GL2.GL_DEPTH_TEST);
		gl.glBegin(GL2.GL_QUADS);
		int blackoutW = 2000;
		int blackoutH = 600;
		float depth = 1f;
		gl.glVertex3f(-blackoutW, 0, depth);
		gl.glVertex3f(-blackoutW, blackoutH, depth);
		gl.glVertex3f(blackoutW, blackoutH, depth);
		gl.glVertex3f(blackoutW, 0, depth);
		gl.glEnd();
		// gl.glEnable(GL2.GL_DEPTH_TEST);
		gl.glPopMatrix();

		// end blackout
	}

	private FloatBuffer setupBuffer(ByteBuffer buf) {
		buf.order(ByteOrder.nativeOrder());
		return buf.asFloatBuffer();
	}

	public void setViewToLatLon(float lat, float lon) {

	}

	public void setViewToEcf(float x, float y, float z) {

	}

	public void setViewToSat() {
		if (coordinateMode == WC.COORDINATES_GLOBE) {
			view_rot[coordinateMode][WC.X] = 0;
			view_rot[coordinateMode][WC.Y] = 0;
			view_rot[coordinateMode][WC.Z] = 0;
		}
	}

	public void setViewToPolar() {
		if (coordinateMode == WC.COORDINATES_GLOBE) {
			view_rot[coordinateMode][WC.X] = 0;
			view_rot[coordinateMode][WC.Y] = 0;
			view_rot[coordinateMode][WC.Z] = 0;
		}
	}

	// less accurate, but quicker
	public void scaMetadataToKml() {

	}

	public void tilesToKml() {
		JFileChooser fc = new JFileChooser();
		
		fc.setCurrentDirectory(new File(defaultSaveDirStr));
		fc.showSaveDialog(cvt);

		File saveFile = fc.getSelectedFile();
		try {
			BufferedWriter bout = new BufferedWriter(new FileWriter(saveFile));

			String kmlStr = "";

			kmlStr += "<kml xmlns='http://www.opengis.net/kml/2.2'>";

			for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
				if (flightLoadMask[flight] == 1) {
					for (int k = 0; k < WC.TOTAL_SCAS; k++) {
						if (scaLoadMask[flight][k] == 1) {

							kmlStr += "<Placemark>";
							String nameStr = "<name> Footprint - Flight "
									+ (flight + 1) + " - SCA " + (k + 1)
									+ "</name>";
							kmlStr += nameStr;

							System.out.println("GEN KML: " + nameStr);

							kmlStr += "<Polygon><altitudeMode>relativeToGround</altitudeMode><outerBoundaryIs><LinearRing><coordinates>";

							if (witFrameList[flight][k] != null) {
								if (witFrameList[flight][k].size() > 0
										&& witSCAPlayhead[flight][k] >= 0
										&& witSCAPlayhead[flight][k] < witFrameList[flight][k]
												.size()) {

									WITFrame rasterFrame = null;
									if (lastDrawIndexList[flight][k] != null) {
										if (lastDrawIndexList[flight][k].size() != 0) {
											rasterFrame = (WITFrame) witFrameList[flight][k]
													.get((Integer) lastDrawIndexList[flight][k]
															.get(lastDrawIndexList[flight][k]
																	.size() - 1));
										}
									}

									if (rasterFrame != null) {

										if (rasterFrame.glDrawListStatusPerCoordinateSystem[WC.COORDINATES_GLOBE] == WC.STATUS_READY
												&& rasterFrame.glTexStatus == WC.STATUS_COMPLETE) {

											int blockCountX = rasterFrame.geoLocDataSparse.length - 1;
											int blockCountY = rasterFrame.geoLocDataSparse[0].length - 1;

											for (int x = 0; x < (blockCountX); x++) {

												for (int y = 0; y < (blockCountY); y++) {
													
													float tLatLon[][] = new float[4][2];

													int indicesX[] = new int[4];
													int indicesY[] = new int[4];

													int xSkip = rasterFrame.tileSizeX;
													int ySkip = rasterFrame.tileSizeX;

													indicesX[0] = x;
													indicesX[1] = x;
													indicesX[2] = x + 1;
													indicesX[3] = x + 1;

													indicesY[0] = y;
													indicesY[1] = y + 1;
													indicesY[2] = y + 1;
													indicesY[3] = y;

													int okayCountX = 0;
													int okayCountY = 0;

													int destX[] = new int[4];
													int destY[] = new int[4];

													for (int j = 0; j < 4; j++) {

														destX[j] = indicesX[j]
																* xSkip;
														destY[j] = indicesY[j]
																* ySkip;

														tLatLon[j][WC.GEODATA_LON] = rasterFrame.geoLocDataSparse[indicesX[j]][indicesY[j]][WC.GEODATA_LON];
														tLatLon[j][WC.GEODATA_LAT] = rasterFrame.geoLocDataSparse[indicesX[j]][indicesY[j]][WC.GEODATA_LAT];

													}

													int okayCount = 0;
													for (int j = 0; j < 4; j++) {
														if (tLatLon[j][WC.GEODATA_LON] != WC.INVALID_GEOLOCATION) {
															okayCount++;
														}
													}
													if (okayCount >= 3) {

														for (int j = 0; j <= 4; j++) { // complete
															// the
															// perimeter
															if (tLatLon[j % 4][WC.GEODATA_LON] != WC.INVALID_GEOLOCATION) {
																String coordStr = tLatLon[j % 4][WC.GEODATA_LON]
																		+ ","
																		+ tLatLon[j % 4][WC.GEODATA_LAT]
																		+ ","
																		+ 0
																		+ " ";
																kmlStr += coordStr;
															}
														}

													}

												}
											}
										}
									}
								}
							}

							kmlStr += "</coordinates></LinearRing></outerBoundaryIs></Polygon>";

							kmlStr += "</Placemark>";
						}
					}
				}
			}

			kmlStr += "</kml>";

			bout.write(kmlStr);

			bout.close();

			System.out.println("SAVED KML");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public void render3D(GL2 gl) {
		// gl = drawable.getGL();

		if (opMask[WC.THREAD_GPU_FRAG_TIMELAPSE] == true) {
			renderClearBypass = 1;
		} else {
			renderClearBypass = 0;
		}

		if (firstRenderPass == WC.STATUS_READY) {
			boolean vboTest = gl.isFunctionAvailable("glGenBuffers");
			System.out.println("VBO support " + vboTest);
			System.out.println("GL Version " + gl.glGetString(GL2.GL_VERSION));
			System.out
					.println("GL Renderer " + gl.glGetString(GL2.GL_RENDERER));
			System.out.println("GL Vendor " + gl.glGetString(GL2.GL_VENDOR));
			System.out.println("GL Ext " + gl.glGetString(GL2.GL_EXTENSIONS));
			// firstRenderPass = WC.STATUS_ERROR;
		}

		long renderTime3D1 = System.currentTimeMillis();

		int[] vp = new int[4];
		gl.glGetIntegerv(GL2.GL_VIEWPORT, vp, 0);

		gl.glMatrixMode(GL2.GL_PROJECTION);
		gl.glLoadIdentity();
		int bounds = 1;
		int zoom = 1000;
		float ratio = (float) viewportGlX / (float) viewportGlY;
		gl.glOrtho(-ratio, ratio, -1, 1, zoom * bounds, -zoom * bounds);
		float h = (float) viewportGlX / (float) viewportGlY;
		// glu.gluPerspective(50f, 1f, 1f, 100f);
		gl.glMatrixMode(GL2.GL_MODELVIEW);

		gl.glEnable(GL2.GL_DEPTH_TEST);

		gl.glEnable(GL2.GL_BLEND);
		// gl.glEnable(GL2.GL_LINE_SMOOTH);
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);

		gl.glShadeModel(GL2.GL_FLAT);

		gl.glClearColor(0f, 0f, 0f, 1.0f);

		if (renderClearBypass == 1) {
			gl.glClear(GL.GL_DEPTH_BUFFER_BIT);
		} else {
			if (opMask[WC.THREAD_GPU_FRAG_BURNIN] == false) {
				gl.glClear(GL2.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT
						| GL2.GL_ACCUM_BUFFER_BIT);
			} else if (opMask[WC.THREAD_GPU_FRAG_BURNIN] == true) {
				gl.glClear(GL.GL_DEPTH_BUFFER_BIT);
			}
		}

		int userMotionDetected = 0;
		if (userMotionDetected == 1) { // reset some filters based on screen
										// movement
			gl.glClear(GL2.GL_ACCUM_BUFFER_BIT);
		}

		gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_LINE);
		// gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);
		gl.glPushMatrix(); // push 0
		gl.glLoadIdentity();

		gl.glRotatef(view_rot[coordinateMode][WC.X], 1.0f, 0.0f, 0.0f);
		gl.glRotatef(-view_rot[coordinateMode][WC.Y], 0.0f, 1.0f, 0.0f);
		gl.glRotatef(view_rot[coordinateMode][WC.Z], 0.0f, 0.0f, 1.0f);

		float staticScaleAmount = .5f;
		// gl.glScalef(staticScaleAmount, staticScaleAmount, staticScaleAmount);

		gl.glScalef(view_scale[coordinateMode], view_scale[coordinateMode],
				view_scale[coordinateMode]);

		gl.glTranslatef(view_trans[coordinateMode][WC.X],
				view_trans[coordinateMode][WC.Y],
				view_trans[coordinateMode][WC.Z]);

		gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);
		gl.glEnable(GL2.GL_TEXTURE_2D);

		gl.glActiveTexture(GL2.GL_TEXTURE0);

		int TextureID[] = new int[1];

		int updateTexItems = 0;
		if (playheadDir != 0) {
			updateTexItems = 1;

		}
		// DRAW FROM VBO

		// DEBUG PATH

		float texCoordRay[][] = new float[4][2];
		texCoordRay[0][WC.X] = 0;
		texCoordRay[0][WC.Y] = 0;

		texCoordRay[1][WC.X] = 0;
		texCoordRay[1][WC.Y] = 1;

		texCoordRay[2][WC.X] = 1;
		texCoordRay[2][WC.Y] = 1;

		texCoordRay[3][WC.X] = 1;
		texCoordRay[3][WC.Y] = 0;

		gl.glColor3f(1f, 1f, 1f);

		// tex gen
		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {

			if (flightLoadMask[flight] == 1) {
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					if (scaLoadMask[flight][k] == 1) {
						if (witFrameList[flight][k] != null) {
							if (witFrameList[flight][k].size() > 0
									&& witSCAPlayhead[flight][k] >= 0
									&& witSCAPlayhead[flight][k] < witFrameList[flight][k]
											.size()) {

								WITFrame rasterFrame = null;
								if (scanDirAgreementDrawFlag[flight][k] == 1
										&& timeAgreementDrawFlag[flight][k] == 1
										&& scanSeqAgreementDrawFlag[flight][k] == 1) {

									rasterFrame = (WITFrame) witFrameList[flight][k]
											.get(witSCAPlayhead[flight][k]);

								} else { // draw previous otherwise
									// if (lastDrawIndex[flight][k] != -1){
									if (lastDrawIndexList[flight][k] != null) {
										if (lastDrawIndexList[flight][k].size() != 0) {
											rasterFrame = (WITFrame) witFrameList[flight][k]
													.get((Integer) lastDrawIndexList[flight][k]
															.get(lastDrawIndexList[flight][k]
																	.size() - 1));
										}
									}
								}

								if (rasterFrame != null) {

									if (rasterFrame.glTexStatus == WC.STATUS_READY) {

										try {
											for (int i = 0; i < rasterFrame.witFrameTiles
													.size(); i++) {
												WITFrameTile wft = (WITFrameTile) rasterFrame.witFrameTiles
														.get(i);

												if (wft.tileStatusPerCoordinateSystem[coordinateMode] == WC.STATUS_COMPLETE) {

													if (tileBufferFills < maxTiles) {
														// copy to VBO if new
														// frame

														if (wft.t == null
																&& updateTexItems == 1) {

													
															TextureData td = AWTTextureIO
																	.newTextureData(
																			GLProfile
																					.getDefault(),
																			wft.texBI,
																			false);
												
															wft.t = TextureIO
																	.newTexture(td);

															wft.texBI = null;

												
														}
													} else {

													}

												}

											}

											rasterFrame.glTexStatus = WC.STATUS_COMPLETE;
										} catch (Exception e) {
											e.printStackTrace(); // resource was
											// freed
										}

										// end list

									} else {
										// draw from compiled instructions

									}

								}
							}
						}
					}
				}
			}
		}

		// gen and use drawLists

		if (coordinateMode == WC.COORDINATES_SENSOR) {

			gl.glPolygonMode(GL2.GL_FRONT, GL2.GL_FILL);
			gl.glPolygonMode(GL2.GL_BACK, GL2.GL_FILL);

		} else {

			gl.glPolygonMode(GL2.GL_FRONT, GL2.GL_FILL);
			gl.glPolygonMode(GL2.GL_BACK, GL2.GL_FILL);
			// gl.glPolygonMode(GL2.GL_BACK, GL2.GL_LINE);

		}

		int totalPX = 0;

		int didCompile = 0;

		// user flip

		if (systemState == WC.SYSTEM_STATE_ONLINE) {
		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {

			// push manual adjustment to coords
			gl.glPushMatrix();
			// gl.glLoadIdentity();
			gl.glRotatef(-los_error_rot[flight][WC.X], 1.0f, 0.0f, 0.0f);
			gl.glRotatef(-los_error_rot[flight][WC.Y], 0.0f, 1.0f, 0.0f);
			gl.glRotatef(los_error_rot[flight][WC.Z], 0.0f, 0.0f, 1.0f);

			gl.glRotatef(user_view_rot[WC.CURRENT], 0.0f, 0.0f, 1.0f);

			if (flightLoadMask[flight] == 1) {

				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					if (scaLoadMask[flight][k] == 1) {
						if (witFrameList[flight][k] != null) {
							if (witFrameList[flight][k].size() > 0
									&& witSCAPlayhead[flight][k] >= 0
									&& witSCAPlayhead[flight][k] < witFrameList[flight][k]
											.size()) {

								WITFrame rasterFrame = null;

								if (scanDirAgreementDrawFlag[flight][k] == 1
										&& timeAgreementDrawFlag[flight][k] == 1
										&& scanSeqAgreementDrawFlag[flight][k] == 1) {

									rasterFrame = (WITFrame) witFrameList[flight][k]
											.get(witSCAPlayhead[flight][k]);

								} else { // draw previous otherwise

									if (lastDrawIndexList[flight][k] != null) {
										if (lastDrawIndexList[flight][k].size() != 0) {
											rasterFrame = (WITFrame) witFrameList[flight][k]
													.get((Integer) lastDrawIndexList[flight][k]
															.get(lastDrawIndexList[flight][k]
																	.size() - 1));
										}
									}
								}

								if (rasterFrame != null) {

									satPosEcf[flight][WC.X] = (float) rasterFrame.satPosECF[WC.X];
									satPosEcf[flight][WC.Y] = (float) rasterFrame.satPosECF[WC.Y];
									satPosEcf[flight][WC.Z] = (float) rasterFrame.satPosECF[WC.Z];

									setGlobeOverlayRotation(rasterFrame);

									// draw hist

									// end draw hist

									int glTileCount = 0;

									if (rasterFrame.glDrawListStatusPerCoordinateSystem[coordinateMode] == WC.STATUS_READY
											&& rasterFrame.glTexStatus == WC.STATUS_COMPLETE) {

										if (rasterFrame.glDrawListIdPerCoordinateSystem[coordinateMode] != WC.STATUS_ERROR) {
											// gl.glDeleteLists(rasterFrame.glDrawListID,
											// 1);
										}

										if (GPU_CONFIG_DISPLAY_LIST == WC.STATUS_ON) {
											rasterFrame.glDrawListIdPerCoordinateSystem[coordinateMode] = gl
													.glGenLists(1);

											gl
													.glNewList(
															rasterFrame.glDrawListIdPerCoordinateSystem[coordinateMode],
															GL2.GL_COMPILE);
										}

										try {
											for (int i = 0; i < rasterFrame.witFrameTiles
													.size(); i++) {
												WITFrameTile wft = (WITFrameTile) rasterFrame.witFrameTiles
														.get(i);

												if (wft.tileStatusPerCoordinateSystem[coordinateMode] == WC.STATUS_COMPLETE) {

													if (wft.t != null) {
														//System.out.println("RENDER TILE "+i+" OF "+rasterFrame.witFrameTiles.size()+" SCA "+rasterFrame.scaID);
														if (GPU_INTERPOLATE_PIXELS == WC.STATUS_OFF) {
															gl
																	.glTexParameteri(
																			GL.GL_TEXTURE_2D,
																			GL2.GL_TEXTURE_MIN_FILTER,
																			GL.GL_NEAREST);
															gl
																	.glTexParameteri(
																			GL.GL_TEXTURE_2D,
																			GL2.GL_TEXTURE_MAG_FILTER,
																			GL.GL_NEAREST);
														} else {
															gl
																	.glTexParameteri(
																			GL.GL_TEXTURE_2D,
																			GL2.GL_TEXTURE_MIN_FILTER,
																			GL.GL_LINEAR);
															gl
																	.glTexParameteri(
																			GL.GL_TEXTURE_2D,
																			GL2.GL_TEXTURE_MAG_FILTER,
																			GL.GL_LINEAR);
														}
														wft.t.enable(gl);
														wft.t.bind(gl);

														// wft.t.getEstimatedMemorySize();

														totalPX += wft.t
																.getWidth()
																* wft.t
																		.getHeight();
														didCompile++;
													}

													gl.glBegin(GL2.GL_QUADS);

													for (int j = 0; j < 4; j++) {
														gl
																.glTexCoord2f(
																		texCoordRay[j][WC.X],
																		texCoordRay[j][WC.Y]);
														gl
																.glVertex3f(
																		wft.xyzLoc[coordinateMode][j][WC.X],
																		wft.xyzLoc[coordinateMode][j][WC.Y],
																		wft.xyzLoc[coordinateMode][j][WC.Z]);
													}
													gl.glEnd();
													glTileCount++;

												}
											}

										} catch (Exception e) {
											e.printStackTrace(); // resource was
											// freed
										}

									}
									if (GPU_CONFIG_DISPLAY_LIST == WC.STATUS_ON && rasterFrame.glDrawListStatusPerCoordinateSystem[coordinateMode] == WC.STATUS_READY) {
										gl.glEndList();

										//System.out.println("ENDING GL CALLLIST");
										if (glTileCount > 2) {
											rasterFrame.glDrawListStatusPerCoordinateSystem[coordinateMode] = WC.STATUS_COMPLETE;
										}
									}
								}

								if (rasterFrame != null
										&& GPU_CONFIG_DISPLAY_LIST == WC.STATUS_ON) {
									if (rasterFrame.glDrawListStatusPerCoordinateSystem[coordinateMode] == WC.STATUS_COMPLETE
											&& rasterFrame.glDrawListIdPerCoordinateSystem[coordinateMode] != WC.STATUS_ERROR) {
										// draw from compiled instructions

										gl.glCallList(rasterFrame.glDrawListIdPerCoordinateSystem[coordinateMode]);
									}
								}
							}
						}
					}
				}
			}

			gl.glPopMatrix();

		}
		}

		gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
		// end gen and use drawLists

		// gl.glShadeModel(GL2.GL_FLAT);
		gl.glShadeModel(GL2.GL_SMOOTH);

		// SCA globe overlay
		int renderGlobeOverlay = 0;
		if (renderGlobeOverlay == 1) {
			gl.glPushMatrix(); // push 1

			float scaleTemp = .1f;// 1.002f; 
			gl.glScalef(scaleTemp, scaleTemp, scaleTemp);

			gl.glRotatef(overlayGlobeRot[userFlight][WC.X], 1.0f, 0.0f, 0.0f);
			gl.glRotatef(-overlayGlobeRot[userFlight][WC.Y], 0.0f, 1.0f, 0.0f);
			gl.glRotatef(overlayGlobeRot[userFlight][WC.Z], 0.0f, 0.0f, 1.0f);

			gl.glCallList(globeMapList);
			// drawCurtain();
			gl.glPopMatrix(); // pop 1
			drawCurtain(gl);
		}
		// end SCA globe overlay

		// mini globe ground track
		int renderMiniGlobe = 0;
		if (renderMiniGlobe == 1) {
			gl.glPushMatrix(); // push 1

			float scaleTemp = .01f;// 1.002f; 
			gl.glScalef(scaleTemp, scaleTemp, scaleTemp);

			gl.glRotatef(overlayGlobeRot[userFlight][WC.X], 1.0f, 0.0f, 0.0f);
			gl.glRotatef(-overlayGlobeRot[userFlight][WC.Y], 0.0f, 1.0f, 0.0f);
			gl.glRotatef(overlayGlobeRot[userFlight][WC.Z], 0.0f, 0.0f, 1.0f);

			gl.glCallList(globeMapList);

			// gl.glColor3f(1f,1f,0f);
			gl.glColor3f(1f, 0f, 0f);
			gl.glBegin(GL2.GL_POINTS);
			for (int i = 0; i < satTrackList.size(); i++) {
				float satXyz[] = (float[]) satTrackList.get(i);
				gl.glVertex3f(satXyz[WC.X], satXyz[WC.Y], satXyz[WC.Z]);
			}
			System.out.println("DRAW " + satTrackList.size() + " TRACE POINTS");

			gl.glEnd();

			gl.glColor3f(1f, 0f, 0f);
			gl.glBegin(GL2.GL_POINTS);

			gl.glVertex3f(overlayGlobeTrack[userFlight][WC.X],
					overlayGlobeTrack[userFlight][WC.Y],
					overlayGlobeTrack[userFlight][WC.Z]);
			gl.glEnd();

			// drawCurtain();
			gl.glPopMatrix(); // pop 1
			drawCurtain(gl);
		}
		// end SCA globe overlay

		// mask items
		if (coordinateMode == WC.COORDINATES_GLOBE
				&& overlayStates[WC.OVERLAY_GLOBE_LINES] == true) {

			gl.glPushMatrix(); // push 1

			float scaleTemp = 1.002f; // over 
			gl.glScalef(scaleTemp, scaleTemp, scaleTemp);

			// city call list

			gl.glPopMatrix(); // pop 1
			drawCurtain(gl);
		}

		

		// draw WxPolys
		gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_LINE);
		for (int i = 0; i < wxPolyList.size(); i++) {
			WxPoly wp = (WxPoly) wxPolyList.get(i);

			gl.glColor3f(wp.polyColor[0], wp.polyColor[1], wp.polyColor[2]);

			gl.glBegin(GL2.GL_POLYGON);

			for (int j = 0; j < wp.polyPoints.size(); j++) {
				WxPolyPoint wpp = (WxPolyPoint) wp.polyPoints.get(j);
				gl.glVertex3f(wpp.ecfX[coordinateMode],
						wpp.ecfY[coordinateMode], wpp.ecfZ[coordinateMode]);
			}
			gl.glEnd();
		}

		// END DEBUG PATH

		// only for globe mode
		if (coordinateMode == WC.COORDINATES_GLOBE) {
			drawCurtain(gl);
		}

		// plot intercept lines
		if (coordinateMode == WC.COORDINATES_GLOBE && drawSatDetails == true) {
			float lineScale = .0000001f;// .000001f;

			float grayLineCol = 1f;
			gl.glColor4f(grayLineCol, grayLineCol, grayLineCol, .2f);
			gl.glBegin(GL2.GL_LINES);
			for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
				if (flightLoadMask[flight] == 1) {
					for (int k = 0; k < WC.TOTAL_SCAS; k++) {
						if (scaLoadMask[flight][k] == 1) {
							if (witFrameList[flight][k] != null) {
								if (witFrameList[flight][k].size() > 0
										&& witSCAPlayhead[flight][k] >= 0
										&& witSCAPlayhead[flight][k] < witFrameList[flight][k]
												.size()) {

									WITFrame rasterFrame = null;
									if (scanDirAgreementDrawFlag[flight][k] == 1
											&& timeAgreementDrawFlag[flight][k] == 1
											&& scanSeqAgreementDrawFlag[flight][k] == 1) {

										rasterFrame = (WITFrame) witFrameList[flight][k]
												.get(witSCAPlayhead[flight][k]);

									} else { 
										if (lastDrawIndexList[flight][k] != null) {
											if (lastDrawIndexList[flight][k]
													.size() != 0) {
												rasterFrame = (WITFrame) witFrameList[flight][k]
														.get((Integer) lastDrawIndexList[flight][k]
																.get(lastDrawIndexList[flight][k]
																		.size() - 1));
											}
										}
									}

									if (rasterFrame != null) {

										float satPosX = (float) (rasterFrame.satPosECF[WC.X] * lineScale);
										float satPosY = (float) (rasterFrame.satPosECF[WC.Y] * lineScale);
										float satPosZ = (float) (rasterFrame.satPosECF[WC.Z] * lineScale);

										for (int j = 0; j < 4; j++) {
											
											gl.glVertex3f(satPosX, satPosY,
													satPosZ);
											gl.glVertex3f(
															rasterFrame.scanBoundsEcf[WC.X][j],
															rasterFrame.scanBoundsEcf[WC.Y][j],
															rasterFrame.scanBoundsEcf[WC.Z][j]);
										
										}

									}
								}
							}
						}
					}
				}
			}
			gl.glEnd();
		}

		// draw GL UI

		gl.glDisable(GL2.GL_DEPTH_TEST);
		gl.glPushMatrix(); // push 1
		gl.glLoadIdentity();

		gl.glBindTexture(GL.GL_TEXTURE_2D, 0);

		gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_LINE);

		float ratioScale = (float) ((float) glCanvas.getWidth() / (float) glCanvas
				.getHeight());
		float uiScaleAmount = 1f / ((float) glCanvas.getWidth() / (2.01f * ratioScale));
		

		gl.glColor3f(1f, 0f, 0f);

		gl.glScalef(uiScaleAmount, uiScaleAmount, uiScaleAmount);
		gl.glTranslatef(-glCanvas.getWidth() / 2, -glCanvas.getHeight() / 2, 0);

		gl.glBegin(GL2.GL_QUADS);

		float uiZ = 0;// .0000001f;

		// draw selection area
		gl.glVertex3f(userSelection[WC.START][WC.X],
				userSelection[WC.START][WC.Y], uiZ);
		gl.glVertex3f(userSelection[WC.END][WC.X],
				userSelection[WC.START][WC.Y], uiZ);
		gl.glVertex3f(userSelection[WC.END][WC.X], userSelection[WC.END][WC.Y],
				uiZ);
		gl.glVertex3f(userSelection[WC.START][WC.X],
				userSelection[WC.END][WC.Y], uiZ);

		gl.glEnd();

		// draw the pixel pro
		gl.glBegin(GL2.GL_LINES);
		gl.glVertex3f(lensPosX, lensPosY, 0);
		gl.glVertex3f(lensPosX, lensPosY + 10, 0);
		gl.glEnd();

		execPipeline(gl);
		// END FRAG pipeline

		gl.glPopMatrix(); // pop1

		gl.glEnable(GL2.GL_DEPTH_TEST);

		if (coordinateMode == WC.COORDINATES_SENSOR) {

		} else if (coordinateMode == WC.COORDINATES_GLOBE) {

			if (overlayStates[WC.OVERLAY_GLOBE_BOUNDARIES] == true) {
				gl.glPushMatrix(); // push 1
				// allow political boundaries over the data
				float scaleTemp = 1.001f; // over
				gl.glScalef(scaleTemp, scaleTemp, scaleTemp);

				// System.out.println("CALL LIST GLOBE");
				gl.glCallList(globeMapList);

				gl.glPopMatrix(); // pop 1
			}
			
			drawCurtain(gl);

		} else if (coordinateMode == WC.COORDINATES_MERCATOR) {

			if (overlayStates[WC.OVERLAY_GLOBE_BOUNDARIES] == true) {
				gl.glPushMatrix();
				gl.glCallList(mercatorMapList);
				gl.glPopMatrix();
			}
		} else {

		}

		// end globe mode

		gl.glPopMatrix(); 

		// blackout the control area again

		drawOpenglUiItems(gl);

		// end blackout


		// ACCUM BUFFER
		if (opMask[WC.THREAD_GPU_FRAG_TIMELAPSE] == true) {
			
			gl.glAccum(GL2.GL_READ_BUFFER, GL2.GL_BACK);
			gl.glAccum(GL2.GL_MULT, (1.0f - gpuAccumAmount));
			gl.glAccum(GL2.GL_ACCUM, gpuAccumAmount);
			gl.glAccum(GL2.GL_RETURN, 1.0f);
		} else if (opMask[WC.THREAD_GPU_FRAG_TIMELAPSE] == true) {
			gl.glAccum(GL2.GL_READ_BUFFER, GL2.GL_BACK);

			gl.glAccum(GL2.GL_ACCUM, gpuAccumAmount);
			gl.glAccum(GL2.GL_RETURN, 1.0f);
		}

		long renderTime3D2 = System.currentTimeMillis();

		renderTime3D = (int) (renderTime3D2 - renderTime3D1);

		if (firstRenderPass == WC.STATUS_READY) {
			firstRenderPass = WC.STATUS_ERROR;
		}
	}

	public void drawOpenglUiItems(GL2 gl) {
		float uiZ = 0;

		long startTimeGlHist = System.currentTimeMillis();

		gl.glPushMatrix();
		gl.glLoadIdentity();
		float contrastScale = .001f;

		float ratioScale = (float) ((float) glCanvas.getWidth() / (float) glCanvas
				.getHeight());
		float uiScaleAmount = 1f / ((float) glCanvas.getWidth() / (2.01f * ratioScale));
		gl.glScalef(uiScaleAmount, uiScaleAmount, uiScaleAmount);
		gl.glTranslatef(-glCanvas.getWidth() / 2, -glCanvas.getHeight() / 2, 0);

		gl.glDisable(GL2.GL_DEPTH_TEST);
		float histTickScaleX = .00025f;
		float histTickMinX = 20f;
		float histOpacityOuter = .75f;// 1f;//.2f;
		float histOpacityInner = 1f;// 1f;//.2f;
		float histOpacityFocus = 1f;// .2f;
		float boostWidth = 40f;
		int histValSkipInner = 1;
		int histValSkipOuter = 1;
		gl.glLineWidth(1.0f);
		gl.glBegin(GL2.GL_LINES);

		int tickGapX = 0;

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			if (flightLoadMask[flight] == 1) {
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					if (scaLoadMask[flight][k] == 1) {
						if (witFrameList[flight][k] != null) {
							if (witFrameList[flight][k].size() > 0
									&& witSCAPlayhead[flight][k] >= 0
									&& witSCAPlayhead[flight][k] < witFrameList[flight][k]
											.size()) {

								WITFrame rasterFrame = null;
								if (scanDirAgreementDrawFlag[flight][k] == 1
										&& timeAgreementDrawFlag[flight][k] == 1
										&& scanSeqAgreementDrawFlag[flight][k] == 1) {

									rasterFrame = (WITFrame) witFrameList[flight][k]
											.get(witSCAPlayhead[flight][k]);

								} else { 
									if (lastDrawIndexList[flight][k] != null) {
										if (lastDrawIndexList[flight][k].size() != 0) {
											rasterFrame = (WITFrame) witFrameList[flight][k]
													.get((Integer) lastDrawIndexList[flight][k]
															.get(lastDrawIndexList[flight][k]
																	.size() - 1));
										}
									}
								}

								if (rasterFrame != null) {

									for (int i = rasterFrame.histStats[WC.STATS_MIN]; i <= rasterFrame.histStats[WC.STATS_Q1]
											- histValSkipOuter; i += histValSkipOuter) {
										if (i < WC.CONTRAST_UI_HARD_LIMIT) {
											
											float colorHistH = intensityToContrastGlyLinear(i);
											float histTickW = histTickMinX
													+ (histTickScaleX * (float) rasterFrame.histogram[i]);

											float histPointX1 = glContrastControlX
													+ glContrastControlW;
											float histPointX2 = glContrastControlX
													+ glContrastControlW
													+ histTickMinX;
											float histPointX3 = glContrastControlX
													+ glContrastControlW
													+ histTickW
													+ histOpaBoost[flight][k]
													* boostWidth;
											gl
													.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.R],
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.G],
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.B],
															histOpacityOuter
																	+ histOpaBoost[flight][k]);

											gl.glVertex3f(histPointX1,
													glContrastControlY
															+ colorHistH, uiZ);
											gl
													.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.R] / 2f,
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.G] / 2f,
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.B] / 2f,
															histOpacityOuter
																	+ histOpaBoost[flight][k]);

											gl.glVertex3f(histPointX2,
													glContrastControlY
															+ colorHistH, uiZ);
											gl
													.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.R],
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.G],
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.B],
															histOpacityOuter
																	+ histOpaBoost[flight][k]);

											gl.glVertex3f(histPointX2
													+ tickGapX,
													glContrastControlY
															+ colorHistH, uiZ);
											gl.glVertex3f(histPointX3,
													glContrastControlY
															+ colorHistH, uiZ);
										}
									}

									
									for (int i = rasterFrame.histStats[WC.STATS_Q3]
											+ histValSkipOuter; i <= rasterFrame.histStats[WC.STATS_MAX]; i += histValSkipOuter) {
										if (i < WC.CONTRAST_UI_HARD_LIMIT) {
										
											float colorHistH = intensityToContrastGlyLinear(i);
											float histTickW = histTickMinX
													+ (histTickScaleX * (float) rasterFrame.histogram[i]);
											float histPointX1 = glContrastControlX
													+ glContrastControlW;
											float histPointX2 = glContrastControlX
													+ glContrastControlW
													+ histTickMinX;
											float histPointX3 = glContrastControlX
													+ glContrastControlW
													+ histTickW
													+ histOpaBoost[flight][k]
													* boostWidth;
											gl
													.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.R],
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.G],
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.B],
															histOpacityOuter
																	+ histOpaBoost[flight][k]);

											gl.glVertex3f(histPointX1,
													glContrastControlY
															+ colorHistH, uiZ);
											gl
													.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.R] / 2f,
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.G] / 2f,
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.B] / 2f,
															histOpacityOuter
																	+ histOpaBoost[flight][k]);

											gl.glVertex3f(histPointX2,
													glContrastControlY
															+ colorHistH, uiZ);

											gl
													.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.R],
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.G],
															uiGlContrastColors[WC.COLOR_GL_HIST_OUT][WC.B],
															histOpacityOuter
																	+ histOpaBoost[flight][k]);

											gl.glVertex3f(histPointX2
													+ tickGapX,
													glContrastControlY
															+ colorHistH, uiZ);
											gl.glVertex3f(histPointX3,
													glContrastControlY
															+ colorHistH, uiZ);
										}
									}

								}
							}
						}
					}
				}
			}
		}

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			if (flightLoadMask[flight] == 1) {
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					if (scaLoadMask[flight][k] == 1) {
						if (witFrameList[flight][k] != null) {
							if (witFrameList[flight][k].size() > 0
									&& witSCAPlayhead[flight][k] >= 0
									&& witSCAPlayhead[flight][k] < witFrameList[flight][k]
											.size()) {

								WITFrame rasterFrame = null;
								if (scanDirAgreementDrawFlag[flight][k] == 1
										&& timeAgreementDrawFlag[flight][k] == 1
										&& scanSeqAgreementDrawFlag[flight][k] == 1) {

									rasterFrame = (WITFrame) witFrameList[flight][k]
											.get(witSCAPlayhead[flight][k]);

								} else { 
									if (lastDrawIndexList[flight][k] != null) {
										if (lastDrawIndexList[flight][k].size() != 0) {
											rasterFrame = (WITFrame) witFrameList[flight][k]
													.get((Integer) lastDrawIndexList[flight][k]
															.get(lastDrawIndexList[flight][k]
																	.size() - 1));
										}
									}
								}

								if (rasterFrame != null) {

									for (int i = rasterFrame.histStats[WC.STATS_Q1]; i <= rasterFrame.histStats[WC.STATS_Q2]
											- histValSkipInner; i += histValSkipInner) {
										if (i < WC.CONTRAST_UI_HARD_LIMIT) {
											float colorHistH = intensityToContrastGlyLinear(i);
											float histTickW = histTickMinX
													+ (histTickScaleX * (float) rasterFrame.histogram[i]);
											float histPointX1 = glContrastControlX
													+ glContrastControlW;
											float histPointX2 = glContrastControlX
													+ glContrastControlW
													+ histTickMinX;
											float histPointX3 = glContrastControlX
													+ glContrastControlW
													+ histTickW
													+ histOpaBoost[flight][k]
													* boostWidth;
											gl.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.R],
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.G],
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.B],
															histOpacityInner
																	+ histOpaBoost[flight][k]);

											gl.glVertex3f(histPointX1,
													glContrastControlY
															+ colorHistH, uiZ);
											gl.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.R] / 2f,
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.G] / 2f,
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.B] / 2f,
															histOpacityInner
																	+ histOpaBoost[flight][k]);

											gl.glVertex3f(histPointX2,
													glContrastControlY
															+ colorHistH, uiZ);

											gl.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.R],
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.G],
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.B],
															histOpacityInner
																	+ histOpaBoost[flight][k]);

											gl.glVertex3f(histPointX2
													+ tickGapX,
													glContrastControlY
															+ colorHistH, uiZ);
											gl.glVertex3f(histPointX3,
													glContrastControlY
															+ colorHistH, uiZ);
										}
									}

									for (int i = rasterFrame.histStats[WC.STATS_Q2]
											+ histValSkipInner; i <= rasterFrame.histStats[WC.STATS_Q3]; i += histValSkipInner) {
										if (i < WC.CONTRAST_UI_HARD_LIMIT) {
											float colorHistH = intensityToContrastGlyLinear(i);
											float histTickW = histTickMinX
													+ (histTickScaleX * (float) rasterFrame.histogram[i]);
											float histPointX1 = glContrastControlX
													+ glContrastControlW;
											float histPointX2 = glContrastControlX
													+ glContrastControlW
													+ histTickMinX;
											float histPointX3 = glContrastControlX
													+ glContrastControlW
													+ histTickW
													+ histOpaBoost[flight][k]
													* boostWidth;

											gl.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.R],
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.G],
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.B],
															histOpacityInner
																	+ histOpaBoost[flight][k]);
											gl.glVertex3f(histPointX1,
													glContrastControlY
															+ colorHistH, uiZ);
											gl.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.R] / 2f,
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.G] / 2f,
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.B] / 2f,
															histOpacityInner
																	+ histOpaBoost[flight][k]);
											gl.glVertex3f(histPointX2,
													glContrastControlY
															+ colorHistH, uiZ);

											gl.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.R],
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.G],
															uiGlContrastColors[WC.COLOR_GL_HIST_IN][WC.B],
															histOpacityInner
																	+ histOpaBoost[flight][k]);
											gl.glVertex3f(histPointX2
													+ tickGapX,
													glContrastControlY
															+ colorHistH, uiZ);
											gl.glVertex3f(histPointX3,
													glContrastControlY
															+ colorHistH, uiZ);
										}
									}

								}
							}
						}
					}
				}
			}
		}
		gl.glEnd();
		gl.glLineWidth(3f);
		gl.glBegin(GL2.GL_LINES);
		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			if (flightLoadMask[flight] == 1) {
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					if (scaLoadMask[flight][k] == 1) {
						if (witFrameList[flight][k] != null) {
							if (witFrameList[flight][k].size() > 0
									&& witSCAPlayhead[flight][k] >= 0
									&& witSCAPlayhead[flight][k] < witFrameList[flight][k]
											.size()) {

								WITFrame rasterFrame = null;
								if (scanDirAgreementDrawFlag[flight][k] == 1
										&& timeAgreementDrawFlag[flight][k] == 1
										&& scanSeqAgreementDrawFlag[flight][k] == 1) {

									rasterFrame = (WITFrame) witFrameList[flight][k]
											.get(witSCAPlayhead[flight][k]);

								} else { 
									if (lastDrawIndexList[flight][k] != null) {
										if (lastDrawIndexList[flight][k].size() != 0) {
											rasterFrame = (WITFrame) witFrameList[flight][k]
													.get((Integer) lastDrawIndexList[flight][k]
															.get(lastDrawIndexList[flight][k]
																	.size() - 1));
										}
									}
								}

								if (rasterFrame != null) {

									for (int i = rasterFrame.histStats[WC.STATS_Q2]; i <= rasterFrame.histStats[WC.STATS_Q2]; i++) {
										if (i < WC.CONTRAST_UI_HARD_LIMIT) {
											float colorHistH = intensityToContrastGlyLinear(i);
											float histTickW = histTickMinX
													+ (histTickScaleX * (float) rasterFrame.histogram[i]);
											float histPointX1 = glContrastControlX
													+ glContrastControlW;
											float histPointX2 = glContrastControlX
													+ glContrastControlW
													+ histTickMinX;
											float histPointX3 = glContrastControlX
													+ glContrastControlW
													+ histTickW
													+ histOpaBoost[flight][k]
													* boostWidth;

											gl.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_FOCUS][WC.R],
															uiGlContrastColors[WC.COLOR_GL_HIST_FOCUS][WC.G],
															uiGlContrastColors[WC.COLOR_GL_HIST_FOCUS][WC.B],
															histOpacityFocus
																	+ histOpaBoost[flight][k]);
											gl.glVertex3f(histPointX1,
													glContrastControlY
															+ colorHistH, uiZ);
											gl.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_FOCUS][WC.R] / 2,
															uiGlContrastColors[WC.COLOR_GL_HIST_FOCUS][WC.G] / 2,
															uiGlContrastColors[WC.COLOR_GL_HIST_FOCUS][WC.B] / 2,
															histOpacityFocus
																	+ histOpaBoost[flight][k]);
											gl.glVertex3f(histPointX2,
													glContrastControlY
															+ colorHistH, uiZ);

											gl.glColor4f(
															uiGlContrastColors[WC.COLOR_GL_HIST_FOCUS][WC.R],
															uiGlContrastColors[WC.COLOR_GL_HIST_FOCUS][WC.G],
															uiGlContrastColors[WC.COLOR_GL_HIST_FOCUS][WC.B],
															histOpacityFocus
																	+ histOpaBoost[flight][k]);
											gl.glVertex3f(histPointX2
													+ tickGapX,
													glContrastControlY
															+ colorHistH, uiZ);
											gl.glVertex3f(histPointX3,
													glContrastControlY
															+ colorHistH, uiZ);
										}
									}

								}
							}
						}
					}
				}
			}
		}
		gl.glEnd();
		gl.glLineWidth(1f);

		long stopTimeGlHist = System.currentTimeMillis();

		gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);
		for (int i = 0; i < glContrastColorBands - 1; i++) {

			float colorRampH = intensityToContrastGlyLinear(glColorLimits[glColorScheme][i]);
			float colorRampH2 = intensityToContrastGlyLinear(glColorLimits[glColorScheme][i + 1]);
			int index2 = i + 1;
			gl.glBegin(GL2.GL_QUADS);

			gl.glColor3f(glColorLimitsRGB[glColorScheme][i][WC.R],
					glColorLimitsRGB[glColorScheme][i][WC.G],
					glColorLimitsRGB[glColorScheme][i][WC.B]);
			gl.glVertex3f(glContrastControlX, glContrastControlY + colorRampH,
					uiZ);
			gl.glVertex3f(glContrastControlX + glContrastControlW,
					glContrastControlY + colorRampH, uiZ);

			gl.glColor3f(glColorLimitsRGB[glColorScheme][index2][WC.R],
					glColorLimitsRGB[glColorScheme][index2][WC.G],
					glColorLimitsRGB[glColorScheme][index2][WC.B]);
			gl.glVertex3f(glContrastControlX + glContrastControlW,
					glContrastControlY + colorRampH2, uiZ);
			gl.glVertex3f(glContrastControlX, glContrastControlY + colorRampH2,
					uiZ);
			gl.glEnd();
		}

		gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_LINE);
		gl.glColor3f(1f, 1f, 1f);
		gl.glBegin(GL2.GL_QUADS);
		gl.glVertex3f(glContrastControlX + glContrastControlW,
				glContrastControlY, uiZ);
		gl.glVertex3f(glContrastControlX + glContrastControlW,
				glContrastControlY + glContrastControlH, uiZ);
		gl.glVertex3f(glContrastControlX, glContrastControlY
				+ glContrastControlH, uiZ);
		gl.glVertex3f(glContrastControlX, glContrastControlY, uiZ);
		gl.glEnd();
		
		gl.glBegin(GL2.GL_LINES);
		gl.glColor3f(1f, 1f, 1f);
		int tickW = 10;

		for (int i = 0; i <= glContrastColorBands + 1; i++) {
			float colorRampH = ((float) i * glContrastControlLinearH);// glContrastControlExpH;
			gl.glVertex3f(glContrastControlX, glContrastControlY + colorRampH,
					uiZ);
			gl.glVertex3f(glContrastControlX - tickW, glContrastControlY
					+ colorRampH, uiZ);
		}
		
		// label user control points
		for (int i = 0; i < glContrastColorBands; i++) {

			float colorRampH = intensityToContrastGlyLinear(glColorLimits[glColorScheme][i]);
			gl.glVertex3f(glContrastControlX + glContrastControlW,
					glContrastControlY + colorRampH, uiZ);
			gl.glVertex3f(glContrastControlX + glContrastControlW
					+ histTickMinX, glContrastControlY + colorRampH, uiZ);
		}

		gl.glEnd();
		
		gl.glPopMatrix();

		// end histogram

		// timeline UI in openGL
		if (timelineImageTexSyncGlDrawListFlag == WC.STATUS_READY) {
		
			gl.glNewList(timelineGlDrawListId, GL2.GL_COMPILE);
			gl.glPushMatrix();
			gl.glDisable(GL2.GL_DEPTH_TEST);
			gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);
			
			gl.glColor3f(0f,0f,0f);  
			gl.glBegin(GL2.GL_QUADS);
			gl.glVertex3f(0, 90, 0);
			gl.glVertex3f(WC.SEC_IN_DAY, 90, 0);
			gl.glVertex3f(WC.SEC_IN_DAY, -5, 0);
			gl.glVertex3f(0, -5, 0);
			gl.glEnd();
			
			gl.glColor3f(1f,1f,1f);
			gl.glBegin(GL2.GL_LINES);
			gl.glVertex3f(0, -5, 0);
			gl.glVertex3f(WC.SEC_IN_DAY, -5, 0);
			gl.glEnd();
			
			gl.glColor3f(.2f, .2f, .2f);
			gl.glBegin(GL2.GL_QUADS);
			float hoverZ = -1f;

			int nudgeY = tivoStatusBarTickYsliver - 1;
			for (int f = 0; f < WC.TOTAL_FLIGHTS; f++) {
				int yOffsetSat = 30 * f;
				for (int s = 0; s < WC.TOTAL_SCAS; s++) {

					gl.glVertex3f(0, yOffsetSat
							+ (s * tivoStatusBarTickYsliver), 0);
					gl.glVertex3f(WC.SEC_IN_DAY * tivoStatusBarTickX,
							yOffsetSat + (s * tivoStatusBarTickYsliver), 0);
					gl.glVertex3f(WC.SEC_IN_DAY * tivoStatusBarTickX,
							yOffsetSat + (s * tivoStatusBarTickYsliver)
									+ nudgeY, 0);
					gl.glVertex3f(0, yOffsetSat
							+ (s * tivoStatusBarTickYsliver) + nudgeY, 0);

				}

			}

			gl.glColor3f(uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.R],
					uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.G],
					uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.B]);

			for (int f = 0; f < WC.TOTAL_FLIGHTS; f++) {
				int yOffsetSat = 30 * f;
				for (int i = 0; i < WC.SEC_IN_DAY; i++) {
					int tickXpos = i * tivoStatusBarTickX;
					for (int s = 0; s < WC.TOTAL_SCAS; s++) {
						if (dataLoadStatus[f][s][i] == WC.STATUS_COMPLETE) {

							gl.glVertex3f(tickXpos, yOffsetSat
									+ (s * tivoStatusBarTickYsliver), hoverZ);
							gl
									.glVertex3f(
											tickXpos + tivoStatusBarTickX,
											yOffsetSat
													+ (s * tivoStatusBarTickYsliver),
											hoverZ);
							gl.glVertex3f(tickXpos + tivoStatusBarTickX,
									yOffsetSat + (s * tivoStatusBarTickYsliver)
											+ nudgeY, hoverZ);
							gl.glVertex3f(tickXpos, yOffsetSat
									+ (s * tivoStatusBarTickYsliver) + nudgeY,
									hoverZ);

						}
					}
				}
			}

			gl.glColor3f(uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.R],
					uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.G],
					uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.B]);
			for (int f = 0; f < WC.TOTAL_FLIGHTS; f++) {
				int yOffsetSat = 30 * f;
				for (int i = 0; i < WC.SEC_IN_DAY; i++) {
					int tickXpos = i * tivoStatusBarTickX;
					for (int s = 0; s < WC.TOTAL_SCAS; s++) {
						if (dataLoadStatus[f][s][i] == WC.STATUS_WORKING) {

							gl.glVertex3f(tickXpos, yOffsetSat
									+ (s * tivoStatusBarTickYsliver), hoverZ);
							gl
									.glVertex3f(
											tickXpos + tivoStatusBarTickX,
											yOffsetSat
													+ (s * tivoStatusBarTickYsliver),
											hoverZ);
							gl.glVertex3f(tickXpos + tivoStatusBarTickX,
									yOffsetSat + (s * tivoStatusBarTickYsliver)
											+ nudgeY, hoverZ);
							gl.glVertex3f(tickXpos, yOffsetSat
									+ (s * tivoStatusBarTickYsliver) + nudgeY,
									hoverZ);

						}
					}
				}
			}
			gl.glColor3f(uiGlContrastColors[WC.COLOR_GL_ACCENT3][WC.R],
					uiGlContrastColors[WC.COLOR_GL_ACCENT3][WC.G],
					uiGlContrastColors[WC.COLOR_GL_ACCENT3][WC.B]);
			for (int f = 0; f < WC.TOTAL_FLIGHTS; f++) {
				int yOffsetSat = 30 * f;
				for (int i = 0; i < WC.SEC_IN_DAY; i++) {
					int tickXpos = i * tivoStatusBarTickX;
					for (int s = 0; s < WC.TOTAL_SCAS; s++) {
						if (dataLoadStatus[f][s][i] == WC.STATUS_READY) {

							gl.glVertex3f(tickXpos, yOffsetSat
									+ (s * tivoStatusBarTickYsliver), hoverZ);
							gl
									.glVertex3f(
											tickXpos + tivoStatusBarTickX,
											yOffsetSat
													+ (s * tivoStatusBarTickYsliver),
											hoverZ);
							gl.glVertex3f(tickXpos + tivoStatusBarTickX,
									yOffsetSat + (s * tivoStatusBarTickYsliver)
											+ nudgeY, hoverZ);
							gl.glVertex3f(tickXpos, yOffsetSat
									+ (s * tivoStatusBarTickYsliver) + nudgeY,
									hoverZ);

						}
					}
				}
			}

			gl.glEnd();

			gl.glBegin(GL2.GL_LINES);
			gl.glColor3f(0f, 1f, 0f);
			for (int i = 0; i < WC.SEC_IN_DAY; i += (60 * 10)) {
				int tickXpos = i * tivoStatusBarTickX;
				gl.glVertex3f(tickXpos,
						30f + (WC.TOTAL_SCAS * tivoStatusBarTickYsliver),
						hoverZ);
				gl.glVertex3f(tickXpos, 0, hoverZ);

			}
			gl.glEnd();

			gl.glColor3f(0f, 1f, 0f);

			gl.glBegin(GL2.GL_QUADS);
			for (int i = 1; i < WC.SEC_IN_DAY; i += (60 * 60)) {
				int tickXpos = i * tivoStatusBarTickX;

				gl.glVertex3f(tickXpos, 0, hoverZ);
				gl.glVertex3f(tickXpos,
						30f + (WC.TOTAL_SCAS * tivoStatusBarTickYsliver),
						hoverZ);
				gl.glVertex3f(tickXpos - 2,
						30f + (WC.TOTAL_SCAS * tivoStatusBarTickYsliver),
						hoverZ);
				gl.glVertex3f(tickXpos - 2, 0, hoverZ);
			}

			gl.glEnd();

			gl.glBegin(GL2.GL_LINES);
			for (int i = 0; i <= WC.SEC_IN_DAY; i += (60 * 60)) {
				int tickXpos = i * tivoStatusBarTickX;
				gl.glVertex3f(tickXpos, 0, hoverZ);
				gl.glVertex3f(tickXpos,
						30f + (WC.TOTAL_SCAS * tivoStatusBarTickYsliver),
						hoverZ);
			}
			gl.glEnd();

			gl.glEnable(GL2.GL_DEPTH_TEST);
			gl.glPopMatrix();
			gl.glEndList();

			timelineImageTexSyncGlDrawListFlag = WC.STATUS_COMPLETE;

		}

		if (timelineImageTexSyncGlDrawListFlag == WC.STATUS_COMPLETE) {

			float glTimelineScale = .0016f;
			float glTimelineScaleWholeDay = .0008f;

			// blackout the control area

			gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);
			gl.glPushMatrix();
			gl.glLoadIdentity();
			gl.glScalef(glTimelineScale, -glTimelineScale, glTimelineScale);
			gl.glTranslatef(0, 422, 0);

			gl.glColor3f(0f, 0f, 0f);
			gl.glDisable(GL2.GL_DEPTH_TEST);
			gl.glBegin(GL2.GL_QUADS);
			int blackoutW = 2000;
			int blackoutH = 600;
			gl.glVertex3f(-blackoutW, 0, 0);
			gl.glVertex3f(-blackoutW, blackoutH, 0);
			gl.glVertex3f(blackoutW, blackoutH, 0);
			gl.glVertex3f(blackoutW, 0, 0);
			gl.glEnd();
			gl.glEnable(GL2.GL_DEPTH_TEST);
			gl.glPopMatrix();

			// end blackout

			gl.glPushMatrix();
			gl.glLoadIdentity();
			float timelineXpos = ((float) tivoStatusBarX + userTimelineOffset[CURRENT])
					* glTimelineScale;
			gl.glTranslatef(0, 0, 0);
			// gl.glTranslatef(timelineXpos, 0, 0);
			gl.glScalef(glTimelineScale, -glTimelineScale, glTimelineScale);
			gl.glScalef(userTimelineZoom[CURRENT], 1f, 1f);
			gl.glTranslatef(0, 360, 0);
			//gl.glTranslatef(0, 424, 0); // !! AFWA
			gl.glTranslatef(userTimelineOffset[CURRENT], 0, 0);
			
			//System.out.println("TIMELINE OFFSET "+userTimelineOffset[CURRENT]);

			gl.glCallList(timelineGlDrawListId);

			int timelineHeight = 56;

			loopBoundStartX = userSelection[WC.START][WC.T];
			loopBoundEndX = userSelection[WC.END][WC.T];
						
			gl.glDisable(GL2.GL_DEPTH_TEST);
			if (timelineStatus != WC.STATUS_ERROR){
			gl.glColor3f(.7f, 0f, 0f);
			gl.glBegin(GL2.GL_LINES);
			gl.glVertex3f(loopBoundStartX, 0, 0);
			gl.glVertex3f(loopBoundStartX, timelineHeight, 0);

			gl.glVertex3f(loopBoundEndX, 0, 0);
			gl.glVertex3f(loopBoundEndX, timelineHeight, 0);
			
			if (mouseState == WC.UI_STATE_TIMELINE_SELECT){
				gl.glColor3f(1f, 0f, 0f);

				if (userSelectionReloader[WC.START][WC.T]< userSelection[WC.START][WC.T]){
				gl.glVertex3f(userSelectionReloader[WC.START][WC.T], 0, 0);
				gl.glVertex3f(userSelectionReloader[WC.START][WC.T], timelineHeight, 0);
				}


				if (userSelectionReloader[WC.END][WC.T]> userSelection[WC.END][WC.T]){
				gl.glVertex3f(userSelectionReloader[WC.END][WC.T], 0, 0);
				gl.glVertex3f(userSelectionReloader[WC.END][WC.T], timelineHeight, 0);
				}
			}

			if (exportBounceVideoState == WC.STATUS_OFF) {
				gl.glColor3f(1f, 1f, 1f);
			} else if (exportBounceVideoState == WC.STATUS_ON) {
				gl.glColor3f(.7f, 0f, 0f);
			}

			gl.glVertex3f(witTimePlayhead, 0, 0);
			gl.glVertex3f(witTimePlayhead, timelineHeight, 0);
			
			gl.glEnd();
			}

			// labels
			if (tr == null) {
				Font f = new Font(Font.SANS_SERIF, Font.BOLD, 12);
				tr = new TextRenderer(f, true, true);

				Font f2 = new Font(Font.SANS_SERIF, Font.BOLD, 10);
				tr2 = new TextRenderer(f2, true, true);
				tr2.setColor(Color.green);
			}

			tr.setColor(Color.white);
			tr.beginRendering(glCanvas.getWidth(), glCanvas.getHeight(), false);
			tr.draw(userInterfaceInfoStr, 20, 20);

			String labelStr = "";
			if (dynamicLoadStatus == WC.STATUS_COMPLETE) {
				if (playbackStepSeconds < 1.0) {
					labelStr = secondsOfDayToReadableF(witTimePlayheadFloat);
				} else {
					labelStr = secondsOfDayToReadableF((int) (witTimePlayheadFloat));
				}
			} else {
				labelStr = secondsOfDayToReadableF((witTimePlayhead));
			}
			labelStr += "Z";


			if (timelineStatus != WC.STATUS_ERROR){
			int labelPlayheadStrPosX = (int) ((witTimePlayhead + userTimelineOffset[CURRENT])
					* (1f / glShimScale) * (userTimelineZoom[CURRENT]))
					+ viewportGlX / 2;
			tr.draw(labelStr, labelPlayheadStrPosX -45, 200);
			
			String labelTimeStartStr = secondsOfDayToReadableF((userSelection[WC.START][WC.T]));
			int labelTimeStartStrPosX = (int) ((userSelection[WC.START][WC.T] + userTimelineOffset[CURRENT])
					* (1f / glShimScale) * (userTimelineZoom[CURRENT]))
					+ viewportGlX / 2;
			tr.draw(labelTimeStartStr, labelTimeStartStrPosX - 90, 140);

			String labelTimeEndStr = secondsOfDayToReadableF((userSelection[WC.END][WC.T]));
			int labelTimeEndStrPosX = (int) ((userSelection[WC.END][WC.T] + userTimelineOffset[CURRENT])
					* (1f / glShimScale) * (userTimelineZoom[CURRENT]))
					+ viewportGlX / 2;
			tr.draw(labelTimeEndStr, labelTimeEndStrPosX + 10, 140);
			}
			
			int hLineY2 = 60;
			int hLineY1 = 90;
			tr.setColor(uiColors[WC.COLOR_TIVO_TEXT_HEADER]);
			tr.draw("SENSOR + SCAN", 20, 120);

			if (userFlight == 0) {
				tr.setColor(Color.green);
				tr.draw("1", 20, hLineY1);
				tr.setColor(Color.gray);
				tr.draw("2", 20, hLineY2);
			} else if (userFlight == 1) {
				tr.setColor(Color.gray);
				tr.draw("1", 20, hLineY1);
				tr.setColor(Color.green);
				tr.draw("2", 20, hLineY2);
			}

			int scanIndicatorX1 = 78;
			int scanIndicatorX2 = 83;
			if (playbackModeDir[0] == WC.SCAN_DIR_EVEN) {
				tr.setColor(Color.green);
				tr.draw("<", scanIndicatorX1, hLineY1);
				tr.setColor(Color.gray);
				tr.draw(">", scanIndicatorX2, hLineY1);
			} else if (playbackModeDir[0] == WC.SCAN_DIR_ODD) {
				tr.setColor(Color.gray);
				tr.draw("<", scanIndicatorX1, hLineY1);
				tr.setColor(Color.green);
				tr.draw(">", scanIndicatorX2, hLineY1);
			} else {
				tr.setColor(Color.green);
				tr.draw("<", scanIndicatorX1, hLineY1);
				tr.draw(">", scanIndicatorX2, hLineY1);
			}

			if (playbackModeDir[1] == WC.SCAN_DIR_EVEN) {
				tr.setColor(Color.green);
				tr.draw("<", scanIndicatorX1, hLineY2);
				tr.setColor(Color.gray);
				tr.draw(">", scanIndicatorX2, hLineY2);
			} else if (playbackModeDir[1] == WC.SCAN_DIR_ODD) {
				tr.setColor(Color.gray);
				tr.draw("<", scanIndicatorX1, hLineY2);
				tr.setColor(Color.green);
				tr.draw(">", scanIndicatorX2, hLineY2);
			} else {
				tr.setColor(Color.green);
				tr.draw("<", scanIndicatorX1, hLineY2);
				tr.draw(">", scanIndicatorX2, hLineY2);
			}

			for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
				for (int s = 0; s < WC.TOTAL_SCAS; s++) {
					if (scaLoadMask[flight][s] == 1) {
						if (s < 6) {
							tr.setColor(Color.green);
						} else {
							tr
									.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_WORKING]);
						}

					} else {
						tr.setColor(Color.gray);
					}
					tr.draw("" + (s + 1), 100 + (s * 8), hLineY1
							- (30 * flight));
				}
			}

			tr.setColor(Color.white);

			int knobTextYshim = -40;
			int knobTextYshim2 = -60;
			tr.draw("WINDOW", knobBarX + knobDeltaX1, knobLabelY);
			tr.draw("SKIP", knobBarX + knobDeltaX2, knobLabelY);
			tr.draw("BURST", knobBarX + knobDeltaX3, knobLabelY);
			tr.draw("TIMER", knobBarX + knobDeltaX4, knobLabelY);
			tr.draw("BUFFER", knobBarX + knobDeltaX5, knobLabelY);
			

			tr.draw("LOAD", knobBarX + knobDeltaX3 +1, knobLabelY+knobTextYshim2);
			tr.draw("RE-LOAD", knobBarX + knobDeltaX4, knobLabelY+knobTextYshim2);
			
			tr.setColor(Color.gray);
			tr.draw("________________________", knobBarX + knobDeltaX4, knobLabelY+knobTextYshim);
			tr.draw("________________________", knobBarX + knobDeltaX4+1, knobLabelY+knobTextYshim);
			
			tr.draw("__________________________________________", knobBarX + knobDeltaX1, knobLabelY+knobTextYshim);
			tr.draw("_________________________________________", knobBarX + knobDeltaX1+1, knobLabelY+knobTextYshim);

			tr.setColor(Color.green);
			tr.draw(loadWindowStr, knobBarX + knobDeltaX1 + 6, knobValueY);
			tr.draw(loadSkipStr, knobBarX + knobDeltaX2 - 3, knobValueY);
			tr.draw(loadBurstStr, knobBarX + knobDeltaX3 + 2, knobValueY);
			
			if (autoReloadState == WC.STATUS_OFF){
				tr.setColor(Color.gray);
			}
			
			tr.draw(loadReloadTimerStr, knobBarX + knobDeltaX4 - 2, knobValueY);
			tr.draw(loadReloadBufferStr, knobBarX + knobDeltaX5 + 2, knobValueY);

			int filterLabelY = 120;
			int filterLabelX = 200;
			int filterLabelSpaceY = 30;
			int threadStatusTickX = 2;

			tr.setColor(uiColors[WC.COLOR_TIVO_TEXT_HEADER]);
			tr.draw("FILTER PIPELINE", filterLabelX, filterLabelY);

			int statusLabelX = 380;
			tr.draw("THREAD QUEUE", statusLabelX, filterLabelY);

			for (int i = 0; i < imprRay.length; i++) {
				tr.setColor(Color.gray);
				tr.draw("|", statusLabelX + (i * threadStatusTickX),
						filterLabelY - filterLabelSpaceY);
			}
			for (int i = 0; i < activeThreadCount; i++) {
				tr.setColor(Color.green);
				tr.draw("|", statusLabelX + (i * threadStatusTickX),
						filterLabelY - filterLabelSpaceY);
			}
			for (int i = activeThreadCount; i < activeThreadCount
					+ queuedThreadCount; i++) {
				tr.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_WORKING]);
				tr.draw("|", statusLabelX + (i * threadStatusTickX),
						filterLabelY - filterLabelSpaceY);
			}

			if (opMask[WC.THREAD_GPU_FRAG_DWT] == true) {
				tr.setColor(Color.green);
				tr.draw("SPATIO-TEMPORAL: DWT", filterLabelX, filterLabelY
						- filterLabelSpaceY * 1);
			} else if (opMask[WC.THREAD_GPU_FRAG_DIFF] == true) {
				tr.setColor(Color.green);
				tr.draw("TEMPORAL: DIFF", filterLabelX, filterLabelY
						- filterLabelSpaceY * 1);
			} else {
				tr.setColor(Color.gray);
				tr.draw("TEMPORAL: NONE", filterLabelX, filterLabelY
						- filterLabelSpaceY * 1);
			}

			if (glColorScheme == WC.COLOR_SCHEME_GRAYSCALE
					&& opMask[WC.THREAD_GPU_FRAG_CONTRAST] == true) {
				tr.setColor(Color.green);
				tr.draw("CONTRAST: GRAY+FC", filterLabelX, filterLabelY
						- filterLabelSpaceY * 2);
			} else if (glColorScheme == WC.COLOR_SCHEME_HEATMAP
					&& opMask[WC.THREAD_GPU_FRAG_CONTRAST] == true) {
				tr.setColor(Color.green);
				tr.draw("CONTRAST: FC", filterLabelX, filterLabelY
						- filterLabelSpaceY * 2);
			} else if (opMask[WC.THREAD_GPU_FRAG_CONTRAST] == false) {
				tr.setColor(Color.gray);
				tr.draw("CONTRAST: NONE", filterLabelX, filterLabelY
						- filterLabelSpaceY * 2);
			}

			tr.setColor(Color.white);
			for (int i = 0; i <= glContrastColorBands + 1; i++) {

				tr.draw(
								"" + (int) (i * glContrastControlLinearDiffH),
								glContrastControlLabelX,
								(int) (glContrastControlY + (i * glContrastControlLinearH)));
			}

			if (mouseState == WC.UI_STATE_CONTRAST) {
				tr.draw(
								"" + (int) (currentTouchContrastIntensity),
								glContrastControlLabelTouchX + 50,
								(int) (glContrastControlY + (currentTouchContrastIntensity * (glContrastControlLinearH / glContrastControlLinearDiffH))));
			}

			tr.flush();
			tr.endRendering();

			tr2.beginRendering(glCanvas.getWidth(), glCanvas.getHeight(),
							false);
			if (playbackScanSeqIndexPrev[0] > -1) {
				tr2.draw(" STEP " + playbackScanSeqIndexPrev[0], 20, 75);
			}
			if (playbackScanSeqIndexPrev[1] > -1) {
				tr2.draw(" STEP " + playbackScanSeqIndexPrev[1], 20, 45);
			}

			tr2.flush();
			tr2.endRendering();

			// loop region handles
			if (timelineStatus != WC.STATUS_ERROR){
			float handleW = 5;
			float handleH = 10;
			float handleY = 56;

			int handle1x = loopBoundStartX;
			int handle2x = loopBoundEndX;
			gl.glColor3f(.7f, 0f, 0f);
			gl.glBegin(GL2.GL_QUADS);

			gl.glVertex3f(handle1x, handleY, 0);
			gl.glVertex3f(handle1x - handleW, handleY, 0);
			gl.glVertex3f(handle1x - handleW, handleY + handleH, 0);
			gl.glVertex3f(handle1x, handleY + handleH, 0);

			gl.glVertex3f(handle2x, handleY, 0);
			gl.glVertex3f(handle2x + handleW, handleY, 0);
			gl.glVertex3f(handle2x + handleW, handleY + handleH, 0);
			gl.glVertex3f(handle2x, handleY + handleH, 0);
			gl.glEnd();
			
			if (mouseState == WC.UI_STATE_TIMELINE_SELECT){
				gl.glColor3f(1f, 0f, 0f);
				
				gl.glBegin(GL2.GL_QUADS);
				if (userSelectionReloader[WC.START][WC.T]< userSelection[WC.START][WC.T]){

				gl.glVertex3f(userSelectionReloader[WC.START][WC.T], handleY, 0);
				gl.glVertex3f(userSelectionReloader[WC.START][WC.T] - handleW, handleY, 0);
				gl.glVertex3f(userSelectionReloader[WC.START][WC.T] - handleW, handleY + handleH, 0);
				gl.glVertex3f(userSelectionReloader[WC.START][WC.T], handleY + handleH, 0);
				}

				if (userSelectionReloader[WC.END][WC.T]> userSelection[WC.END][WC.T]){
				gl.glVertex3f(userSelectionReloader[WC.END][WC.T], handleY, 0);
				gl.glVertex3f(userSelectionReloader[WC.END][WC.T] + handleW, handleY, 0);
				gl.glVertex3f(userSelectionReloader[WC.END][WC.T] + handleW, handleY + handleH, 0);
				gl.glVertex3f(userSelectionReloader[WC.END][WC.T], handleY + handleH, 0);
				}
				gl.glEnd();
			}

			}
			
			gl.glEnable(GL2.GL_DEPTH_TEST);

			gl.glPopMatrix();

			if (uiRenderMiniTimeline == WC.STATUS_ON){
			// mini timeline
			gl.glPushMatrix();
			gl.glLoadIdentity();
			float xScaleWholeDay = .02f;
			timelineXpos = -SECONDS_IN_DAY * .5f;
			gl.glScalef(glTimelineScaleWholeDay, -glTimelineScaleWholeDay,
					glTimelineScaleWholeDay);
			gl.glScalef(xScaleWholeDay, 1f, 1f);

			gl.glTranslatef(timelineXpos, 1000, 0);

			gl.glCallList(timelineGlDrawListId);

			float windowPrevW = (2560f * (1f / userTimelineZoom[CURRENT]));
			float windowPreviewX = (viewportGlX / 2)
					* (1f / userTimelineZoom[CURRENT]);
			float userTimelineViewStartX = -windowPrevW / 2f;
			float userTimelineViewEndX = windowPrevW / 2f;

			gl.glTranslated(-userTimelineOffset[CURRENT], 0, 0);

			gl.glDisable(GL2.GL_DEPTH_TEST);
			gl.glBegin(GL2.GL_LINES);

			gl.glColor3f(1f, 1f, 1f);
			gl.glVertex3f(userTimelineViewStartX, 0, 0);
			gl.glVertex3f(userTimelineViewEndX, 0, 0);

			gl.glVertex3f(userTimelineViewStartX, timelineHeight, 0);
			gl.glVertex3f(userTimelineViewEndX, timelineHeight, 0);

			gl.glVertex3f(userTimelineViewStartX, 0, 0);
			gl.glVertex3f(userTimelineViewStartX, timelineHeight, 0);

			gl.glVertex3f(userTimelineViewEndX, 0, 0);
			gl.glVertex3f(userTimelineViewEndX, timelineHeight, 0);

			gl.glEnd();

			gl.glEnable(GL2.GL_DEPTH_TEST);
			gl.glPopMatrix();

			// end timeline UI
			}

			// user interface glyphs
			gl.glEnable(GL2.GL_TEXTURE_2D);
			gl.glDisable(GL2.GL_DEPTH_TEST);
			gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);

			if (knobT1 == null || knobT2 == null) {

				knobImage1 = loadImageBI(defaultResourceImageDirStr
						+ "knob2_1.png");
				knobImage2 = loadImageBI(defaultResourceImageDirStr
						+ "knob2_2.png");
				knobImage3 = loadImageBI(defaultResourceImageDirStr
						+ "knob2_3a.png");
				knobImage4 = loadImageBI(defaultResourceImageDirStr
						+ "knob2_3b.png");

				TextureData td1 = AWTTextureIO.newTextureData(GLProfile
						.getDefault(), knobImage1, false);
				TextureData td2 = AWTTextureIO.newTextureData(GLProfile
						.getDefault(), knobImage2, false);
				TextureData td3 = AWTTextureIO.newTextureData(GLProfile
						.getDefault(), knobImage3, false);
				TextureData td4 = AWTTextureIO.newTextureData(GLProfile
						.getDefault(), knobImage4, false);

				knobT1 = TextureIO.newTexture(td1);
				knobT2 = TextureIO.newTexture(td2);
				knobT3 = TextureIO.newTexture(td3);
				knobT4 = TextureIO.newTexture(td4);
			} else {

				float knobColorTick = .36f;
				float knobColorWindow = .7f;
				float knobColorBurst = .7f;
				// gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);

				for (int k = 0; k < 5; k++) {

					gl.glPushMatrix();
					gl.glLoadIdentity();
					//float knobSize = .20f;
					//float knobSize = .15f; !! AFWA
					float knobSize = .2f;
					// float knobSize2 =knobSize*.8f;


					gl.glScalef(knobSize, knobSize, knobSize);
					
					
					float knobSpaceY = -5.61f;//-5.97f;// 1f;
					//float knobSpaceY = -3.61f;//-5.97f;// 1f;
					//float knobSpaceX = .9f; // !! AFWA

					float knobSpaceX = 1.14f;
					//float knobSpaceXshim = -1.0f;// .4f 2560
					float knobSpaceXshim = -1.27f;// .4f 2560
					float knobSpaceYshim = 1.89f;
					
					gl.glTranslatef(knobSpaceXshim,knobSpaceYshim,0);
					if (k == 0) {
						gl.glTranslatef(-knobSpaceX,
								knobSpaceY, 0f);
					} else if (k == 1) {
						gl.glTranslatef(0f, knobSpaceY, 0f);
					} else if (k == 2) {
						gl.glTranslatef(knobSpaceX,
								knobSpaceY, 0f);
					} else if (k == 3) {
						gl.glTranslatef(2 * knobSpaceX,
								knobSpaceY, 0f);
					} else if (k == 4) {
						gl.glTranslatef(3 * knobSpaceX,
								knobSpaceY, 0f);
					}

					gl.glRotatef(180f, 1f, 0f, 0f);
					// gl.glRotatef(knobStartDeg, 0f,0f,1f);

								
					knobT3.enable(gl);
					knobT3.bind(gl);
					// gl.glColor3f(.5f,.5f,.5f);

					gl.glBegin(GL2.GL_QUADS);
					gl.glColor4f(uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.R],
							uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.G],
							uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.B], 1f);
					if ((k==3 || k==4)){
						if (autoReloadState == WC.STATUS_ON){
						gl.glColor4f(uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.R],
								uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.G],
								uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.B], 1f);
						} else {
							gl.glColor4f(uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.R],
									uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.G],
									uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.B], .7f);
						}
					}
					gl.glTexCoord2f(0, 0);
					gl.glVertex3f(-knobSize, -knobSize, 0);
					gl.glTexCoord2f(0, 1);
					gl.glColor4f(uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.R],
							uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.G],
							uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.B], 0f);
					if ((k==3 || k==4)){
						if (autoReloadState == WC.STATUS_ON){
						gl.glColor4f(uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.R],
								uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.G],
								uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.B], 0f);
						} else {
							gl.glColor4f(uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.R],
									uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.G],
									uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.B], 0f);
						}
					}
					gl.glVertex3f(-knobSize, knobSize, 0);

					gl.glTexCoord2f(1, 1);
					gl.glVertex3f(knobSize, knobSize, 0);
					gl.glTexCoord2f(1, 0);
					gl.glColor4f(uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.R],
							uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.G],
							uiGlContrastColors[WC.COLOR_GL_ACCENT1][WC.B], 1f);
					
					if ((k==3 || k==4)){
						if (autoReloadState == WC.STATUS_ON){
						gl.glColor4f(uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.R],
								uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.G],
								uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.B], 1f);
						} else {
							gl.glColor4f(uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.R],
									uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.G],
									uiGlContrastColors[WC.COLOR_GL_ACCENT4][WC.B], .7f);
						}
					}
					
					gl.glVertex3f(knobSize, -knobSize, 0);
					gl.glEnd();

					knobT4.enable(gl);
					knobT4.bind(gl);
					// gl.glColor3f(.5f,.5f,.5f);
					gl.glBegin(GL2.GL_QUADS);
					gl.glColor4f(uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.R],
							uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.G],
							uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.B], 0f);
					if ((k==3 || k==4) && autoReloadState == WC.STATUS_OFF){
						gl.glColor4f(uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.R],
								uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.G],
								uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.B], 0f);
					}
					gl.glTexCoord2f(0, 0);
					gl.glVertex3f(-knobSize, -knobSize, 0);
					gl.glTexCoord2f(0, 1);
					gl.glVertex3f(-knobSize, knobSize, 0);
					gl.glColor4f(uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.R],
							uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.G],
							uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.B], 1f);
					if ((k==3 || k==4) && autoReloadState == WC.STATUS_OFF){
						gl.glColor4f(uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.R],
								uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.G],
								uiGlContrastColors[WC.COLOR_GL_ACCENT2][WC.B], .7f);
					}
					gl.glTexCoord2f(1, 1);
					gl.glVertex3f(knobSize, knobSize, 0);
					gl.glTexCoord2f(1, 0);
					gl.glVertex3f(knobSize, -knobSize, 0);
					gl.glEnd();

					gl.glRotatef(180f, 0f, 0f, 1f);
					knobT2.enable(gl);
					knobT2.bind(gl);
					// gl.glColor3f(.5f,.5f,.5f);
					float knobBodyColor = .8f;
					gl.glColor3f(knobBodyColor, knobBodyColor + .06f,
							knobBodyColor + .1f);
					gl.glBegin(GL2.GL_QUADS);
					gl.glTexCoord2f(0, 0);
					gl.glVertex3f(-knobSize, -knobSize, 0);
					gl.glTexCoord2f(0, 1);
					gl.glVertex3f(-knobSize, knobSize, 0);
					gl.glTexCoord2f(1, 1);
					gl.glVertex3f(knobSize, knobSize, 0);
					gl.glTexCoord2f(1, 0);
					gl.glVertex3f(knobSize, -knobSize, 0);
					gl.glEnd();

					float tempColor = 0;
					if (k == 0) {
						tempColor = knobColorTick + knobPulseLoad[CURRENT];
						gl.glRotatef(knobRotLoad[CURRENT], 0f, 0f, 1f);
						// gl.glRotatef(knobRotWindow, 0f,0f,1f);
					} else if (k == 1) {
						tempColor = knobColorTick + knobPulseSkip[CURRENT];
						gl.glRotatef(knobRotSkip[CURRENT], 0f, 0f, 1f);
						// gl.glRotatef(knobRotSkip, 0f,0f,1f);
					} else if (k == 2) {
						tempColor = knobColorTick + knobPulseBurst[CURRENT];
						gl.glRotatef(knobRotBurst[CURRENT], 0f, 0f, 1f);
						// gl.glRotatef(knobRotBurst, 0f,0f,1f);
					} else if (k == 3) {
						tempColor = knobColorTick + knobPulseReloadTimer[CURRENT];
						gl.glRotatef(knobRotReloadTimer[CURRENT], 0f, 0f, 1f);
						// gl.glRotatef(knobRotBurst, 0f,0f,1f);
					} else if (k == 4) {
						tempColor = knobColorTick + knobPulseReloadBuffer[CURRENT];
						gl.glRotatef(knobRotReloadBuffer[CURRENT], 0f, 0f, 1f);
						// gl.glRotatef(knobRotBurst, 0f,0f,1f);
					}

					knobT1.enable(gl);
					knobT1.bind(gl);
					// gl.glColor3f(.5f,.5f,.5f);
					gl.glColor3f(tempColor, 0, 0);
					// gl.glColor3f(tempColor,tempColor+.06f,tempColor+.1f);
					gl.glBegin(GL2.GL_QUADS);
					gl.glTexCoord2f(0, 0);
					gl.glVertex3f(-knobSize, -knobSize, 0);
					gl.glTexCoord2f(0, 1);
					gl.glVertex3f(-knobSize, knobSize, 0);
					gl.glTexCoord2f(1, 1);
					gl.glVertex3f(knobSize, knobSize, 0);
					gl.glTexCoord2f(1, 0);
					gl.glVertex3f(knobSize, -knobSize, 0);
					gl.glEnd();

					gl.glPopMatrix();

				}
			}
			gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
			gl.glEnable(GL2.GL_DEPTH_TEST);
			gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
			// end user interface glyphs
		}

	}

	public void cpuPipeline(GL2 gl, int programObject) {

		gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);

		gl.glReadBuffer(GL2.GL_BACK);

		int selX = Math.min(userSelection[WC.START][WC.X],
				userSelection[WC.END][WC.X]);
		int selY = Math.min(userSelection[WC.START][WC.Y],
				userSelection[WC.END][WC.Y]);
		int selW = Math.abs(userSelection[WC.START][WC.X]
				- userSelection[WC.END][WC.X]);
		int selH = Math.abs(userSelection[WC.START][WC.Y]
				- userSelection[WC.END][WC.Y]);

		if (selW > 0 && selH > 0) {

			dwtBi[dwtBufferStep] = Screenshot.readToBufferedImage(selX, selY,
					selW, selH, true);

			if (dwtBi[dwtBufferStep] != null) {
				BufferedImage resBi = new BufferedImage(selW, selH,
						BufferedImage.TYPE_INT_RGB);

				float probe[] = new float[WC.DWT_BUFFER_COUNT];

				for (int w = 0; w < selW; w++) {
					for (int h = 0; h < selH; h++) {

						// System.out.print("PROBE: ");
						for (int i = 0; i < WC.DWT_BUFFER_COUNT; i++) {
							int windowStep = (i + dwtBufferStep)
									% WC.DWT_BUFFER_COUNT;
							if (dwtBi[i] != null) {
								probe[windowStep] = dwtBi[i].getRGB(w, h) >> 16;
								// System.out.print(probe[windowStep]+" ");
							}

						}
						// System.out.print(" ");

						float res = 0;

						for (int i = 0; i < WC.DWT_BUFFER_COUNT; i++) {
							res += probe[i] * (dwtKernel[i]);
						}

						int diff = (int) res;
						if (diff > 255)
							diff = 255;
						if (diff < 0)
							diff = 0;

						int rgbaR = (diff << 16) | (diff << 8) | diff;
						resBi.setRGB(w, h, rgbaR);
					}
				}

				// new tex tile
				Texture tile = AWTTextureIO.newTexture(GLProfile.getDefault(),
						resBi, true);

				tile.enable(gl);
				tile.bind(gl);
				gl.glEnable(GL2.GL_TEXTURE_2D);

				gl.glColor4f(1f, 1f, 1f, 1f);
				gl.glBegin(GL2.GL_QUADS);

				int llX = 0;
				if (userSelection[WC.END][WC.X] < userSelection[WC.START][WC.X]) {
					llX = 1;
				}
				int oppX = (llX + 1) % 2;
				int llY = 0;
				if (userSelection[WC.END][WC.Y] < userSelection[WC.START][WC.Y]) {
					llY = 1;
				}
				int oppY = (llY + 1) % 2;
				float uiZ = 1;

				gl.glTexCoord2f(0, 1);
				gl.glVertex3f(userSelection[llX][WC.X],
						userSelection[oppY][WC.Y], uiZ);

				gl.glTexCoord2f(1, 1);
				gl.glVertex3f(userSelection[oppX][WC.X],
						userSelection[oppY][WC.Y], uiZ);

				gl.glTexCoord2f(1, 0);
				gl.glVertex3f(userSelection[oppX][WC.X],
						userSelection[llY][WC.Y], uiZ);

				gl.glTexCoord2f(0, 0);
				gl.glVertex3f(userSelection[llX][WC.X],
						userSelection[llY][WC.Y], uiZ);

				gl.glEnd();

				// dwtBufferStepTrigger=0;
			}
		}
	}

	public int findIndexOfVal(int[] ray, int val) {
		int index = -1;

		for (int i = 0; i < ray.length; i++) {
			if (ray[i] == val) {
				index = i;
			}
		}
		return index;
	}

	public void getGludVariables(GL2 gl) {
		for (int i = 0; i < 1000; i++) {
			// for (int i = 0; i < WC.HIST_BINS; i++) {
			if (cvt.gludHistBins[i] == null) {
				cvt.gludHistBins[i] = new GLUniformData("gpuHistBins[" + i
						+ "]", gpuHistBins[i]);
			}
			cvt.gludHistBins[i] = glslState
					.getUniform("gpuHistBins[" + i + "]");

			if (i > 300 && 1 < 1000) {
				System.out.println("hist " + i + " : " + gpuHistBins[i]);
			}
		}

	}

	public void setGludVariables(GL2 gl) {
		for (int i = 0; i < WC.FRAG_PROGRAM_COUNT - 1; i++) {
			if (glslSubroutineFlags[i] == true) {
				cvt.gludSubroutineFlags[i] = new GLUniformData(
						"subroutine_flag_" + i, 1);
				glslState.uniform(gl, cvt.gludSubroutineFlags[i]);
			} else if (glslSubroutineFlags[i] == false) {
				cvt.gludSubroutineFlags[i] = new GLUniformData(
						"subroutine_flag_" + i, 0);
				glslState.uniform(gl, cvt.gludSubroutineFlags[i]);
			}
		}

		for (int i = 0; i < WC.DWT_BUFFER_COUNT; i++) {
			// cvt.glud[i].setData(i+dwtBufferStep);
			cvt.glud[i] = new GLUniformData("tex_sampler_" + i, i);
			glslState.uniform(gl, cvt.glud[i]);
		}

		for (int i = 0; i < WC.DWT_BUFFER_COUNT; i++) {
			cvt.gludBufferFillOrder[i] = new GLUniformData("bufferFillOrder["
					+ i + "]", findIndexOfVal(bufferFillOrder, i)); // which
			// texture
			// received
			// the
			// recent
			// draw?
			glslState.uniform(gl, cvt.gludBufferFillOrder[i]);
			// cvt.gludBufferFillTimes[i] = new
			// GLUniformData("bufferFillTimes["+i+"]", bufferFillTimes[i]);
			// glslState.glUniform(gl, cvt.gludBufferFillTimes[i]);
		}

		for (int i = 0; i < WC.DWT_BUFFER_COUNT; i++) {
			cvt.gludDwtKernelCoefficients[i] = new GLUniformData(
					"dwtKernelCoefficients[" + i + "]",
					dwtKernelCoefficients[i]); // which texture received the
			// recent draw?
			glslState.uniform(gl, cvt.gludDwtKernelCoefficients[i]);
		}

		// start GLSL subroutine flag sync
		if (cvt.opMask[WC.THREAD_GPU_FRAG_DIFF] == true) {
			cvt.glslSubroutineFlags[WC.FRAG_PROGRAM_DIFF] = true;
		} else {
			cvt.glslSubroutineFlags[WC.FRAG_PROGRAM_DIFF] = false;
		}
		if (cvt.opMask[WC.THREAD_GPU_FRAG_DWT] == true) {
			cvt.glslSubroutineFlags[WC.FRAG_PROGRAM_DWT] = true;
		} else {
			cvt.glslSubroutineFlags[WC.FRAG_PROGRAM_DWT] = false;
		}
		if (cvt.opMask[WC.THREAD_GPU_FRAG_CONTRAST] == true) {
			cvt.glslSubroutineFlags[WC.FRAG_PROGRAM_CONTRAST] = true;
		} else {
			cvt.glslSubroutineFlags[WC.FRAG_PROGRAM_CONTRAST] = false;
		}
		if (cvt.opMask[WC.THREAD_GPU_FRAG_HDR] == true) {
			cvt.glslSubroutineFlags[WC.FRAG_PROGRAM_HDR] = true;
		} else {
			cvt.glslSubroutineFlags[WC.FRAG_PROGRAM_HDR] = false;
		}
		cvt.opMask[WC.THREAD_GPU_FRAG_HDR] = true;
		cvt.glslSubroutineFlags[WC.FRAG_PROGRAM_HDR] = true;

		for (int i = 0; i < glContrastColorBands; i++) {
			float colorLimitFp = glColorLimits[glColorScheme][i]
					* intensityScaleGpu;
			// System.out.println("intensity fp "+glColorLimits[glColorScheme][i]
			// + " "+colorLimitFp);
			cvt.gludContrastIntensities[i] = new GLUniformData(
					"contrast_node_intensity_" + i, colorLimitFp);
			glslState.uniform(gl, cvt.gludContrastIntensities[i]);
			for (int k = 0; k < 3; k++) {

				cvt.gludContrastFalseColors[i][k] = new GLUniformData(
						"contrast_node_rgb_" + i + "_" + k,
						glColorLimitsRGB[glColorScheme][i][k]);
				glslState.uniform(gl, cvt.gludContrastFalseColors[i][k]);
			}
		}
	}

	public void execPipeline(GL2 gl) {// programObject

		// CREATE DATA
		int selX = Math.min(userSelection[WC.START][WC.X],
				userSelection[WC.END][WC.X]);
		int selY = Math.min(userSelection[WC.START][WC.Y],
				userSelection[WC.END][WC.Y]);
		int selW = Math.abs(userSelection[WC.START][WC.X]
				- userSelection[WC.END][WC.X]);
		int selH = Math.abs(userSelection[WC.START][WC.Y]
				- userSelection[WC.END][WC.Y]);

		if (selW > 0 && selH > 0) {
			int[] vp = new int[4];

			// int texSlot = dwtBufferStep;

			if (dwtBufferStepTrigger == 1) {
				dwtBufferStepPrev = dwtBufferStep;
				dwtBufferStep++;
				if (dwtBufferStep >= WC.DWT_BUFFER_COUNT) {
					dwtBufferStep = 0;
				}
				for (int i = 0; i < WC.DWT_BUFFER_COUNT; i++) {
					bufferFillOrder[i]++;
				}
				bufferFillOrder[dwtBufferStep] = 0;

				dwtBufferStepTrigger = 0;
			}
			
			int texSlot = dwtBufferStep;

			gl.glActiveTexture(dwtTexIdsGpuConst[texSlot]);
			gl.glBindTexture(GL2.GL_TEXTURE_2D, dwtTexIds[texSlot]);
			gl.glReadBuffer(GL2.GL_BACK);

			gl.glCopyTexSubImage2D(GL.GL_TEXTURE_2D, 0, 0, 0, selX, selY, selW,
					selH);

			gl.glActiveTexture(GL2.GL_TEXTURE0);
			gl.glBindTexture(GL2.GL_TEXTURE_2D, dwtTexIds[0]);

			glslState.useProgram(gl, true);
			
			setGludVariables(gl);

			float uiZ = 0f;

			gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);

			gl.glPushMatrix();
			float scaleOverlay = 1.2f;
			gl.glColor3f(1f, 1f, 1f);
			gl.glBegin(GL2.GL_QUADS);

			int llX = 0;
			if (userSelection[WC.END][WC.X] < userSelection[WC.START][WC.X]) {
				llX = 1;
			}
			int oppX = (llX + 1) % 2;
			int llY = 0;
			if (userSelection[WC.END][WC.Y] < userSelection[WC.START][WC.Y]) {
				llY = 1;
			}
			int oppY = (llY + 1) % 2;

			float texScaleW = (float) selW / (float) glCanvas.getWidth();
			float texScaleH = (float) selH / (float) glCanvas.getHeight();
			gl.glTexCoord2f(0, texScaleH);
			gl.glVertex3f(userSelection[llX][WC.X], userSelection[oppY][WC.Y],
					uiZ);

			gl.glTexCoord2f(texScaleW, texScaleH);
			gl.glVertex3f(userSelection[oppX][WC.X], userSelection[oppY][WC.Y],
					uiZ);

			gl.glTexCoord2f(texScaleW, 0);
			gl.glVertex3f(userSelection[oppX][WC.X], userSelection[llY][WC.Y],
					uiZ);

			gl.glTexCoord2f(0, 0);
			gl.glVertex3f(userSelection[llX][WC.X], userSelection[llY][WC.Y],
					uiZ);

			gl.glEnd();

			glslState.useProgram(gl, false);
			gl.glPopMatrix();
			
			gl.glBindTexture(GL2.GL_TEXTURE_2D, 0);
		}

	}

	public void display(GLAutoDrawable drawable) {
		
		GL2 gl = drawable.getGL().getGL2();
		// create any missing resources

		if (mapResourcesExist == 0) {
			cvt.createMapMercatorList(gl);
			cvt.createGlobeMapList(gl);
			cvt.createGlobeLineList(gl);
			mapResourcesExist = 1;
		}

		if (gl != null) {
			doSystemLoop(gl);
		}
	}

	public void initGlItems() {
		System.out.println("INIT GEOMETRY LISTS");

		cvt.glCanvas.addMouseListener(this);
		cvt.glCanvas.addMouseMotionListener(this);
		cvt.glCanvas.addMouseWheelListener(this);

		cvt.glCanvas.setSize(viewportGlX, viewportGlY);
		cvt.glCanvas.setVisible(true);

		for (int cs = 0; cs < WC.COORDINATES_MODE_MAX; cs++) {
			view_scale[cs] = 1f;
		}

		view_rot[WC.COORDINATES_GLOBE][WC.X] = -45f;
		view_rot[WC.COORDINATES_GLOBE][WC.Y] = -180f;
		view_rot[WC.COORDINATES_GLOBE][WC.Z] = 0;

		view_scale[WC.COORDINATES_GLOBE] = 1.7f;
		view_scale[WC.COORDINATES_MERCATOR] = 4f;
		view_scale[WC.COORDINATES_SENSOR] = 8f;

		for (int f = 0; f < WC.TOTAL_FLIGHTS; f++) {
			for (int k = 0; k < 3; k++) {
				los_error_rot[f][k] = 0;
			}
		}

	}

	private void initExtension(GL gl, String glExtensionName) {
		if (!gl.isExtensionAvailable(glExtensionName)) {
			final String message = "OpenGL extension \"" + glExtensionName
					+ "\" not available";
			new Thread(new Runnable() {
				public void run() {
					JOptionPane.showMessageDialog(null, message,
							"Unavailable extension", JOptionPane.ERROR_MESSAGE);

				}
			}).start();
			throw new RuntimeException(message);
		}
	}

	public static void genFragSourceHDR(ArrayList source) {

		// auto collapse contrast range based on local dynamic range
		System.out.println("GENERATING GLSL DYNAMIC CONTRAST CODE");

		String line = "";

		line = "if (subroutine_flag_" + WC.FRAG_PROGRAM_HDR + " == 1){";
		source.add(line);

		// mean
		int kernelSize = WC.FRAG_PROGRAM_KERNEL_SIZE_XY;
		int kernelHalfSize = (int) Math.floor(kernelSize / 2f);

		line = " float average;";
		source.add(line);

		float kernelScale = 1f / (float) (WC.FRAG_PROGRAM_KERNEL_SIZE_XY * WC.FRAG_PROGRAM_KERNEL_SIZE_XY);

		line = " float kernelScale = " + kernelScale + ";";
		source.add(line);

		for (int j = 0; j < kernelSize; j++) {
			for (int k = 0; k < kernelSize; k++) {
				for (int i = 0; i < sampler.length; i++) {
					line = "average += kernelScale* v1" + i + "_SK_" + j + "_"
							+ k + "[0];";
					source.add(line);
				}
			}
		}

		line = "syncedInput[0] = vec4(average,average,average,1.0);";

		line = "}";
		source.add(line);
	}

	public static void genFragSourceContrast(ArrayList source) {
		System.out.println("GENERATING GLSL FALSE COLOR CODE");

		String line = "";

		line = "if (subroutine_flag_" + WC.FRAG_PROGRAM_CONTRAST + " == 1){";
		source.add(line);

		line = "int c1 = -1;";
		source.add(line);
		for (int i = 0; i < cvt.glContrastColorBands; i++) {

			line = "if (syncedInput[0] >= vRGB_" + i + "[3]){ c1=" + i + ";}";
			source.add(line);
		}

		for (int i = 0; i < cvt.glContrastColorBands - 1; i++) {
			line = "if (c1 == " + i + "){";
			source.add(line);

			line = "float span = vRGB_" + (i + 1) + "[3]-vRGB_" + i + "[3];";
			source.add(line);

			line = "float diff = syncedInput[0] - vRGB_" + (i) + "[3];";
			source.add(line);

			line = "float mix2 = diff/span;";
			source.add(line);
			line = "float mix1 = 1.0 - mix2;";
			source.add(line);

			line = "float resR = (vRGB_" + i + "[0]*mix1)+(vRGB_" + (i + 1)
					+ "[0]*mix2);";
			source.add(line);
			line = "float resG = (vRGB_" + i + "[1]*mix1)+(vRGB_" + (i + 1)
					+ "[1]*mix2);";
			source.add(line);
			line = "float resB = (vRGB_" + i + "[2]*mix1)+(vRGB_" + (i + 1)
					+ "[2]*mix2);";
			source.add(line);
			
			line = "syncedInput = vec4(resR, resG, resB, resultAlpha);";
			source.add(line);

			line = "}";
			source.add(line);
		}

		line = "}";
		source.add(line);
	}

	public static void genFragSourceDWT(ArrayList source) {

		System.out.println("GENERATING GLSL DWT CODE");

		String line = "";

		line = "if (subroutine_flag_" + WC.FRAG_PROGRAM_DWT + " == 1){";
		source.add(line);

		float blurCoef = 1f / 15f;

		float noiseBlur = .5f;
		float mainBlur = 1.0f;

		float[] coefGpu = { 0.5f, -.5f, -.5f, .5f, -.5f, .5f, -.5f, 1.0f, -.5f,
				.5f, -.5f, .5f, -.5f, -.5f, .5f };

		float blurCoef2 = 1f / 4f;

		for (int i = 0; i < cvt.dwtKernelCoefficients.length; i++) {
			cvt.dwtKernelCoefficients[i] = 0;
		}
		for (int i = 0; i < coefGpu.length; i++) {
			cvt.dwtKernelCoefficients[i] = coefGpu[i];
		}

		String subline = "";
		for (int i = 0; i < cvt.dwtKernelCoefficients.length; i++) {
			subline += "v1ray[bufferFillOrder[" + (i)
					+ "]]*dwtKernelCoefficients[" + i + "]";
			if (i < cvt.dwtKernelCoefficients.length - 1) {
				subline += "+\n";
			}
		}
		line = "float dwtRes = " + subline + ";";
		source.add(line);

		line = "dwtRes = abs(dwtRes);";
		source.add(line);

		line = "float diffSq = dwtRes*dwtRes;";
		source.add(line);
		line = "float diffAny = 0;";
		source.add(line);
		line = "if (syncedInput[0] != syncedInputPrev[0]){diffAny=.25;};";
		source.add(line);
		// line =
		// "syncedInput = vec4(dwtRes, diffSq+dwtRes, diffSq+diffAny+dwtRes, resultAlpha);";
		line = "syncedInput = vec4(dwtRes, diffSq+dwtRes, diffSq+diffAny+dwtRes, resultAlpha);";

		// line =
		// "syncedInput = vec4(dwtRes, dwtRes*10, dwtRes*50, resultAlpha);";
		source.add(line);

		line = "}";
		source.add(line);
	}

	public static void genFragSourceStats(ArrayList source) {

		System.out.println("GENERATING GLSL DWT CODE");

		String line = "";

		line = "if (subroutine_flag_" + WC.FRAG_PROGRAM_DWT + " == 1){";
		source.add(line);

		float blurCoef = 1f / 15f;
		
		float noiseBlur = .5f;
		float mainBlur = 1.0f;

		float[] coefGpu = { 0.5f, -.5f, -.5f, .5f, -.5f, .5f, -.5f, 1.0f, -.5f,
				.5f, -.5f, .5f, -.5f, -.5f, .5f };

		float blurCoef2 = 1f / 4f;

		for (int i = 0; i < cvt.dwtKernelCoefficients.length; i++) {
			cvt.dwtKernelCoefficients[i] = 0;
		}
		for (int i = 0; i < coefGpu.length; i++) {
			cvt.dwtKernelCoefficients[i] = coefGpu[i];
		}

		String subline = "";
		for (int i = 0; i < cvt.dwtKernelCoefficients.length; i++) {
			subline += "v1ray[bufferFillOrder[" + (i)
					+ "]]*dwtKernelCoefficients[" + i + "]";
			if (i < cvt.dwtKernelCoefficients.length - 1) {
				subline += "+\n";
			}
		}
		line = "float dwtRes = " + subline + ";";
		source.add(line);

		line = "dwtRes = abs(dwtRes);";
		source.add(line);

		line = "float diffSq = dwtRes*dwtRes;";
		source.add(line);
		line = "float diffAny = 0;";
		source.add(line);
		line = "if (syncedInput[0] != syncedInputPrev[0]){diffAny=.25;};";
		source.add(line);
		line = "syncedInput = vec4(dwtRes, diffSq+dwtRes, diffSq+diffAny+dwtRes, resultAlpha);";

		source.add(line);

		line = "}";
		source.add(line);

	}

	public static void genFragSourceCommon(ArrayList source) {
		System.out.println("GENERATING GLSL HEADER CODE");

		String line = "";

		for (int i = 0; i < sampler.length; i++) {
			line = "uniform sampler2D tex_sampler_" + i + ";";
			source.add(line);
		}
		
		for (int i = 0; i < cvt.glContrastColorBands; i++) {
			for (int k = 0; k < 3; k++) {
				line = "uniform float contrast_node_rgb_" + i + "_" + k + ";";
				source.add(line);
			}
		}

		for (int i = 0; i < cvt.glContrastColorBands; i++) {
			line = "uniform float contrast_node_intensity_" + i + ";";
			source.add(line);
		}

		line = "uniform int[" + WC.DWT_BUFFER_COUNT + "] bufferFillOrder;"; // for

		source.add(line);
		line = "uniform int[" + WC.DWT_BUFFER_COUNT + "] bufferFillTimes;"; // to


		source.add(line);

		for (int i = 0; i < WC.FRAG_PROGRAM_COUNT; i++) {
			line = "uniform int subroutine_flag_" + i + ";";
			source.add(line);
		}

		line = "uniform float[" + WC.DWT_BUFFER_COUNT
				+ "] dwtKernelCoefficients;";
		source.add(line);

		line = "void main(void)";
		source.add(line);

		line = "{";
		source.add(line);

		line = "   vec2 texCoordA = gl_TexCoord[0].xy;";
		source.add(line);

		int kernelSize = WC.FRAG_PROGRAM_KERNEL_SIZE_XY;
		int kernelHalfSize = (int) Math.floor(kernelSize / 2f);
		for (int j = 0; j < kernelSize; j++) {
			for (int k = 0; k < kernelSize; k++) {
				line = "   vec2 texCoordA_" + j + "_" + k
						+ " = vec2(texCoordA[0]+" + (j - kernelHalfSize)
						+ ",texCoordA[1]+" + (k - kernelHalfSize) + ");";
				source.add(line);
			}
		}

		for (int i = 0; i < sampler.length; i++) {
			line = "vec4 v1" + i + " = texture2D(tex_sampler_" + i
					+ ", texCoordA);";
			
			source.add(line);
		}

		// spatial kernel
		for (int j = 0; j < kernelSize; j++) {
			for (int k = 0; k < kernelSize; k++) {
				for (int i = 0; i < sampler.length; i++) {
					line = "vec4 v1" + i + "_SK_" + j + "_" + k
							+ " = texture2D(tex_sampler_" + i + ", texCoordA_"
							+ j + "_" + k + ");";
				
					source.add(line);
				}
			}
		}

		line = "float[" + WC.DWT_BUFFER_COUNT + "] v1ray;";
		source.add(line);
		for (int i = 0; i < sampler.length; i++) {
			line = "v1ray[" + i + "] = v1" + i + "[0];";
			// line = "v1ray[" + i + "] = v1" + i + "[0]*.25;";
			source.add(line);
		}

		line = "vec4 res = vec4(1.0, 0.0, 0.0, 1.0);";
		source.add(line);

		line = "float resultAlpha = 1.0;";
		source.add(line);

		for (int i = 0; i < cvt.glContrastColorBands; i++) {
			// for (int i=0; i<cvt.glContrastColorBands; i++){
			line = "vec4 vRGB_" + i + " = vec4(contrast_node_rgb_" + i
					+ "_0,contrast_node_rgb_" + i + "_1,contrast_node_rgb_" + i
					+ "_2,contrast_node_intensity_" + i + ");";
			source.add(line);
		}

		line = "vec4 syncedInput = "
				+ brightnessScaleGpu
				+ "*vec4(v1ray[bufferFillOrder[0]],v1ray[bufferFillOrder[0]],v1ray[bufferFillOrder[0]],resultAlpha);";
		source.add(line);
		line = "vec4 syncedInputPrev = "
				+ brightnessScaleGpu
				+ "*vec4(v1ray[bufferFillOrder[0]],v1ray[bufferFillOrder[0]],v1ray[bufferFillOrder[0]],resultAlpha);";
		source.add(line);

	}

	public static void genFragSourceClosure(ArrayList source) {
		System.out.println("GENERATING GLSL FOOTER CODE");

		String line = "";

		line = "gl_FragColor = syncedInput;";
		// line = "gl_FragColor = res;";
		source.add(line);

		line = "}";
		source.add(line);

	}

	public static String[] genFragSourceAggregate(ArrayList source) {

		String[] srcStr = new String[source.size()];
		for (int i = 0; i < source.size(); i++) {
			srcStr[i] = (String) source.get(i);
			System.out.println("GLSL SOURCE: " + srcStr[i]);
		}

		return srcStr;
	}

	public static void genFragSourceDiffs(ArrayList source) {
		System.out.println("GENERATING GLSL DIFFS CODE");

		String line = "";

		line = "if (subroutine_flag_" + WC.FRAG_PROGRAM_DIFF + " == 1){";
		source.add(line);

		line = "syncedInput = vec4(v1ray[bufferFillOrder[0]],v1ray[bufferFillOrder[0]],v1ray[bufferFillOrder[0]],resultAlpha);";
		source.add(line);
		line = "syncedInputPrev = vec4(v1ray[bufferFillOrder[1]],v1ray[bufferFillOrder[1]],v1ray[bufferFillOrder[1]],resultAlpha);";
		source.add(line);

		line = "float diff = syncedInputPrev[0]-syncedInput[0];";
		source.add(line);
		line = "if (diff < 0){ diff = 0.0; }";
		source.add(line);

		line = "float diffSq = diff*diff;";
		source.add(line);
		line = "float diffAny = 0;";
		source.add(line);
		line = "if (syncedInput[0] != syncedInputPrev[0]){diffAny=.25;};";
		source.add(line);
		line = "syncedInput = vec4(diff, diffSq+diff, diffSq+diffAny+diff, resultAlpha);";

		source.add(line);

		line = "}";
		source.add(line);
	}

	public void init(GLAutoDrawable drawable) {
		System.out.println("JOGL init");
		System.err.println("Init message: " + drawable);
		// Use debug pipeline
		// drawable.setGL(new DebugGL(drawable.getGL()));

		GL2 gl = drawable.getGL().getGL2();

		gl.glHint(GL2.GL_PERSPECTIVE_CORRECTION_HINT, GL2.GL_NICEST);

		System.err.println("Chosen GLCapabilities: "
				+ drawable.getChosenGLCapabilities());
		System.err.println("INIT GL IS: " + gl.getClass().getName());
		System.err.println("GL_VENDOR: " + gl.glGetString(GL2.GL_VENDOR));
		System.err.println("GL_RENDERER: " + gl.glGetString(GL2.GL_RENDERER));
		System.err.println("GL_VERSION: " + gl.glGetString(GL2.GL_VERSION));

		System.err.println("GL_SHADING_LANGUAGE_VERSION: "
				+ gl.glGetString(GL2.GL_SHADING_LANGUAGE_VERSION));

		for (int i = 0; i < WC.DWT_BUFFER_COUNT; i++) {
			dwtTexIds[i] = WC.STATUS_ERROR;
		}

		gl.setSwapInterval(1);
		try {
			initExtension(gl, "GL_ARB_vertex_buffer_object");
		} catch (RuntimeException e) {
			throw (e);
		}

		for (int t = 0; t < maxTiles; t++) {
			gl.glGenTextures(1, texBufferName, t);
			gl.glGenBuffers(1, colBufferName, t);
			gl.glGenBuffers(1, posBufferName, t);
		}

		for (int i = 0; i < WC.DWT_BUFFER_COUNT; i++) {
			dwtTexIdsGpuConst[i] = GL2.GL_TEXTURE0 + i;
		}

		for (int i = 0; i < WC.DWT_BUFFER_COUNT; i++) {
			gl.glActiveTexture(dwtTexIdsGpuConst[i]);
			gl.glGenTextures(1, dwtTexIds, i);
			System.out.println("dwt tex id " + i + ": " + dwtTexIds[i]);
		}

		gl.glActiveTexture(GL2.GL_TEXTURE0);

		// create the FBOs
		if (gl.isExtensionAvailable("GL_EXT_framebuffer_object")) {

			int fboId[] = new int[1];
			int texId[] = new int[1];

			for (int i = 0; i < WC.DWT_BUFFER_COUNT; i++) {
				createFrameBufferObject(gl, fboId, texId, glCanvas.getWidth(),
						glCanvas.getHeight());
				fboIdsDwt[i] = fboId[0];
				texIdsDwt[i] = texId[0];
			}
		}

		if (!gl.isExtensionAvailable("GL_ARB_fragment_shader")
				|| !gl.isExtensionAvailable("GL_ARB_vertex_shader")
				|| !gl.isExtensionAvailable("GL_ARB_shader_objects")
				|| !gl.isExtensionAvailable("GL_ARB_shading_language_100")) {
			System.out
					.println("Driver does not support OpenGL Shading Language\n");
			System.exit(-1);
		}

		gl.glBindTexture(GL.GL_TEXTURE_2D, dwtTexIds[0]);
		gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER,
				GL.GL_LINEAR);
		gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER,
				GL.GL_LINEAR);
		gl
				.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_S,
						GL2.GL_CLAMP);
		gl
				.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_T,
						GL2.GL_CLAMP);
		gl.glTexImage2D(GL.GL_TEXTURE_2D, 0, GL2.GL_RGBA16F, glCanvas
				.getWidth(), glCanvas.getHeight(), 0, GL.GL_RGBA, GL.GL_FLOAT,
				null);

		for (int i = 0; i < WC.DWT_BUFFER_COUNT - 1; i++) {
			gl.glBindTexture(GL2.GL_TEXTURE_2D, dwtTexIds[(i + 1)]);
			gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MIN_FILTER,
					GL2.GL_LINEAR);
			gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MAG_FILTER,
					GL2.GL_LINEAR);
			gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_WRAP_S,
					GL2.GL_CLAMP);
			gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_WRAP_T,
					GL2.GL_CLAMP);
			gl.glTexImage2D(GL2.GL_TEXTURE_2D, 0, GL2.GL_RGBA16F, glCanvas
					.getWidth(), glCanvas.getHeight(), 0, GL.GL_RGBA,
					GL.GL_FLOAT, null);
		}

		genFragSourceCommon(fragSourceAggregator);
		genFragSourceDiffs(fragSourceAggregator);
		genFragSourceDWT(fragSourceAggregator);
		genFragSourceStats(fragSourceAggregator);
		genFragSourceHDR(fragSourceAggregator);
		genFragSourceContrast(fragSourceAggregator);
		genFragSourceClosure(fragSourceAggregator);
		fragSourceAggregate = genFragSourceAggregate(fragSourceAggregator);

		initGpuPipelineVars();

		compileGLSLjogamp(gl, fragSourceAggregate, "FRAG_PROGRAM_AGGREGATE");


	}

	public void initGpuPipelineVars() {
		for (int i = 0; i < bufferFillOrder.length; i++) {
			bufferFillOrder[i] = 9999;// WC.STATUS_ERROR;
		}
	}

	private static void createFrameBufferObject(GL2 gl, int[] frameBuffer,
			int[] colorBuffer, int width, int height) {
		gl.glGenFramebuffers(1, frameBuffer, 0);
		gl.glBindFramebuffer(GL2.GL_FRAMEBUFFER, frameBuffer[0]);

		gl.glGenTextures(1, colorBuffer, 0);
		gl.glBindTexture(GL.GL_TEXTURE_2D, colorBuffer[0]);
		gl.glTexImage2D(GL.GL_TEXTURE_2D, 0, GL2.GL_RGBA16F, width, height, 0,
				GL.GL_RGBA, GL.GL_UNSIGNED_SHORT, Buffers
						.newDirectByteBuffer(width * height * 8));
		gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER,
				GL.GL_LINEAR);
		gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER,
				GL.GL_LINEAR);
		gl.glFramebufferTexture2D(GL2.GL_FRAMEBUFFER, GL2.GL_COLOR_ATTACHMENT0,
				GL.GL_TEXTURE_2D, colorBuffer[0], 0);
		gl.glBindTexture(GL.GL_TEXTURE_2D, 0);

		int status = gl.glCheckFramebufferStatus(GL2.GL_FRAMEBUFFER);
		if (status == GL2.GL_FRAMEBUFFER_COMPLETE) {
			gl.glBindFramebuffer(GL2.GL_FRAMEBUFFER, 0);
		} else {
			throw new IllegalStateException("Frame Buffer Oject not created.");
		}
	}

	public void compileGLSLjogamp(GL2 gl, String[] source, String progName) {
		// public static void compileGLSLjogamp(GL2 gl, int p, String[] source)
		// {
		System.out.println("*** BEGIN COMPILING GLSL FOR " + progName + " ***");
		int p = 0;

		String[][] programs = new String[1][source.length];
		for (int i = 0; i < source.length; i++) {
			programs[0][i] = source[i];
		}

		ShaderCode glslSc = new ShaderCode(GL2.GL_FRAGMENT_SHADER, 1, programs);
		glslSc.compile(gl);
		glslSp[p] = new ShaderProgram();
		glslSp[p].add(glslSc);
		glslSp[p].link(gl, System.out);

		System.out.println("GLSL LINK STATUS: " + cvt.glslSp[p].linked());
		ShaderUtil glslUtil = new ShaderUtil();

		glslState = new ShaderState();
		glslState.setVerbose(true);
		glslState.attachShaderProgram(gl, cvt.glslSp[p]);

		System.out.println("*** END COMPILING GLSL FOR " + progName + " ***");
	}

	public void drawFinalScreen() {
		// flush to screen

		if (resizedView == null) {
			resizedView = new BufferedImage(viewportImage.getWidth() / 2,
					viewportImage.getHeight() / 2, BufferedImage.TYPE_INT_ARGB);
		}

		if (gwc != null) {
			
			gwc.setComposite(graphicComposites[c_COMPLETE]);
			gwc.drawImage(viewportImage, 0, 0, null);

		} else {

			gwc = (Graphics2D) tivoCanvas.getGraphics();
		}

		if (exportBounceVideoState == WC.STATUS_ON) {
			try {
				String fName = defaultFfmpegScratchDirStr
						+ batchFfmpegScratchDirStr + bounceVideoFrameCount
						+ ".png";
				File pngFile = new File(fName);
				pngFile.setReadable(true, false);

				System.out.println("SAVE IMAGE " + fName);

				int selX = Math.min(userSelection[WC.START][WC.X],
						userSelection[WC.END][WC.X]);
				int selY = Math.min(userSelection[WC.START][WC.Y],
						userSelection[WC.END][WC.Y]);
				int selW = Math.abs(userSelection[WC.START][WC.X]
						- userSelection[WC.END][WC.X]);
				int selH = Math.abs(userSelection[WC.START][WC.Y]
						- userSelection[WC.END][WC.Y]);

				String securityMarkStr = productClassificationLabelStr;

				if (selW % 2 == 1)
					selW--;
				if (selH % 2 == 1)
					selH--;

				if (selW > 0 && selH > 0) {
					BufferedImage biCapture = Screenshot.readToBufferedImage(
							selX, selY, selW, selH, true);

					int secBannerH = 20;
					int secBannerTextH = 14;
					int titleBannerH = 20;
					int titleBannerTextH = 14;
					int timeBannerH = 20;
					int timeBannerTextH = secBannerTextH;

					int finalW = (selW);
					int finalH = (selH)
							+ (2 * secBannerH + timeBannerH + titleBannerH);

					BufferedImage biFinalCapture = new BufferedImage(finalW,
							finalH, BufferedImage.TYPE_INT_ARGB);

					Graphics2D gFinalVideoGraphics = (Graphics2D) biFinalCapture
							.getGraphics();
					gFinalVideoGraphics.drawImage(biCapture, 0, timeBannerH
							+ secBannerH + titleBannerH, null);
					int secStrX = finalW / 2
							- (securityMarkStr.length() / 2 * 6);
					int titleStrX = finalW / 2
							- (productTitleLabelStr.length() / 2 * 6);

					gFinalVideoGraphics.setColor(Color.RED);
					gFinalVideoGraphics.fillRect(0, 0, finalW, secBannerH);
					gFinalVideoGraphics.fillRect(0, finalH - secBannerH,
							finalW, secBannerH);

					gFinalVideoGraphics.setColor(Color.BLACK);
					gFinalVideoGraphics.drawString(securityMarkStr, secStrX,
							secBannerTextH);
					gFinalVideoGraphics.drawString(securityMarkStr,
							secStrX + 1, secBannerTextH);
					gFinalVideoGraphics.drawString(securityMarkStr, secStrX,
							finalH - secBannerH + secBannerTextH);
					gFinalVideoGraphics.drawString(securityMarkStr,
							secStrX + 1, finalH - secBannerH + secBannerTextH);

					// if (wfi.timeStampStr.length() > 1) {

					String bounceFrameTickerStr = bounceVideoFrameCount + "";
					while (bounceFrameTickerStr.length() < 5) {
						bounceFrameTickerStr = "0" + bounceFrameTickerStr;
					}

					String timeStr = "FRAME " + bounceFrameTickerStr + " - "
							+ witTimePlayheadTimestampOutputStr;
					// String timeStr = tf[i].timeStampStr;
					int timeStrX = finalW / 2 - (timeStr.length() / 2 * 7);
					gFinalVideoGraphics.setColor(Color.black);
					gFinalVideoGraphics.fillRect(0, secBannerH, finalW,
							timeBannerH + titleBannerH);

					gFinalVideoGraphics.setColor(Color.white);
					gFinalVideoGraphics.drawString(productTitleLabelStr,
							titleStrX, timeBannerH + titleBannerH);
					gFinalVideoGraphics.drawString(productTitleLabelStr,
							titleStrX + 1, timeBannerH + titleBannerH);
					gFinalVideoGraphics.setColor(Color.red);
					gFinalVideoGraphics.drawString(timeStr, timeStrX,
							timeBannerH + timeBannerTextH + titleBannerH);
					gFinalVideoGraphics.drawString(timeStr, timeStrX + 1,
							timeBannerH + timeBannerTextH + titleBannerH);
					// }

					if (newThreadExportVideo == 1
							&& (selW * selH < newThreadExportVideoMaxPixels)) {
						// begin frame export thread
						FrameWriteThread vef = new FrameWriteThread(
								biFinalCapture, "png", pngFile);

						Thread t = new Thread(vef);
						// t.setPriority(threadPriorities[imprRay[i].mode]);
						int vefTimeout = 10000;
						try {
							t.join(vefTimeout);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						t.start();
						userInterfaceInfoStr = "NEW I/O THREAD - SAVED FRAME "
								+ bounceVideoFrameCount + " - \""
								+ pngFile.getAbsolutePath() + "\"";

						// end frame export thread
					} else {
						userInterfaceInfoStr = "INLINE I/O - SAVED FRAME "
								+ bounceVideoFrameCount + " - \""
								+ pngFile.getAbsolutePath() + "\"";
						ImageIO.write(biFinalCapture, "png", pngFile);
					}

					bounceVideoFrameCount++;

					if (bounceVideoFrameCount > WC.MAX_VIDEO_FRAMES) {
						exportBounceVideoState = WC.STATUS_OFF;
						completeVideoExportFromGpu();
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (exportDemoVideoStateFrameSkipper > 0)
			exportDemoVideoStateFrameSkipper--;
		if (exportDemoVideoState == WC.STATUS_ON
				&& exportDemoVideoStateFrameSkipper <= 0) {
			exportDemoVideoStateFrameSkipper = exportDemoVideoStateFrameSkipperInitVal;
			try {

				String fName = defaultSaveDemoVideoDirStr + demoVideoFrameCount
						+ ".png";
				File pngFile = new File(fName);
				pngFile.setReadable(true, false);

				Screenshot.writeToFile(pngFile, glCanvas.getWidth(), glCanvas
						.getHeight());

				demoVideoFrameCount++;

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public int getThreadID() {

		int threadID = -1;
		int threadSearch = 1;

		for (int i = 0; i < MAX_THREADS_QUEUED; i++) {
			if (imprRay[i] != null) {

				if (imprRay[i].threadStatus == WC.THREAD_STATUS_READY
						&& threadID == -1) {// && threadAllocations[i] == 0) {
					if (threadSearch == 1) {

						threadID = i;
						threadSearch = 0;
					}

				}
			}
		}


		return threadID;
	}

	public void checkThreadActivityLevel() {
		// activeThreadCount
		int availThreads = 0;
		int activeThreads = 0;
		for (int i = 0; i < MAX_THREADS_QUEUED; i++) {
			if (imprRay[i].threadStatus == WC.THREAD_STATUS_COMPLETE) {
				imprRay[i].threadStatus = WC.THREAD_STATUS_READY;
				// threadAllocations[i] = 0;

				String reclaimStr = "RECLAIMED THREAD " + i + " - "
						+ opIdToName(imprRay[i].mode);

				if (imprRay[i].mode == WC.THREAD_LOAD_HDF5R) {
					loadEndTimer = System.currentTimeMillis();

					loadEndTimerLastUpdate = loadEndTimer;

					long loadDurationTimer = loadEndTimer - loadStartTimer;

					reclaimStr += " - LOAD TIME " + (loadDurationTimer / 1000)
							+ " SEC";
				}

				System.out.println(reclaimStr);

				userInterfaceInfoStr = reclaimStr;
			}
		}

		for (int i = 0; i < MAX_THREADS_QUEUED; i++) {
			if (imprRay[i].threadStatus == WC.THREAD_STATUS_READY) {
				availThreads++;
			} else {
				activeThreads++;
			}
		}
		int workingThreads = 0;

		int loadingThreads = 0;
		for (int i = 0; i < MAX_THREADS_QUEUED; i++) {
			if (imprRay[i].threadStatus == WC.THREAD_STATUS_WORKING) {
				workingThreads++;
			}
		}

		activeThreadCount = workingThreads;
	}

	public int getThreadQueueCount() {
		int queuedThreads = 0;

		for (int i = 0; i < MAX_THREADS_QUEUED; i++) {
			if (imprRay[i].threadStatus == WC.THREAD_STATUS_QUEUED) {

				queuedThreads++;
			}
		}

		queuedThreadCount = queuedThreads;

		return queuedThreads;
	}

	public void activateQueueThreads() {

		for (int i = 0; i < MAX_THREADS_QUEUED; i++) {

			if (activeThreadCount < MAX_THREADS_ACTIVE
					&& getThreadQueueCount() > 0) {
				if (imprRay[i].threadStatus == WC.THREAD_STATUS_QUEUED) {
					imprRay[i].threadStatus = WC.THREAD_STATUS_WORKING;

					Thread t = new Thread(imprRay[i]);
					t.setPriority(threadPriorities[imprRay[i].mode]);
					try {
						t.join(threadTimeouts[imprRay[i].mode]);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					activeThreadCount++;
					String activeThreadStr = "ACTIVATED THREAD " + i + " - "
							+ opIdToName(imprRay[i].mode);
					System.out.println(activeThreadStr);
					userInterfaceInfoStr = activeThreadStr;
					t.start();

				}
			}
		}
		System.runFinalization();
	}

	public void processWIT() {

		checkThreadActivityLevel();

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			if (flightLoadMask[flight] == 1) {

				for (int k = 0; k < WC.TOTAL_SCAS; k++) {

					if (witFrameList[flight][k] != null) { // if SCA has laoded
						// data

						if (threadScheme == WC.THREAD_SCHEME_BATCH) {

							for (int m = 0; m < WC.MODE_COUNT; m++) {

								if ((userSelectionSCAtouched[k] == 1 && filterRegionReqMask[m] == 1)
										|| filterRegionReqMask[m] == 0) { // if
							

									int mode = m;
									int threadID = -1;


									if (opMask[mode] == true
											&& opReqCPU[mode] == true
											&& checkNeedForThread(
													witFrameList[flight][k], 0,
													witFrameList[flight][k]
															.size(), mode) != -1) {

										threadID = getThreadID();

										StringBuilder strBdr = new StringBuilder();

										if (threadID != -1) {

											createParamList(mode, k); 

											imprRay[threadID] = new ImProcThread(
													getModeStr(mode), mode,
													witFrameList[flight][k], 0,
													witFrameList[flight][k]
															.size(),
													paramLists[k][mode]);

											imprRay[threadID].threadStatus = WC.THREAD_STATUS_QUEUED;

											// strBdr = new StringBuilder();
											strBdr.append("SETTING THREAD ");
											strBdr.append(threadID);
											strBdr
													.append(" AS QUEUED - "
															+ opIdToName(imprRay[threadID].mode));
											System.out.println(strBdr);

											userInterfaceInfoStr = strBdr
													.toString();
										}
									}
								}
							}
						}
					}
				}
			}
		}

		activateQueueThreads();
	}

	public void setGlobeOverlayRotation(WITFrame rasterFrame) {

		int flight = rasterFrame.satID;

		float ax = (float) rasterFrame.satPosECF[WC.X];
		float ay = (float) rasterFrame.satPosECF[WC.Y];
		float az = (float) rasterFrame.satPosECF[WC.Z];

		float at = (ax * ax) + (ay * ay) + (az * az);

		float maxDim = -1;

		if (Math.abs(ax) > maxDim) {
			maxDim = ax;
		}
		if (Math.abs(ay) > maxDim) {
			maxDim = ay;
		}
		if (Math.abs(az) > maxDim) {
			maxDim = az;
		}

		at = maxDim;// (float) Math.pow(at,.5f);

		float mult = 1f;// 360f;

		overlayGlobeTrack[flight][WC.X] = (float) rasterFrame.satPosECF[WC.X]
				/ at;
		overlayGlobeTrack[flight][WC.Y] = (float) rasterFrame.satPosECF[WC.Y]
				/ at;
		overlayGlobeTrack[flight][WC.Z] = (float) rasterFrame.satPosECF[WC.Z]
				/ at;

		overlayGlobeRot[flight][WC.X] = mult * overlayGlobeTrack[flight][WC.X];
		overlayGlobeRot[flight][WC.Y] = mult * overlayGlobeTrack[flight][WC.Y];
		overlayGlobeRot[flight][WC.Z] = mult * overlayGlobeTrack[flight][WC.Z];

		while (satTrackList.size() > WC.MAX_SAT_GROUND_TRACE_POINTS) {
			satTrackList.remove(satTrackList.size() - 1);
		}
		satTrackList.add(overlayGlobeTrack[flight]);

	}

	public void syncDrawSegments() {

		int playbackTimeMargin = loadSeconds;

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {

			if (flightLoadMask[flight] == 1) {
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					witSCAPlayhead[flight][k] = getIndexFromTime(
							witTimePlayhead, flight, k, playbackTimeMargin,
							playbackModeDir[flight]);//

					if (lastDrawIndexList[flight][k] != null) {
						while (lastDrawIndexList[flight][k].size() > 1) {
							lastDrawIndexList[flight][k].remove(0); // !!
							// 1/12/2011
						}

						lastDrawIndexList[flight][k]
								.add(witSCAPlayhead[flight][k]);

						if (lastDrawIndexList[flight][k].get(0) != lastDrawIndexList[flight][k]
								.get(lastDrawIndexList[flight][k].size() - 1)) {
							dwtBufferStepTrigger = 1;
						}
					}
				}
			}
		}

	}

	public void animatePlayback(GL2 gl) {


		if (playbackPaused == 0 && playheadDir != 0
				&& mouseState != WC.UI_STATE_TIMELINE_LOAD) {
			witFrameListStep(playheadDir, playbackStepSeconds);
		}

		syncDrawSegments();

	}

	public void genGpuCode(GL2 gl) {

		String[] vertexSource = new String[1];// "";

		IntBuffer ib = Buffers.newDirectIntBuffer(10);

		int vertexShader = gl.glCreateShader(GL2.GL_VERTEX_SHADER);
		gl.glShaderSource(vertexShader, 1, vertexSource, ib);

		shaderProgram = gl.glCreateProgram();
		gl.glAttachShader(shaderProgram, vertexShader);
		gl.glLinkProgram(shaderProgram);
		gl.glUseProgram(shaderProgram);

	}

	public void copyItemsToVBO2(GL2 gl) {

		// TRANSFER TO VBO

		tileBufferFills = 0;

		int discardedTiles = 0;
		int posSize = Buffers.SIZEOF_FLOAT * WC.VBO_VERTEX_COMPONENTS * 4;
		int colSize = Buffers.SIZEOF_FLOAT * WC.VBO_COLOR_COMPONENTS * 4;

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {

			if (flightLoadMask[flight] == 1) {

				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					if (scaLoadMask[flight][k] == 1) {
						if (witFrameList[flight][k] != null) {
							if (witFrameList[flight][k].size() > 0
									&& witSCAPlayhead[flight][k] >= 0
									&& witSCAPlayhead[flight][k] < witFrameList[flight][k]
											.size()) {

								WITFrame rasterFrame = null;
								if (scanDirAgreementDrawFlag[flight][k] == 1
										&& timeAgreementDrawFlag[flight][k] == 1
										&& scanSeqAgreementDrawFlag[flight][k] == 1) {

									rasterFrame = (WITFrame) witFrameList[flight][k]
											.get(witSCAPlayhead[flight][k]);

								} else { // draw previous otherwise
									// if (lastDrawIndex[flight][k] != -1){
									if (lastDrawIndexList[flight][k] != null) {
										if (lastDrawIndexList[flight][k].size() != 0) {
											rasterFrame = (WITFrame) witFrameList[flight][k]
													.get((Integer) lastDrawIndexList[flight][k]
															.get(lastDrawIndexList[flight][k]
																	.size() - 1));
										}
									}
								}

								if (rasterFrame != null) {

									// gl.glColor3f(1.0f, 0, 0);
									try {
										for (int i = 0; i < rasterFrame.witFrameTiles
												.size(); i++) {
											WITFrameTile wft = (WITFrameTile) rasterFrame.witFrameTiles
													.get(i);

											if (wft.tileStatusPerCoordinateSystem[coordinateMode] == WC.STATUS_COMPLETE) {

												if (tileBufferFills < maxTiles) {
													// copy to VBO if new frame

													int didFill = 0;

													// position
													if (posDataBufferTile
															.remaining() >= wft.bufferDataRaw[WC.BUFFER_POS].length) {
														posDataBufferTile
																.clear();
														posDataBufferTile
																.put(wft.bufferDataRaw[WC.BUFFER_POS]);
														didFill = 1;

														posDataBufferTile.rewind();
														
														gl.glBindBuffer(
																		GL.GL_ARRAY_BUFFER,
																		posBufferName[tileBufferFills]);
														gl.glBufferData(
																		GL.GL_ARRAY_BUFFER,
																		tileBufferSize,
																		null,
																		GL2.GL_DYNAMIC_DRAW);
														gl.glBufferSubData(
																		GL.GL_ARRAY_BUFFER,
																		0,
																		posSize,
																		posDataBufferTile);
													}

													// color
													if (colDataBufferTile
															.remaining() >= wft.bufferDataRaw[WC.BUFFER_COL].length) { // check
														
														colDataBufferTile
																.clear();
														colDataBufferTile
																.put(wft.bufferDataRaw[WC.BUFFER_COL]);
														colDataBufferTile
																.rewind();

														gl.glBindBuffer(
																		GL.GL_ARRAY_BUFFER,
																		colBufferName[tileBufferFills]);
														gl.glBufferData(
																		GL.GL_ARRAY_BUFFER,
																		tileBufferSize,
																		null,
																		GL2.GL_DYNAMIC_DRAW);
														gl.glBufferSubData(
																		GL.GL_ARRAY_BUFFER,
																		0,
																		colSize,
																		colDataBufferTile);

													}

													if (didFill == 1) {

														tileCollection[tileBufferFills] = AWTTextureIO
																.newTexture(
																		GLProfile
																				.getDefault(),
																		wft.texBI,
																		true);

														tileBufferFills++;
													}
												} else {
													discardedTiles++;
												}

											}

										}

									} catch (Exception e) {
										e.printStackTrace(); // resource was
										// freed
									}

								}
							}
						}
					}

				}

			}
		}
		gl.glBindTexture(GL.GL_TEXTURE_2D, 0);

	}

	public void copyItemsToVBO(GL2 gl) {

		// TRANSFER TO VBO

		tileBufferFills = 0;

		int discardedTiles = 0;
		int posSize = Buffers.SIZEOF_FLOAT * WC.VBO_VERTEX_COMPONENTS * 4;
		int colSize = Buffers.SIZEOF_FLOAT * WC.VBO_COLOR_COMPONENTS * 4;

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {

			if (flightLoadMask[flight] == 1) {

				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					if (scaLoadMask[flight][k] == 1) {
						if (witFrameList[flight][k] != null) {
							if (witFrameList[flight][k].size() > 0
									&& witSCAPlayhead[flight][k] >= 0
									&& witSCAPlayhead[flight][k] < witFrameList[flight][k]
											.size()) {

								WITFrame rasterFrame = null;
								if (scanDirAgreementDrawFlag[flight][k] == 1
										&& timeAgreementDrawFlag[flight][k] == 1
										&& scanSeqAgreementDrawFlag[flight][k] == 1) {

									rasterFrame = (WITFrame) witFrameList[flight][k]
											.get(witSCAPlayhead[flight][k]);

								} else { 

									if (lastDrawIndexList[flight][k] != null) {
										if (lastDrawIndexList[flight][k].size() != 0) {
											rasterFrame = (WITFrame) witFrameList[flight][k]
													.get((Integer) lastDrawIndexList[flight][k]
															.get(lastDrawIndexList[flight][k]
																	.size() - 1));
										}
									}
								}

								if (rasterFrame != null) {

									try {
										for (int i = 0; i < rasterFrame.witFrameTiles
												.size(); i++) {
											WITFrameTile wft = (WITFrameTile) rasterFrame.witFrameTiles
													.get(i);

											if (wft.tileStatusPerCoordinateSystem[coordinateMode] == WC.STATUS_COMPLETE) {

												if (tileBufferFills < maxTiles) {
													// copy to VBO if new frame

													int didFill = 0;
													if (posDataBuffer
															.remaining() >= wft.bufferDataRaw[WC.BUFFER_POS].length) {
														posDataBuffer
																.put(wft.bufferDataRaw[WC.BUFFER_POS]);
														didFill = 1;
													}

													if (colDataBuffer
															.remaining() >= wft.bufferDataRaw[WC.BUFFER_COL].length) { 

														colDataBuffer
																.put(wft.bufferDataRaw[WC.BUFFER_COL]);
													}
													if (didFill == 1) {
														tileBufferFills++;
													}
												} else {
													discardedTiles++;
												}

											}

										}

									} catch (Exception e) {
										e.printStackTrace(); // resource was
										// freed
									}

								}
							}
						}
					}

				}
			}
		}

		finalTileBufferSizeCol = tileBufferFills * colSize;
		finalTileBufferSizePos = tileBufferFills * posSize;

		posDataBuffer.rewind();
		colDataBuffer.rewind();

		gl.glBindBuffer(GL.GL_ARRAY_BUFFER, posBufferName[0]);
		gl.glBufferData(GL.GL_ARRAY_BUFFER, maxBufferSize, null,
				GL2.GL_DYNAMIC_DRAW);
		gl.glBufferSubData(GL.GL_ARRAY_BUFFER, 0, finalTileBufferSizePos,
				posDataBuffer);

		gl.glVertexPointer(WC.VBO_COLOR_COMPONENTS, GL2.GL_FLOAT,
				WC.VBO_COLOR_COMPONENTS * Buffers.SIZEOF_FLOAT, 0); // param 3
		// max size

	}

	public int getIndexFromTime(int secs, int flight, int scaID,
			int searchSecs, int scanDir) {
		int index = 0;
		int threshDelta = searchSecs;// 5;// searchSecs+5;//5;
		int minDelta = threshDelta;

		timeAgreementDrawFlag[flight][scaID] = -1;
		scanSeqAgreementDrawFlag[flight][scaID] = -1;
		int timeResult = 0;
		for (int i = 0; i < witFrameList[flight][scaID].size(); i++) {

			WITFrame w = (WITFrame) witFrameList[flight][scaID].get(i);
			int tDelta = Math.abs(w.timeStampSecOfDay - secs);
			if (tDelta < threshDelta) {

				if (tDelta < minDelta) {
					// scan dir
					if (scanDir == SCAN_SELECT_ALL
							&& (playbackScanSeqIndexMask[userFlight][w.scanSeqIndex] == WC.STATUS_ON || w.scanSeqIndex >= WC.SCAN_SEQ_INDEX_MAX_VAL)) {
						minDelta = tDelta;
						index = i;
						timeResult = w.timeStampSecOfDay;
						scanDirAgreementDrawFlag[flight][scaID] = 1;
						scanSeqAgreementDrawFlag[flight][scaID] = 1;
						playbackScanSeqIndexPrev[flight] = w.scanSeqIndex;
						timeAgreementDrawFlag[flight][scaID] = 1;
					} else if (scanDir == SCAN_SELECT_EVEN) {

						if (w.scanDirection == SCAN_SELECT_EVEN
								&& (playbackScanSeqIndexMask[userFlight][w.scanSeqIndex] == WC.STATUS_ON || w.scanSeqIndex >= WC.SCAN_SEQ_INDEX_MAX_VAL)) {
							minDelta = tDelta;
							index = i;
							timeResult = w.timeStampSecOfDay;
							scanDirAgreementDrawFlag[flight][scaID] = 1;
							scanSeqAgreementDrawFlag[flight][scaID] = 1;
							playbackScanSeqIndexPrev[flight] = w.scanSeqIndex;
							timeAgreementDrawFlag[flight][scaID] = 1;
						}
					} else if (scanDir == SCAN_SELECT_ODD) {
						if (w.scanDirection == SCAN_SELECT_ODD
								&& (playbackScanSeqIndexMask[userFlight][w.scanSeqIndex] == WC.STATUS_ON || w.scanSeqIndex >= WC.SCAN_SEQ_INDEX_MAX_VAL)) {
							minDelta = tDelta;
							index = i;
							timeResult = w.timeStampSecOfDay;
							scanDirAgreementDrawFlag[flight][scaID] = 1;
							scanSeqAgreementDrawFlag[flight][scaID] = 1;
							playbackScanSeqIndexPrev[flight] = w.scanSeqIndex;
							timeAgreementDrawFlag[flight][scaID] = 1;
						}
					}

				}
			}
		}

		return index;
	}

	public void witFrameListStep(int dir, float secs) {

		if (dir > 0) {
			witTimePlayheadFloat += secs;// skipSeconds;

		} else if (dir < 0) {
			witTimePlayheadFloat -= secs;// skipSeconds;
		}

		if (witTimePlayheadFloat > userSelection[WC.END][WC.T]) {
			witTimePlayheadFloat = userSelection[WC.START][WC.T];

			if (outputOptionMask[WC.OPTION_VIDEO_LOOP] == false) {
				if (exportBounceVideoState == WC.STATUS_ON) { // end bounce
					exportBounceVideoState = WC.STATUS_OFF;

					completeVideoExportFromGpu();
				}
			}
		}
		if (witTimePlayheadFloat < userSelection[WC.START][WC.T]) {
			witTimePlayheadFloat = userSelection[WC.END][WC.T];

			if (outputOptionMask[WC.OPTION_VIDEO_LOOP] == false) {
				if (exportBounceVideoState == WC.STATUS_ON) { // end bounce
					exportBounceVideoState = WC.STATUS_OFF;

					completeVideoExportFromGpu();
				}
			}
		}

		cvt.checkWitFrameLoop();

		witTimePlayhead = (int) Math.floor(witTimePlayheadFloat);

		witTimePlayheadTimestampStr = secondsOfDayToReadableF(witTimePlayheadFloat);
		witTimePlayheadTimestampOutputStr = witTimePlayheadTimestampStr + "Z";

		if (lockPlayhead == 1 && playbackPaused == 0
				&& dataState == WC.STATUS_COMPLETE && witTimePlayhead != 0) {
			userTimelineOffset[CURRENT] = -witTimePlayhead;
			userTimelineOffset[GOAL] = -witTimePlayhead;
		}

	}

	public void witFrameListJump(int destinationTime) {

		int prevPlayhead = witTimePlayhead;
		witTimePlayhead = destinationTime;

		if (witTimePlayhead > userSelection[WC.END][WC.T]) {
			witTimePlayhead = userSelection[WC.START][WC.T];
		}
		if (witTimePlayhead < userSelection[WC.START][WC.T]) {
			witTimePlayhead = userSelection[WC.END][WC.T];
		}

		cvt.checkWitFrameLoop();


	}


	public void playheadFromXPos(int xPos) {
		witTimePlayhead = xPos - (int) userTimelineOffset[CURRENT];

	}


	public void handleAutoUnpause() {
		if (autoUnpauseAfterLoad == 1 && needsToAutoResumeFlag == 1) { // playbackPaused
			// == 1
			// &&
			long autoStartDelay = System.currentTimeMillis()
					- loadEndTimerLastUpdate;

			if (autoStartDelay >= postLoadDelayAutoPlay
					|| (queuedThreadCount == 0 && activeThreadCount == 0 && autoStartDelay > autoUnpauseMinDelayMs)) {
				if (playbackPaused == 1) {

					doPlaybackPause();
				}
				needsToAutoResumeFlag = 0;
			}

		}
	}

	public void uiWIT() {


		int scaID = indexSca[userFlight];

		// gui animation stuff
		for (int i = 0; i < rasterLayerOpa.length; i++) {

			rasterLayerOpa[i][CURRENT] = rasterLayerOpa[i][GOAL];
			
		}

		handleAutoUnpause();

		// thread completion from external processes
		if (vet != null) {
			if (vet.status == WC.STATUS_COMPLETE) {
				userInterfaceInfoStr = "VIDEO ENCODING COMPLETE";
				vet.status = WC.STATUS_READY;
			} else {
			

			}
		}

		// view animation
		if (Math.abs(userPanOffset[GOAL][WC.X] - userPanOffset[CURRENT][WC.X]) > .01
				|| Math.abs(userPanOffset[GOAL][WC.Y]
						- userPanOffset[CURRENT][WC.Y]) > .01) {
			userPanOffset[CURRENT][WC.X] = vaRate * userPanOffset[GOAL][WC.X]
					+ (1.0f - vaRate) * userPanOffset[CURRENT][WC.X];

			userPanOffset[CURRENT][WC.Y] = vaRate * userPanOffset[GOAL][WC.Y]
					+ (1.0f - vaRate) * userPanOffset[CURRENT][WC.Y];

			miniMapInsetPos[CURRENT][WC.X] = (int) (userPanOffset[CURRENT][WC.X] * miniMapScale);
			miniMapInsetPos[CURRENT][WC.Y] = (int) (userPanOffset[CURRENT][WC.Y] * miniMapScale);

			// sync GPU rendering
			if (gpuState == 1) {

				// gpuReg.setViewPos(gpuRastPosX+(int)userXoffset[CURRENT],
				// gpuRastPosY);
			}

			// update the lat/lon overlay
			if (lensMagnifyActive == 1
					&& witFrameList[userFlight][scaID].size() > 0
					&& dynamicLoadStatus == WC.STATUS_COMPLETE) {
				// getMouseOverSCA(cursorX, cursorY);

			}
		}
		if (userTimelineOffset[GOAL] != userTimelineOffset[CURRENT]) {
			userTimelineOffset[CURRENT] = taRate * userTimelineOffset[GOAL]
					+ (1.0f - taRate) * userTimelineOffset[CURRENT];

			if (dynamicLoadStatus == WC.STATUS_COMPLETE) {
				if (witFrameList[userFlight][scaID] != null) {
					if (witFrameList[userFlight][scaID].size() > 0) {
						// tivoPlayheadXpos = witTimePlayhead + (int)
						// userTimelineOffset[CURRENT];
						// System.out.println("NEW POS "+tivoPlayheadXpos);
					}
				}
			}

		}

		if (user_view_rot[GOAL] != user_view_rot[CURRENT]) {
			user_view_rot[CURRENT] = viewFlipRate * user_view_rot[GOAL]
					+ (1.0f - viewFlipRate) * user_view_rot[CURRENT];
		}

		if (userTimelineZoom[GOAL] != userTimelineZoom[CURRENT]) {
			userTimelineZoom[CURRENT] = tzRate * userTimelineZoom[GOAL]
					+ (1.0f - tzRate) * userTimelineZoom[CURRENT];
		}

		if (histOpaBoostTimer > 0) {
			histOpaBoostTimer--;
		} else {
			for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					if (histOpaBoost[flight][k] > .01f) {
						histOpaBoost[flight][k] *= histOpaBoostFadeRate;
					} else if (histOpaBoost[flight][k] > 0f) {
						histOpaBoost[flight][k] = 0f;
					}
				}
			}
		}

		if (userEventFlash > WC.STATUS_OFF) {
			if (userEventFlash > 10) {
				userEventFlash -= 5;
			} else {
				userEventFlash--;
			}

		}

		// knobs
		if (knobPulseSkip[GOAL] != knobPulseSkip[CURRENT]) {
			knobPulseSkip[CURRENT] = knobPulseFadeRate * knobPulseSkip[GOAL]
					+ (1.0f - knobPulseFadeRate) * knobPulseSkip[CURRENT];
		}
		if (knobPulseLoad[GOAL] != knobPulseLoad[CURRENT]) {
			knobPulseLoad[CURRENT] = knobPulseFadeRate * knobPulseLoad[GOAL]
					+ (1.0f - knobPulseFadeRate) * knobPulseLoad[CURRENT];
		}
		if (knobPulseBurst[GOAL] != knobPulseBurst[CURRENT]) {
			knobPulseBurst[CURRENT] = knobPulseFadeRate * knobPulseBurst[GOAL]
					+ (1.0f - knobPulseFadeRate) * knobPulseBurst[CURRENT];
		}
		if (knobPulseReloadTimer[GOAL] != knobPulseReloadTimer[CURRENT]) {
			knobPulseReloadTimer[CURRENT] = knobPulseFadeRate
					* knobPulseReloadTimer[GOAL] + (1.0f - knobPulseFadeRate)
					* knobPulseReloadTimer[CURRENT];
		}
		if (knobPulseReloadBuffer[GOAL] != knobPulseReloadBuffer[CURRENT]) {
			knobPulseReloadBuffer[CURRENT] = knobPulseFadeRate
					* knobPulseReloadBuffer[GOAL] + (1.0f - knobPulseFadeRate)
					* knobPulseReloadBuffer[CURRENT];
		}

		if (knobRotSkip[GOAL] != knobRotSkip[CURRENT]) {
			knobRotSkip[CURRENT] = knobRotRate * knobRotSkip[GOAL]
					+ (1.0f - knobRotRate) * knobRotSkip[CURRENT];
		}
		if (knobRotLoad[GOAL] != knobRotLoad[CURRENT]) {
			knobRotLoad[CURRENT] = knobRotRate * knobRotLoad[GOAL]
					+ (1.0f - knobRotRate) * knobRotLoad[CURRENT];
		}
		if (knobRotBurst[GOAL] != knobRotBurst[CURRENT]) {
			knobRotBurst[CURRENT] = knobRotRate * knobRotBurst[GOAL]
					+ (1.0f - knobRotRate) * knobRotBurst[CURRENT];
		}
		if (knobRotReloadTimer[GOAL] != knobRotReloadTimer[CURRENT]) {
			knobRotReloadTimer[CURRENT] = knobRotRate * knobRotReloadTimer[GOAL]
					+ (1.0f - knobRotRate) * knobRotReloadTimer[CURRENT];
		}
		if (knobRotReloadBuffer[GOAL] != knobRotReloadBuffer[CURRENT]) {
			knobRotReloadBuffer[CURRENT] = knobRotRate * knobRotReloadBuffer[GOAL]
					+ (1.0f - knobRotRate) * knobRotReloadBuffer[CURRENT];
		}

		// end knobs
		// }

		tivoSpeedOverlayAlpha = alphaFadeRate * tivoSpeedOverlayAlpha;
		regionHintAlpha = alphaFadeRate * regionHintAlpha;

		// if (selectionContrastStatus == SELECTION_READY) {

		// contrastOverlayAlpha = alphaFadeRate * contrastOverlayAlpha;
		// }
	}

	public BufferedImage cutoutBoundaries(float latMin, float latMax,
			float lonMin, float lonMax, float scale) {

		int biW = (int) ((lonMax - lonMin) * scale);
		int biH = (int) ((latMax - latMin) * scale);

		BufferedImage cutoutRegion = new BufferedImage(biW, biH,
				BufferedImage.TYPE_INT_ARGB);

		return cutoutRegion;
	}

	private BufferedImage loadImageBI(String name) {
		// System.out.println("LOAD FILE " + name);
		Image imageRay = Toolkit.getDefaultToolkit().getImage(name);
		MediaTracker mediaTracker = new MediaTracker(new Container());
		mediaTracker.addImage(imageRay, 0);
		try {
			mediaTracker.waitForID(0);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		int width = imageRay.getWidth(null);
		int height = imageRay.getHeight(null);
		System.out.println(width + " X " + height);

		BufferedImage b = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = (Graphics2D) b.getGraphics();
		g.drawImage(imageRay, 0, 0, null);

		return b;
	}

	public void determineNorthArrowsMouse(float coord1[], float coord2[]) {

		float degToRadScale = (float) (Math.PI / 180f);
		float lat1rad = coord1[GEODATA_LAT] * degToRadScale;
		float lat2rad = coord2[GEODATA_LAT] * degToRadScale;

		float lon1rad = coord1[GEODATA_LON] * degToRadScale;
		float lon2rad = coord2[GEODATA_LON] * degToRadScale;

		float deltaLonRad = lon2rad - lon1rad;

		float deltaLat = coord1[GEODATA_LAT] - coord2[GEODATA_LAT];
		float deltaLon = coord1[GEODATA_LON] - coord2[GEODATA_LON];

		float compY = (float) (Math.sin(deltaLonRad) * Math.cos(lat2rad));
		float compX = (float) (Math.cos(lat1rad) * Math.sin(lat2rad) - Math
				.sin(lat1rad)
				* Math.cos(lat2rad) * Math.cos(deltaLonRad));

		if (deltaLat != 0 && deltaLon != 0 && deltaLat < 180 && deltaLon < 360
				&& coord1[GEODATA_LAT] > -999 && coord2[GEODATA_LAT] > -999
				&& coord1[GEODATA_LON] > -999 && coord2[GEODATA_LON] > -999) {

			float m = (float) Math.atan2(compY, compX);

			compassAngle = m;

			int rastX = 0;
			int rastY = 0;

			float b = (float) rastY - (m * (float) rastX);

			int rastY2 = rastY + 100;
			int rastX2 = (int) (((float) rastY2 - b) / m);

			float vecLength = 64f;

			float dist = rastY2 * rastY2 + rastX2 * rastX2;

			rastY2 = (int) (rastY2 * (vecLength / dist) * 20);
			rastX2 = (int) (rastX2 * (vecLength / dist) * 20);
			// convert to unit vector

			northArrowRasters[WC.START][WC.X] = rastX;
			northArrowRasters[WC.START][WC.Y] = rastY;

			northArrowRasters[WC.END][WC.X] = rastX2;
			northArrowRasters[WC.END][WC.Y] = rastY2;

			compassIsValid = 1;
		} else {
			compassIsValid = 0;
		}
	}

	public void checkTimelineRefresh() {
		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {

			if (flightLoadMask[flight] == 1) {
				loaderInfoFramesPrev = loaderInfoFrames;

				loaderInfoFrames = 0;
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					if (witFrameList[flight][k] != null) {
						for (int i = 0; i < witFrameList[flight][k].size(); i++) {
							WITFrame w = (WITFrame) witFrameList[flight][k]
									.get(i);

							if (w.layerStatus[WC.THREAD_PREFILTER] == WC.THREAD_STATUS_COMPLETE) {
								// w.layerStatus[WC.THREAD_PREFILTER] =
								// WC.THREAD_STATUS_COMPLETE
								if (w.bookmarkList.size() > 0) {
									dataLoadInfo[flight][k][w.timeStampSecOfDay] = WC.INFO_EVENT;
									loaderInfoFrames++;
								}
							}
						}
					}
				}

				int diffProgFrames = Math.abs(loaderInfoFramesPrev
						- loaderInfoFrames);
				// System.out.println(diffProgFrames+ " NEW FRAMES - info");
				if (diffProgFrames > 0
						&& timelineImageUpdateFlag == WC.TIMELINE_UPDATE_NONE) {

					timelineImageUpdateFlag = WC.TIMELINE_UPDATE_PROGRESS;
					
				}
			}
		}

		syncAndForceTimelineRefresh();
	}

	public void doRealtimeBounce() {

	}

	private void doSystemLoop(GL2 gl) {
		// System.out.println("SYSTEM LOOP");
		if (autoReloadState == 1) {
			autoReloadTime1 = System.currentTimeMillis();
			if (autoReloadTime1 - autoReloadTime2 > autoReloadTimerSeconds * 1000) {
				// if (autoReloadTime1 - autoReloadTime2 >
				// autoReloadSeconds*1000) {
				autoReloadTime2 = autoReloadTime1;

				if (mouseState != WC.UI_STATE_KNOB_RELOAD_TIMER && mouseState != WC.UI_STATE_KNOB_RELOAD_BUFFER){
					//reloadNewData(gl);
					reloadNewData(1,1);
				}
			}
		}

		dwtEditorTime1 = System.currentTimeMillis();
		if (dwtEditorTime1 - dwtEditorTime2 > dwtEditorTimeDeltaPlaybackMS) {
			dwtEditorTime2 = dwtEditorTime1;

			if (kernelEditorUI != null){
				kernelEditorUI.paintCanvas();
			}

		}

		guiTime1 = System.currentTimeMillis();
		if (guiTime1 - guiTime2 > guiTimeDeltaPlaybackMS) {
			guiTime2 = guiTime1;

			uiWIT();

		}

		bookmarkRefreshInfoTime1 = System.currentTimeMillis();
		if (bookmarkRefreshInfoTime1 - bookmarkRefreshInfoTime2 > bookmarkRefreshInfoTimeDelta) {
			bookmarkRefreshInfoTime2 = bookmarkRefreshInfoTime1;

			copyBookmarksFromWF();

		}

		timelineRefreshInfoTime1 = System.currentTimeMillis();
		if (timelineRefreshInfoTime1 - timelineRefreshInfoTime2 > timelineRefreshInfoTimeDelta) {
			timelineRefreshInfoTime2 = timelineRefreshInfoTime1;

			checkTimelineRefresh();

		}
		
		timelineCheckNewFilesTime1 = System.currentTimeMillis();
		if (timelineCheckNewFilesTime1-timelineCheckNewFilesTime2 > timelineCheckNewFilesTimeDelta){
			timelineCheckNewFilesTime2 = timelineCheckNewFilesTime1;
			if (timelineCheckEnabled == WC.STATUS_ON){
				updateLatestFiles();
			}
		}

		timelineRefreshStatusTime1 = System.currentTimeMillis();
		if (timelineRefreshStatusTime1 - timelineRefreshStatusTime2 > timelineRefreshStatusTimeDelta) {
			timelineRefreshStatusTime2 = timelineRefreshStatusTime1;

			for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
				loaderProgressFramesPrev[flight] = loaderProgressFrames[flight];
				loaderProgressFrames[flight] = 0;

				if (flightLoadMask[flight] == 1) {

					// tally loaded frames
					for (int k = 0; k < WC.TOTAL_SCAS; k++) {
						if (witFrameList[flight][k] != null) {
							loaderProgressFrames[flight] += witFrameList[flight][k]
									.size();
						}
					}
					int diffProgFrames = Math
							.abs(loaderProgressFramesPrev[flight]
									- loaderProgressFrames[flight]);
					// System.out.println(diffProgFrames+ " NEW FRAMES - prog");
					if (diffProgFrames > 0
							&& timelineImageUpdateFlag == WC.TIMELINE_UPDATE_NONE) {
						timelineImageUpdateFlag = WC.TIMELINE_UPDATE_PROGRESS;
					}
				}
			}
			syncAndForceTimelineRefresh();
		}

		playheadTime1 = System.currentTimeMillis();
		if (playheadTime1 - playheadTime2 > playheadTimeDelta) {
			playheadTime2 = playheadTime1;

			if (systemState == WC.SYSTEM_STATE_ONLINE
					&& dynamicLoadStatus != WC.STATUS_WORKING) {
				// && dynamicLoadStatus != WC.STATUS_WORKING && cvt != null) {

				if (playheadDir != 0) {
					animatePlayback(gl);
				}
				
			}
		}

		if (systemState == WC.SYSTEM_STATE_ONLINE) {
			processTime1 = System.currentTimeMillis();

			if (processTime1 - processTime2 > processTimeMS) {
				processTime2 = processTime1;

				if (dynamicLoadTaskCreatorStatus == WC.STATUS_READY) {
					createLoaderTasks();
				}

				createOclTasks();
				
				processWIT();
			}
		}

		if (systemState == WC.SYSTEM_STATE_ONLINE) {

		}

		time1 = System.currentTimeMillis();

		if (time1 - time2 > timeDeltaPlaybackMS && drawCyclePaused == 0) {
			time2 = time1;

			if ((uiState == WC.UI_STATE_VIEW && graphicsStatus == WC.STATUS_READY)
					|| uiState == WC.UI_STATE_CONTRAST) {

				if (externalGLSLNeedsCompile == WC.STATUS_READY) {
					externalGLSLNeedsCompile = WC.STATUS_ERROR;
					compileGLSLjogamp(gl, fragSourceAggregate,
							"FRAG_PROGRAM_AGGREGATE");
				}

				render3D(gl);
			} else if (uiState == WC.UI_STATE_SCA_SELECT
					&& graphicsStatus == WC.STATUS_READY) {
				
			}

			drawFinalScreen();

		}

	}

	public String formatIDtoName(int id) {
		String idStr = "[UNKNOWN FORMAT]";

		int FORMAT_MPG = 0;
		int FORMAT_MP4 = 1;
		int FORMAT_MP4_H264 = 2;
		int FORMAT_WMV = 3;
		int FORMAT_PNG = 10;
		int FORMAT_JPG = 11;
		int FORMAT_GEOTIFF = 12;
		if (id == FORMAT_PNG) {
			idStr = "FORMAT_PNG";
		} else if (id == FORMAT_JPG) {
			idStr = "FORMAT_JPG";
		} else if (id == FORMAT_MPG) {
			idStr = "FORMAT_MPG";
		} else if (id == FORMAT_MP4) {
			idStr = "FORMAT_MP4";
		} else if (id == FORMAT_MP4_H264) {
			idStr = "FORMAT_MP4_H264";
		} else if (id == FORMAT_WMV) {
			idStr = "FORMAT_WMV";
		} else if (id == FORMAT_GEOTIFF) {
			idStr = "FORMAT_GEOTIFF";
		}

		return idStr;
	}

	public String opIdToName(int op) {
		String opStr = "[UNKNOWN OP]";

		if (op == WC.THREAD_LOAD) {
			opStr = "LOAD DATA";
		} else if (op == WC.THREAD_LOAD_HDF5R) {

			opStr = "LOAD DATA";
		} else if (op == WC.THREAD_LOAD_GEOLOCATION) {

			opStr = "LOAD GEOLOCATION";
		} else if (op == WC.THREAD_FIX_GEOLOCATION) {

			opStr = "INTERPOLATE GEOLOC";
		} else if (op == WC.THREAD_HISTOGRAM) {

			opStr = "HISTOGRAM";
		} else if (op == WC.THREAD_CONTRAST) {

			if (contrastMode == CONTRAST_AUTO) {
				opStr = "CONTRAST - AUTO";
			} else if (contrastMode == CONTRAST_WINDOW) {
				opStr = "CONTRAST - AUTO (REGION)";
			} else if (contrastMode == CONTRAST_USER) {
				opStr = "CONTRAST - USER SELECT";
			}

			// opStr = "CONTRAST - MANUAL";
		} else if (op == WC.THREAD_DIFF) {

			opStr = "DIFFS";
		} else if (op == WC.THREAD_TIMELAPSE) {

			opStr = "TEMPORAL BLUR";
		} else if (op == WC.THREAD_TEMPORAL) {

			opStr = "TEMPORAL1";
		} else if (op == WC.THREAD_EXPORT_VIDEO) {

			// opStr = "EXPORT VIDEO";
			opStr = "EXPORT";
		} else if (op == WC.THREAD_EXPORT_WEATHER_VIDEO) {

			// opStr = "EXPORT VIDEO";
			opStr = "EXPORT";
		} else if (op == WC.THREAD_EXPORT_IMAGES) {

			// opStr = "EXPORT IMAGES";
			opStr = "EXPORT";
		} else if (op == WC.THREAD_LOAD_METADATA) {

			opStr = "LOAD METADATA";
		} else if (op == WC.THREAD_DEJITTER_ADV) {

			opStr = "DEJITTER";
		} else if (op == WC.THREAD_PREFILTER) {

			opStr = "PREFILTER";
		} else if (op == WC.THREAD_REGISTRATION) {

			opStr = "REGISTER SUBWINDOW";
		} else if (op == WC.THREAD_SCAN_DIR_Y_OFFSET) {

			opStr = "SCAN Y OFFSET";
		} else if (op == WC.THREAD_GPU_FRAG_PIPELINE) {

			opStr = "THREAD_GPU_FRAG_PIPELINE";
		} else if (op == WC.THREAD_GPU_FRAG_DIFF) {

			opStr = "GPU DIFF";
		} else if (op == WC.THREAD_GPU_FRAG_DWT) {

			opStr = "GPU DWT";
		} else if (op == WC.THREAD_GPU_FRAG_CONTRAST) {

			opStr = "GPU CONTRAST";
		} else if (op == WC.THREAD_GPU_FRAG_TIMELAPSE) {

			opStr = "GPU TIMELAPSE";
		} else if (op == WC.THREAD_GPU_OPENCL_TEST) {

			opStr = "GPU OPENCL TEST";
		}

		return opStr;
	}

	public int checkNeedForThread(ArrayList wfl, int a, int b, int mode) {
		int need = -1;
		int scaID = -1;
		int scidID = -1;
		for (int i = a; i < b; i++) {
			if (wfl.size() > i) {
				WITFrame wfi = (WITFrame) wfl.get(i);

				if (wfi.timeStampSecOfDay > userSelection[WC.START][WC.T]
						&& wfi.timeStampSecOfDay < userSelection[WC.END][WC.T]) {
					scaID = wfi.scaID;
					scidID = wfi.satID;
					if (wfi.layerStatus[mode] == WC.STATUS_READY) {
						need = 1;
						i = b; // break
					} else if (mode == WC.THREAD_HISTOGRAM) {
						// System.out.println("STATE HIST LAYER "+wfi.layerStatus[mode]);
					}
				}
			}
		}

		if (need != -1) {

			StringBuilder strBdr = new StringBuilder();
			strBdr.append("THREAD REQUESTED FOR SCA ");
			strBdr.append(scaID);
			strBdr.append(" FLIGHT ");
			strBdr.append(scidID);
			strBdr.append(" - FRAMES: ");
			strBdr.append(a);
			strBdr.append("-");
			strBdr.append(b);
			strBdr.append(" - TIME: ");
			strBdr
					.append(secondsOfDayToReadable(userSelection[WC.START][WC.T]));
			strBdr.append("-");
			strBdr.append(secondsOfDayToReadable(userSelection[WC.END][WC.T]));
			strBdr.append(" - MODE: ");
			strBdr.append(opIdToName(mode));
			System.out.println(strBdr);

		} else {
			// System.out.println("THREAD REQUEST DECLINED");
		}
		return need;
	}

	public static Composite makeComposite(float a) {
		Composite c = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, a);

		return c;

	}

	public void resetThreads() {
		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int i = 0; i < MAX_THREADS_QUEUED; i++) {
				// imprRay[i].interrupt();
				try {
					imprRay[i] = null;
				} catch (Exception e) {
					e.printStackTrace();
				}

				imprRay[i] = new ImProcThread("WC.THREAD_IDLE", WC.THREAD_IDLE,
						witFrameList[flight][0], 0, 0, null);
				imprRay[i].threadStatus = WC.THREAD_STATUS_READY;

				// threadAllocations[i] = 0;
			}
		}
	}

	public void restartSystem() {
		systemState = WC.SYSTEM_STATE_OFFLINE;

		resetThreads();

		systemState = WC.SYSTEM_STATE_ONLINE;

	}

	public void pauseSystem() {

		if (pauseFlag == PAUSED) {
			pauseFlag = UNPAUSED;
			systemPlaybackRate = systemPlaybackRatePause;
			// systemPlaybackRate = SYSTEM_PLAYBACK_RATE_PAUSE;
		} else if (pauseFlag == UNPAUSED) {
			pauseFlag = PAUSED;
			systemPlaybackRatePause = systemPlaybackRate;
			systemPlaybackRate = SYSTEM_PLAYBACK_RATE_PAUSE;
		}

		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
	}

	public void clearContrastSelection() {

	}

	public void checkContrastSelection() {

		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
	}

	public void swapThreadSchemes() {
		if (systemState == WC.THREAD_SCHEME_BATCH) {
			systemState = WC.THREAD_SCHEME_PLAYHEAD;

			System.out.println("WC.THREAD_SCHEME_PLAYHEAD");
		} else {
			systemState = WC.THREAD_SCHEME_BATCH;

			System.out.println("WC.THREAD_SCHEME_BATCH");
		}
	}

	public void checkWitFrameLoop() {

		// int scaID=0;

		int scaID = indexSca[userFlight];

		if (witTimePlayheadFloat < loopStart) {
			witTimePlayheadFloat = loopEnd;

			if (exportBounceVideoState == WC.STATUS_ON) { // end bounce
				exportBounceVideoState = WC.STATUS_OFF;
			}
		}
		if (witTimePlayheadFloat > loopEnd) {
			witTimePlayheadFloat = loopStart;

			if (exportBounceVideoState == WC.STATUS_ON) { // end bounce
				exportBounceVideoState = WC.STATUS_OFF;
			}
		}
	}

	public void tivoStepPlaybackSeconds(int speedChange) {
		float prevSpeed = playbackStepSeconds;
		if (speedChange == 1) {
			playbackStepSeconds *= 2;
		} else if (speedChange == -1) {
			playbackStepSeconds /= 2;
		}

		if (playbackStepSeconds < WC.SKIP_SECONDS_PLAYBACK_MIN) {
			playbackStepSeconds = WC.SKIP_SECONDS_PLAYBACK_MIN;
		}
		if (playbackStepSeconds > WC.SKIP_SECONDS_PLAYBACK_MAX) {
			playbackStepSeconds = WC.SKIP_SECONDS_PLAYBACK_MAX;
		}

		if (playbackStepSeconds > loadSeconds / 2) {
			playbackStepSeconds = prevSpeed;
		}

		userInterfaceInfoStr = "PLAYBACK INTERVAL " + playbackStepSeconds
				+ " SECONDS";
	}

	public void tivoStepPlaybackSpeed(int speedChange) {
		if (speedChange == 1) {

			if (SYSTEM_PLAYBACK_RATE_R16X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 8;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 8X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R8X;
			} else if (SYSTEM_PLAYBACK_RATE_R8X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 4;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 4X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R4X;
			} else if (SYSTEM_PLAYBACK_RATE_R4X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 2;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 2X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R2X;
			} else if (SYSTEM_PLAYBACK_RATE_R2X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 1X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R1X;
			} else if (SYSTEM_PLAYBACK_RATE_R1X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed;
				playheadDir = 0;
				userInterfaceInfoStr = "PAUSED";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_PAUSE;
			} else if (SYSTEM_PLAYBACK_RATE_PAUSE == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 1X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F1X;
			} else if (SYSTEM_PLAYBACK_RATE_F1X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 2;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 2X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F2X;
			} else if (SYSTEM_PLAYBACK_RATE_F2X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 4;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 4X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F4X;
			} else if (SYSTEM_PLAYBACK_RATE_F4X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 8;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 8X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F8X;
			} else if (SYSTEM_PLAYBACK_RATE_F8X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 16;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 16X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F16X;
			} else if (SYSTEM_PLAYBACK_RATE_F16X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 16;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 16X (MAX)";
			}
		} else if (speedChange == -1) {
			if (SYSTEM_PLAYBACK_RATE_R16X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 16;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 16X (MAX)";
			} else if (SYSTEM_PLAYBACK_RATE_R8X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 16;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 16X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R16X;
			} else if (SYSTEM_PLAYBACK_RATE_R4X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 8;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 8X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R8X;
			} else if (SYSTEM_PLAYBACK_RATE_R2X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 4;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 4X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R4X;
			} else if (SYSTEM_PLAYBACK_RATE_R1X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 2;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 2X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R2X;
			} else if (SYSTEM_PLAYBACK_RATE_PAUSE == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 1X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R1X;
			} else if (SYSTEM_PLAYBACK_RATE_F1X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed;
				playheadDir = 0;
				userInterfaceInfoStr = "PAUSED";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_PAUSE;
			} else if (SYSTEM_PLAYBACK_RATE_F2X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 1X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F1X;
			} else if (SYSTEM_PLAYBACK_RATE_F4X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 2;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 2X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F2X;
			} else if (SYSTEM_PLAYBACK_RATE_F8X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 4;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 4X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F4X;
			} else if (SYSTEM_PLAYBACK_RATE_F16X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 8;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 8X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F8X;
			}

		}

		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;

	
	}

	public void showKeyboardHelp() {

	}

	public void showFilterPriorities() {

	}

	public void showWebHelp() {

		String commandStr = webHelpLocation;

		Runtime rt = Runtime.getRuntime();
		Process p = null;

		try {
			p = rt.exec(commandStr);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void selectOnlyDominantSosId(){
	
		int mainSosId = 0;
		
		int skipFrames = 10; // every nth frame
		
		int sosCounter[] = new int[WC.SCAN_SEQ_INDEX_MAX_VAL];
		
		try {
		for (int w=0; w<WC.TOTAL_SCAS; w++){
			if (witFrameList[userFlight][w] != null){
				for (int i=0; i<witFrameList[userFlight][w].size(); i+=skipFrames){
					WITFrame wf = (WITFrame) witFrameList[userFlight][w].get(i);
					sosCounter[wf.scanSeqIndex]++;
				}
			}
		}
		
		int maxCount = 0;
		for (int i=0; i<WC.SCAN_SEQ_INDEX_MAX_VAL; i++){
			if (sosCounter[i] > maxCount){
				maxCount = sosCounter[i];
				mainSosId = i;
			}
		}
		
		for (int i=0; i<WC.SCAN_SEQ_INDEX_MAX_VAL; i++){
			if (i == mainSosId){
				playbackScanSeqIndexMask[userFlight][i] = 1;
			} else {
				playbackScanSeqIndexMask[userFlight][i] = 0;
			}
		}
		
		userInterfaceInfoStr = "TOGGLE TO SOS INDEX "+mainSosId;
		
		} catch (Exception e){
			e.printStackTrace();
			
			
		}
		
	}

	public void keyPressed(KeyEvent e) {

		float globeNudgeAmount = .01f;

		if (e.getKeyCode() == KeyEvent.VK_F1) {
			setLoadFrames(10, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F2) {
			setLoadFrames(60, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F3) {
			setLoadFrames(120, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F4) {
			setLoadFrames(180, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F5) {
			setLoadFrames(300, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F6) {
			setLoadFrames(600, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F7) {
			setLoadFrames(900, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F8) {
			setLoadFrames(1200, 30, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F9) {
			setLoadFrames(1800, 30, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F10) {
			setLoadFrames(3600, 120, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F11) {
			setLoadFrames(7200, 120, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F12) {
			setLoadFrames(14400, 300, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_D) {
			if (coordinateMode == WC.COORDINATES_GLOBE) {
				if (e.isShiftDown()) {
					los_error_rot[userFlight][WC.Y] += globeNudgeAmount;
				} else {
					view_rot[WC.COORDINATES_GLOBE][WC.Y] += globeNudgeAmount;
				}
			} else if (coordinateMode == WC.COORDINATES_SENSOR) {

				if (e.isControlDown() && e.isShiftDown()) {
					user_view_rot[GOAL] = -90f;
				} else if (e.isControlDown()) {
					user_view_rot[GOAL] -= user_view_rot_inc;
				} else if (e.isShiftDown()) {
					view_trans[coordinateMode][WC.X] += viewTransIncSensorPerspective
							* viewTransIncMultiplier;
				} else {
					view_trans[coordinateMode][WC.X] += viewTransIncSensorPerspective;
				}

			}
		} else if (e.getKeyCode() == KeyEvent.VK_A) {
			if (coordinateMode == WC.COORDINATES_GLOBE) {

				if (e.isShiftDown()) {
					los_error_rot[userFlight][WC.Y] -= globeNudgeAmount;
				} else {
					view_rot[WC.COORDINATES_GLOBE][WC.Y] -= globeNudgeAmount;
				}
			} else if (coordinateMode == WC.COORDINATES_SENSOR) {
				if (e.isControlDown() && e.isShiftDown()) {
					user_view_rot[GOAL] = 90;
				} else if (e.isControlDown()) {
					user_view_rot[GOAL] += user_view_rot_inc;
				} else if (e.isShiftDown()) {
					view_trans[coordinateMode][WC.X] -= viewTransIncSensorPerspective
							* viewTransIncMultiplier;
				} else {
					view_trans[coordinateMode][WC.X] -= viewTransIncSensorPerspective;
				}

			}
		} else if (e.getKeyCode() == KeyEvent.VK_W) {
			if (coordinateMode == WC.COORDINATES_GLOBE) {
				if (e.isShiftDown()) {
					los_error_rot[userFlight][WC.X] += globeNudgeAmount;
				} else {
					view_rot[WC.COORDINATES_GLOBE][WC.X] += globeNudgeAmount;
				}
			} else if (coordinateMode == WC.COORDINATES_SENSOR) {
				if (e.isControlDown() && e.isShiftDown()) {
					user_view_rot[GOAL] = 0f;
				} else if (e.isShiftDown()) {
					view_trans[coordinateMode][WC.Y] += viewTransIncSensorPerspective
							* viewTransIncMultiplier;
				} else {
					view_trans[coordinateMode][WC.Y] += viewTransIncSensorPerspective;
				}

			}

		} else if (e.getKeyCode() == KeyEvent.VK_S) {

			if (coordinateMode == WC.COORDINATES_GLOBE) {
				if (e.isShiftDown()) {
					los_error_rot[userFlight][WC.X] -= globeNudgeAmount;
				} else {
					view_rot[WC.COORDINATES_GLOBE][WC.X] -= globeNudgeAmount;
				}
			} else if (coordinateMode == WC.COORDINATES_SENSOR) {
				if (e.isControlDown() && e.isShiftDown()) {
					user_view_rot[GOAL] = 180f;
				} else if (e.isShiftDown()) {
					view_trans[coordinateMode][WC.Y] -= viewTransIncSensorPerspective
							* viewTransIncMultiplier;
				} else {
					view_trans[coordinateMode][WC.Y] -= viewTransIncSensorPerspective;
				}

			}
		} else if (e.getKeyCode() == KeyEvent.VK_Q) {
			if (coordinateMode == WC.COORDINATES_GLOBE) {

				if (e.isShiftDown()) {
					los_error_rot[userFlight][WC.Z] += globeNudgeAmount;
				} else {
					view_rot[WC.COORDINATES_GLOBE][WC.Z] += globeNudgeAmount;
				}
			}
		} else if (e.getKeyCode() == KeyEvent.VK_E) {
			if (coordinateMode == WC.COORDINATES_GLOBE) {

				if (e.isShiftDown()) {
					los_error_rot[userFlight][WC.Z] -= globeNudgeAmount;
				} else {
					view_rot[WC.COORDINATES_GLOBE][WC.Z] -= globeNudgeAmount;
				}
			}
		} else if (e.getKeyCode() == KeyEvent.VK_SPACE) {

			if (e.isShiftDown()) {
				autoUnpauseAfterLoad = (autoUnpauseAfterLoad + 1) % 2;
				userInterfaceInfoStr = "TOGGLE AUTO-UNPAUSE AFTER LOAD ";
				if (autoUnpauseAfterLoad == 1) {
					userInterfaceInfoStr += "- ON";
				} else {
					userInterfaceInfoStr += "- OFF";
				}
			} else {

				doPlaybackPause();
			}

		} else if (e.getKeyCode() == KeyEvent.VK_PLUS) {

			
		} else if (e.getKeyCode() == KeyEvent.VK_MINUS) {
			
		} else if (e.getKeyCode() == KeyEvent.VK_G) {
			if (e.isShiftDown()){
				flagOclComputing();
			} else {
				changeCoordinateMode();
			}
			
		} else if (e.getKeyCode() == KeyEvent.VK_1) {
			if (e.isShiftDown() == true) {
				
				int activeScaCount = 0;
				int activeFlight = 0;
				for (int j = 0; j < WC.TOTAL_SCAS; j++) {
					if (scaLoadMask[activeFlight][j] == 1) {
						activeScaCount++;
					}
				}

				if (activeScaCount >= 3) {
					for (int j = 0; j < WC.TOTAL_SCAS; j++) {
						scaLoadMask[activeFlight][j] = 0;
					}
				} else {
					for (int j = 0; j < WC.TOTAL_SCAS; j++) {
						scaLoadMask[activeFlight][j] = 1;
					}
				}
			} else {

				int scaID = 0;
				scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;

				if (scaLoadMask[userFlight][scaID] == 1) {
					histOpaBoostTimer = histOpaBoostTimerInit;
					histOpaBoost[userFlight][scaID] = histOpaBoostAmount;
				}
			}
		} else if (e.getKeyCode() == KeyEvent.VK_2) {
			if (e.isShiftDown() == true) {
				int activeScaCount = 0;
				int activeFlight = 1;
				for (int j = 0; j < WC.TOTAL_SCAS; j++) {
					if (scaLoadMask[activeFlight][j] == 1) {
						activeScaCount++;
					}
				}

				if (activeScaCount >= 3) {
					for (int j = 0; j < WC.TOTAL_SCAS; j++) {
						scaLoadMask[activeFlight][j] = 0;
					}
				} else {
					for (int j = 0; j < WC.TOTAL_SCAS; j++) {
						scaLoadMask[activeFlight][j] = 1;
					}
				}
			} else {

				int scaID = 1;
				scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;

				if (scaLoadMask[userFlight][scaID] == 1) {
					histOpaBoostTimer = histOpaBoostTimerInit;
					histOpaBoost[userFlight][scaID] = histOpaBoostAmount;
				}
			}
		} else if (e.getKeyCode() == KeyEvent.VK_3) {
			int scaID = 2;
			scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;

			if (scaLoadMask[userFlight][scaID] == 1) {
				histOpaBoostTimer = histOpaBoostTimerInit;
				histOpaBoost[userFlight][scaID] = histOpaBoostAmount;
			}
		} else if (e.getKeyCode() == KeyEvent.VK_4) {
			int scaID = 3;
			scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;

			if (scaLoadMask[userFlight][scaID] == 1) {
				histOpaBoostTimer = histOpaBoostTimerInit;
				histOpaBoost[userFlight][scaID] = histOpaBoostAmount;
			}
		} else if (e.getKeyCode() == KeyEvent.VK_5) {
			int scaID = 4;
			scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;

			if (scaLoadMask[userFlight][scaID] == 1) {
				histOpaBoostTimer = histOpaBoostTimerInit;
				histOpaBoost[userFlight][scaID] = histOpaBoostAmount;
			}
		} else if (e.getKeyCode() == KeyEvent.VK_6) {
			int scaID = 5;
			scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;

			if (scaLoadMask[userFlight][scaID] == 1) {
				histOpaBoostTimer = histOpaBoostTimerInit;
				histOpaBoost[userFlight][scaID] = histOpaBoostAmount;
			}
		} else if (e.getKeyCode() == KeyEvent.VK_7) {
			int scaID = 6;
			scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;

			if (scaLoadMask[userFlight][scaID] == 1) {
				histOpaBoostTimer = histOpaBoostTimerInit;
				histOpaBoost[userFlight][scaID] = histOpaBoostAmount;
			}
		} else if (e.getKeyCode() == KeyEvent.VK_8) {
			int scaID = 7;
			scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;

			if (scaLoadMask[userFlight][scaID] == 1) {
				histOpaBoostTimer = histOpaBoostTimerInit;
				histOpaBoost[userFlight][scaID] = histOpaBoostAmount;
			}
		} else if (e.getKeyCode() == KeyEvent.VK_Y) {

			if (e.isShiftDown() == true) {

				drawSatDetails = toggleBoolean(drawSatDetails);
			} else {

				lockViewToSat = toggleBoolean(lockViewToSat);
			}

		} else if (e.getKeyCode() == KeyEvent.VK_R) {

			if (e.isShiftDown() == true) {

			} else {

				resetViews();
			}

		} else if (e.getKeyCode() == KeyEvent.VK_Z) {
			
			if (e.isShiftDown() == true) {

			} else {

			}
		} else if (e.getKeyCode() == KeyEvent.VK_X) { // toggle scan seq

			if (e.isShiftDown() == true) {

				for (int i = 0; i < WC.SCAN_SEQ_INDEX_MAX_VAL; i++) {
					playbackScanSeqIndexMask[userFlight][i] = WC.STATUS_ON;
				}
				userInterfaceInfoStr = "LOAD/PLAY ALL SCAN SEQS";
			} else if (e.isControlDown()){
				
				// determine dominant SOS ID and turn off all others
				
				selectOnlyDominantSosId();
				
			} else {
			
				int seqIndex = playbackScanSeqIndexPrev[userFlight];
				if (seqIndex != WC.STATUS_ERROR) {
					if (playbackScanSeqIndexMask[userFlight][seqIndex] == 0) {
						playbackScanSeqIndexMask[userFlight][seqIndex] = 1;
					} else {
						playbackScanSeqIndexMask[userFlight][seqIndex] = 0;
					}
					userInterfaceInfoStr = "TOGGLE LOAD/PLAY SCAN SEQ "
							+ seqIndex;
				}
			}
		} else if (e.getKeyCode() == KeyEvent.VK_LEFT) { // toggle scan seq

			if (e.isShiftDown() == true) {
				if (e.isControlDown()) {
					userTimelineZoom[GOAL] /= timelineZoomUiRate;
					if (userTimelineZoom[GOAL] < userTimelineZoomMin) {
						userTimelineZoom[GOAL] = userTimelineZoomMin;
					}
				} else {
					panTime(1);
				}
			} else {
				witFrameListStep(-1, 1f);

				syncDrawSegments();
			}
		} else if (e.getKeyCode() == KeyEvent.VK_RIGHT) { // toggle scan seq

			if (e.isShiftDown() == true) {
				if (e.isControlDown()) {
					userTimelineZoom[GOAL] *= timelineZoomUiRate;
					if (userTimelineZoom[GOAL] > userTimelineZoomMax) {
						userTimelineZoom[GOAL] = userTimelineZoomMax;
					}
				} else {
					panTime(-1);
				}
			} else {
				witFrameListStep(1, 1f);

				syncDrawSegments();
			}
		} else if (e.getKeyCode() == KeyEvent.VK_UP) { // toggle scan seq

			if (e.isShiftDown() == true) {
				panTime(0);
			} else {
				tivoStepPlaybackSeconds(1);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_DOWN) { // toggle scan seq

			if (e.isShiftDown() == true) {
				panTime(0);
			} else {
				tivoStepPlaybackSeconds(-1);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_L) { // toggle scan seq

			if (e.isShiftDown() == true) {
				lockPlayhead = (lockPlayhead + 1) % 2;
			} else {
				playheadDir *= -1;
			}
		} else if (e.getKeyCode() == KeyEvent.VK_COMMA) { // toggle scan seq

			if (e.isShiftDown() == true) {

			} else {
				resetLastDrawIndex();
				setPlaybackScanMode(SCAN_DIR_EVEN);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_PERIOD) { // toggle scan seq

			if (e.isShiftDown() == true) {

			} else {
				resetLastDrawIndex();
				setPlaybackScanMode(SCAN_DIR_ODD);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_J) { // jump


			if (e.isShiftDown() == true) {
				reloadNewData(-1,0);

			} else if (e.isControlDown() == true) {
				reloadNewData(0,0);

			} else {
				reloadNewData(1,0);
			}
			
		} else if (e.getKeyCode() == KeyEvent.VK_F) {

			if (e.isShiftDown() == true) {

			} else {
				toggleFlight();

				// auto re-center
				panBookmarkEvent(0);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_C) {
			if (e.isShiftDown() == true) {
				handleContrastColorChange();
			} else {
				handleContrastModeChange(CONTRAST_USER);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_T) {
			if (e.isShiftDown() == true) {
				toggleOpMask(WC.THREAD_GPU_FRAG_DIFF);

			} else {
				toggleOpMask(WC.THREAD_GPU_FRAG_DWT);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_B) {
			if (e.isShiftDown() == true) {
				toggleOpMask(WC.THREAD_GPU_FRAG_BURNIN);
			} else {
				toggleOpMask(WC.THREAD_GPU_FRAG_TIMELAPSE);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_M) {
			if (e.isShiftDown() == true) {

			} else {
				userInterfaceInfoStr = "TOGGLE MOUSE OVERLAY (INCOMING FEATURE)";
			}
		} else if (e.getKeyCode() == KeyEvent.VK_V) {
			if (e.isShiftDown() == true) {
				if (e.isControlDown() == true) { // make WIT demo videos
					exportDemoVideoState = (exportDemoVideoState + 1) % 2;
				}
				outputOptionMask[WC.OPTION_VIDEO_LOOP] = false;
				recordVideo();
			} else {
				outputOptionMask[WC.OPTION_VIDEO_LOOP] = true;
				recordVideo();
			}
		} else if (e.getKeyCode() == KeyEvent.VK_H) {
			if (e.isShiftDown() == true) {
				initColorRamps();
			} else {
				collapseContrast();
			}
		}

	}

	public void tivoExit() {
		System.exit(0);
	}

	public void toggleLoopMode() {

		if (selectionStatus == SELECTION_COMPLETE) {
			if (loopMode == LOOP_MODE_ALL) {
				loopMode = LOOP_MODE_SELECTION;
			} else {

				loopMode = LOOP_MODE_ALL;
			}
		}
	}

	public void flagOclComputing(){
		System.out.println("UNBLOCK OCL EXECUTION");
		for (int f=0; f<WC.TOTAL_FLIGHTS; f++){
			for (int s=0; s<WC.TOTAL_SCAS; s++){
				if (witFrameList[f][s]!=null){
					if (witFrameList[f][s].size() > 0){
						if (scaLoadMask[f][s] == 1){
							scaOclMask[f][s] = WC.STATUS_READY;
						}
					}
				}
				
			}
		}
	}
	
	public void changeCoordinateMode() {
		coordinateMode++;

		if (coordinateMode >= WC.COORDINATES_MODE_MAX) {
			coordinateMode = 0;
		}

		if (coordinateMode == WC.COORDINATES_WIT_UI_OLDSCHOOL) {
			
		} else {
			
		}

		while (coordinateSpaceLoadMask[coordinateMode] == 0) {
			changeCoordinateMode();
		}
	}

	public void clearSelection() {

		loopMode = LOOP_MODE_ALL;
	}

	public void allSelection() {

		int scaID = indexSca[userFlight];

		if (witFrameList[userFlight][scaID].size() > 0) {
			WITFrame wfa = (WITFrame) witFrameList[userFlight][scaID].get(0);
			userSelection[WC.START][WC.T] = 0;// 0+witFrameLoadStartSec;
			userSelection[WC.END][WC.T] = witFrameList[userFlight][scaID]
					.size() - 1;// witFrameList.size();//frameCount-1;

			userSelection[WC.START][T_SECS] = ((WITFrame) witFrameList[userFlight][scaID]
					.get(userSelection[WC.START][WC.T])).timeStampSecOfDay;
			userSelection[WC.END][T_SECS] = ((WITFrame) witFrameList[userFlight][scaID]
					.get(userSelection[WC.END][WC.T])).timeStampSecOfDay;

			userSelection[WC.START][WC.X] = 0;

			userSelection[WC.START][WC.Y] = 0;

			userSelectionArea = (Math.abs(userSelection[WC.START][WC.X]
					- userSelection[WC.END][WC.X]))
					* (Math.abs(userSelection[WC.START][WC.Y]
							- userSelection[WC.END][WC.Y]));

			selectionStatus = SELECTION_COMPLETE;
			loopMode = LOOP_MODE_SELECTION;
		}
	}

	public void setInputAppend() {

	}
	

	
	public void updateLatestFiles(){
			long time1 =	System.currentTimeMillis();
		IncomingDataScraperThread idst = new IncomingDataScraperThread();
		
		
		idst.incomingDataDirStr = incomingDataDirStr;
		idst.cvt = cvt;

		long updateFileWindow = 60*5;
		
		long searchEndSecs = (System.currentTimeMillis()/1000)+(timelineCheckTimezoneOffset*3600);
		long searchStartSecs = searchEndSecs - updateFileWindow;
		
		idst.searchStartSecs = searchStartSecs;
		idst.searchEndSecs = searchEndSecs;
		
		new Thread(idst).start();

		long time2 =	System.currentTimeMillis();
		
		
	}

	public void setAutoReload(int toggle, int timerHint, int bufferHint) {

		if (toggle != -1) {
			autoReloadState = toggle;
			userInterfaceInfoStr = "AUTO-RELOAD TOGGLED ";
		}
		
		if (timerHint != -1) {
			if (timerHint > MAX_RELOAD_TIMER_SECONDS) {
				timerHint = (int) MAX_RELOAD_TIMER_SECONDS;
			}

			if (timerHint < MIN_RELOAD_TIMER_SECONDS) {
				timerHint = (int) MIN_RELOAD_TIMER_SECONDS;
			}
		}

		if (timerHint != -1) {
			if (timerHint != autoReloadTimerSeconds) {
				knobPulseReloadTimer[CURRENT] = knobPulseStartIntensity;
				knobPulseReloadTimer[GOAL] = 0;
			}

			autoReloadTimerSeconds = timerHint;

			if (autoReloadTimerSeconds == MID_RELOAD_TIMER_SECONDS) {
				knobRotReloadTimer[GOAL] = knobStartDeg + (knobSweepDeg / 2f);
			} else if (autoReloadTimerSeconds > MID_RELOAD_TIMER_SECONDS) {
				knobRotReloadTimer[GOAL] = knobStartDeg
						+ (knobSweepDeg / 2f + (((float) (autoReloadTimerSeconds - MID_RELOAD_TIMER_SECONDS) / (MAX_RELOAD_TIMER_SECONDS - MID_RELOAD_TIMER_SECONDS)) * (knobSweepDeg / 2f)));
			} else if (autoReloadTimerSeconds < MID_RELOAD_TIMER_SECONDS) {
				knobRotReloadTimer[GOAL] = knobStartDeg
						+ (((float) autoReloadTimerSeconds / MID_RELOAD_TIMER_SECONDS) * (knobSweepDeg / 2f));
			}


		}
		
		if (bufferHint != -1) {
			if (bufferHint > MAX_RELOAD_BUFFER_SECONDS) {
				bufferHint = (int) MAX_RELOAD_BUFFER_SECONDS;
			}

			if (bufferHint < MIN_RELOAD_BUFFER_SECONDS) {
				bufferHint = (int) MIN_RELOAD_BUFFER_SECONDS;
			}
		}

		if (bufferHint != -1) {
			if (bufferHint != autoReloadBufferSeconds) {
				knobPulseReloadBuffer[CURRENT] = knobPulseStartIntensity;
				knobPulseReloadBuffer[GOAL] = 0;
			}

			autoReloadBufferSeconds = bufferHint;

			if (autoReloadBufferSeconds == MID_RELOAD_BUFFER_SECONDS) {
				knobRotReloadBuffer[GOAL] = knobStartDeg + (knobSweepDeg / 2f);
			} else if (autoReloadBufferSeconds > MID_RELOAD_BUFFER_SECONDS) {
				knobRotReloadBuffer[GOAL] = knobStartDeg
						+ (knobSweepDeg / 2f + (((float) (autoReloadBufferSeconds - MID_RELOAD_BUFFER_SECONDS) / (MAX_RELOAD_BUFFER_SECONDS - MID_RELOAD_BUFFER_SECONDS)) * (knobSweepDeg / 2f)));
			} else if (autoReloadBufferSeconds < MID_RELOAD_BUFFER_SECONDS) {
				knobRotReloadBuffer[GOAL] = knobStartDeg
						+ (((float) autoReloadBufferSeconds / MID_RELOAD_BUFFER_SECONDS) * (knobSweepDeg / 2f));
			}


		}

		String reloadTimerTimeUnitStr = "SEC";
		int displayReloadTimerUnits = timerHint;
		if (timerHint >= 60 && timerHint < 3600) {
			displayReloadTimerUnits = timerHint / 60;

			if (displayReloadTimerUnits == 1) {
				reloadTimerTimeUnitStr = "MIN";
			} else {
				reloadTimerTimeUnitStr = "MIN";
			}

		} else if (timerHint >= 3600) {
			displayReloadTimerUnits = timerHint / 3600;
			if (displayReloadTimerUnits == 1) {
				reloadTimerTimeUnitStr = "HR";
			} else {
				reloadTimerTimeUnitStr = "HR";
			}
		}
		if (timerHint != -1) {
			loadReloadTimerStr = displayReloadTimerUnits + " " + reloadTimerTimeUnitStr;

		}
		
		String reloadBufferTimeUnitStr = "SEC";
		int displayReloadBufferUnits = bufferHint;
		if (bufferHint >= 60 && bufferHint < 3600) {
			displayReloadBufferUnits = bufferHint / 60;

			if (displayReloadBufferUnits == 1) {
				reloadBufferTimeUnitStr = "MIN";
			} else {
				reloadBufferTimeUnitStr = "MIN";
			}

		} else if (bufferHint >= 3600) {
			displayReloadBufferUnits = bufferHint / 3600;
			if (displayReloadBufferUnits == 1) {
				reloadBufferTimeUnitStr = "HR";
			} else {
				reloadBufferTimeUnitStr = "HR";
			}
		}
		if (bufferHint != -1) {
			loadReloadBufferStr = displayReloadBufferUnits + " " + reloadBufferTimeUnitStr;

		}

	}

	public void setLoadFrames(int loadHint, int skipHint, int burstHint) {

		// check bounds

		if (loadHint != -1) {
			if (loadHint > MAX_LOAD_SECONDS) {
				loadHint = (int) MAX_LOAD_SECONDS;
			}

			if (loadHint < MIN_LOAD_SECONDS) {
				loadHint = (int) MIN_LOAD_SECONDS;
			}
		}

		if (skipHint != -1) {
			if (skipHint > MAX_SKIP_SECONDS) {
				skipHint = (int) MAX_SKIP_SECONDS;
			}

			if (skipHint < MIN_SKIP_SECONDS) {
				skipHint = (int) MIN_SKIP_SECONDS;
			}
		}

		if (burstHint != -1) {
			if (burstHint > MAX_BURST_SECONDS) {
				burstHint = (int) MAX_BURST_SECONDS;
			}

			if (burstHint < MIN_BURST_SECONDS) {
				burstHint = (int) MIN_BURST_SECONDS;
			}
		}

		// end check bounds

		if (burstHint != -1) {
			if (burstHint != burstSeconds) {
				knobPulseBurst[CURRENT] = knobPulseStartIntensity;
				knobPulseBurst[GOAL] = 0;
			}
			burstSeconds = burstHint;

			if (burstSeconds == MID_BURST_SECONDS) {
				knobRotBurst[GOAL] = knobStartDeg + (knobSweepDeg / 2f);
			} else if (burstSeconds > MID_BURST_SECONDS) {
				knobRotBurst[GOAL] = knobStartDeg
						+ (knobSweepDeg / 2f + (((float) (burstSeconds - MID_BURST_SECONDS) / (MAX_BURST_SECONDS - MID_BURST_SECONDS)) * (knobSweepDeg / 2f)));
			} else if (burstSeconds < MID_BURST_SECONDS) {
				knobRotBurst[GOAL] = knobStartDeg
						+ (((float) burstSeconds / MID_BURST_SECONDS) * (knobSweepDeg / 2f));
			}
		}

		if (loadHint != -1) {
			if (loadSeconds != loadHint) {
				knobPulseLoad[CURRENT] = knobPulseStartIntensity;
				knobPulseLoad[GOAL] = 0;
			}
			loadSeconds = loadHint;

			if (loadSeconds == MID_LOAD_SECONDS) {
				knobRotLoad[GOAL] = knobStartDeg + (knobSweepDeg / 2f);
			} else if (loadSeconds > MID_LOAD_SECONDS) {
				knobRotLoad[GOAL] = knobStartDeg
						+ (knobSweepDeg / 2f + (((float) (loadSeconds - MID_LOAD_SECONDS) / (MAX_LOAD_SECONDS - MID_LOAD_SECONDS)) * (knobSweepDeg / 2f)));
			} else if (loadSeconds < MID_LOAD_SECONDS) {
				knobRotLoad[GOAL] = knobStartDeg
						+ (((float) loadSeconds / MID_LOAD_SECONDS) * (knobSweepDeg / 2f));
			}

		}

		if (skipHint != -1) {
			if (skipHint != skipSeconds) {
				knobPulseSkip[CURRENT] = knobPulseStartIntensity;
				knobPulseSkip[GOAL] = 0;
			}

			skipSeconds = skipHint;

			if (skipSeconds == MID_SKIP_SECONDS) {
				knobRotSkip[GOAL] = knobStartDeg + (knobSweepDeg / 2f);
			} else if (skipSeconds > MID_SKIP_SECONDS) {
				knobRotSkip[GOAL] = knobStartDeg
						+ (knobSweepDeg / 2f + (((float) (skipSeconds - MID_SKIP_SECONDS) / (MAX_SKIP_SECONDS - MID_SKIP_SECONDS)) * (knobSweepDeg / 2f)));
			} else if (skipSeconds < MID_SKIP_SECONDS) {
				knobRotSkip[GOAL] = knobStartDeg
						+ (((float) skipSeconds / MID_SKIP_SECONDS) * (knobSweepDeg / 2f));
			}
		}

		String loadTimeUnitStr = "SEC";
		int displayLoadUnits = loadSeconds;

		String skipTimeUnitStr = "SEC";
		int displaySkipUnits = skipHint;

		String burstTimeUnitStr = "SEC";
		int displayBurstUnits = burstHint;

		if (loadHint >= 60 && loadHint < 3600) {
			displayLoadUnits = loadHint / 60;
			if (displayLoadUnits == 1) {
				loadTimeUnitStr = "MIN";
			} else {
				loadTimeUnitStr = "MIN";
			}
		} else if (loadHint >= 3600) {
			displayLoadUnits = loadHint / 3600;
			if (displayLoadUnits == 1) {
				loadTimeUnitStr = "HR";
			} else {
				loadTimeUnitStr = "HR";
			}
		}

		if (skipHint >= 60 && skipHint < 3600) {
			displaySkipUnits = skipHint / 60;

			if (displaySkipUnits == 1) {
				skipTimeUnitStr = "MIN";
			} else {
				skipTimeUnitStr = "MIN";
			}

		} else if (skipHint >= 3600) {
			displaySkipUnits = skipHint / 3600;
			if (displaySkipUnits == 1) {
				skipTimeUnitStr = "HR";
			} else {
				skipTimeUnitStr = "HR";
			}
		}

		if (burstHint >= 60 && burstHint < 3600) {
			displayBurstUnits = burstHint / 60;

			if (displayBurstUnits == 1) {
				burstTimeUnitStr = "MIN";
			} else {
				burstTimeUnitStr = "MIN";
			}

		} else if (burstHint >= 3600) {
			displayBurstUnits = burstHint / 3600;
			if (displayBurstUnits == 1) {
				burstTimeUnitStr = "HR";
			} else {
				burstTimeUnitStr = "HR";
			}
		}

		// if (skipHint != -1) {
		skipSeconds = skipHint;
		StringBuilder strBdr = new StringBuilder();
		strBdr.append("LOAD BUFFER CHANGED - ");
		strBdr.append(displayLoadUnits);
		strBdr.append(" ");
		strBdr.append(loadTimeUnitStr);
		strBdr.append(" ... SKIPPING ");
		strBdr.append(displaySkipUnits);
		strBdr.append(" ");
		strBdr.append(skipTimeUnitStr);
		// userInterfaceInfoStr = strBdr.toString();
	
		if (loadHint != -1) {
			loadWindowStr = displayLoadUnits + " " + loadTimeUnitStr;
		}

		if (skipHint != -1) {
			loadSkipStr = displaySkipUnits + " " + skipTimeUnitStr;
		}

		if (burstHint != -1) {
			loadBurstStr = displayBurstUnits + " " + burstTimeUnitStr;
		}

		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
	}

	public void setLoadSkipShortScans() {

	}

	public void setLoadSkipOverscans() {

	}

	public void setLoadSkipSeconds(int skipHint) {
		skipSeconds = skipHint;

		int displaySkipUnits = skipHint;

		String skipTimeUnitStr = "";

		if (displaySkipUnits == 1) {
			skipTimeUnitStr = "SECOND";
		} else {
			skipTimeUnitStr = "SECONDS";
		}

		if (skipHint >= 60 && skipHint < 3600) {
			displaySkipUnits = skipHint / 60;

			if (displaySkipUnits == 1) {
				skipTimeUnitStr = "MINUTE";
			} else {
				skipTimeUnitStr = "MINUTES";
			}
		} else if (skipHint >= 3600) {
			displaySkipUnits = skipHint / 3600;
			if (displaySkipUnits == 1) {
				skipTimeUnitStr = "HOUR";
			} else {
				skipTimeUnitStr = "HOURS";
			}
		}

		StringBuilder strBdr = new StringBuilder();
		strBdr.append("LOAD SKIP CHANGED - ");
		strBdr.append(displaySkipUnits);
		strBdr.append(" ");
		strBdr.append(skipTimeUnitStr);
		userInterfaceInfoStr = strBdr.toString();

		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
	}

	public void openFiles() {
		timelineCheckEnabled = WC.STATUS_OFF;
		
		initTimeline();
		initTimelineRefs();

		loadMetadataExplicitFileList();

		timelineImageUpdateFlag = WC.TIMELINE_UPDATE_ALL;


		timelineStatus = WC.STATUS_READY;

	}

	public void setInputSource() {

		systemState = WC.SYSTEM_STATE_OFFLINE;

		resetThreads();

		systemState = WC.SYSTEM_STATE_ONLINE;

	}

	public void exportImageSeq(String ext) {

		int[] channels = getVideoExportSelection();


		channels[WC.THREAD_LOAD_HDF5R] = 1;
		channels[WC.THREAD_DIFF] = 1;
		channels[WC.THREAD_CONTRAST] = 1;
		channels[WC.THREAD_TIMELAPSE] = 1;

		startImageExport(ext, channels, 0);
	}

	public void exportMarkedImageSeq(String ext) {
		int[] channels = getVideoExportSelection();

		channels[WC.THREAD_LOAD_HDF5R] = 1;
		channels[WC.THREAD_DIFF] = 1;
		channels[WC.THREAD_CONTRAST] = 1;
		channels[WC.THREAD_TIMELAPSE] = 1;

		startImageExport(ext, channels, 1);
	}

	public void exportWeatherImageSeq(String ext) {
		int[] channels = getVideoExportSelection();

		int[][] bounds = new int[2][2];


		channels[WC.THREAD_LOAD_HDF5R] = 1;
		channels[WC.THREAD_DIFF] = 0;
		channels[WC.THREAD_CONTRAST] = 1;
		channels[WC.THREAD_TIMELAPSE] = 0;

		bounds[WC.START][GEODATA_LON] = -180;
		bounds[WC.END][GEODATA_LON] = 180;
		bounds[WC.START][GEODATA_LAT] = -90;
		bounds[WC.END][GEODATA_LAT] = 90;

		float scale = 13;

		startImageExportProj(ext, channels, 0, bounds, scale, 1);
	}
	public void setVideoExportMagnification(int magScale) {
		userVideoMagnification = magScale;
	}

	public void recordVideo() {

		if (exportBounceVideoState == WC.STATUS_OFF) {
			userInterfaceInfoStr = "STARTED VIDEO EXPORT";
			vidExportUI.showVideoExport();
		} else {
			userInterfaceInfoStr = "STOPPED VIDEO EXPORT";
			exportBounceVideoState = WC.STATUS_OFF;
			completeVideoExportFromGpu();

		}
	}

	public void setKernel(float[] ker) {
		for (int i = 0; i < ker.length; i++) {
			if (i < dwtKernelCoefficients.length) {
				dwtKernelCoefficients[i] = ker[i];
			}
		}
	}

	public void editKernel() {
		kernelEditorUI.showKernelEditor();
	}

	public void editGLSL() {
		String glslSourceCode = "";
		for (int i = 0; i < fragSourceAggregate.length; i++) {
			glslSourceCode += fragSourceAggregate[i];
			glslSourceCode += "\n";
		}
		glslEditorUI.glsleui.glslText.setText(glslSourceCode);
		glslEditorUI.cvt = cvt;
		glslEditorUI.showGLSLEditor();
	}

	public void contrastEditorUI() {
		System.out.println("SHOW EDITOR");

	}

	public void exportVideoUI() {
		System.out.println("STARTING VID EXPORT");

		startVideoExportFromGpu();

	}

	public void exportReport() {

	}

	public void keyReleased(KeyEvent e) {

	}

	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseClicked(MouseEvent e) {

		if (uiState == WC.UI_STATE_VIEW) {

		}
	}

	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

		if (uiState == WC.UI_STATE_VIEW) {

		}
	}

	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

		if (uiState == WC.UI_STATE_VIEW) {

		}
	}

	public void mousePressed(MouseEvent e) {
	
		if (uiState == WC.UI_STATE_VIEW) {
			int posX = e.getX();
			int posY = e.getY();

			int posYinv = viewportGlY - e.getY();

			if (true) {
			

				cursorX = posX + cursorUnblockX;
				cursorY = glCanvas.getHeight() - (posY + cursorUnblockY);

				if (widgetVisibility[WC.WIDGET_HISTOGRAM] == 1
						&& cursorX >= glContrastControlX - 2
								* glContrastControlW
						&& cursorX <= glContrastControlX + 2
								* glContrastControlW
						&& cursorY < glContrastControlY + glContrastControlH
						&& cursorY >= glContrastControlY) {

					mouseState = WC.UI_STATE_CONTRAST;
					mouseStateContrastNode = WC.STATUS_ERROR;

					// userContrastCPStatus = SELECTION_WORKING;

					int specialEditFlag = WC.CONTRAST_UI_SPECIAL_EDIT_NONE;
					if (e.isShiftDown() == true) {
						specialEditFlag = WC.CONTRAST_UI_SPECIAL_EDIT_MOVE_ALL;
					}

					// touchGlContrastSelectorExp(cursorY, specialEditFlag);
					touchGlContrastSelectorLinear(cursorY, specialEditFlag);

				} else if (posX >= miniMapPos[CURRENT][WC.X]
						&& posX <= miniMapPos[CURRENT][WC.X]
								+ miniMapSize[CURRENT][WC.X]
						&& posY >= miniMapPos[CURRENT][WC.Y]
						&& posY <= miniMapPos[CURRENT][WC.Y]
								+ miniMapSize[CURRENT][WC.Y]) { // drag view
					// region
					mouseState = WC.UI_STATE_PAN_VIEW;
					mousePan(posX, posY);

				} else if (posY > tivoStatusBarY + 22
						&& posX < scaOpMaskX + scaOpMaskW && posX >= scaOpMaskX) {// switch
					// to
					// SCA
					// selection

					mouseState = WC.UI_STATE_SCA_SELECT;
					uiState = WC.UI_STATE_SCA_SELECT;
					System.out.println("MODE CHANGE ");
				} 
			else if (posX < viewportX
						&& posY < userSelectionLowerBoundary) { // draw
			
					if (coordinateMode == WC.COORDINATES_GLOBE
							|| coordinateMode == WC.COORDINATES_GLOBE_SENSOR) {

						if (e.getButton() == e.BUTTON3 && e.isControlDown()) {
							mouseState = WC.UI_STATE_LOS_ROTATE;
							prevMouse3dX = e.getX();
							prevMouse3dY = e.getY();
						} else if (e.getButton() == e.BUTTON3) {

							mouseState = WC.UI_STATE_GLOBE_ROTATE;
							prevMouse3dX = e.getX();
							prevMouse3dY = e.getY();
						} else {
							mouseState = WC.UI_STATE_PROCESS_WINDOW;

							cursorX = posX + cursorUnblockX;
							cursorY = glCanvas.getHeight()
									- (posY + cursorUnblockY);

							userSelection[WC.START][WC.X] = cursorX;
							userSelection[WC.START][WC.Y] = cursorY;

							userSelection[WC.END][WC.X] = cursorX;
							userSelection[WC.END][WC.Y] = cursorY;

						}

					} else if (coordinateMode == WC.COORDINATES_MERCATOR) {

						if (e.isShiftDown() == true) {
							mouseState = WC.UI_STATE_PROCESS_WINDOW;

							cursorX = posX + cursorUnblockX;
							cursorY = glCanvas.getHeight()
									- (posY + cursorUnblockY);

							userSelection[WC.START][WC.X] = cursorX;
							userSelection[WC.START][WC.Y] = cursorY;

							// start us at click location
							userSelection[WC.END][WC.X] = cursorX;
							userSelection[WC.END][WC.Y] = cursorY;

						} else {
							mouseState = WC.UI_STATE_PROCESS_WINDOW;
							prevMouse3dX = e.getX();
							prevMouse3dY = e.getY();
						}
					} else if (coordinateMode == WC.COORDINATES_SENSOR) {

						if (e.getButton() == e.BUTTON3) {

							mouseState = WC.UI_STATE_PAN_VIEW;
							// System.out.println("START GLOBE DRAG");
							prevMouse3dX = e.getX();
							prevMouse3dY = e.getY();
						} else {
							mouseState = WC.UI_STATE_PROCESS_WINDOW;

							cursorX = posX + cursorUnblockX;
							cursorY = glCanvas.getHeight()
									- (posY + cursorUnblockY);

							userSelection[WC.START][WC.X] = cursorX;
							userSelection[WC.START][WC.Y] = cursorY;

							// start us at click location
							userSelection[WC.END][WC.X] = cursorX;
							userSelection[WC.END][WC.Y] = cursorY;

						}
					}

				} else if (posY > loopSelectorYtop
						&& posY < loopSelectorYbottom) {

					mouseState = WC.UI_STATE_TIMELINE_LOAD;

					touchPlayhead(posX);
					// touchPlayhead(posX-(int)userXoffset[CURRENT]);
				} else if (posY > loopSelectorYbottom && posY < loopSelectorYhandle) {

					mouseState = WC.UI_STATE_TIMELINE_SELECT;
					
					// init bounds
					userSelectionReloader[WC.START][WC.T] = userSelection[WC.START][WC.T];
					userSelectionReloader[WC.END][WC.T] = userSelection[WC.END][WC.T];
					
					touchLoopSelector(posX);

				} else if (posYinv > knobLabelY
						&& posYinv < knobLabelY + 2 * knobPixelW
						&& posX > knobBarX + knobDeltaX1 - knobPixelW
						&& posX < knobBarX + knobDeltaX1 + knobPixelW) {
					mouseState = WC.UI_STATE_KNOB_LOAD;
				} else if (posYinv > knobLabelY
						&& posYinv < knobLabelY + 2 * knobPixelW
						&& posX > knobBarX + knobDeltaX2 - knobPixelW
						&& posX < knobBarX + knobDeltaX2 + knobPixelW) {
					mouseState = WC.UI_STATE_KNOB_SKIP;
				} else if (posYinv > knobLabelY
						&& posYinv < knobLabelY + 2 * knobPixelW
						&& posX > knobBarX + knobDeltaX3 - knobPixelW
						&& posX < knobBarX + knobDeltaX3 + knobPixelW) {
					mouseState = WC.UI_STATE_KNOB_BURST;
				} else if (posYinv > knobLabelY
						&& posYinv < knobLabelY + 2 * knobPixelW
						&& posX > knobBarX + knobDeltaX4 - knobPixelW
						&& posX < knobBarX + knobDeltaX4 + knobPixelW) {
					
					if (e.isShiftDown()){
						if (autoReloadState == WC.STATUS_ON){
							setAutoReload(WC.STATUS_OFF, -1,-1);
						} else {
							setAutoReload(WC.STATUS_ON, autoReloadTimerSeconds, autoReloadBufferSeconds);
						}
						knobPulseReloadTimer[CURRENT] = knobPulseStartIntensity;
						knobPulseReloadTimer[GOAL] = 0;
					} else {
						mouseState = WC.UI_STATE_KNOB_RELOAD_TIMER;
					}
					
				} else if (posYinv > knobLabelY
						&& posYinv < knobLabelY + 2 * knobPixelW
						&& posX > knobBarX + knobDeltaX5 - knobPixelW
						&& posX < knobBarX + knobDeltaX5 + knobPixelW) {
					
						mouseState = WC.UI_STATE_KNOB_RELOAD_BUFFER;
				}
			}
			
		}

	}


	public void sortCPList() {

		// check the control points
		for (int i = 0; i < userContrastCPList.size(); i++) {
			UserContrastCP uc = (UserContrastCP) userContrastCPList.get(i);
			if (uc.histIntensityBin < userContrast[WC.START]) {
				userContrastCPList.remove(i);
			}
			if (uc.histIntensityBin > userContrast[WC.END]) {
				userContrastCPList.remove(i);
			}
		}

		if (userContrastCPList.size() > 1) {
			int swaps = 1;
			while (swaps > 0) {
				swaps = 0;

				for (int i = 1; i < userContrastCPList.size(); i++) {

					UserContrastCP u1 = (UserContrastCP) userContrastCPList
							.get(i - 1);
					UserContrastCP u2 = (UserContrastCP) userContrastCPList
							.get(i);

					if (u1.intensity > u2.intensity) {
						swaps++;
						userContrastCPList.set(i - 1, u2);
						userContrastCPList.set(i, u1);
					}
				}
			}
		}

		for (int i = 0; i < userContrastCPList.size(); i++) {

			UserContrastCP u2 = (UserContrastCP) userContrastCPList.get(i);

		}

	}

	public void touchContrastCPs(int posX, int posY, boolean clearFlag) {

		int modCP = 0;
		float minDist = Float.MAX_VALUE;
		int minID = -1;
		for (int i = 0; i < userContrastCPList.size(); i++) {
			UserContrastCP uc = (UserContrastCP) userContrastCPList.get(i);
			float distSq = (uc.clickX - posX) * (uc.clickX - posX)
					+ (uc.clickY - posY) * (uc.clickY - posY);

			if (distSq <= (float) (contrastCurveDotRadius * contrastCurveDotRadius) * 1.1f) {
				minDist = distSq;
				minID = i;
			}
		}

		// System.out.println("MIN DIST "+minDist+" ID "+minID);
		if (minDist <= 300) {
			modCP = 1;
		}

		if (modCP == 0 && clearFlag == false) { // new
			UserContrastCP uccp = new UserContrastCP();
			uccp.histIntensityBin = (posX - histX);
			uccp.intensity = uccp.histIntensityBin * histClusterSize;
			uccp.rasterIntensity = (histY - posY);
			uccp.clickX = posX;
			uccp.clickY = posY;
			userContrastCPList.add(uccp);

			resetContrastEtc();

		}

		if (modCP == 1 && clearFlag == true) { // delete

			userContrastCPList.remove(minID);

		}

		if (modCP == 1 && clearFlag == false && minID >= 0) { // modify

			userContrastCPStatus = SELECTION_WORKING;
			userContrastCPmodID = minID;

			UserContrastCP uc = (UserContrastCP) userContrastCPList.get(minID);
			uc.clickX = posX;
			uc.clickY = posY;
			uc.histIntensityBin = (posX - histX);
			uc.intensity = uc.histIntensityBin * histClusterSize;
			uc.rasterIntensity = histY - posY;
			userContrastCPList.set(minID, uc);

		}

		sortCPList();
	}

	public void expandContrast() {
		if (contrastCollapseLevel > 1) {
			int centerContrastNode = lastEditedContrastNode;

			if (lastEditedContrastNode == WC.STATUS_ERROR) {
				centerContrastNode = cvt.glContrastColorBands / 2;
			}

			contrastCollapseLevel++;
			int collapseSpace = 200 / contrastCollapseLevel;

			for (int i = 1; i < cvt.glContrastColorBands - 1; i++) {
				if (i < centerContrastNode) {
					int space = -(centerContrastNode - i) * collapseSpace;
					glColorLimits[glColorScheme][i] = glColorLimits[glColorScheme][centerContrastNode]
							+ space;
				} else if (i > centerContrastNode) {
					int space = (i - centerContrastNode) * collapseSpace;
					glColorLimits[glColorScheme][i] = glColorLimits[glColorScheme][centerContrastNode]
							+ space;
				}
			}

			checkColorLimits();

			determineGlContrastControlPointRasterPosLinear();
			userInterfaceInfoStr = ("CONTRAST COLLAPSED TO " + collapseSpace + "-WIDE INTENSITY BANDS");
		}

	}

	public void collapseContrast() {
		if (contrastCollapseLevel < 65) {
			int centerContrastNode = lastEditedContrastNode;

			if (lastEditedContrastNode == WC.STATUS_ERROR) {
				centerContrastNode = cvt.glContrastColorBands / 2;
			}

			contrastCollapseLevel++;
			// int collapseSpace = 200 / contrastCollapseLevel; full HDR

			int collapseSpace = contrastCollapseSpacing / contrastCollapseLevel;

			for (int i = 1; i < cvt.glContrastColorBands - 1; i++) {
				if (i < centerContrastNode) {
					int space = -(centerContrastNode - i) * collapseSpace;
					glColorLimits[glColorScheme][i] = glColorLimits[glColorScheme][centerContrastNode]
							+ space;
				} else if (i > centerContrastNode) {
					int space = (i - centerContrastNode) * collapseSpace;
					glColorLimits[glColorScheme][i] = glColorLimits[glColorScheme][centerContrastNode]
							+ space;
				}
			}

			checkColorLimits();

			determineGlContrastControlPointRasterPosLinear();
			userInterfaceInfoStr = ("CONTRAST COLLAPSED TO " + collapseSpace + "-WIDE INTENSITY BANDS");
		}

	}

	public void checkColorLimits() {

		for (int i = 1; i < cvt.glContrastColorBands; i++) {
			if (glColorLimits[glColorScheme][i] < glColorLimits[glColorScheme][0]) {
				glColorLimits[glColorScheme][i] = glColorLimits[glColorScheme][0];
			}

			if (glColorLimits[glColorScheme][i] > glColorLimits[glColorScheme][cvt.glContrastColorBands - 1]) {
				glColorLimits[glColorScheme][i] = glColorLimits[glColorScheme][cvt.glContrastColorBands - 1];
			}
		}
	}

	public void initWxPolys() {

		wxPolyList = new ArrayList();
	}

	public void initColorRamps() {
		contrastCollapseLevel = 0;

		int origGlcs = glColorScheme;

		for (int gli = 0; gli < WC.COLOR_SCHEME_COUNT; gli++) {
			glColorScheme = gli;

			if (glColorScheme == WC.COLOR_SCHEME_HEATMAP) {

				glColorLimits[glColorScheme][0] = 0;
				glColorLimits[glColorScheme][1] = 43;
				glColorLimits[glColorScheme][2] = 86;
				glColorLimits[glColorScheme][3] = 128;
				glColorLimits[glColorScheme][4] = 170;
				glColorLimits[glColorScheme][5] = 213;
				glColorLimits[glColorScheme][6] = 256;
				glColorLimits[glColorScheme][7] = WC.CONTRAST_UI_HARD_LIMIT;

				// duplicate first and last colors to allow easier lo-cut hi-cut

				// purple
				glColorLimitsRGB[glColorScheme][0][WC.R] = 0f;// 20;
				glColorLimitsRGB[glColorScheme][0][WC.G] = 0;
				glColorLimitsRGB[glColorScheme][0][WC.B] = 0f;// 50;

				// purple
				glColorLimitsRGB[glColorScheme][1][WC.R] = .2f;// 20;
				glColorLimitsRGB[glColorScheme][1][WC.G] = 0;
				glColorLimitsRGB[glColorScheme][1][WC.B] = .45f;// 50;

				// blue
				glColorLimitsRGB[glColorScheme][2][WC.R] = 0;
				glColorLimitsRGB[glColorScheme][2][WC.G] = 0;
				glColorLimitsRGB[glColorScheme][2][WC.B] = 1f;

				// green
				glColorLimitsRGB[glColorScheme][3][WC.R] = 0;
				glColorLimitsRGB[glColorScheme][3][WC.G] = .7f;
				glColorLimitsRGB[glColorScheme][3][WC.B] = .2f;

				// yellow
				glColorLimitsRGB[glColorScheme][4][WC.R] = 1f;
				glColorLimitsRGB[glColorScheme][4][WC.G] = 1f;
				glColorLimitsRGB[glColorScheme][4][WC.B] = 0;

				// red
				glColorLimitsRGB[glColorScheme][5][WC.R] = 1f;
				glColorLimitsRGB[glColorScheme][5][WC.G] = 0;
				glColorLimitsRGB[glColorScheme][5][WC.B] = 0;

				// white
				glColorLimitsRGB[glColorScheme][6][WC.R] = 0f;
				glColorLimitsRGB[glColorScheme][6][WC.G] = 0f;
				glColorLimitsRGB[glColorScheme][6][WC.B] = 0f;

				// white
				glColorLimitsRGB[glColorScheme][7][WC.R] = 0f;
				glColorLimitsRGB[glColorScheme][7][WC.G] = 0f;
				glColorLimitsRGB[glColorScheme][7][WC.B] = 0f;

			} else if (glColorScheme == WC.COLOR_SCHEME_GRAYSCALE) {


				glColorLimits[glColorScheme][0] = 0;
				glColorLimits[glColorScheme][1] = 20;
				glColorLimits[glColorScheme][2] = 128;
				glColorLimits[glColorScheme][3] = 256;
				glColorLimits[glColorScheme][4] = 300;
				glColorLimits[glColorScheme][5] = 400;
				glColorLimits[glColorScheme][6] = 500;
				glColorLimits[glColorScheme][7] = WC.CONTRAST_UI_HARD_LIMIT;

				for (int i = 0; i <= 3; i++) {
					for (int j = 0; j < 3; j++) {
						glColorLimitsRGB[glColorScheme][i][j] = (float) glColorLimits[glColorScheme][i] / 255f;
						if (glColorLimitsRGB[glColorScheme][i][j] > 1) {
							glColorLimitsRGB[glColorScheme][i][j] = 1f;
						}
					}
				}

				for (int j = 0; j < 3; j++) {
					glColorLimitsRGB[glColorScheme][1][j] += .1f;
				}

				glColorLimitsRGB[glColorScheme][1][WC.R] = 0f;
				glColorLimitsRGB[glColorScheme][1][WC.G] = 0f;
				glColorLimitsRGB[glColorScheme][1][WC.B] = 0f;

				glColorLimitsRGB[glColorScheme][4][WC.R] = 0f;
				glColorLimitsRGB[glColorScheme][4][WC.G] = 0f;
				glColorLimitsRGB[glColorScheme][4][WC.B] = 1f;

				glColorLimitsRGB[glColorScheme][5][WC.R] = 0f;
				glColorLimitsRGB[glColorScheme][5][WC.G] = 1f;
				glColorLimitsRGB[glColorScheme][5][WC.B] = 1f;

				glColorLimitsRGB[glColorScheme][6][WC.R] = 1f;
				glColorLimitsRGB[glColorScheme][6][WC.G] = 0f;
				glColorLimitsRGB[glColorScheme][6][WC.B] = 0f;

				glColorLimitsRGB[glColorScheme][7][WC.R] = 1f;
				glColorLimitsRGB[glColorScheme][7][WC.G] = 0f;
				glColorLimitsRGB[glColorScheme][7][WC.B] = 0f;

			}

			determineGlContrastControlPointRasterPosLinear();

		}

		glColorScheme = origGlcs;
	}

	public void determineGlContrastControlPointRasterPosExp() {

		for (int i = 0; i < glContrastColorBands - 1; i++) {
			glColorLimitDiffs[glColorScheme][i] = glColorLimits[glColorScheme][i + 1]
					- glColorLimits[glColorScheme][i];
		}

		for (int i = 0; i < glContrastColorBands - 1; i++) {
			int index2 = i + 1;

			colorRampYpos[WC.END][i] = 0;

			colorRampYpos[WC.START][i] = intensityToContrastGlyExp(glColorLimits[glColorScheme][i]);
			if (index2 < glContrastColorBands - 1) {

				colorRampYpos[WC.END][i] = intensityToContrastGlyExp(glColorLimits[glColorScheme][index2]);
			} else {
				colorRampYpos[WC.END][i] = 16 * glContrastControlExpoH;
			}

			if (i == 0) {
				colorRampYpos[WC.START][i] = 0;
			}
		}
	}

	public void determineGlContrastControlPointRasterPosLinear() {

		for (int i = 0; i < glContrastColorBands - 1; i++) {
			glColorLimitDiffs[glColorScheme][i] = glColorLimits[glColorScheme][i + 1]
					- glColorLimits[glColorScheme][i];
		}

		for (int i = 0; i < glContrastColorBands - 1; i++) {
			int index2 = i + 1;

			colorRampYpos[WC.END][i] = 0;

			colorRampYpos[WC.START][i] = intensityToContrastGlyLinear(glColorLimits[glColorScheme][i]);

			if (index2 < glContrastColorBands - 1) {

				colorRampYpos[WC.END][i] = intensityToContrastGlyLinear(glColorLimits[glColorScheme][index2]);
			} else {
				colorRampYpos[WC.END][i] = (int) ((glContrastColorBands + 1) * glContrastControlLinearH);// glContrastControlExpH;
			}

			if (i == 0) {
				colorRampYpos[WC.START][i] = 0;
			}
		}
	}

	public int contrastGlyToIntensityExp(int posY) {
		int intensity = 0;

		int exp1 = (int) Math.floor(posY / glContrastControlExpoH);

		int exp2 = exp1;
		float diff = posY - exp1 * glContrastControlExpoH;
		if (diff != 0) {
			exp2 = exp1 + 1;
			float diffH = diff / (float) glContrastControlExpoH;
			float expRes1 = (float) Math.pow(2, exp1);
			float expRes2 = (float) Math.pow(2, exp2);
			float gap = expRes2 - expRes1;

			intensity = (int) (expRes1 + (diffH * gap));
		} else {
			float expRes1 = (float) Math.pow(2, exp1);
			intensity = (int) expRes1;
		}

		return intensity;
	}

	public int contrastGlyToIntensityLinear(int posY) {
		int intensity = 0;

		float exp1 = (float) posY / glContrastControlLinearH;

		float exp2 = exp1;
		float diff = (float) posY - (exp1 * glContrastControlLinearH);
		if (diff != 0) {
			exp2 = exp1 + 1;
			float diffH = diff
					* (glContrastControlLinearH / glContrastControlLinearDiffH);
			float expRes1 = glContrastControlLinearDiffH * exp1;
			
			float expRes2 = glContrastControlLinearDiffH * exp2;
			
			float gap = expRes2 - expRes1;

			intensity = (int) (expRes1);
			
		} else {
			float expRes1 = glContrastControlLinearDiffH * exp1;
			intensity = (int) expRes1;
		}

		return intensity;

	}

	public float intensityToContrastGlyLinear(int intensity) {
		float posY = 0;

		float exp1 = 0;
		float exp2 = 0;

		// for clamped 0-255 data
		for (int i = 0; i < glContrastColorBands; i++) {

			int expResTemp = (int) (glContrastControlLinearDiffH * i);// (int)
			
			if (intensity >= expResTemp) {
				exp1 = i;
				exp2 = i + 1;
			}
		}

		int expRes1 = (int) (exp1 * glContrastControlLinearDiffH);

		int expRes2 = (int) (exp2 * glContrastControlLinearDiffH);

		float gap = expRes2 - expRes1;
		float diff = intensity - (expRes1);
		float diffH = (diff / gap) * ((float) glContrastControlLinearH);

		posY = (int) ((exp1 * glContrastControlLinearH) + diffH);

		if (intensity == 0) {
			posY = 0;
		}

		return posY;
	}

	public int intensityToContrastGlyExp(int intensity) {
		int posY = 0;

		int exp1 = 0;
		int exp2 = 0;

		for (int i = 0; i < 16; i++) {
			int expResTemp = (int) Math.pow(2, i);
			if (intensity >= expResTemp) {
				exp1 = i;

				exp2 = i + 1;

			}
		}

		int expRes1 = (int) Math.pow(2, exp1);
		int expRes2 = (int) Math.pow(2, exp2);
		float gap = expRes2 - expRes1;
		float diff = intensity - (expRes1);
		float diffH = (diff / gap) * ((float) glContrastControlExpoH);

		posY = (int) ((exp1 * glContrastControlExpoH) + diffH);

		if (intensity == 0) {
			posY = 0;
		}

		return posY;
	}

	public void touchGlContrastSelectorExp(int posY, int specialFlags) {

		contrastCollapseLevel = 0;

		posY = posY - (int) glContrastControlY;

		int newIntensity = contrastGlyToIntensityExp(posY);

		if (mouseStateContrastNode == WC.STATUS_ERROR) {
			int minDiff = Integer.MAX_VALUE;
			int minDiffId = WC.STATUS_ERROR;
			for (int i = 1; i < glContrastColorBands - 1; i++) {
				int diff = Math.abs(newIntensity
						- glColorLimits[glColorScheme][i]);
				if (diff < minDiff) {
					minDiff = diff;
					minDiffId = i;
				}
			}
			mouseStateContrastNode = minDiffId;

			lastEditedContrastNode = mouseStateContrastNode;
		}

		// alter nearest control point
		if (mouseStateContrastNode != WC.STATUS_ERROR) {

			int oldIntensity = glColorLimits[glColorScheme][mouseStateContrastNode];
			int diff = newIntensity - oldIntensity;

			userInterfaceInfoStr = ("CONTRAST POINT " + mouseStateContrastNode
					+ " SET TO INTENSITY " + newIntensity);

			glColorLimits[glColorScheme][mouseStateContrastNode] = newIntensity;

			if (specialFlags == WC.CONTRAST_UI_SPECIAL_EDIT_MOVE_ALL) {
				for (int i = 1; i < cvt.glContrastColorBands - 1; i++) {
					if (i != mouseStateContrastNode) {
						glColorLimits[glColorScheme][i] += diff;
					}
				}
			}
		}
		checkColorLimits();

		determineGlContrastControlPointRasterPosLinear();
		// rendering
	}

	public void touchGlContrastSelectorLinear(int posY, int specialFlags) {

		contrastCollapseLevel = 0;

		posY = posY - (int) glContrastControlY;
		
		int newIntensity = contrastGlyToIntensityLinear(posY);

		if (mouseStateContrastNode == WC.STATUS_ERROR) {
			int minDiff = Integer.MAX_VALUE;
			int minDiffId = WC.STATUS_ERROR;
			for (int i = 1; i < glContrastColorBands - 1; i++) {
				int diff = Math.abs(newIntensity
						- glColorLimits[glColorScheme][i]);
				if (diff < minDiff) {
					minDiff = diff;
					minDiffId = i;
				}
			}
			mouseStateContrastNode = minDiffId;

			lastEditedContrastNode = mouseStateContrastNode;
		}

		// don't allow out of order CPs
		int upperCpId = mouseStateContrastNode + 1;
		int lowerCpId = mouseStateContrastNode - 1;

		int minSeparation = 2;

		if (upperCpId < glContrastColorBands) {
			if (newIntensity >= glColorLimits[glColorScheme][upperCpId]) {
				newIntensity = glColorLimits[glColorScheme][upperCpId]
						- minSeparation;
			}
		}

		if (lowerCpId >= 0) {
			if (newIntensity <= glColorLimits[glColorScheme][lowerCpId]) {
				newIntensity = glColorLimits[glColorScheme][lowerCpId]
						+ minSeparation;
			}
		}

		// alter nearest control point
		if (mouseStateContrastNode != WC.STATUS_ERROR) {

			int oldIntensity = glColorLimits[glColorScheme][mouseStateContrastNode];
			int diff = newIntensity - oldIntensity;

			currentTouchContrastIntensity = newIntensity;
			userInterfaceInfoStr = ("CONTRAST POINT " + mouseStateContrastNode
					+ " SET TO INTENSITY " + newIntensity);

			glColorLimits[glColorScheme][mouseStateContrastNode] = newIntensity;

			if (specialFlags == WC.CONTRAST_UI_SPECIAL_EDIT_MOVE_ALL) {
				for (int i = 1; i < cvt.glContrastColorBands - 1; i++) {
					if (i != mouseStateContrastNode) {
						glColorLimits[glColorScheme][i] += diff;
					}
				}
			}
		}
		checkColorLimits();

		determineGlContrastControlPointRasterPosLinear(); // update items for GL
		// rendering
	}

	public void touchContrastSelector(int posX) {

		int phX1 = posX;

		int phX2 = posX;

		int cSelPosX1 = contrastBarX
				+ (userContrast[WC.START] * contrastBarSpaceX);
		int cSelPosX2 = contrastBarX
				+ (userContrast[WC.END] * contrastBarSpaceX);

		int diff1 = Math.abs(phX1 - cSelPosX1);
		int diff2 = Math.abs(phX2 - cSelPosX2);

		int cGap = 1;

		if (diff1 <= diff2) {
			userContrast[WC.START] = (phX1 - contrastBarX) / contrastBarSpaceX;

			if (userContrast[WC.START] > userContrast[WC.END] - cGap) {
				userContrast[WC.START] = userContrast[WC.END] - cGap;
			}
		} else {
			userContrast[WC.END] = (phX2 - contrastBarX) / contrastBarSpaceX;

			if (userContrast[WC.END] < userContrast[WC.START] + cGap) {
				userContrast[WC.END] = userContrast[WC.START] + cGap;
			}
		}

		if (userContrast[WC.END] > histBins / histClusterSize) {
			userContrast[WC.END] = histBins / histClusterSize;
		}
		if (userContrast[WC.START] < 0) {
			userContrast[WC.START] = 0;
		}

		sortCPList();
	}

	public int getHistIntensityRasterX() {
		int xPos = 0;

		return xPos;
	}

	public void touchLoopSelector(int posX) {

		int playheadT1pos = userSelection[WC.START][WC.T];
		int playheadT2pos = userSelection[WC.END][WC.T];

		posX = (int) ((posX - viewportGlX / 2) * glShimScale * (1f / userTimelineZoom[CURRENT]));
		posX = (int) (posX - userTimelineOffset[CURRENT]);

		int phX1 = posX;

		int phX2 = posX;

		int diff1 = Math.abs(phX1 - playheadT1pos);
		int diff2 = Math.abs(phX2 - playheadT2pos);

		if (diff1 <= diff2) {
			userSelection[WC.START][WC.T] = phX1;
			
		} else {
			userSelection[WC.END][WC.T] = phX2;
			
		}

		checkTimeSelectorBounds();

		loopBoundStartX = tivoStatusBarX + (int) userTimelineOffset[CURRENT]
				+ userSelection[WC.START][WC.T];
		loopBoundEndX = tivoStatusBarX + (int) userTimelineOffset[CURRENT]
				+ userSelection[WC.END][WC.T];

	}

	public void dynamicLoadAppend(){
		

		int gap = userSelectionReloader[WC.END][WC.T]-userSelectionReloader[WC.START][WC.T];
		
		if (userSelectionReloader[WC.START][WC.T] < loopStart){
			systemState = WC.SYSTEM_STATE_OFFLINE;
			cvt.resetLastDrawIndex();
			dynamicLoad3(userSelectionReloader[WC.START][WC.T], gap, 0, skipSeconds, WC.STATUS_OFF);
		}
		if (userSelectionReloader[WC.END][WC.T] > loopEnd){
			systemState = WC.SYSTEM_STATE_OFFLINE;
			cvt.resetLastDrawIndex();
			dynamicLoad3(userSelectionReloader[WC.START][WC.T], gap, 0, skipSeconds, WC.STATUS_OFF);
		}
	}
	
	public void checkTimeSelectorBounds() {
		userSelectionReloader[WC.START][WC.T] = userSelection[WC.START][WC.T];
		userSelectionReloader[WC.END][WC.T] = userSelection[WC.END][WC.T];
		
		if (userSelection[WC.START][WC.T] <= loopStart){
			
			userSelection[WC.START][WC.T] = loopStart;
		}
		if (userSelection[WC.END][WC.T] >= loopEnd){
			
			userSelection[WC.END][WC.T] = loopEnd;
		}
	}

	public void touchPlayhead(int posX) {
		dynamicLoadStatus = WC.STATUS_WORKING;

		witTimePlayhead = (int) ((posX - viewportGlX / 2) * glShimScale * (1f / userTimelineZoom[CURRENT]));
		witTimePlayhead = (int) (witTimePlayhead - userTimelineOffset[CURRENT]);


	}

	public void clearFilterLayers() {
		// int scaID =0;

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				for (int i = 0; i < witFrameList[flight][k].size(); i++) {

					WITFrame wfi = (WITFrame) witFrameList[flight][k].get(i);

					wfi.layerStatus[WC.THREAD_CONTRAST] = WC.THREAD_STATUS_READY;
					
					wfi.layerStatus[WC.THREAD_DIFF] = WC.THREAD_STATUS_READY;
					
					wfi.layerStatus[WC.THREAD_TIMELAPSE] = WC.THREAD_STATUS_READY;
					
					wfi.layerStatus[WC.THREAD_REGISTRATION] = WC.THREAD_STATUS_READY;
					
				}
			}

		}
	}

	public void mouseReleased(MouseEvent e) {

		if (uiState == WC.UI_STATE_VIEW) {
			if (selectionStatus == SELECTION_WORKING) {
				

				if (mouseState == WC.UI_STATE_PROCESS_WINDOW) {
					translateSelectionToSCAs();

					selectionStatus = SELECTION_COMPLETE;

					userSelectionArea = (Math.abs(userSelection[WC.START][WC.X]
							- userSelection[WC.END][WC.X]))
							* (Math.abs(userSelection[WC.START][WC.Y]
									- userSelection[WC.END][WC.Y]));

					clearFilterLayers();
				}
			}

			if (mouseState == WC.UI_STATE_TIMELINE_LOAD) {

				selectionTimeStatus = SELECTION_READY;

				if (mouseState == WC.UI_STATE_TIMELINE_LOAD) {

					int xReleaseLoc = witTimePlayhead;

					if (xReleaseLoc < loopStart || xReleaseLoc > loopEnd
							|| userFlight != loadedFlight) {
						
						systemState = WC.SYSTEM_STATE_OFFLINE;
						cvt.resetLastDrawIndex();
						
						dynamicLoad3(xReleaseLoc, loadSeconds, 0, skipSeconds, WC.STATUS_ON);

					} else {
						touchPlayhead(e.getX());

					}
					dynamicLoadStatus = WC.STATUS_COMPLETE;
				}

			} else if (mouseState == WC.UI_STATE_TIMELINE_SELECT){
				dynamicLoadAppend();
			
			} else if (mouseState == WC.UI_STATE_CONTRAST) {
			
				mouseStateContrastNode = WC.STATUS_ERROR;

				if (userContrastRangeStatus == SELECTION_WORKING
						|| userContrastCPStatus == SELECTION_WORKING) {
					userContrastCPStatus = SELECTION_READY;
					userContrastRangeStatus = SELECTION_READY;

					resetContrastEtc();

					StringBuilder strBdr = new StringBuilder();
					strBdr.append("CONTRAST RANGE ");
					strBdr.append(userContrast[WC.START]);
					strBdr.append(" ");
					strBdr.append(userContrast[WC.END] * histClusterSize);
					userInterfaceInfoStr = strBdr.toString();
					tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
				}
			} else if (mouseState == WC.UI_STATE_KNOB_LOAD) {

			} else if (mouseState == WC.UI_STATE_KNOB_SKIP) {

			} else if (mouseState == WC.UI_STATE_KNOB_BURST) {

			} else if (mouseState == WC.UI_STATE_KNOB_RELOAD_TIMER) {

			} else if (mouseState == WC.UI_STATE_KNOB_RELOAD_BUFFER) {

			}

		}

		mouseState = WC.STATUS_READY;
	}

	public void determineIndexSca() {
		int maxLengthSca = 0;
		int maxLengthCount = 0;

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				if (witFrameList[flight][k].size() > maxLengthCount) {
					maxLengthCount = witFrameList[flight][k].size();
					maxLengthSca = k;
				}
			}

			indexSca[flight] = maxLengthSca;
		}
	}

	public void growUserSelectionT() {

	}

	public void translateSelectionToSCAs() {

		int leftSca = 0;
		int rightSca = 0;

		for (int i = 0; i < WC.TOTAL_SCAS - 1; i++) {
			userSelectionSCAtouched[i] = 0;
		}

		int fxMin = Math.min(userSelection[WC.START][WC.X],
				userSelection[WC.END][WC.X]);
		int fxMax = Math.max(userSelection[WC.START][WC.X],
				userSelection[WC.END][WC.X]);
		int fyMin = Math.min(userSelection[WC.START][WC.Y],
				userSelection[WC.END][WC.Y]);
		int fyMax = Math.max(userSelection[WC.START][WC.Y],
				userSelection[WC.END][WC.Y]);

		// System.out.println("Y SELECT " + fyMin + " " + fyMax);

		for (int i = 0; i < WC.TOTAL_SCAS; i++) {
			if (fxMin >= scaOffsets[i][WC.X]
					&& fxMin <= scaOffsets[i][WC.X] + WC.SCA_CHANNELS) {
				leftSca = i;
			}
			if (fxMax >= scaOffsets[i][WC.X]
					&& fxMax <= scaOffsets[i][WC.X] + WC.SCA_CHANNELS) {
				rightSca = i;
			}
		}

		for (int i = 0; i < WC.TOTAL_SCAS; i++) {
			userSelectionSCA[i][WC.START][WC.X] = -1;
			userSelectionSCA[i][WC.END][WC.X] = -1;
			userSelectionSCA[i][WC.START][WC.Y] = -1;
			userSelectionSCA[i][WC.END][WC.Y] = -1;
		}

		// assign processing areas on SCAs, left to right
		if (leftSca == rightSca) {
			userSelectionSCA[leftSca][WC.START][WC.X] = fxMin
					- scaOffsets[leftSca][WC.X];
			userSelectionSCA[leftSca][WC.END][WC.X] = fxMax
					- scaOffsets[leftSca][WC.X];

			userSelectionSCA[leftSca][WC.START][WC.Y] = fyMin
					- scaOffsets[leftSca][WC.Y];
			userSelectionSCA[leftSca][WC.END][WC.Y] = fyMax
					- scaOffsets[leftSca][WC.Y];

			userSelectionSCAtouched[leftSca] = 1;
			userSelectionSCAtouched[rightSca] = 1;
		} else {
			userSelectionSCA[leftSca][WC.START][WC.X] = fxMin
					- scaOffsets[leftSca][WC.X];
			userSelectionSCA[leftSca][WC.END][WC.X] = WC.SCA_CHANNELS;

			userSelectionSCA[leftSca][WC.START][WC.Y] = fyMin
					- scaOffsets[leftSca][WC.Y];
			userSelectionSCA[leftSca][WC.END][WC.Y] = fyMax
					- scaOffsets[leftSca][WC.Y];

			for (int i = leftSca + 1; i < rightSca; i++) {
				userSelectionSCA[i][WC.START][WC.X] = 0;
				userSelectionSCA[i][WC.END][WC.X] = WC.SCA_CHANNELS;

				userSelectionSCA[i][WC.START][WC.Y] = fyMin
						- scaOffsets[i][WC.Y];
				userSelectionSCA[i][WC.END][WC.Y] = fyMax - scaOffsets[i][WC.Y];
				userSelectionSCAtouched[i] = 1;
			}

			userSelectionSCA[rightSca][WC.START][WC.X] = 0;
			userSelectionSCA[rightSca][WC.END][WC.X] = fxMax
					- scaOffsets[rightSca][WC.X];

			userSelectionSCA[rightSca][WC.START][WC.Y] = fyMin
					- scaOffsets[rightSca][WC.Y];
			userSelectionSCA[rightSca][WC.END][WC.Y] = fyMax
					- scaOffsets[rightSca][WC.Y];

			userSelectionSCAtouched[leftSca] = 1;
			userSelectionSCAtouched[rightSca] = 1;
		}
	}

	public void mousePan(int x, int y) {

		x -= miniMapInsetSize[CURRENT][WC.X] / 2;
		y -= miniMapInsetSize[CURRENT][WC.Y] / 2;

		float xFrac = (float) (x - miniMapPos[CURRENT][WC.X])
				/ (float) (miniMapSize[CURRENT][WC.X] - miniMapInsetSize[CURRENT][WC.X]);// -miniMapInsetSize[CURRENT][WC.X]);
		userPanOffset[GOAL][WC.X] = xFrac * (float) (minPanX);// +(viewportX/2);//
		// + minPanX/2;

		float yFrac = (float) (y - miniMapPos[CURRENT][WC.Y])
				/ (float) (miniMapSize[CURRENT][WC.Y] - miniMapInsetSize[CURRENT][WC.Y]);// -miniMapInsetSize[CURRENT][WC.Y]);
		userPanOffset[GOAL][WC.Y] = yFrac * (float) (minPanY);// +(viewportY/2);//+
		// minPanY/2;

		// check limits
		if (userPanOffset[GOAL][WC.X] < minPanX) {
			userPanOffset[GOAL][WC.X] = minPanX;
		}
		if (userPanOffset[GOAL][WC.X] > maxPanX) {
			userPanOffset[GOAL][WC.X] = maxPanX;
		}
		if (userPanOffset[GOAL][WC.Y] < minPanY) {
			userPanOffset[GOAL][WC.Y] = minPanY;
		}
		if (userPanOffset[GOAL][WC.Y] > maxPanY) {
			userPanOffset[GOAL][WC.Y] = maxPanY;
		}

		userPanOffset[CURRENT][WC.X] = userPanOffset[GOAL][WC.X];
		userPanOffset[CURRENT][WC.Y] = userPanOffset[GOAL][WC.Y];

		miniMapInsetPos[CURRENT][WC.X] = (int) (userPanOffset[CURRENT][WC.X] * miniMapScale);
		miniMapInsetPos[CURRENT][WC.Y] = (int) (userPanOffset[CURRENT][WC.Y] * miniMapScale);

	}

	public void getMouse3dGlobe(int x, int y) {

	}

	public void getMouse3D(int x, int y) {

		// input is the reticule position

		// for SCA view, back out visualization transforms

		// undo scaling, translation
		float scale = view_scale[coordinateMode];

		float transX = view_trans[coordinateMode][WC.X];
		float transY = view_trans[coordinateMode][WC.Y];

		float transXHouse = 0;
		float transYHouse = 0;

		float finalY = y - transY;
		finalY = finalY / scale;

		float finalX = x - transX;
		finalX = finalX / scale;
	}

	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

		if (uiState == WC.UI_STATE_VIEW) {
			int posX = e.getX();
			int posY = e.getY();

			if (false) {

			} else {

				if (mouseState == WC.UI_STATE_PAN_VIEW) { // pan view of data

					int x = e.getX();
					int y = e.getY();
			
					if (coordinateMode == WC.COORDINATES_SENSOR) {

						float transIncX = (1f / (float) viewportGlX)
								* dragSpeed * (1f / view_scale[coordinateMode]);// *
						// view_scale[coordinateMode];
						float transIncY = (1f / (float) viewportGlY)
								* dragSpeed * aspectRatio
								* (1f / view_scale[coordinateMode]);// *
						// view_scale[coordinateMode];

						view_trans[coordinateMode][WC.X] += transIncX
								* ((float) x - (float) prevMouse3dX);
						view_trans[coordinateMode][WC.Y] += -transIncY
								* ((float) y - (float) prevMouse3dY);

						prevMouse3dX = x;
						prevMouse3dY = y;
					}
				} else if (mouseState == WC.UI_STATE_GLOBE_ROTATE) { // pan view
					// of
					// data
					// System.out.println("DRAG GLOBE");
					int x = e.getX();
					int y = e.getY();
					Dimension size = e.getComponent().getSize();

					float thetaY = 360.0f * ((float) (x - prevMouse3dX) / (float) size.width);
					float thetaX = 360.0f * ((float) (prevMouse3dY - y) / (float) size.height);

					prevMouse3dX = x;
					prevMouse3dY = y;

					view_rot[coordinateMode][WC.X] += thetaX;
					view_rot[coordinateMode][WC.Y] += thetaY;

				} else if (mouseState == WC.UI_STATE_LOS_ROTATE) { // pan view

					int x = e.getX();
					int y = e.getY();
					Dimension size = e.getComponent().getSize();

					float thetaY = 360.0f * ((float) (x - prevMouse3dX) / (float) size.width);
					float thetaX = 360.0f * ((float) (prevMouse3dY - y) / (float) size.height);

					prevMouse3dX = x;
					prevMouse3dY = y;

					los_error_rot[userFlight][WC.X] += thetaX;
					los_error_rot[userFlight][WC.Y] += thetaY;

				} else if (mouseState == WC.UI_STATE_PROCESS_WINDOW) { // selection
					// box for
					// processing

					if (coordinateMode == WC.COORDINATES_GLOBE) {
						int x = e.getX();
						int y = e.getY();

						// if (e.isShiftDown() == true) {

						if (mouseState == WC.STATUS_READY
								|| mouseState == WC.UI_STATE_PROCESS_WINDOW) {

							cursorX = posX + cursorUnblockX;
							cursorY = glCanvas.getHeight()
									- (posY + cursorUnblockY);

							if (lensMagnifyActive == 1) {

								lensPosX = cursorX;
								lensPosY = cursorY;

							}

							userSelection[WC.END][WC.X] = cursorX;
							userSelection[WC.END][WC.Y] = cursorY;

							selectionStatus = SELECTION_WORKING;
						}
				
					} else if (coordinateMode == WC.COORDINATES_MERCATOR) {
						int x = e.getX();
						int y = e.getY();

						// if (e.isShiftDown() == true) {

						if (mouseState == WC.STATUS_READY
								|| mouseState == WC.UI_STATE_PROCESS_WINDOW) {

							cursorX = posX + cursorUnblockX;
							cursorY = glCanvas.getHeight()
									- (posY + cursorUnblockY);

							if (lensMagnifyActive == 1) {

								lensPosX = cursorX;
								lensPosY = cursorY;

							}

							userSelection[WC.END][WC.X] = cursorX;
							userSelection[WC.END][WC.Y] = cursorY;

							selectionStatus = SELECTION_WORKING;

						} else {
							

							float transIncX = (1f / (float) viewportGlX)
									* dragSpeed;
							float transIncY = (1f / (float) viewportGlY)
									* dragSpeed * aspectRatio;

							view_trans[coordinateMode][WC.X] += transIncX
									* ((float) x - (float) prevMouse3dX);
							view_trans[coordinateMode][WC.Y] += -transIncY
									* ((float) y - (float) prevMouse3dY);

							prevMouse3dX = x;
							prevMouse3dY = y;
						}
					} else if (coordinateMode == WC.COORDINATES_SENSOR) {
						int x = e.getX();
						int y = e.getY();

						// if (e.isShiftDown() == true) {

						if (mouseState == WC.STATUS_READY
								|| mouseState == WC.UI_STATE_PROCESS_WINDOW) {

							cursorX = posX + cursorUnblockX;
							cursorY = glCanvas.getHeight()
									- (posY + cursorUnblockY);

							if (lensMagnifyActive == 1) {

								// createLens(posX, posY);
								lensPosX = cursorX;
								lensPosY = cursorY;

							}

							userSelection[WC.END][WC.X] = cursorX;
							userSelection[WC.END][WC.Y] = cursorY;

							// translateSelectionToSCAs();

							selectionStatus = SELECTION_WORKING;
						}
					}

				} else if (mouseState == WC.UI_STATE_TIMELINE_SELECT) {
					touchLoopSelector(posX);
				} else if (mouseState == WC.UI_STATE_TIMELINE_LOAD) { // modify
					// playhead

					touchPlayhead(posX);

				} else if (mouseState == WC.UI_STATE_CONTRAST) {
				
					cursorX = posX + cursorUnblockX;
					cursorY = glCanvas.getHeight() - (posY + cursorUnblockY);

					int specialEditFlag = WC.CONTRAST_UI_SPECIAL_EDIT_NONE;
					if (e.isShiftDown() == true) {
						specialEditFlag = WC.CONTRAST_UI_SPECIAL_EDIT_MOVE_ALL;
					}

					touchGlContrastSelectorLinear(cursorY, specialEditFlag);
				
				} else if (mouseState == WC.UI_STATE_KNOB_LOAD) {
					int y = e.getY();
					int x = e.getX();
					if (y < prevMouse3dY || x > prevMouse3dX) {
						if (loadSeconds <= MID_LOAD_SECONDS) {
							setLoadFrames(
									(int) (loadSeconds + INC_LOAD_SECONDS1),
									-1, -1);
						} else {
							setLoadFrames(
									(int) (loadSeconds + INC_LOAD_SECONDS2),
									-1, -1);
						}
					} else if (y > prevMouse3dY || x < prevMouse3dX) {
						if (loadSeconds <= MID_LOAD_SECONDS) {
							setLoadFrames(
									(int) (loadSeconds - INC_LOAD_SECONDS1),
									-1, -1);
						} else {
							if (loadSeconds <= MID_LOAD_SECONDS
									+ INC_LOAD_SECONDS2) {
								setLoadFrames(
										(int) (loadSeconds - INC_LOAD_SECONDS1),
										-1, -1);
							} else {
								setLoadFrames(
										(int) (loadSeconds - INC_LOAD_SECONDS2),
										-1, -1);
							}

						}
					}
					prevMouse3dY = y;
					prevMouse3dX = x;
				} else if (mouseState == WC.UI_STATE_KNOB_SKIP) {
					int y = e.getY();
					int x = e.getX();
					if (y < prevMouse3dY || x > prevMouse3dX) {
						if (skipSeconds <= MID_SKIP_SECONDS) {
							setLoadFrames(-1,
									(int) (skipSeconds + INC_SKIP_SECONDS1), -1);
						} else {
							setLoadFrames(-1,
									(int) (skipSeconds + INC_SKIP_SECONDS2), -1);
						}
					} else if (y > prevMouse3dY || x < prevMouse3dX) {
						if (skipSeconds <= MID_SKIP_SECONDS) {
							setLoadFrames(-1,
									(int) (skipSeconds - INC_SKIP_SECONDS1), -1);
						} else {
							if (skipSeconds <= MID_SKIP_SECONDS
									+ INC_SKIP_SECONDS2) {
								setLoadFrames(
										-1,
										(int) (skipSeconds - INC_SKIP_SECONDS1),
										-1);
							} else {
								setLoadFrames(
										-1,
										(int) (skipSeconds - INC_SKIP_SECONDS2),
										-1);
							}

						}
					}
					prevMouse3dY = y;
					prevMouse3dX = x;
				} else if (mouseState == WC.UI_STATE_KNOB_BURST) {
					
					int y = e.getY();
					int x = e.getX();
					if (y < prevMouse3dY || x > prevMouse3dX) {
						if (burstSeconds <= MID_BURST_SECONDS) {
							setLoadFrames(-1, -1,
									(int) (burstSeconds + INC_BURST_SECONDS1));
						} else {
							setLoadFrames(-1, -1,
									(int) (burstSeconds + INC_BURST_SECONDS2));
						}
					} else if (y > prevMouse3dY || x < prevMouse3dX) {
						if (burstSeconds <= MID_BURST_SECONDS) {
							setLoadFrames(-1, -1,
									(int) (burstSeconds - INC_BURST_SECONDS1));
						} else {
							if (burstSeconds <= MID_BURST_SECONDS
									+ INC_BURST_SECONDS2) {
								setLoadFrames(
										-1,
										-1,
										(int) (burstSeconds - INC_BURST_SECONDS1));
							} else {
								setLoadFrames(
										-1,
										-1,
										(int) (burstSeconds - INC_BURST_SECONDS2));
							}
						}
					}
					prevMouse3dY = y;
					prevMouse3dX = x;
				} else if (mouseState == WC.UI_STATE_KNOB_RELOAD_TIMER) {
					
					int y = e.getY();
					int x = e.getX();
					if (y < prevMouse3dY || x > prevMouse3dX) {
						if (autoReloadTimerSeconds <= MID_RELOAD_TIMER_SECONDS) {
							setAutoReload(
									-1,
									(int) (autoReloadTimerSeconds + INC_RELOAD_TIMER_SECONDS1),-1);
						} else {
							setAutoReload(
									-1,
									(int) (autoReloadTimerSeconds + INC_RELOAD_TIMER_SECONDS2),-1);
						}
					} else if (y > prevMouse3dY || x < prevMouse3dX) {
						if (autoReloadTimerSeconds <= MID_RELOAD_TIMER_SECONDS) {
							setAutoReload(
									-1,
									(int) (autoReloadTimerSeconds - INC_RELOAD_TIMER_SECONDS1),-1);
						} else {
							if (autoReloadTimerSeconds <= MID_RELOAD_TIMER_SECONDS
									+ INC_RELOAD_TIMER_SECONDS2) {
								setAutoReload(
										-1,
										(int) (autoReloadTimerSeconds - INC_RELOAD_TIMER_SECONDS1),-1);
							} else {
								setAutoReload(
										-1,
										(int) (autoReloadTimerSeconds - INC_RELOAD_TIMER_SECONDS2), -1);
							}
						}
					}
					
					prevMouse3dY = y;
					prevMouse3dX = x;
				}  else if (mouseState == WC.UI_STATE_KNOB_RELOAD_BUFFER) {
					
					int y = e.getY();
					int x = e.getX();
					if (y < prevMouse3dY || x > prevMouse3dX) {
						if (autoReloadBufferSeconds <= MID_RELOAD_BUFFER_SECONDS) {
							setAutoReload(
									-1, -1,
									(int) (autoReloadBufferSeconds + INC_RELOAD_BUFFER_SECONDS1));
						} else {
							setAutoReload(
									-1, -1,
									(int) (autoReloadBufferSeconds + INC_RELOAD_BUFFER_SECONDS2));
						}
					} else if (y > prevMouse3dY || x < prevMouse3dX) {
						if (autoReloadBufferSeconds <= MID_RELOAD_BUFFER_SECONDS) {
							setAutoReload(
									-1, -1,
									(int) (autoReloadBufferSeconds - INC_RELOAD_BUFFER_SECONDS1));
						} else {
							if (autoReloadBufferSeconds <= MID_RELOAD_BUFFER_SECONDS
									+ INC_RELOAD_BUFFER_SECONDS2) {
								setAutoReload(
										-1, -1,
										(int) (autoReloadBufferSeconds - INC_RELOAD_BUFFER_SECONDS1));
							} else {
								setAutoReload(
										-1, -1,
										(int) (autoReloadBufferSeconds - INC_RELOAD_BUFFER_SECONDS2));
							}
						}
					}
					
					prevMouse3dY = y;
					prevMouse3dX = x;
				}
			}
		}
	}


	public void mouseMoved(MouseEvent e) {

		if (uiState == WC.UI_STATE_VIEW
				&& coordinateMode == WC.COORDINATES_WIT_UI_OLDSCHOOL) {
			int posX = e.getX();
			int posY = e.getY();

			cursorX = posX + cursorUnblockX;
			cursorY = posY + cursorUnblockY;

			// mouseOverSCA = getMouseOverSCA(cursorX, cursorY);
			if (mouseOverSCA != mouseOverSCAprev) {
				
			}
			mouseOverSCAprev = mouseOverSCA;

			if (lensMagnifyActive == 1) {


				lensPosX = cursorX;
				lensPosY = cursorY;
			}

			if (posY > tivoStatusBarY) {
				timelineMouseoverX = posX - tivoInfoBarX;

			} else {

				timelineMouseoverX = -1;
			}
			// add the GPU picking code
			System.out.println("LAT LON ");

		}

		if (uiState == WC.UI_STATE_CONTRAST) {

			int posX = e.getX();
			int posY = e.getY();

			cursorX = posX + cursorUnblockX;
			cursorY = posY + cursorUnblockY;

			// mouseOverSCA = getMouseOverSCA(cursorX, cursorY);

			if (lensMagnifyActive == 1) {

				// createLens(posX, posY);

				lensPosX = cursorX;
				lensPosY = cursorY;

			}
		}

		// allow interpolation on GPUs
		if (coordinateMode != WC.COORDINATES_WIT_UI_OLDSCHOOL) {
			int posX = e.getX();
			int posY = e.getY();

			cursorX = posX + cursorUnblockX;
			cursorY = posY + cursorUnblockY;

			// getMouse3D(posX, posY);

			getMouseGlSensorPlane(cursorX, cursorY);
			// getMouse3dGlobe(cursorX, cursorY);
		}
	}

	public void checkCoordFrameBounds() {

	}

	public void getMouseGlSensorPlane(int cursorX, int cursorY) {


		float scaToScreenRatio = WC.SENSOR_PLANE_SCALE;
		// float scaToScreenRatio = WC.SENSOR_PLANE_SCALE;

		float distOriginX1 = cursorX - (viewportGlX / 2f);
		float distOriginY1 = cursorY - (viewportGlY / 2f);

		float distOriginX0 = distOriginX1;
		float distOriginY0 = distOriginY1;

		distOriginX1 /= (view_scale[coordinateMode]);
		distOriginY1 /= (view_scale[coordinateMode]);

		// pixel space // distance to center
		float distOriginX2 = cursorX - (viewportGlX / 2f);
		float distOriginY2 = cursorY - (viewportGlY / 2f);

		distOriginX2 -= view_trans[coordinateMode][WC.X];
		distOriginY2 -= view_trans[coordinateMode][WC.Y];

		distOriginX2 /= view_scale[coordinateMode];
		distOriginY2 /= view_scale[coordinateMode];

	}

	public void createLens(int x, int y) {

		userInterfaceInfoStr = "CURSOR " + x + " " + y;
		lensStatus = WC.STATUS_WORKING;

		// create magnified image

		lensStatus = WC.STATUS_COMPLETE;
	}

	public void restoreState(int mode) {

		try {
			File loadFile = null;

			if (mode == RESTORE_STATE_ON_LAUNCH) {
				loadFile = new File(tivoRootDir + tivoLoadFile);
			} else if (mode == SAVE_STATE_DIALOG_BOX) {
				JFileChooser fc = new JFileChooser();
				fc.setCurrentDirectory(new File(tivoRootDir));
				fc.showOpenDialog(cvt);
				loadFile = fc.getSelectedFile();
			}

			if (loadFile != null) {
				System.out.println("RESTORING SESSION FROM FILE "
						+ loadFile.getAbsoluteFile());
				BufferedReader bin = new BufferedReader(
						new FileReader(loadFile));

				// load the file
				String fileContents = "";

				while (bin.ready()) {
					String ln = bin.readLine();
					fileContents += ln;
				}
				// System.out.println(fileContents);
				// parse manually or with XML classes

				String varName = "";

				String vars[] = fileContents.split("</");
				for (int i = 0; i < vars.length; i++) {
					// System.out.println(vars[i]);
					varName = "witSCAPlayhead";
					if (vars[i].contains("<" + varName + ">")) {
						witSCAPlayhead[userFlight][0] = Integer // REVISIT
								.parseInt(vars[i]
										.substring(
												vars[i].lastIndexOf(">") + 1,
												vars[i].length()));

					}
					varName = "tivoPlayheadMin";
					if (vars[i].contains("<" + varName + ">")) {
						loopStart = Integer.parseInt(vars[i].substring(vars[i]
								.lastIndexOf(">") + 1, vars[i].length()));
					}
					varName = "tivoPlayheadMax";
					if (vars[i].contains("<" + varName + ">")) {
						loopEnd = Integer.parseInt(vars[i].substring(vars[i]
								.lastIndexOf(">") + 1, vars[i].length()));
					}

					varName = "tivoPlayheadBuffer";
					if (vars[i].contains("<" + varName + ">")) {
						tivoPlayheadBuffer = Integer.parseInt(vars[i]
								.substring(vars[i].lastIndexOf(">") + 1,
										vars[i].length()));
					}
					varName = "loopMode";
					if (vars[i].contains("<" + varName + ">")) {
						loopMode = Integer.parseInt(vars[i].substring(vars[i]
								.lastIndexOf(">") + 1, vars[i].length()));
					}
					varName = "systemPlaybackRate";
					if (vars[i].contains("<" + varName + ">")) {
						systemPlaybackRate = Integer.parseInt(vars[i]
								.substring(vars[i].lastIndexOf(">") + 1,
										vars[i].length()));
					}
					varName = "systemPlaybackRatePause";
					if (vars[i].contains("<" + varName + ">")) {
						systemPlaybackRatePause = Integer.parseInt(vars[i]
								.substring(vars[i].lastIndexOf(">") + 1,
										vars[i].length()));
					}

					varName = "selectionStatus";
					if (vars[i].contains("<" + varName + ">")) {
						selectionStatus = Integer
								.parseInt(vars[i]
										.substring(
												vars[i].lastIndexOf(">") + 1,
												vars[i].length()));
					}
					varName = "selectionTimeStatus";
					if (vars[i].contains("<" + varName + ">")) {
						selectionTimeStatus = Integer.parseInt(vars[i]
								.substring(vars[i].lastIndexOf(">") + 1,
										vars[i].length()));
					}

					for (int j = 0; j < 2; j++) {
						for (int k = 0; k < 3; k++) {

							varName = "userSelection_" + j + "_" + k;
							if (vars[i].contains("<" + varName + ">")) {
								userSelection[j][k] = Integer.parseInt(vars[i]
										.substring(
												vars[i].lastIndexOf(">") + 1,
												vars[i].length()));
							}
						}
					}

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void initPriorities() {

		for (int m = 0; m < WC.MODE_COUNT; m++) {
			threadPriorities[m] = WC.THREAD_PRIORITY_DEFAULT;
		}

		threadPriorities[WC.THREAD_LOAD] = 7;
		threadPriorities[WC.THREAD_DIFF] = 1;
		threadPriorities[WC.THREAD_EXPORT_VIDEO] = 1;
		threadPriorities[WC.THREAD_EXPORT_WEATHER_VIDEO] = 1;
		threadPriorities[WC.THREAD_HISTOGRAM] = 1;
		threadPriorities[WC.THREAD_HISTOGRAM_EQ] = 1;
		threadPriorities[WC.THREAD_TEMPORAL] = 2;
		threadPriorities[WC.THREAD_DEJITTER] = 3;

	}

	public void initTimeouts() {

		for (int m = 0; m < WC.MODE_COUNT; m++) {
			threadTimeouts[m] = WC.THREAD_TIMEOUT_DEFAULT;
		}

	}

	public void initParamLists() {
		paramLists = new ArrayList[WC.TOTAL_SCAS][WC.MODE_COUNT];
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			for (int m = 0; m < WC.MODE_COUNT; m++) {
				paramLists[k][m] = new ArrayList();
				paramLists[k][m].add(defaultInputSrc); 

			}
		}
	}

	public void createParamList(int mode, int scaID) {
		System.out.println("CREATING PARAMS FOR " + opIdToName(mode));

		int fxMin = userSelectionSCA[scaID][WC.START][WC.X];
		int fxMax = userSelectionSCA[scaID][WC.END][WC.X];
		int fyMin = userSelectionSCA[scaID][WC.START][WC.Y];
		int fyMax = userSelectionSCA[scaID][WC.END][WC.Y];

		int ftMin = userSelection[WC.START][WC.T];
		int ftMax = userSelection[WC.END][WC.T];

		if ((fyMax - fyMin > 0 && fxMax - fxMin > 0)
				|| selectionStatus != SELECTION_WORKING) {

			// each sca may have varying region needing to be processed

			if (mode == WC.THREAD_DIFF) {
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(WC.THREAD_CONTRAST); // load source
				// paramLists[scaID][mode].add(defaultInputSrc); // load source

				// user's filter region
				paramLists[scaID][mode].add(0);
				paramLists[scaID][mode].add(fxMax - fxMin);
				paramLists[scaID][mode].add(0);
				paramLists[scaID][mode].add(fyMax - fyMin);

				paramLists[scaID][mode].add(ftMin);
				paramLists[scaID][mode].add(ftMax);

				paramLists[scaID][mode].add(diffSkip);
				paramLists[scaID][mode].add(SCAN_DIR_BOTH);

			} else if (mode == WC.THREAD_REGISTRATION) {
				paramLists[scaID][mode] = new ArrayList();
				// paramLists[scaID][mode].add(defaultInputSrc); // load source
				
				paramLists[scaID][mode].add(WC.THREAD_LOAD_HDF5R); // load
				// source

				// user's filter region
				paramLists[scaID][mode].add(fxMin);
				paramLists[scaID][mode].add(fxMax);
				paramLists[scaID][mode].add(fyMin);
				paramLists[scaID][mode].add(fyMax);

				paramLists[scaID][mode].add(ftMin);
				paramLists[scaID][mode].add(ftMax);

				paramLists[scaID][mode].add(playbackModeDir[userFlight]);

			} else if (mode == WC.THREAD_SCAN_DIR_Y_OFFSET) {
				paramLists[scaID][mode] = new ArrayList();

				paramLists[scaID][mode].add(WC.THREAD_LOAD_HDF5R); 


				paramLists[scaID][mode].add(ftMin);
				paramLists[scaID][mode].add(ftMax);

				System.out.println("CREATE Y PARAMS");

			} else if (mode == WC.THREAD_TIMELAPSE) {
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(WC.THREAD_DIFF); 

				paramLists[scaID][mode].add(0);
				paramLists[scaID][mode].add(fxMax - fxMin);
				paramLists[scaID][mode].add(0);
				paramLists[scaID][mode].add(fyMax - fyMin);

				paramLists[scaID][mode].add(ftMin);
				paramLists[scaID][mode].add(ftMax);

				paramLists[scaID][mode].add(timelapseHistory);
				paramLists[scaID][mode].add(timelapseSkip);

				paramLists[scaID][mode].add(SCAN_DIR_BOTH);

			} else if (mode == WC.THREAD_CONTRAST) {
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(defaultInputSrc); // load source

				// user's filter region
				paramLists[scaID][mode].add(fxMin);
				paramLists[scaID][mode].add(fxMax);
				paramLists[scaID][mode].add(fyMin);
				paramLists[scaID][mode].add(fyMax);

				paramLists[scaID][mode].add(ftMin);
				paramLists[scaID][mode].add(ftMax);

				paramLists[scaID][mode].add(contrastMode);
				paramLists[scaID][mode].add(userContrast[WC.START]
						* histClusterSize);
				paramLists[scaID][mode].add(userContrast[WC.END]
						* histClusterSize);
				paramLists[scaID][mode].add(userContrastCPList);
			} else if (mode == WC.THREAD_LOAD_HDF5R) {
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(scaID); // load source

			} else if (mode == WC.THREAD_HISTOGRAM) {
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(ftMin);
				paramLists[scaID][mode].add(ftMax);
			} else if (mode == WC.THREAD_PREFILTER) {
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(defaultInputSrc); // load source

			} else if (mode == WC.THREAD_GPU_OPENCL_TEST) {
				
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(WC.THREAD_LOAD_HDF5R); // load source
			
				paramLists[scaID][mode].add(ftMin);
				paramLists[scaID][mode].add(ftMax);
				
				int framesPerOclDispatch = 1;//10;
				paramLists[scaID][mode].add(framesPerOclDispatch); 
				int framesToSum = 16;
				paramLists[scaID][mode].add(framesToSum); 

				paramLists[scaID][mode].add(playbackModeDir[userFlight]); // 5
				paramLists[scaID][mode].add(playbackScanSeqIndexMask[userFlight]); //6
				
			}

		}
		
	}

	public void initTivoBars() {

		tivoStatusBarYRay = new int[20]; 
		for (int i = 0; i < tivoStatusBarYRay.length; i++) {
			tivoStatusBarYRay[i] = tivoStatusBarY + (tivoBarYSeparation) * i
					+ 40;
		}
	}

	public void initUserContrast() {
		
		userContrast[WC.START] = 0;
		userContrast[WC.END] = 50;
	}

	public void initLayerProperties() {

		for (int i = 0; i < WC.MODE_COUNT; i++) {
			rasterLayerOrder[i] = RASTER_OMIT; // set to 'not drawn'
			rasterLayerOpa[i][CURRENT] = 0.0f;
			rasterLayerOpa[i][GOAL] = 0.0f;

			defaultOpOpacity[i] = 1f;

			// not drawn
			for (int k = 0; k < 3; k++) {
				timelineLayerOrder[i][k] = -1;
			}
		}

		defaultOpOpacity[WC.THREAD_CONTRAST] = 1.0f;

		defaultOpOpacity[WC.THREAD_REGISTRATION] = 1.0f;

		rasterLayerOpa[WC.THREAD_LOAD][GOAL] = 1.0f;
		rasterLayerOpa[WC.THREAD_LOAD_HDF5R][GOAL] = 1.0f;
		// no delay on raw data
		rasterLayerOpa[WC.THREAD_LOAD][CURRENT] = 1.0f;
		rasterLayerOpa[WC.THREAD_LOAD_HDF5R][CURRENT] = 1.0f;

		rasterLayerOrder[0] = WC.THREAD_LOAD_HDF5R;

		rasterLayerOrder[2] = WC.THREAD_GPU_FRAG_CONTRAST;
		rasterLayerOrder[3] = WC.THREAD_GPU_FRAG_DIFF;
		rasterLayerOrder[4] = WC.THREAD_GPU_FRAG_DWT;
		rasterLayerOrder[6] = WC.THREAD_GPU_FRAG_CONTRAST;

		rasterLayerOrder[5] = WC.THREAD_SCAN_DIR_Y_OFFSET;

		rasterLayerOrder[7] = WC.THREAD_REGISTRATION;

		timelineLayerOrder[WC.THREAD_GPU_FRAG_DWT][WC.Y] = 6;
		timelineLayerOrder[WC.THREAD_GPU_FRAG_DWT][WC.Z] = 0;

		timelineLayerOrder[WC.THREAD_GPU_FRAG_DIFF][WC.Y] = 5;
		timelineLayerOrder[WC.THREAD_GPU_FRAG_DIFF][WC.Z] = 0;

		timelineLayerOrder[WC.THREAD_GPU_FRAG_TIMELAPSE][WC.Y] = 7;
		timelineLayerOrder[WC.THREAD_GPU_FRAG_TIMELAPSE][WC.Z] = 0;

		timelineLayerOrder[WC.THREAD_GPU_FRAG_CONTRAST][WC.Y] = 8;
		timelineLayerOrder[WC.THREAD_GPU_FRAG_CONTRAST][WC.Z] = 0;


	}

	public void initOpBuffers() {
		witOpBuffers = new int[WC.MODE_COUNT];
		for (int m = 0; m < WC.MODE_COUNT; m++) {
			witOpBuffers[m] = WIT_OP_BUFFER_DEFAULT;
		}

		witOpBuffers[WC.THREAD_HISTOGRAM] = 20; // computationally light
		witOpBuffers[WC.THREAD_DIFF] = 2;// 10;
		witOpBuffers[WC.THREAD_CONTRAST] = 2;// 10;
		witOpBuffers[WC.THREAD_REGISTRATION] = 2;
		witOpBuffers[WC.THREAD_TIMELAPSE] = 1; // computationally expensive
		// threadTimeouts[WC.THREAD_TEMPORAL] = WC.THREAD_TIMEOUT_DEFAULT*100;
	}

	// !!TODO
	// show what files are actually loaded in the timelin
	public static void whatFilesLoaded() {

	}

	// save state so system can restart
	public void saveState(int mode) {

		whatFilesLoaded();

		try {

			File saveFile = null;

			// current session
			if (mode == SAVE_STATE_ON_EXIT) {
				saveFile = new File(tivoRootDir + tivoSaveFile);
			} else if (mode == SAVE_STATE_DIALOG_BOX) {
				JFileChooser fc = new JFileChooser();
				fc.setCurrentDirectory(new File(tivoRootDir));
				fc.showSaveDialog(cvt);
				saveFile = fc.getSelectedFile();
			}

			if (saveFile != null) {

				BufferedWriter bout = new BufferedWriter(new FileWriter(
						saveFile));

				String fileContents = "";
				String fileElement = "";

				// playhead position
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					fileElement = "<witSCAPlayhead>"
							+ witSCAPlayhead[userFlight][k]
							+ "</witSCAPlayhead>";
				}
				fileContents += fileElement + "\n";
				fileElement = "<tivoPlayheadMin>" + loopStart
						+ "</tivoPlayheadMin>";
				fileContents += fileElement + "\n";
				fileElement = "<tivoPlayheadMax>" + loopEnd
						+ "</tivoPlayheadMax>";
				fileContents += fileElement + "\n";
				fileElement = "<tivoPlayheadBuffer>" + tivoPlayheadBuffer
						+ "</tivoPlayheadBuffer>";
				fileContents += fileElement + "\n";

				fileElement = "<loopMode>" + loopMode + "</loopMode>";
				fileContents += fileElement + "\n";

				fileElement = "<systemPlaybackRate>" + systemPlaybackRate
						+ "</systemPlaybackRate>";
				fileContents += fileElement + "\n";
				fileElement = "<systemPlaybackRatePause>"
						+ systemPlaybackRatePause
						+ "</systemPlaybackRatePause>";
				fileContents += fileElement + "\n";

				for (int j = 0; j < 2; j++) {
					for (int k = 0; k < 3; k++) {

						fileElement = "<userSelection_" + j + "_" + k + ">"
								+ userSelection[j][k] + "</userSelection_" + j
								+ "_" + k + ">";
						fileContents += fileElement + "\n";
					}
				}
				fileElement = "<selectionStatus>" + selectionStatus
						+ "</selectionStatus>";
				fileContents += fileElement + "\n";
				fileElement = "<selectionTimeStatus>" + selectionTimeStatus
						+ "</selectionTimeStatus>";
				fileContents += fileElement + "\n";

				// save user settings re: visible layers
				for (int i = 0; i < 4; i++) {
					fileElement = "<viewMask_" + i + ">" + viewMask[i]
							+ "</viewMask_" + i + ">";
					fileContents += fileElement + "\n";
				}
				// save user settings re: filter / processing operations
				for (int i = 0; i < WC.MODE_COUNT; i++) {
					fileElement = "<opMask_" + i + ">" + opMask[i]
							+ "</opMask_" + i + ">";
					fileContents += fileElement + "\n";
				}

				bout.write(fileContents);
				bout.close();

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void displayChanged(GLAutoDrawable arg0, boolean arg1, boolean arg2) {
		// TODO Auto-generated method stub

	}

	public void reshape(GLAutoDrawable drawable, int x, int y, int width,
			int height) {

		GL2 gl = drawable.getGL().getGL2();

		// gl = glu.getCurrentGL();

		if (height == 0)
			height = 1;

		gl.glMatrixMode(GL2.GL_PROJECTION);
		gl.glLoadIdentity();
		float h = (float) height / (float) width;

		gl.glViewport(0, 0, width, height);

		gl.glMatrixMode(GL2.GL_MODELVIEW);
		gl.glLoadIdentity();
		gl.glViewport(0, 0, width, height);

	}

	public void mouseWheelMoved(MouseWheelEvent e) {
		// TODO Auto-generated method stub

		float mouseVal = e.getWheelRotation();
		float zoomInc = view_scale[coordinateMode] / 10f;// .05f;

		float transIncX = (1f / (float) viewportGlX) * dragSpeed
				* (1f / view_scale[coordinateMode]);// *
		// view_scale[coordinateMode];
		float transIncY = (1f / (float) viewportGlY) * dragSpeed * aspectRatio
				* (1f / view_scale[coordinateMode]);// *

		float priorZoom = view_scale[coordinateMode];
		if (mouseVal < 0) {
			view_scale[coordinateMode] += zoomInc;
		} else if (mouseVal > 0) {
			view_scale[coordinateMode] -= zoomInc;
		}

		// check bounds
		if (view_scale[coordinateMode] < userScale3DMin) {
			view_scale[coordinateMode] = userScale3DMin;
		}
		if (view_scale[coordinateMode] > userScale3DMax) {
			view_scale[coordinateMode] = userScale3DMax;
		}

		// zoom according to mouse position
		if (coordinateMode == WC.COORDINATES_SENSOR) {

			int x = e.getX();
			int y = e.getY();

			float dX = (float) (x - viewportGlX / 2f)
					* (1f / (float) viewportGlX);
			float dY = (float) (y - viewportGlY / 2f)
					* (1f / (float) viewportGlY);
			
			float transIncX2 = (1f / (float) viewportGlX)
					* (1f / view_scale[coordinateMode]);// *
	
			float transIncY2 = (1f / (float) viewportGlY) * aspectRatio
					* (1f / view_scale[coordinateMode]);// *
	
			view_trans[coordinateMode][WC.X] += transIncX2 * -dX;
			view_trans[coordinateMode][WC.Y] += transIncY2 * -dY;

		}
	}

	@Override
	public void dispose(GLAutoDrawable drawable) {
		// TODO Auto-generated method stub
		System.out.println("dispose");
	}

	@Override
	public void componentHidden(ComponentEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void componentMoved(ComponentEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void componentResized(ComponentEvent e) {
		// TODO Auto-generated method stub
		cvt.viewportGlX = cvt.getWidth();
		cvt.viewportGlY = cvt.getHeight();
		cvt.viewportX = cvt.getWidth();
		cvt.viewportY = cvt.getHeight();
		// cvt.setSize(cvt.viewportX, cvt.viewportY);
		cvt.initUIDims();

		cvt.initTivoBars();

		cvt.aspectRatio = (float) cvt.viewportGlY / (float) cvt.viewportGlX;

	}

	@Override
	public void componentShown(ComponentEvent e) {
		// TODO Auto-generated method stub

	}

}
