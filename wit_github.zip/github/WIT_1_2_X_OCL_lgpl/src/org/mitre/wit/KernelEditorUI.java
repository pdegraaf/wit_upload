/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

/** @author Adrian Johnson **/
 
package org.mitre.wit;

import java.awt.Canvas;
import java.awt.Checkbox;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.TextField;

import javax.swing.JFrame;

public class KernelEditorUI extends JFrame{
	
	static KernelEditorUI keui;
	static CV_MT_GPU_WIT_1_2 cvt = null;
	
	static Canvas canvas;

	static int tfRaySpaceX = 40;
	static int tfRayMarginX = 2;
	
	static int dwtCanvasH = 200;
	static int dwtCanvasW = WC.DWT_BUFFER_COUNT*(tfRayMarginX+tfRaySpaceX)+tfRayMarginX;
	
	static int dwtH = 400;
	static int dwtW = dwtCanvasW;
	
	static boolean enforceSymmetry = true;
	static boolean enforceZeroSum = false;
	static boolean enforceOneSum = false;
	
	float kernelCoefficients[];
	
	int kernelCoefRasterX[];
	int kernelCoefRasterY[];
	
	static TextField textBoxRay[];
	
	static Checkbox checkboxSymmetry;
	 
	static Choice dwtPresets;
	
	public static void init(){
		
		keui = new KernelEditorUI();
		
		keui.setLayout(null);
		
		keui.setTitle("KERNEL EDITOR");
		keui.setVisible(true);

		keui.setSize(dwtW, dwtH);
		
		keui.checkboxSymmetry = new Checkbox();
		keui.checkboxSymmetry.setLabel("Symmetry");
		
		canvas = new Canvas();
		canvas.setSize(dwtCanvasW, dwtCanvasH);
		
		canvas.setBackground(Color.BLACK);
		
		if (keui.cvt != null){
			keui.kernelCoefficients = cvt.dwtKernel;
		}

		keui.textBoxRay = new TextField[WC.DWT_BUFFER_COUNT];
		
		
		for (int i=0; i< WC.DWT_BUFFER_COUNT; i++){
			keui.textBoxRay[i] = new TextField();
			keui.textBoxRay[i].setSize(tfRaySpaceX, 20);
			keui.textBoxRay[i].setLocation(i*(tfRaySpaceX+tfRayMarginX), dwtH-50);
			keui.textBoxRay[i].setVisible(true);
			keui.textBoxRay[i].setBackground(Color.black);
			keui.textBoxRay[i].setForeground(Color.white);
			keui.add(keui.textBoxRay[i]);
			System.out.println("ADDED FIELD");
		}

		keui.add(canvas);
		
		
		keui.updateRasterPos();
		keui.updateTextFields();
	}
	
	public void updateTextFields(){

		if (keui.cvt != null && keui.kernelCoefficients != null){
		for (int i=0; i< WC.DWT_BUFFER_COUNT; i++){
			keui.textBoxRay[i].setText(keui.kernelCoefficients[i]+"");
		}
		}
		
	}
	
	public void updateRasterPos(){
		if (kernelCoefficients != null){
		kernelCoefRasterX = new int[kernelCoefficients.length];
		kernelCoefRasterY = new int[kernelCoefficients.length];

		float spaceX = (int)((float)dwtCanvasW/(float)(keui.kernelCoefficients.length+1));
		float offsetY = 10;
		
		float scaleY = 10f;
		
		int marginX = 10;

		for (int i=0; i<keui.kernelCoefficients.length; i++){
			kernelCoefRasterX[i] = marginX+(int)(spaceX*(float)i);

			kernelCoefRasterY[i] = (int)(offsetY-keui.kernelCoefficients[i]*scaleY);
		}
		}
	}
	
	public void restoreKernel(int kernelId){
		float[] blurKer = null;
		cvt.setKernel(blurKer);
		
	}
	
	public void paintCanvas(){
		Graphics2D g = (Graphics2D)canvas.getGraphics();
		
		g.setColor(Color.black);
		g.fillRect(0, 0, dwtCanvasW, dwtCanvasH);
		
		g.setColor(Color.red);
		
		float scale = 10f;
		
		keui.updateRasterPos();
		
		if (keui.kernelCoefficients != null  && kernelCoefRasterX != null && kernelCoefRasterY != null ){

		
		for (int i=0; i<keui.kernelCoefficients.length-1; i++){
			g.drawLine(kernelCoefRasterX[i], kernelCoefRasterY[i], kernelCoefRasterX[i+1], kernelCoefRasterY[i+1]);
		}
		
		for (int i=0; i<keui.kernelCoefficients.length; i++){
			g.fillOval(kernelCoefRasterX[i]-2, kernelCoefRasterY[i]-2, 5, 5);	
		}
			
		}
	}
	
	public static void showKernelEditor(){
		
		if (keui.cvt != null){
			keui.kernelCoefficients = keui.cvt.dwtKernel;
			keui.kernelCoefficients = new float[keui.cvt.dwtKernel.length];
			
			for (int i=0; i<keui.cvt.dwtKernel.length; i++){
				keui.kernelCoefficients[i] = keui.cvt.dwtKernel[i];
			}
		}
		
		keui.setVisible(true);		
		keui.paintCanvas();
		
	}
	
	public static void cleanupKernel(){
		
		
	}
	
	public static void main(String args[]) {
		init();
		
		//while (true){
			
		//}
	}
	
}
