/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

/** @author Adrian Johnson **/
 
package org.mitre.wit;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Container;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferUShort;
import java.awt.image.Kernel;
import java.awt.image.Raster;
import java.awt.image.SampleModel;
import java.awt.image.WritableRaster;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.media.opengl.GL;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLContext;
import javax.media.opengl.GLProfile;
import javax.media.opengl.awt.GLCanvas;
import javax.media.opengl.glu.GLU;

import ncsa.hdf.object.Dataset;
import ncsa.hdf.object.FileFormat;
import ncsa.hdf.object.Group;
import ncsa.hdf.object.h5.H5File;

import javax.vecmath.*;


import com.jogamp.opengl.util.texture.awt.*;
//import com.sun.opengl.util.BufferUtil;

import Jama.Matrix;

public class VideoEncodeThread implements Runnable {
	
	int status = WC.STATUS_READY;
	
	String defaultFfmpegScratchDirStr;
	String batchFfmpegScratchDirStr;
	boolean outputFormatMask[] = new boolean[WC.FORMAT_COUNT];
	String videoExportFileStr;
	
	String feedbackString = "";
	
	InputHandler outputHandler;
	InputHandler errorHandler;

	InputHandler outputHandler2;
	InputHandler errorHandler2;

	public VideoEncodeThread(String a,String b, boolean[] m,	String c ) {
		this.defaultFfmpegScratchDirStr = a;
		this.batchFfmpegScratchDirStr = b;
		this.videoExportFileStr = c;
		this.outputFormatMask = new boolean[m.length];
		
		for (int i=0; i<m.length; i++){
			System.out.println("COPY "+m[i]);
			this.outputFormatMask[i] = m[i];
		}
		status = WC.STATUS_READY;
	}

	public void run() {
		completeVideoExportFromGpu(defaultFfmpegScratchDirStr, batchFfmpegScratchDirStr, outputFormatMask, videoExportFileStr);
	}

	public void completeVideoExportFromGpu(String defaultFfmpegScratchDirStr,String batchFfmpegScratchDirStr, boolean outputFormatMask[],	String videoExportFileStr){
		//userInterfaceInfoStr = "ENCODING VIDEO...";
	
		try {

			File batchScratchFile = new File(defaultFfmpegScratchDirStr+batchFfmpegScratchDirStr);

			for (int i=0; i<outputFormatMask.length; i++){

				if (outputFormatMask[i] == true){

					if (i != WC.FORMAT_PNG && i!= WC.FORMAT_JPG) {
						// final destination

						String destStr = videoExportFileStr;
						destStr = destStr.replaceAll("\\\\", "/");

						String commandStr = "ffmpeg";
						String ffmpegStr = "";
						String extStr= "";
						String paramStr = " ";

						if (i == WC.FORMAT_MP4) {
							paramStr = " -vcodec mpeg4  ";
							extStr = ".mp4";
						} else if (i == WC.FORMAT_MP4_H264) {
							paramStr = " -vcodec libx264 ";
							// intercept extension
							extStr = "(h264).mp4";
						} else if (i == WC.FORMAT_WMV) {
							paramStr = " -vcodec wmv2 ";
							extStr = ".wmv";
						} else if (i == WC.FORMAT_MPG) {
							extStr = ".mpg";
						}
						if (!destStr.endsWith(extStr)) {
							destStr = destStr  + extStr;
						}

						paramStr += " -sameq ";
						//float encodingFps = 1000f/(float)timeDeltaPlaybackMS; // need to reference FPS of current system
						float encodingFps = 30f;
						String fpsStr = " -r "+encodingFps+" ";//" -r 2 ";// " -r 15";
						String fpsOutStr = " -r 24 ";
						String inputStr = " -i " + batchScratchFile.getAbsolutePath() + "/%d.png";

						if (extStr.equalsIgnoreCase(".mpg")) {
							ffmpegStr = commandStr + fpsStr + inputStr + fpsOutStr + paramStr + destStr;
						} else {
							ffmpegStr = commandStr + fpsStr + inputStr + paramStr + destStr;
						}

						Runtime rt = Runtime.getRuntime();
						Process p = null;

						// InputStream is = new InputStream();
						p = rt.exec(ffmpegStr);

						errorHandler = new InputHandler(p.getErrorStream(), "Error Stream");
						errorHandler.start();
						outputHandler = new InputHandler(p.getInputStream(), "Output Stream");
						outputHandler.start();

						feedbackString = "FFMPEG: " + ffmpegStr;
						System.out.println("   FFMPEG: " + ffmpegStr);
						
						int pVal = p.waitFor();
						
						String ffmpegExitStr = "FFMPEG EXIT VALUE " + pVal;
						System.out.println(ffmpegExitStr);
						feedbackString = ffmpegExitStr;
						
						if (pVal != 0){
							String errorStr = "VIDEO ENCODING ERROR DETECTED";
							System.out.println(errorStr);
							feedbackString = errorStr;
						}

						String commandChmod = "chmod 777 "+destStr;
						feedbackString = commandChmod;
						System.out.println(commandChmod);
						Runtime rtChmod = Runtime.getRuntime();
						Process pChmod = null;
						pChmod = rtChmod.exec(commandChmod);

						errorHandler2 = new InputHandler(pChmod.getErrorStream(), "Error Stream");
						errorHandler2.start();
						outputHandler2 = new InputHandler(pChmod.getInputStream(), "Output Stream");
						outputHandler2.start();

						int pVal2 = pChmod.waitFor();
						String chmodExitStr = "CHMOD EXIT VALUE " + pVal2;
						System.out.println(chmodExitStr);
						feedbackString = chmodExitStr;

					}
				}
			}

			// copy PNGs if need be
			if (outputFormatMask[WC.FORMAT_PNG] == true){

				System.out.println("   MOVING PNGs");
				String destPngStr = videoExportFileStr;
				destPngStr = destPngStr.replaceAll("\\\\", "/");
				destPngStr = destPngStr+"_PNGs";
				File pngDir = new File(destPngStr);
				pngDir.mkdir();

				File[] pngFiles = batchScratchFile.listFiles();

				for (int i=0; i<pngFiles.length; i++){
					pngFiles[i].renameTo(new File(pngDir+"/"+pngFiles[i].getName()));
				}
			}

			// cleanup PNGs
			boolean dk = deleteDir(batchScratchFile);
			if (dk) {
				System.out
				.println("   DELETED SCRATCH FRAMES FROM "+batchScratchFile.getAbsolutePath());
			}

			System.out.println("VIDEO ENCODING COMPLETE (SHUTTING DOWN ENCODING THREAD)");

		} catch (Exception e){
			e.printStackTrace();
		}
		
		status = WC.STATUS_COMPLETE;
	}

	
	public static boolean deleteDir(File dir) {
		if (dir.isDirectory()) {
			String children[] = dir.list();
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteDir(new File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}

		return dir.delete();
	}

}
