/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

/** @author Adrian Johnson **/
 

package org.mitre.wit;

import java.awt.image.BufferedImage;
import java.nio.FloatBuffer;

import com.jogamp.opengl.util.texture.Texture;


public class WITFrameTile {

	int index =-1;
	
	float xyzLoc[][][] = new float[3][4][3];	// CURR/GOAL, 4 coordinates with XYZ vals
	
	float floatVal[] = new float[4]; // corner intensities
	
	BufferedImage texBI; // raster data
	
	int tileStatusPerCoordinateSystem[] = new int[WC.COORDINATES_MODE_MAX];
	
	int tileVBOstatus = WC.STATUS_ERROR;
	
	int VboIdC=0; // colors
	int VboIdV=0; // vertices
	int VboIdVI=0; // interpolated
	
	int bufferName[] = new int[WC.VBO_MODE_MAX];
	int bufferSize[] = new int[WC.VBO_MODE_MAX];
	
	FloatBuffer bufferData[] = new FloatBuffer[WC.VBO_MODE_MAX];
	float bufferDataRaw[][] = new float[2][4*WC.VBO_COLOR_COMPONENTS];
	
	Texture t;
	
	int tileMaxVal;
	int tileMaxRasterX;
	int tileMaxRasterY;
	
	int tileMinVal;
	int tileQ1Val;
	int tileQ2Val;
	int tileQ3Val;
	
	// carry for future updates - pointers into raw data
	int tileRasterX =0;
	int tileRasterY =0;
	int ySkip = 0;
	int xSkip = 0;
	
	int opMaskGPU[] = new int[10]; // what GPU ops does this tile execute?
	
}
