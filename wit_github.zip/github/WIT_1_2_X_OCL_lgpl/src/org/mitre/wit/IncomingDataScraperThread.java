/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

/** @author Adrian Johnson **/
 
package org.mitre.wit;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class IncomingDataScraperThread implements Runnable {

	String incomingDataDirStr;
	CV_MT_GPU_WIT_1_2 cvt;
	String curTimeStr;
	long searchStartSecs;
	long searchEndSecs;
	
	public String getSearchTimeString(long searchTime){
		long searchTimeMs = searchTime*1000;
		SimpleDateFormat smdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm");
		
		
		String searchTimeStr = smdf.format(new Date(searchTimeMs));
			//System.out.println(searchTimeStr+" ");
		return searchTimeStr;
	}
	
	public void run() {
		ArrayList fileList = new ArrayList();
		
		File parentDir = new File(incomingDataDirStr);
		
		File[] fileListRay = parentDir.listFiles();
		System.out.println("MONITORING INCOMING DATA... "+incomingDataDirStr);
		
		if (fileListRay!=null){
		
		int searchMinutes = (int) ((searchEndSecs - searchStartSecs)/60);
		if ((searchEndSecs - searchStartSecs)%60 != 0){
			searchMinutes +=1;
		}
		String searchTimeStrRay[] = new String[searchMinutes];
		
		int a=0;
		for (long i=searchStartSecs; i<searchEndSecs; i+= 60){
			searchTimeStrRay[a] = getSearchTimeString(i);
			a++;
		}
		
		for (int i=0; i<fileListRay.length; i++){
			for (int j=0; j<searchTimeStrRay.length; j++){
			if (fileListRay[i].getName().contains(searchTimeStrRay[j]) && !fileListRay[i].getName().contains(".tmp")){
				fileList.add(fileListRay[i]);
			}
			}
		}

		
		int fileIndex = searchTimeStrRay.length-1;
		cvt.userInterfaceInfoStr = "FETCHING FILES FOR TIME "+searchTimeStrRay[0]+"-"+searchTimeStrRay[fileIndex];
		
		cvt.getDataCacheFileList(incomingDataDirStr, fileList);
		cvt.timelineImageUpdateFlag =WC.TIMELINE_UPDATE_ALL;
		cvt.timelineStatus = WC.STATUS_READY;
				
		int parsedH= Integer.parseInt(searchTimeStrRay[fileIndex].substring(11, 13));
		int parsedM= Integer.parseInt(searchTimeStrRay[fileIndex].substring(14, 16));
		
		int secH = parsedH*3600;
		int secM = parsedM*60;

		int secsOfDay = secH+secM;
		System.out.println("DETECTED "+fileList.size()+" FILES FOR TIMESTAMP "+searchTimeStrRay[0]+ " ");
		cvt.scrollTimelineAfterTimelineRefresh(secsOfDay);
	

		}
	}
}
