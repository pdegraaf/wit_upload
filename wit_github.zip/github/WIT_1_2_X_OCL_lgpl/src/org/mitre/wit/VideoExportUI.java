/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

/** @author Adrian Johnson **/
 
package org.mitre.wit;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class VideoExportUI extends JFrame {

	static int THREAD_LOAD = 0;
	static int THREAD_CONV = 1;
	static int THREAD_FEAT = 2;
	static int THREAD_THRS = 3;
	static int THREAD_DIFF = 4;
	static int THREAD_SEGMENT = 5;
	static int THREAD_FILT = 6;
	static int THREAD_MON = 7;
	static int THREAD_EXPORT_VIDEO = 8;
	static int THREAD_DEJITTER = 9;
	static int THREAD_HISTOGRAM = 10;
	static int THREAD_HISTOGRAM_EQ = 11;
	static int THREAD_TEMPORAL = 12;
	static int THREAD_DIFF_DJ = 13;
	static int THREAD_DEJITTER_ADV = 14;
	static int THREAD_CONTRAST = 15;
	static int THREAD_LOAD_HDF5R = 16;
	static int THREAD_EXPORT_IMAGES = 17;
	static int THREAD_INTERNAL = 18;
	static int THREAD_EXPORT_MARKED_IMAGES = 19;
	static int THREAD_LOAD_METADATA = 20;
	static int THREAD_LOAD_GEOLOCATION = 21;
	static int THREAD_FIX_GEOLOCATION = 22;
	static int THREAD_STATICS = 23;
	static int THREAD_TIMELAPSE = 24;
	static int THREAD_LOAD_HDF5R_STITCH = 25;
	static int THREAD_EXPORT_KML = 26;
	static int THREAD_MAP_OVERLAY = 27;

	static int MODE_COUNT = 40;
	
	static CV_MT_GPU_WIT_1_2 cvt = null;
	
	static int STATUS_ERROR = -1;
	static int STATUS_READY = 0;
	static int STATUS_WORKING = 1;
	static int STATUS_COMPLETE = 2;
	static int STATUS_INCOMPLETE = 3;

	// product formats
	
	static int inputStatus = STATUS_READY;
	
	static int itemCounter = -1;
	static int progressCounter = -1;
	
	static VideoExportUI veui;
	
	boolean layerMask[] = new boolean[MODE_COUNT];
	boolean formatMask[] = new boolean[WC.FORMAT_COUNT];

	// formats
	static JCheckBox cbVideoWmv;
	static JCheckBox cbVideoMpg;
	static JCheckBox cbVideoMp4;
	static JCheckBox cbImagePng;
	static JCheckBox cbImageJpg;
	
	// options
	static JCheckBox cbVideoAutoComplete;
	
	static float userVideoExportSpeedOther = 16.0f;
	
	// specific start/stop
	static JTextField startTime;
	static JTextField stopTime;

	static JTextField minLon;
	static JTextField maxLon;
	static JTextField minLat;
	static JTextField maxLat;
	
	static JTextField minPxX;
	static JTextField maxPxX;
	static JTextField minPxY;
	static JTextField maxPxY;
	
	static JLabel labelFormat;
	static JLabel labelOptions;
	static JLabel labelSecMark;
	static JLabel labelTitle;

	public static JTextField securityLabel;
	public static JTextField titleLabel;
	
	// buttons
	static JButton buttonCancel;
	static JButton buttonOkay;

	
	public static void init(){
		// rb speed 
		ActionListener actionListenerSpeedHalf = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoExportSpeed = 1f;
			}
		};
		ActionListener actionListenerSpeed1x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoExportSpeed = 1f;
			}
		};
		ActionListener actionListenerSpeed2x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("SPEED 2");
				cvt.userVideoExportSpeed = 2f;
			}
		};
		ActionListener actionListenerSpeed4x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("SPEED 4");
				cvt.userVideoExportSpeed = 4f;
			}
		};
		ActionListener actionListenerSpeed10x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoExportSpeed = 10f;
			}
		};
		ActionListener actionListenerSpeed25x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoExportSpeed = 25f;
			}
		};
		ActionListener actionListenerSpeed50x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoExportSpeed = 50f;
			}
		};
		ActionListener actionListenerSpeed100x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoExportSpeed = 100f;
			}
		};
		
		// rb mag
		ActionListener actionListenerMagHalf = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoMagnification = .5f;
			}
		};
		ActionListener actionListenerMag1x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoMagnification = 1f;
			}
		};
		ActionListener actionListenerMag2x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoMagnification = 2f;
			}
		};
		ActionListener actionListenerMag4x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoMagnification = 4f;
			}
		};
		ActionListener actionListenerMag8x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoMagnification = 8f;
			}
		};
	

		// cb format
		ActionListener actionListenerFormatWmv = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int format = WC.FORMAT_WMV;
				cvt.toggleOutputFormatMask(format);
			}
		};
		ActionListener actionListenerFormatMpg = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int format = WC.FORMAT_MPG;
				cvt.toggleOutputFormatMask(format);
			}
		};
		ActionListener actionListenerFormatMp4 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int format = WC.FORMAT_MP4;
				cvt.toggleOutputFormatMask(format);
			}
		};
		ActionListener actionListenerFormatPng = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int format = WC.FORMAT_PNG;
				cvt.toggleOutputFormatMask(format);
			}
		};
		ActionListener actionListenerFormatJpg = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int format = WC.FORMAT_JPG;
				cvt.toggleOutputFormatMask(format);
			}
		};
		ActionListener actionListenerAutoComplete = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int option = WC.OPTION_VIDEO_LOOP;
				cvt.toggleOutputOptionMask(option);
			}
		};
		
		// cb modes
		ActionListener actionListenerModeRaw = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int mode = THREAD_LOAD_HDF5R;
				cvt.toggleOutputModeMask(mode);
			}
		};
		ActionListener actionListenerModeContrast = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int mode = THREAD_CONTRAST;
				cvt.toggleOutputModeMask(mode);
			}
		};
		ActionListener actionListenerModeDiff = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int mode = THREAD_DIFF;
				cvt.toggleOutputModeMask(mode);
			}
		};
		ActionListener actionListenerModeTimelapse = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int mode = THREAD_TIMELAPSE;
				cvt.toggleOutputModeMask(mode);
			}
		};
		
		// end action listeners
		
		veui = new VideoExportUI();
		veui.setLayout(null);
		veui.setTitle("PRODUCT EXPORT");
		veui.setVisible(false);
		veui.setSize(360, 300);
		
		System.out.println("VIDEO EXPORT");
				
		int marginX = 10;
		int marginY = 10;
		int spacingY = 20;
		int spacingX = 160;
		int spacingXnarrow = 120;
		
		int widthX = spacingX;
		int heightY = spacingY;
	
		// formats
		cbVideoWmv = new JCheckBox();
		cbVideoWmv.setText("WMV");
		cbVideoWmv.setSize(spacingXnarrow, spacingY);
		cbVideoWmv.setVisible(true);
		cbVideoWmv.setLocation(marginX, marginY+spacingY*1);
		cbVideoWmv.addActionListener(actionListenerFormatWmv);
		
		cbVideoMpg = new JCheckBox();
		cbVideoMpg.setText("MPEG");
		cbVideoMpg.setSize(spacingXnarrow, spacingY);
		cbVideoMpg.setVisible(true);
		cbVideoMpg.setLocation(marginX, marginY+spacingY*2);
		cbVideoMpg.addActionListener(actionListenerFormatMpg);
		
		cbVideoMp4 = new JCheckBox();
		cbVideoMp4.setText("MP4");
		cbVideoMp4.setSize(spacingXnarrow, spacingY);
		cbVideoMp4.setVisible(true);
		cbVideoMp4.setLocation(marginX, marginY+spacingY*3);
		cbVideoMp4.addActionListener(actionListenerFormatMp4);
		
		cbImagePng = new JCheckBox();
		cbImagePng.setText("PNG");
		cbImagePng.setSize(spacingXnarrow, spacingY);
		cbImagePng.setVisible(true);
		cbImagePng.setLocation(marginX, marginY+spacingY*4);
		cbImagePng.addActionListener(actionListenerFormatPng);
		
		cbVideoAutoComplete = new JCheckBox();
		cbVideoAutoComplete.setText("Loop While Recording");
		cbVideoAutoComplete.setSize(200, spacingY);
		cbVideoAutoComplete.setVisible(true);
		cbVideoAutoComplete.setLocation(spacingXnarrow+marginX, marginY+spacingY*1);
		cbVideoAutoComplete.addActionListener(actionListenerAutoComplete);

		// magnification

		ActionListener actionListenerButtonOkay = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				cvt.productClassificationLabelStr = securityLabel.getText();
				cvt.productTitleLabelStr = titleLabel.getText();
				
				System.out.println("*** EXPORT GUI ***");
				
				for (int i=0; i<WC.FORMAT_COUNT; i++){
					if (cvt.outputFormatMask[i] == true){
						System.out.println("FORMAT "+cvt.formatIDtoName(i));
					}
				}
				
				for (int i=0; i<MODE_COUNT; i++){
					if (cvt.outputModeMask[i] == true){
						System.out.println("MODE "+cvt.opIdToName(i));
					}
				}				
				
				//cvt.exportVideoUI();
				if (cvt.exportBounceVideoState == WC.STATUS_OFF){
					cvt.startVideoExportFromGpu();
					// ffmpeg
				} 
				
				System.out.println("*** EXPORT GUI ***");	
				// show status		
				buttonOkay.setEnabled(false);
				
				hideVideoExport();
			}
		};
		
		ActionListener actionListenerButtonCancel = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hideVideoExport();
			}
		};
		
		// video speed

		// markings
		securityLabel = new JTextField();
		securityLabel.setText("// SECRET // OT&E PRODUCT - NOT TO BE USED FOR TARGETING OR DECISION SUPPORT //");
		securityLabel.setLocation(marginX, marginY+spacingY*7);
		securityLabel.setSize(marginX+spacingX*2, heightY);
		securityLabel.setVisible(true);
		
		titleLabel = new JTextField();
		titleLabel.setText("SBIRS HEO WB");
		titleLabel.setLocation(marginX, marginY+spacingY*9);
		titleLabel.setSize(marginX+spacingX*2, heightY);
		titleLabel.setVisible(true);
		
		// buttons
		buttonOkay = new JButton();
		buttonOkay.setSize(widthX, heightY);
		buttonOkay.setText("EXPORT");
		buttonOkay.setLocation(marginX, veui.getHeight()-60);
		buttonOkay.setVisible(true);
		buttonOkay.setMnemonic('e');
		buttonOkay.addActionListener(actionListenerButtonOkay);
		
		buttonCancel = new JButton();
		buttonCancel.setSize(widthX, heightY);
		buttonCancel.setText("CANCEL");
		buttonCancel.setLocation(2*marginX+spacingX, veui.getHeight()-60);
		buttonCancel.setVisible(true);
		buttonCancel.setMnemonic('c');
		buttonCancel.addActionListener(actionListenerButtonCancel);
		
		// labels
		
		labelFormat = new JLabel();
		labelFormat.setText("FORMATS");
		labelFormat.setLocation(marginX, marginY+spacingY*0);
		labelFormat.setSize(widthX, heightY);
		labelFormat.setVisible(true);
		
		labelOptions = new JLabel();
		labelOptions.setText("OPTIONS");
		labelOptions.setLocation(marginX+spacingXnarrow, marginY+spacingY*0);
		labelOptions.setSize(widthX, heightY);
		labelOptions.setVisible(true);
		
		labelSecMark = new JLabel();
		labelSecMark.setText("CLASSIFICATION MARKING");
		labelSecMark.setLocation(marginX, marginY+spacingY*6);
		labelSecMark.setSize(marginX+spacingX*2, heightY);
		//labelSecMark.setVisible(true);
		
		labelTitle = new JLabel();
		labelTitle.setText("TITLE");
		labelTitle.setLocation(marginX, marginY+spacingY*8);
		labelTitle.setSize(marginX+spacingX*2, heightY);
		
		veui.add(cbVideoWmv);
		veui.add(cbVideoMpg);
		veui.add(cbVideoMp4);
		veui.add(cbImagePng);

		veui.add(cbVideoAutoComplete);
		
		veui.add(labelFormat);
		veui.add(labelOptions);
		
		veui.add(labelSecMark);
		veui.add(labelTitle);
		veui.add(securityLabel);
		veui.add(titleLabel);

		veui.add(buttonCancel);
		veui.add(buttonOkay);
		
	}
	
	public static void showVideoExport(){
		// sync the prefs
		buttonOkay.setEnabled(true);
				
		if (cvt!= null){
			cbVideoWmv.setSelected(cvt.outputFormatMask[WC.FORMAT_WMV]);
			cbVideoMpg.setSelected(cvt.outputFormatMask[WC.FORMAT_MPG]);
			cbVideoMp4.setSelected(cvt.outputFormatMask[WC.FORMAT_MP4]);
			cbImagePng.setSelected(cvt.outputFormatMask[WC.FORMAT_PNG]);

			cbVideoAutoComplete.setSelected(cvt.outputOptionMask[WC.OPTION_VIDEO_LOOP]);
		}
		
		veui.setVisible(true);
	}
	
	public static void hideVideoExport(){
		veui.setVisible(false);
		
	}
	
	public static void getInput(){
		
	}
	
	public static void main(String args[]) {
		init();
		showVideoExport();
		while (true){
		}
		//v.setVisible(true);
	}
	
	public static void setupVideoExportUI(final String ext) {

		int fw = 260;
		int fh = 130;

		int inputX1 = 20;
		int inputX2 = 170;

		int inputY1 = 20;
		int inputY2 = 60;
		int inputY3 = 90;
		int inputY4 = 130;

	}
}
