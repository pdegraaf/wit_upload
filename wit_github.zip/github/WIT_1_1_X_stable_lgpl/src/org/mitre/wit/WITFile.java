/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

package org.mitre.wit;
/**
 * @author Adrian Johnson <abjohnson@mitre.org>
 *
 */

public class WITFile {
	
	// error handling
	static int MISSING_ITEM_GEOLOCATION = 0;
	static int MISSING_ITEM_TIME = 1;
	static int MISSING_ITEM_INTENSITIES = 2;
	static int[] missingDataItems = new int[3];	// flag missing geolocation and other items
	// end error handling
	
	int fileID = -1;

	int preprocessCompleted = -1;
	int prepNextCompleted = -1;
	int prepPrevCompleted = -1;
	int loadedToWit = 0;
	
	String path = "";
	String name = "";
	
	int enabled = 1;	// loaded - marked as non-corrupt

	int minYear;
	int maxYear;
	int minDay;
	int maxDay;
	double minSeconds;
	double maxSeconds;
	int totalFrames;
	int validFrames;
	int SCA;
	int SCID;
	long modified;
	
	int minMinutes;
	int maxMinutes;
	
	int minCalIntensity;
	int maxCalIntensity;
	
	int nextID = -1;
	int prevID = -1;
	
	//int timelineSecStart = 0;
	//int timelineSecStop = 0;
	
	// peer files for other SCAs
	int peerID[] = new int[8];
	
	int fileLoadStatus;		// flag errors which occurred during file read
	int fileHealthStatus;	// flag errors in the files
}
