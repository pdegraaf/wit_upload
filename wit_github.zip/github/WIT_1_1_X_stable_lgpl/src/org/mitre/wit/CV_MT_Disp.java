/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

package org.mitre.wit;

/**
 * @author Adrian Johnson <abjohnson@mitre.org>
 *
 */

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.CheckboxMenuItem;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.MenuShortcut;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class CV_MT_Disp extends JFrame implements MouseListener,
MouseMotionListener, KeyListener, ComponentListener {

	// master config file location
	String masterConfigFileStr = "WIT_CONFIG.txt";

	String productClassificationLabelStr = "// SECRET // OT&E PRODUCT //";
	String productTitleLabelStr = "";
	String defaultLoadDirStr = "/export/";
	String defaultSaveDirStr = "/export/";
	String defaultSaveDemoVideoDirStr = "/export/WIT_DEV/DEMO_VIDEO_FRAMES/";
	String defaultResourceDirStr = "/export/";
	String defaultMapDataDirStr = "/export/";
	String defaultMapGraphicStr = "/export/";
	String defaultFfmpegScratchDirStr = "/export/";
	String intensityBiasFileStr ="/export/WIT_DEV/channel_biases.txt";
	String webHelpLocation = "";
	String kmlPolyTemplateLocationStr = "";
	String cotPolyTemplateLocationStr = "";

	// XML templates
	String kmlPolyTemplateStr = "";
	String cotPolyTemplateStr = "";

	// XML messages
	String kmlPolyMessageStr = "";
	String cotPolyMessageStr = "";

	// allow server/client modes
	int HEADLESS_MODE = 0; // 0 is standard, 1 is headless, 2 is distributed
	int DISPLAY_MODE = 0; // 0 is classic, 1 is remote

	// poly items
	WxPoly poly = new WxPoly();


	// XML widgets
	static XmlExportUI xeui;

	// ruler
	String rulerDistStr = "";
	String rulerSpeedStr = "";
	String rulerAccStr = "";
	WxPoly ruler = new WxPoly();

	// biases used to correct channels
	int intensityBiasPerScaPerChannel[][][][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS][WC.SCA_CHANNELS][2]; // per scan direction

	int masterOverlayToggle = 1;
	// mini-map
	int miniMapPos[][] = new int[2][2]; // goal/current and X/Y
	int miniMapSize[][] = new int[2][2]; // goal/current and W/H
	float miniMapScale = .025f;
	// draw the view area
	int miniMapInsetPos[][] = new int[2][2]; // goal/current and X/Y
	int miniMapInsetSize[][] = new int[2][2]; // goal/current and W/H

	int drawMiniMapSCALabels = 1;
	int miniGlobePos[][] = new int[2][2];
	int miniGlobeSize[][] = new int[2][2];
	float miniGlobeScale = 1.12f;// .5f;
	BufferedImage miniGlobeImage;

	int MAX_SCAN_LENGTH = 8000;

	// optimize the graphic elements
	int pointerH1 = 40;
	int pointerH2 = 26;
	int pointerH3 = -12;
	int pointerW1 = 2;
	BasicStroke stroke1;
	BasicStroke stroke2;
	BasicStroke strokeWidth1;
	BasicStroke strokeWidth2;
	BasicStroke strokeWidth3;
	Graphics2D gMain;
	Graphics2D gh;
	int graphicsStatus = WC.STATUS_ERROR;
	//
	int uiState = WC.UI_STATE_VIEW;

	int SCA_FOCUS = 2; // default pan location

	//
	int widgetVisibility[] = new int[WC.MAX_WIDGETS];

	// contrast ui items
	int contrastCurveDotRadius = 8;
	int contrastCurveDotOffsetRadius = contrastCurveDotRadius / 2;

	// allow user to choose flight 33 (0) or 34 (1)
	int userFlight = 0;
	int loadedFlight = -1;
	int timelineCenterX; // allow this to center in the view

	String lastLoadedFileStr = "";
	String lastLoadedDirStr = "";

	// threading
	int MAX_THREADS_ACTIVE = 4;// 2;//2;
	int MAX_THREADS_QUEUED = 200;
	int activeThreadCount = 0;

	int queuedThreadCount = 0;
	ImProcThread imprRay[] = new ImProcThread[MAX_THREADS_QUEUED];
	int maxLoaderThreads = 100;
	int loaderThreadIndex = 0;

	int maxGenericThreads = 100;
	int genericThreadIndex = 0;

	int maxContrastThreads = 100;
	int contrastThreadIndex = 0;
	int loaderProgressFrames = 0;
	int loaderProgressFramesPrev = 0;

	int loaderInfoFrames = 0;
	int loaderInfoFramesPrev = 0;

	int uiCompassRotationState = WC.STATUS_OFF;

	int threadMode;

	int threadPriorities[] = new int[WC.MODE_COUNT];
	int threadTimeouts[] = new int[WC.MODE_COUNT];

	int threadScheme = WC.THREAD_SCHEME_BATCH;// WC.THREAD_SCHEME_BATCH;
	int systemState = WC.SYSTEM_STATE_ONLINE;
	int dataState = WC.STATUS_READY;
	int exportDemoVideoState = WC.STATUS_OFF;
	int demoVideoFrameCount=0;

	// today's timeline

	int minTimeOffset = -WC.SEC_IN_DAY + 2000;
	int maxTimeOffset = 0;// -WC.SEC_IN_DAY;

	int reconstructFullScans = 1;

	float MAX_LOAD_SECONDS = 60*60*4; // 4 hrs
	float MAX_SKIP_SECONDS = 60*60*1; // 1 hrs
	float MAX_BURST_SECONDS = 60;

	float MIN_LOAD_SECONDS = 1f;
	float MIN_SKIP_SECONDS = 1f;
	float MIN_BURST_SECONDS = 1f;

	float MID_BURST_SECONDS = 5f;
	float MID_SKIP_SECONDS = 60f;
	float MID_LOAD_SECONDS = 300f;

	float INC_LOAD_SECONDS1 = 3f;
	float INC_LOAD_SECONDS2 = 120f;
	float INC_SKIP_SECONDS1 = 1f;
	float INC_SKIP_SECONDS2 = 60f;
	float INC_BURST_SECONDS1 = 1f;
	float INC_BURST_SECONDS2 = 2f;

	int jumpLoadStart = -1;
	int jumpLoadDistance = -1;
	int uiLoadTriggerTimer = 0;
	int loadTriggerState = WC.STATUS_OFF;

	float userTimelineOffset[] = { 0, 0 };
	int loadSeconds = 120; // seconds of data to load
	int skipSeconds = 1;

	String loadWindowStr = "";
	String loadSkipStr = "";
	String loadBurstStr = "";


	int burstSeconds = WC.SNIPPET_SECONDS_LOAD;
	int dataAvailability[][] = new int[WC.TOTAL_SCAS][WC.SEC_IN_DAY]; // show
	// data
	// availability
	// for
	// all
	// minutes
	// of
	// the
	// day
	// per
	// SCA
	int dataArrayRef[] = new int[WC.SEC_IN_DAY]; // for every second of
	// data, reference the
	// WITFrame object
	// associated with it
	// int dataFrameNumber[][] = new int[WC.TOTAL_SCAS][WC.SEC_IN_DAY];
	int dataLoadStatus[][][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS][WC.SEC_IN_DAY]; // flight,
	// sca,
	// minutes
	// int dataLoadScanSegment[][][] = new int[2][WC.TOTAL_SCAS][WC.SEC_IN_DAY];
	int dataLoadInfo[][][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS][WC.SEC_IN_DAY];
	int dataFramesInFile[][] = new int[WC.TOTAL_SCAS][WC.SEC_IN_DAY];
	int dataRefWITFile[][][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS][WC.SEC_IN_DAY];
	int dynamicLoadStatus = WC.STATUS_ERROR;
	int flightSelected = 0;
	ArrayList wFileListTimeline = new ArrayList();

	// 
	int northArrowRasters[][] = new int[2][2]; // sca, start/stop, x/y
	float compassAngle = 0;
	float compassIsValid = 0;
	BufferedImage compassImage;
	BufferedImage compassImageRot;
	// error handling flags
	int ERROR_STATE_COUNT = 5;
	int dataErrorHandling[][][][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS][WC.SEC_IN_DAY][ERROR_STATE_COUNT];
	int MISSING_ITEM_GEOLOCATION = 0;
	int[] missingDataItems = new int[ERROR_STATE_COUNT]; // flag missing


	ArrayList bookmarkList = new ArrayList(); // !! migrate to this format
	// transitioning to new data queueing - use the HDF5 metadata to know what
	int bookmarkListIndex[] = new int[WC.TOTAL_FLIGHTS];
	int bookmarkSyncFlag = WC.STATUS_ON;
	long bookmarkSyncTime = 0;
	int timelineMouseoverX = -1;

	int WASD_speed = 1;
	int WASD_speed_fast = 20;

	// sca selector
	int scaSelectorGraphic[][] = new int[WC.TOTAL_SCAS][4]; // x, y, w, h
	int scaSelectorBand[] = new int[WC.TOTAL_SCAS];
	String scaSelectorString[] = new String[WC.TOTAL_SCAS];

	int viewportY = 1000;//1500;
	int viewportX = 1400;//2560;

	int GEODATA_LON = 0;
	int GEODATA_LAT = 1;

	static int GEODATA_UL = 0;
	static int GEODATA_UR = 1;
	static int GEODATA_LR = 2;
	static int GEODATA_LL = 3;

	int statusInterp = 0;

	int latLonOverlayEnabled = 1;
	float overlayMapScale = 32.0f;

	int cursorX = 0; // using only the frame as the reference
	int cursorY = 0;
	int cursorUnblockX = -8; // grab a slight offset so the cursor does
	// not block the pixel being checked
	int cursorUnblockY = -8;
	int cursorOverWidget = WC.STATUS_OFF;

	int mouseOverSCA = -1;
	int histogramSCAselector = -1;
	int histogramSCAselectorPrev = -1;
	int histogramZoomEnabled = 0;

	int histogramZoomLevel = 1;
	int histogramMinZoomLevel = 1;
	int histogramMaxZoomLevel = 8;

	int mouseDragStartX;
	int mouseDragStartY;

	int mouseX = 0; // using the frame plus SCA pan as the reference
	// frame
	int mouseY = 0;
	int mousePanoramaX = 0; // just using the panorama coords, not SCA
	int mousePanoramaY = 0;
	int mouseIntensity = 0;
	float mouseLon;
	float mouseLat;
	float mouseLonFast;
	float mouseLatFast;
	int mouseOverSCAprev = -1;
	int lensTextColorMode = 0;
	int userEventFlashDefault = 100;
	int userEventFlash = WC.STATUS_OFF;

	int mouseState = WC.STATUS_READY; 

	int LAT_LON_COLOR_AUTO = 0;
	int LAT_LON_COLOR_DARK = 1;
	int LAT_LON_COLOR_LIGHT = 2;

	int scaOffsets[][] = new int[8][2];

	// default number of files to attempt to read
	int inputFileSeqCount = 2;// 9; // 3 usually works, 2 to be safe, 1
	// to allow processing

	int autoReloadState = 0;
	int autoReloadSeconds = 30;

	long autoReloadTime1 = 0;
	long autoReloadTime2 = 0;
	long autoReloadTimeD = 1000 * 60 * 20; // reload every 5 minutes

	String lastFileLoaded = "";

	String invalidPathStr = "INVALID_FILE_PATH";

	// lenses
	int lensFilterActive = 0;
	int lensMagnifyActive = 0;

	// map assets
	int drawMapImageActive = 0;
	BufferedImage mapImage;
	BufferedImage mapImageLive;
	int mapImageRasterX;
	int mapImageRasterY;

	// plot assets
	int drawPlotImageActive = 0;
	BufferedImage plotImage;
	int plotImageRasterX;
	int plotImageRasterY;

	// georeference cues
	int drawNorthArrowsStatus = 1; // show NORTH arrows
	int drawPoliticalOverlay = 1; // nation boundaries

	// masks
	short INVALID_DATA_MASK = (short) -1;
	int INVALID_GEOLOCATION = -9999;

	//
	VideoExportUI vidExportUI;

	int SCAN_SELECT_ALL = 2;
	int SCAN_SELECT_EVEN = 0;
	int SCAN_SELECT_ODD = 1;
	int scanSelectionMode = SCAN_SELECT_ALL;
	int scanExportMode = SCAN_SELECT_ALL;

	int SCAN_DIR_UNKNOWN = -1;
	int SCAN_DIR_EVEN = 0;
	int SCAN_DIR_ODD = 1;
	int SCAN_DIR_BOTH = 2;
	int playbackModeDir[] = { SCAN_DIR_EVEN, SCAN_DIR_EVEN };

	int SCAN_SEGMENT_ONE = 0;
	int SCAN_SEGMENT_ALL = 0;
	int playbackModeSeg = SCAN_SEGMENT_ONE;

	int scanLength = 0;
	int scanPosYStartPointer = 0;
	int scanPosYEndPointer = 0;

	//
	int CURRENT = 0;
	int GOAL = 1;

	int rasterLayerOrder[] = new int[WC.MODE_COUNT];
	int timelineLayerOrder[][] = new int[WC.MODE_COUNT][3]; // op, Y, Z
	float rasterLayerOpa[][] = new float[WC.MODE_COUNT][2]; // allow
	// goal/current
	// for fades
	float defaultOpOpacity[] = new float[WC.MODE_COUNT]; 
	int RASTER_OMIT = -1;
	float rasterOpaFadeRate = .5f;

	int playbackPaused = 0;
	int drawCyclePaused = 0;
	float playbackStepSeconds = 1.0f;
	BufferedImage contrastPrevBI;

	BufferedImage lensMagImage;
	int lensW = 100;//100;
	int lensH = 100;//100;
	int lensScale = 4;// 4; !! 4,8,16
	int lensPosX = 0;
	int lensPosY = 0;

	// buffer the drawing of the timeline and available data
	BufferedImage timelineImage;
	Graphics2D timelineGraphics;
	TimelineDrawThread timelineDrawThread;
	int timelineImageUpdateFlag = 0;

	int timelineImageW = WC.SEC_IN_DAY;
	int timelineImageH = 100;

	int latLonOverlayUpdateFlag = 1;
	int mapOverlayUpdateFlag = 1;

	static CV_MT_Disp cvt = new CV_MT_Disp();
	// UI

	String tivoRootDir = "/export/WIT_DEV/";
	// String tivoRootDir = "/Volumes/Areca/tivo/";

	String tivoLoadFile = "wit_previous_session.xml";
	String tivoSaveFile = "wit_previous_session.xml";

	// stats
	int STATS_MIN = 0;
	int STATS_Q1 = 1;
	int STATS_Q2 = 2;
	int STATS_Q3 = 3;
	int STATS_MAX = 4;
	int STATS_MIN_BIN = 5;
	int STATS_MAX_BIN = 6;

	// contrast
	int CONTRAST_OFF = 0;
	int CONTRAST_GAIN = 1;
	int CONTRAST_CURVES = 2;
	int CONTRAST_AUTO = 3;
	int CONTRAST_WINDOW = 4;
	int CONTRAST_USER = 5;
	int contrastMode = CONTRAST_USER;
	float loadTimeGain = 1.0f;
	float loadTimeBoost = 0.0f;

	// distributed computing / sharing

	int NODE_STATE_MASTER = 1;
	int NODE_STATE_SLAVE = 2;
	int NODE_STATE_INACTIVE = -1;
	int nodeState = NODE_STATE_MASTER;// NODE_STATE_SLAVE;
	int nodeStateLabel = 1;// show the state of each node
	int nodePlayheadLocked = 0;
	int nodePlayheadShared = 0;
	int peerPlayheadListening = 1;
	int tivoPlayheadPeer = 0;

	int witTimePlayhead = 0;
	int lockPlayhead = 1;
	float witTimePlayheadFloat = 0;
	String witTimePlayheadTimestampStr = "";
	String witTimePlayheadTimestampOutputStr = "";
	String witScanPlayheadTimestampStr = "";

	int scanDirAgreementDrawFlag[][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];
	int timeAgreementDrawFlag[][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];
	int scanSeqAgreementDrawFlag[][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];
	//int lastDrawIndex[][][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS][WC.SCA_MAX_SCAN_SEGMENTS];
	ArrayList lastDrawIndexList[][] = new ArrayList[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];

	int playbackDir = 1;

	// use to sync array indices across SCAs
	int witSCAPlayhead[][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS]; 

	// min and max determined from user's load preferences
	int minSeconds = 0;
	int maxSeconds = 0;

	int userScid = 33;

	float userPanOffset[][] = { { 0, 0 }, { 0, 0 } };
	float vaRate = .45f; // view animation rate
	float taRate = .35f; // view animation rate
	int minPanX;// (int)(-768f * 4.85f);
	int maxPanX;
	int minPanY;
	int maxPanY;

	// state restoration

	int RESTORE_STATE_MANUAL = 0;
	int RESTORE_STATE_ON_LAUNCH = 1;
	int RESTORE_STATE_DIALOG_BOX = 2;
	int restoreStateMode = RESTORE_STATE_MANUAL;

	int SAVE_STATE_MANUAL = 0;
	int SAVE_STATE_ON_EXIT = 1;
	int SAVE_STATE_DIALOG_BOX = 2;
	int saveStateMode = SAVE_STATE_ON_EXIT;

	ArrayList nodeList = new ArrayList();
	//

	int T_RASTER = 3;
	int T_SECS = 3;
	// user selection

	int CHECK_BOUNDS_LOCK = 1;
	int CHECK_BOUNDS_LOOP = 0;

	int SELECTION_READY = 0;
	int SELECTION_WORKING = 1;
	int SELECTION_COMPLETE = 2;

	// based on loaded data
	int loopStart = 0;
	int loopEnd = 0;

	int userSelection[][] = new int[2][4]; // start/end x/y/t/index - for
	int userSelectionSCA[][][] = new int[WC.TOTAL_SCAS][2][4]; // start/end

	int userSelectionSCAtouched[] = new int[WC.TOTAL_SCAS];
	int userContrast[] = new int[2]; // start/end ...modes - select
	ArrayList userContrastCPList;
	ArrayList userContrastCPListSorted;
	int userContrastCPStatus = SELECTION_READY;
	int userContrastRangeStatus = SELECTION_READY;
	int userContrastCPmodID = -1;
	int userSelectionArea = 0; 

	int selectionStatus = SELECTION_READY;
	int selectionTimeStatus = SELECTION_READY;

	int handleFlagW = 8; // flags for grabbing the selectors
	int handleFlagH = 22;
	int histogramZoomButtonSize = 20;

	// playback mode
	int LOOP_MODE_ALL = 0;
	int LOOP_MODE_SELECTION = 1;
	int loopMode = LOOP_MODE_ALL;

	int PAUSED = 0;
	int UNPAUSED = 1;
	int pauseFlag = UNPAUSED;

	int dejitterPlaybackX = 0;
	int dejitterPlaybackY = 0;
	//
	// Canvas tivoCanvas;
	JPanel tivoCanvas;

	int latLonRenderEnabled = 0;

	BufferedImage viewportImage;
	BufferedImage viewportImageRot; // for rotated viewport
	BufferedImage viewportImageOverlay;
	// BufferedImage missingDataImage;
	Graphics2D g;
	Graphics2D gb;
	Graphics2D gwc;

	Composite graphicComposites[];
	static int c_WORKING;
	static int c_WIDGET;
	static int c_LOOP_SELECTION;
	static int c_COMPLETE;
	static int c_LATLON_OVERLAY;
	int c_raster;

	// product formats
	int FORMAT_COUNT = 30;
	int FORMAT_MPG = 0;
	int FORMAT_MP4 = 1;
	int FORMAT_MP4_H264 = 2;
	int FORMAT_WMV = 3;
	int FORMAT_PNG = 10;
	int FORMAT_JPG = 11;
	int FORMAT_GEOTIFF = 12;

	int tivoPlayheadXpos = 0; 
	int tivoPlayheadBuffer = 2;
	int witOpBuffers[]; 
	int WIT_OP_BUFFER_DEFAULT = tivoPlayheadBuffer;

	int witLoopBoundsMinSecs = 0;
	int witLoopBoundsMaxSecs = 0;

	int SECONDS_IN_DAY = 24 * 60 * 60;

	int viewMask[] = new int[4]; // configurable views
	boolean opMask[] = new boolean[WC.MODE_COUNT]; // toggle active/inactive
	int filterRegionReqMask[] = new int[WC.MODE_COUNT]; // toggle

	boolean outputModeMask[] = new boolean[WC.MODE_COUNT];
	boolean outputFormatMask[] = new boolean[FORMAT_COUNT];
	String outputFormatExtStr[] = new String[FORMAT_COUNT];
	float userVideoMagnification = 1f;
	float userVideoSpeed = 1f;
	float userVideoExportSpeed = 1f;
	// active/inactive

	// information overlays
	float tivoSpeedOverlayAlpha = 0f;
	float tivoSpeedOverlayAlphaReset = 10f;
	float tivoInfoOverlayAlpha = 0f;
	float regionHintAlpha = 0f;
	float alphaFadeRate = .95f;
	float contrastOverlayAlpha = 0f;

	String userInterfaceInfoStr = "";
	String regionHintStr = " ";
	String fontNameStr = "";

	int basePlaybackSpeed = 16; // 1000 // 1 second refresh

	// ui anim
	long guiTime1 = 0;
	long guiTime2 = 0;
	int guiTimeDeltaPlaybackMS = 40;

	// timeline refresh (status)
	long timelineRefreshStatusTime1 = 0;
	long timelineRefreshStatusTime2 = 0;
	int timelineRefreshStatusTimeDelta = 200;

	// timeline refresh (info)
	long timelineRefreshInfoTime1 = 0;
	long timelineRefreshInfoTime2 = 0;
	int timelineRefreshInfoTimeDelta = 500;

	// bookmark refresh (info)
	long bookmarkRefreshInfoTime1 = 0;
	long bookmarkRefreshInfoTime2 = 0;
	int bookmarkRefreshInfoTimeDelta = 500;

	// new playhead for Arraylist
	long playheadTime1 = 0;
	long playheadTime2 = 0;
	int playheadTimeDelta = basePlaybackSpeed;// 1000;
	int playheadDir = 1;
	int playheadDirPrev = 1; // for pause

	int playbackScanSeqIndexMask[][] = new int[WC.TOTAL_FLIGHTS][WC.SCAN_SEQ_INDEX_MAX_VAL]; // mask
	// overscans,
	// or
	// do
	// overscans
	// onl
	String sosScanSeqIndexLabel[] = new String[WC.SCAN_SEQ_INDEX_MAX_VAL];
	int playbackScanSeqIndexPrev[] = { -1, -1 };
	int playbackScanLengthPrev[][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];


	// playback anim
	long time1 = 0;
	long time2 = 0;
	int timeDeltaPlaybackMS = 30;// 33; // new frame every 33 frames

	long restartTime1 = 0;
	long restartTime2 = 0;
	long restartMS = 1000 * 60 * 5;

	// process time - kick off new threads
	long processTime1 = 0;
	long processTime2 = 0;
	long processTimeMS = 1200;

	// finalization tim
	long finalizationTime1 = 0;
	long finalizationTime2 = 0;
	long finalizationTimeMS = 30000;

	// int frameCount = 900;//300//255;
	int frameCountAlloc = 0;

	int tivoMaxFrame = 300;

	int DEFAULT_FILE_LIMIT = 10000;
	int witFileCount = 0; // current file to load
	WITFrame tfMWIR[];
	WITFrame tfSTG[];

	ArrayList witFrameList[][] = new ArrayList[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];
	ArrayList witFileList[][] = new ArrayList[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];
	int witLoadListSizePrev[] = new int[WC.TOTAL_SCAS];


	ArrayList wFileListSCA[] = new ArrayList[WC.TOTAL_SCAS];
	int witFileListRootSCA[] = new int[WC.TOTAL_SCAS];
	// int[][] scaLoadMask = {{0,1,1,0,0,0,0,0},{0,1,1,1,0,0,0,0}};
	int[][] scaLoadMask = { { 1, 1, 1, 1, 1, 1, 1, 1 },
			{ 1, 1, 1, 1, 1, 1, 1, 1 } };

	int[] flightLoadMask = { 1, 1 };
	int[] indexSca = { 0, 0 };
	
	// forward
	int SYSTEM_PLAYBACK_RATE_F1X = 0;
	int SYSTEM_PLAYBACK_RATE_F2X = 1;
	int SYSTEM_PLAYBACK_RATE_F4X = 2;
	int SYSTEM_PLAYBACK_RATE_F8X = 3;
	int SYSTEM_PLAYBACK_RATE_F16X = 4;
	// reverse
	int SYSTEM_PLAYBACK_RATE_R1X = 10;
	int SYSTEM_PLAYBACK_RATE_R2X = 11;
	int SYSTEM_PLAYBACK_RATE_R4X = 12;
	int SYSTEM_PLAYBACK_RATE_R8X = 13;
	int SYSTEM_PLAYBACK_RATE_R16X = 14;
	int SYSTEM_PLAYBACK_RATE_PAUSE = 20;

	int systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F1X;
	int systemPlaybackRatePause = SYSTEM_PLAYBACK_RATE_F1X; // toggle
	// pause

	int HISTOGRAM_DISPLAY_LINEAR = 0;
	int HISTOGRAM_DISPLAY_EXPONENTIAL = 1;
	int histogramDisplayState = HISTOGRAM_DISPLAY_EXPONENTIAL;
	BufferedImage histogramImage;

	int tivoStatusBarX;// viewportTileX;
	int scaOpMaskX;
	int scaOpMaskW;

	// contrast slider bars
	int contrastBarTickX;
	int contrastBarSpaceX;

	int[] histClusterCutoffs = { (int) (Math.pow(2, 8)),
			(int) (Math.pow(2, 12)), (int) (Math.pow(2, 14)),
			(int) (Math.pow(2, 16)) };
	int[] histClusterSizes = { 1, 8, 32, 128 };
	int histClusterSize = 2;
	int histBins = (int) (Math.pow(2, 11) - 1); // 12
	// int histBins = (int) (Math.pow(2, 14) - 1);
	int histBinsWindow;

	int histWindowW;

	int contrastBarX;

	int histX;// tivoInfoBarX;
	int histY;// h -10;
	int histWindowH;
	int histAdjustHandleSize;

	int tivoInfoBarX;
	int tivoStatusBarY;
	int userSelectionLowerBoundary;
	int tivoStatusBarTickX;// 5;
	int tivoStatusBarTickYmaster;// 5;
	int tivoStatusBarTickY;// 5;
	int tivoStatusBarTickYsliver;// 5;
	// int tivoStatusBarTickYData = 10;//5;
	int tivoBarYSeparation;

	int tivoGraphicsH2;
	int tivoGraphicsY2; // where
	// the
	// playhead
	// lives

	// loop handles
	int loopSelectorHeight;
	int loopSelectorY;
	int loopSelectorY2;
	int loopBoundStartX;
	int loopBoundEndX;

	// individual status bars
	int tivoStatusBarYRay[];

	// tivo status overlay
	int tivoInfoBarY;

	Color statusColors[] = new Color[WC.MODE_COUNT];
	Color uiColors[] = new Color[WC.UI_COLOR_COUNT];

	// params

	ArrayList paramLists[][];
	int defaultInputSrc = WC.THREAD_LOAD_HDF5R;

	int diffSkip = 2;
	int timelapseSkip = 2;
	int timelapseHistory = 30; // 20
	int timelapseSource = WC.THREAD_DIFF;// WC.THREAD_LOAD_HDF5R;

	int showHistogram = 1;

	// lens - temporary until openGL zoom
	int lensStatus = WC.STATUS_READY;
	int lensX;
	int lensY;
	int magnifierToggle = 0; // flip flop based on cursor
	int magTogYTop;
	int magTogYBottom;

	// map data
	MapLoader map = new MapLoader();

	// GPU

	int inputSrcGPU = WC.THREAD_LOAD_HDF5R;

	int gpuRastPosX = 0;
	int gpuRastPosY = 0;

	int gpuState = 0;

	int GLOBE_DATA_GEODATA = 0; // only render the SCA outlines
	int GLOBE_DATA_INTENSITY = 1; // only render the SCA outlines
	int globeDataMode = GLOBE_DATA_GEODATA;

	// end GPU

	public static void main(String args[]) {
		cvt = new CV_MT_Disp();

		// do this init first
		String conf = null;
		if (args.length > 0) {
			for (int i = 0; i < args.length; i++) {
				if (args[i].equalsIgnoreCase("-conf")) {
					if (args.length > i) {
						conf = args[i + 1];
					}
				}
			}
		}
		// strBdr = "LOADING WIT - RECEIVED ";
		StringBuilder strBdr = new StringBuilder();
		strBdr.append("LOADING WIT - RECEIVED ");
		strBdr.append(args.length);
		strBdr.append(" ARGS");
		System.out.println(strBdr);


		cvt.initMasterConfig(conf);
		cvt.initUIDims();
		cvt.setSize(cvt.viewportX, cvt.viewportY);

		//cvt.loadMapData();

		cvt.loadParamLists();
		cvt.loadPlaybackState();
		cvt.loadUserState(); // can override the default config
		cvt.initMiniMap();
		cvt.initFormats();
		cvt.initWidgets();
		cvt.initOpMasks();
		cvt.initPlaybackParams();
		//		cvt.initBiasPerChannel();
		cvt.initSCAselectorGraphics();

		cvt.initXmlTemplates();
		cvt.initXmlWidget();

		// cvt.setDefaultCloseOperation();

		cvt.setTitle("Wideband Imagery Tool");

		cvt.tivoCanvas = new JPanel();

		// tivoCanvas = new Canvas();

		cvt.addKeyListener(cvt);
		cvt.tivoCanvas.addMouseListener(cvt);
		cvt.tivoCanvas.addMouseMotionListener(cvt);

		cvt.addComponentListener(cvt);

		cvt.add(cvt.tivoCanvas);

		cvt.tivoCanvas.setDoubleBuffered(true);


		cvt.initVidExportUI();

		WindowListener witWIndowListener = new WindowListener() {

			@Override
			public void windowActivated(WindowEvent e) {
				// TODO Auto-generated method stub

				// System.out.println("WIT ACTIVE");
			}

			@Override
			public void windowClosed(WindowEvent e) {
				// TODO Auto-generated method stub
				// System.out.println("WIT SHUTDOWN");
			}

			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub

				System.out.println("WIT SHUTDOWN");
				// cvt = null;
			}

			@Override
			public void windowDeactivated(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeiconified(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowIconified(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowOpened(WindowEvent e) {
				// TODO Auto-generated method stub

				// System.out.println("WIT VIEW OPEN");
			}

		};

		cvt.addWindowListener(witWIndowListener);

		GraphicsEnvironment ge = GraphicsEnvironment
		.getLocalGraphicsEnvironment();

		String[] fontNames = ge.getAvailableFontFamilyNames();

		for (int i = 0; i < fontNames.length; i++) {
			// System.out.println(fontNames[i]);
		}

		cvt.tivoCanvas.requestFocus();

		cvt.viewportImage = new BufferedImage(cvt.viewportX, cvt.viewportY,
				BufferedImage.TYPE_INT_RGB);
		cvt.viewportImageRot = new BufferedImage(cvt.viewportX, cvt.viewportY,
				BufferedImage.TYPE_INT_RGB);

		cvt.viewportImageOverlay = new BufferedImage(cvt.viewportX,
				cvt.viewportY, BufferedImage.TYPE_INT_ARGB);

		// optimizations
		cvt.g = (Graphics2D) cvt.viewportImage.getGraphics();
		cvt.gb = (Graphics2D) cvt.viewportImageOverlay.getGraphics();
		cvt.gwc = (Graphics2D) cvt.tivoCanvas.getGraphics();

		cvt.graphicComposites = new Composite[12];
		cvt.graphicComposites[c_WORKING] = makeComposite(.6f);
		cvt.graphicComposites[c_LOOP_SELECTION] = makeComposite(.45f);
		cvt.graphicComposites[c_COMPLETE] = makeComposite(1.0f);

		cvt.graphicComposites[c_LATLON_OVERLAY] = makeComposite(.50f);
		cvt.graphicComposites[c_WIDGET] = makeComposite(.8f);

		// imprContrastRay = new ImpContrastThread[maxLoaderThreads];

		// construct idle threads

		cvt.resetThreads();

		cvt.initNetworkFeatures();

		cvt.restoreState(cvt.restoreStateMode);

		// thread params

		cvt.initTimeline();
		cvt.initTimelineRefs();
		cvt.initPriorities();
		cvt.initTimeouts();
		cvt.initOpBuffers();
		cvt.initLayerProperties();
		cvt.initParamLists();
		cvt.initTivoBars();
		cvt.initUserContrast();
		cvt.initGraphicsElements();
		cvt.initFrameLists();

		cvt.initTimelineImage();

		cvt.scaOffsets = ImProcThread.initSCAoffsets(1);

		// UI - with enabled ops
		cvt.populateMenus(cvt);

		cvt.setVisible(true);

		// init UI bits

		// default color

		for (int i = 0; i < WC.MODE_COUNT; i++) {
			cvt.statusColors[i] = new Color(40, 80, 255);
		}

		cvt.initColors();

		cvt.userFlight = 0; 

		cvt.initUserElements();

		cvt.openFiles();

		while (true) {
			if (cvt != null) {
				if (cvt.systemState == WC.SYSTEM_STATE_ONLINE) {
					cvt.doSystemLoop();
				}
			}
		}
	}

	public void writeBiasPerChannel(){
		String biasFileStr = "";

		String flightTagStr = "<FLIGHT>";
		String flightEndTagStr = "</FLIGHT>";
		String scaTagStr = "<SCA>";
		String scaEndTagStr = "</SCA>";
		String scanDirTagStr = "<SCAN_DIR>";
		String scanDirEndTagStr = "</SCAN_DIR>";
		String channelTagStr = "<CHANNEL>";
		String channelEndTagStr = "</CHANNEL>";
		String biasTagStr = "<BIAS>";
		String biasEndTagStr = "</BIAS>";

		for (int f=0; f<WC.TOTAL_FLIGHTS; f++){

			biasFileStr+=flightTagStr;
			biasFileStr+=f;
			biasFileStr+=flightEndTagStr;
			biasFileStr+="/n";

			for (int s=0; s<WC.TOTAL_SCAS; s++){

				biasFileStr+=scaTagStr;
				biasFileStr+=s;
				biasFileStr+=scaEndTagStr;
				biasFileStr+="/n";

				for (int d=0; d<2; d++){

					biasFileStr+=scanDirTagStr;
					biasFileStr+=d;
					biasFileStr+=scanDirEndTagStr;
					biasFileStr+="/n";

					for (int c=0; c<WC.SCA_CHANNELS; c++){

						biasFileStr+=channelTagStr;
						biasFileStr+=c;
						biasFileStr+=channelEndTagStr;
						biasFileStr+="/n";

						biasFileStr+=biasTagStr;
						biasFileStr+= "intensityBiasPerScaPerChannel[f][s][c][d]";
						biasFileStr+=biasEndTagStr;
						biasFileStr+="/n";
					}
				}
			}
		}

		// save file
	}

	public void initXmlWidget() {
		xeui = new XmlExportUI();

		xeui.init();

		xeui.setLocation(400, 400);

	}

	public void initBiasPerChannel(){
		System.out.println("LOADING CHANNEL BIASES");

		File loadFile = new File(intensityBiasFileStr);
		BufferedReader bin;

		ArrayList tagList = new ArrayList();

		tagList.add("<FLIGHT>");
		tagList.add("<SCA>");
		tagList.add("<SCAN_DIR>");
		tagList.add("<CHANNEL>");
		tagList.add("<BIAS>");

		try {
			bin = new BufferedReader(
					new FileReader(loadFile));

			// load the file
			String fileContents = "";

			while (bin.ready()) {
				String ln = bin.readLine();
				fileContents = ln;

				int currFlight = WC.STATUS_ERROR;
				int currSca = WC.STATUS_ERROR;
				int currChannel = WC.STATUS_ERROR;
				int currScanDir = WC.STATUS_ERROR;
				int currBias = WC.STATUS_ERROR;

				int writeValue = WC.STATUS_ERROR; 

				for (int i = 0; i < tagList.size(); i++) {

					String identifier = (String) tagList.get(i);
					String closure = identifier.substring(0, 1) + "/"
					+ identifier.substring(1);
					int itemStart = fileContents.indexOf(identifier)
					+ identifier.length();
					int itemEnd = fileContents.indexOf(closure);
					String dataStr = fileContents.substring(itemStart,
							itemEnd);

					dataStr.trim();

					if (identifier.equalsIgnoreCase("<FLIGHT>")) {
						currFlight = (Integer.parseInt(dataStr));
					} else if (identifier.equalsIgnoreCase("<SCA>")) {
						currSca = (Integer.parseInt(dataStr));
					} else if (identifier.equalsIgnoreCase("<CHANNEL>")) {
						currChannel = (Integer.parseInt(dataStr));
					} else if (identifier.equalsIgnoreCase("<SCAN_DIR>")) {
						currScanDir = (Integer.parseInt(dataStr));
					} else if (identifier.equalsIgnoreCase("<BIAS>")) {
						currBias = (Integer.parseInt(dataStr));
						writeValue = WC.STATUS_READY;
					}

					if (writeValue == WC.STATUS_READY && currFlight != WC.STATUS_ERROR && currSca != WC.STATUS_ERROR && currScanDir != WC.STATUS_ERROR && currChannel != WC.STATUS_ERROR){
						writeValue = WC.STATUS_ERROR;
						intensityBiasPerScaPerChannel[currFlight][currSca][currChannel][currScanDir] = currBias;
					}

				}


			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void initUIDims() {
		minPanX = (int) (-768f * 8.2f + viewportX);// (int)(-768f * 4.85f);
		maxPanX = 0;
		minPanY = -MAX_SCAN_LENGTH + viewportY;
		maxPanY = 0;

		timelineCenterX = viewportX / 4;

		userPanOffset[GOAL][WC.X] = -WC.SCA_CHANNELS * (SCA_FOCUS - 1); // default
		// to
		// SCAs 3+4
		if (minPanX > userPanOffset[GOAL][WC.X]) {
			userPanOffset[GOAL][WC.X] = minPanX;
		}

		tivoStatusBarY = viewportY - 240;// viewportTileY*1 + 80;
		tivoStatusBarX = 160;// viewportTileX;
		tivoInfoBarX = 20;
		tivoInfoBarY = viewportY - 60;

		scaOpMaskX = tivoStatusBarX - 32;
		scaOpMaskW = 30;

		// contrast slider bars
		contrastBarTickX = 1;
		contrastBarSpaceX = 1;

		// loop handles
		loopSelectorHeight = 100;
		loopSelectorY = tivoStatusBarY + 20;
		loopSelectorY2 = tivoStatusBarY + loopSelectorHeight;
		loopBoundStartX = tivoStatusBarX + (int) userTimelineOffset[CURRENT]
		                                                            + userSelection[WC.START][WC.T];
		loopBoundEndX = tivoStatusBarX + (int) userTimelineOffset[CURRENT]
		                                                          + userSelection[WC.END][WC.T];

		// histogram / contrast

		contrastBarX = tivoInfoBarX;
		histWindowW = histBins / histClusterSize;
		histWindowH = 255;
		histY = viewportY - 80;// viewportY - 120;// h -10;
		histX = contrastBarX;// tivoInfoBarX;

		histAdjustHandleSize = 20;
		// contrastBarX = viewportX - histWindowW - 30;
		histBinsWindow = histBins; // modify for smaller window

		tivoGraphicsH2 = 80;
		tivoGraphicsY2 = tivoStatusBarY + tivoGraphicsH2 - 3; // where
		userSelectionLowerBoundary = tivoStatusBarY - 10;
		tivoStatusBarTickX = 1;
		tivoStatusBarTickYmaster = 24;
		tivoStatusBarTickY = 8;
		tivoStatusBarTickYsliver = 3;
		tivoBarYSeparation = tivoStatusBarTickY + 1 + 5;

		// lense
		lensX = 200;
		lensY = 200;
		magTogYTop = 500;
		magTogYBottom = 800;
	}


	public void initMasterConfig(String confFile) {
		// 
		if (confFile == null) {
			confFile = masterConfigFileStr;
		}
		File loadFile = new File(confFile);

		ArrayList tagList = new ArrayList();

		tagList.add("<MAX_THREADS_QUEUED>");
		tagList.add("<MAX_THREADS_ACTIVE>");

		tagList.add("<DISPLAY_WIDTH>");
		tagList.add("<DISPLAY_HEIGHT>");

		tagList.add("<SCA_FOCUS>");

		tagList.add("<INPUT_DIR>");
		tagList.add("<OUTPUT_DIR>");

		tagList.add("<RESOURCE_DIR>");
		tagList.add("<MAP_DATA_DIR>");
		tagList.add("<MAP_GRAPHIC>");
		tagList.add("<FFMPEG_SCRATCH_DIR>");
		tagList.add("<DEFAULT_CLASSIFICATION_LABEL>");
		tagList.add("<DEFAULT_TITLE_LABEL>");
		tagList.add("<WEB_HELP_LOCATION>");

		tagList.add("<UI_AUTO_SCROLL>");

		tagList.add("<KML_POLY_TEMPLATE>");
		tagList.add("<COT_POLY_TEMPLATE>");

		tagList.add("<AUTO_RELOAD_FREQUENCY>");
		tagList.add("<AUTO_RELOAD_TOGGLE>");

		int loadedItemChecklist[] = new int[tagList.size()];
		String loadedItemStr[] = new String[tagList.size()];

		try {
			if (loadFile != null) {
				System.out.println("LOADING WIT CONFIG FILE... "
						+ loadFile.getAbsoluteFile());
				BufferedReader bin = new BufferedReader(
						new FileReader(loadFile));

				// load the file
				String fileContents = "";

				while (bin.ready()) {
					String ln = bin.readLine();
					fileContents += ln;
				}

				for (int i = 0; i < tagList.size(); i++) {

					String identifier = (String) tagList.get(i);
					String closure = identifier.substring(0, 1) + "/"
					+ identifier.substring(1);
					int itemStart = fileContents.indexOf(identifier)
					+ identifier.length();
					int itemEnd = fileContents.indexOf(closure);

					if (itemStart>=0 && itemEnd >=0){
						String dataStr = fileContents.substring(itemStart, itemEnd);

						dataStr.trim();

						// need to clean up matching of tags and WIT variables
						if (identifier.equalsIgnoreCase("<MAX_THREADS_QUEUED>")) {
							MAX_THREADS_QUEUED = (Integer.parseInt(dataStr));
							loadedItemChecklist[i] = 1;
						} else if (identifier
								.equalsIgnoreCase("<MAX_THREADS_ACTIVE>")) {
							MAX_THREADS_ACTIVE = (Integer.parseInt(dataStr));
							loadedItemChecklist[i] = 1;
						} else if (identifier.equalsIgnoreCase("<DISPLAY_WIDTH>")) {
							viewportX = (Integer.parseInt(dataStr));

							loadedItemChecklist[i] = 1;
						} else if (identifier.equalsIgnoreCase("<DISPLAY_HEIGHT>")) {
							viewportY = (Integer.parseInt(dataStr));

							loadedItemChecklist[i] = 1;
						} else if (identifier.equalsIgnoreCase("<SCA_FOCUS>")) {
							SCA_FOCUS = (Integer.parseInt(dataStr));
							loadedItemChecklist[i] = 1;
						}  else if (identifier
								.equalsIgnoreCase("<OPEN_ON_LAUNCH>")) {

						} else if (identifier
								.equalsIgnoreCase("<DEFAULT_CLASSIFICATION_LABEL>")) {
							productClassificationLabelStr = dataStr;
							loadedItemChecklist[i] = 1;
						} else if (identifier
								.equalsIgnoreCase("<DEFAULT_TITLE_LABEL>")) {
							productTitleLabelStr = dataStr;
							loadedItemChecklist[i] = 1;
						} else if (identifier
								.equalsIgnoreCase("<FFMPEG_SCRATCH_DIR>")) {
							defaultFfmpegScratchDirStr = dataStr;
							loadedItemChecklist[i] = 1;
						} else if (identifier.equalsIgnoreCase("<INCOMING_DIR>")) {

						} else if (identifier.equalsIgnoreCase("<INPUT_DIR>")) {
							defaultLoadDirStr = dataStr;
							loadedItemChecklist[i] = 1;
						} else if (identifier.equalsIgnoreCase("<OUTPUT_DIR>")) {
							defaultSaveDirStr = dataStr;
							loadedItemChecklist[i] = 1;
						} else if (identifier.equalsIgnoreCase("<RESOURCE_DIR>")) {
							defaultResourceDirStr = dataStr;
							loadedItemChecklist[i] = 1;
						} else if (identifier.equalsIgnoreCase("<MAP_DATA_DIR>")) {
							defaultMapDataDirStr = dataStr;
							loadedItemChecklist[i] = 1;
						} else if (identifier.equalsIgnoreCase("<MAP_GRAPHIC>")) {
							defaultMapGraphicStr = dataStr;
							loadedItemChecklist[i] = 1;
						} else if (identifier
								.equalsIgnoreCase("<WEB_HELP_LOCATION>")) {
							webHelpLocation = dataStr;
							loadedItemChecklist[i] = 1;
						} else if (identifier.equalsIgnoreCase("<UI_AUTO_SCROLL>")) {
							lockPlayhead = (Integer.parseInt(dataStr));
							loadedItemChecklist[i] = 1;
						} else if (identifier
								.equalsIgnoreCase("<AUTO_RELOAD_ENABLED>")) {
							autoReloadState = (Integer.parseInt(dataStr));
							loadedItemChecklist[i] = 1;
						} else if (identifier
								.equalsIgnoreCase("<AUTO_RELOAD_BUFFER_SECONDS>")) {

						} else if (identifier
								.equalsIgnoreCase("<AUTO_RELOAD_TIMER_SECONDS>")) {

						} else if (identifier
								.equalsIgnoreCase("<INCOMING_DATA_MONITOR_ENABLED>")) {

						}  else if (identifier
								.equalsIgnoreCase("<INCOMING_DATA_MONITOR_PREROLL_SECONDS>")) {

						} else if (identifier
								.equalsIgnoreCase("<INCOMING_DATA_MONITOR_UPDATE_MS>")) {

						} else if (identifier
								.equalsIgnoreCase("<INCOMING_DATA_MONITOR_LOCAL_TIME_OFFSET>")) {

						} else if (identifier.equalsIgnoreCase("<KML_POLY_TEMPLATE>")) {
							kmlPolyTemplateLocationStr = dataStr;
							loadedItemChecklist[i] = 1;
						}  else if (identifier.equalsIgnoreCase("<COT_POLY_TEMPLATE>")) {
							cotPolyTemplateLocationStr = dataStr;
							loadedItemChecklist[i] = 1;
						} 

						if (loadedItemChecklist[i] == 1) {
							loadedItemStr[i] = dataStr;
						}

					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		for (int i = 0; i < loadedItemChecklist.length; i++) {
			System.out.println("   LOADED SETTINGS FOR "
					+ (String) tagList.get(i) + " - " + loadedItemStr[i]);
		}
	}


	public void initMasterConfigOld(String confFile) {
		// 
		if (confFile == null) {
			confFile = masterConfigFileStr;
		}
		File loadFile = new File(confFile);

		ArrayList tagList = new ArrayList();

		tagList.add("<MAX_THREADS_QUEUED>");
		tagList.add("<MAX_THREADS_ACTIVE>");

		tagList.add("<DISPLAY_WIDTH>");
		tagList.add("<DISPLAY_HEIGHT>");

		tagList.add("<SCA_FOCUS>");

		tagList.add("<INPUT_DIR>");
		tagList.add("<OUTPUT_DIR>");

		tagList.add("<RESOURCE_DIR>");
		tagList.add("<MAP_DATA_DIR>");
		tagList.add("<MAP_GRAPHIC>");
		tagList.add("<FFMPEG_SCRATCH_DIR>");
		tagList.add("<DEFAULT_CLASSIFICATION_LABEL>");
		tagList.add("<DEFAULT_TITLE_LABEL>");
		tagList.add("<WEB_HELP_LOCATION>");

		tagList.add("<UI_AUTO_SCROLL>");

		tagList.add("<KML_POLY_TEMPLATE>");
		tagList.add("<COT_POLY_TEMPLATE>");

		tagList.add("<AUTO_RELOAD_FREQUENCY>");
		tagList.add("<AUTO_RELOAD_TOGGLE>");

		int loadedItemChecklist[] = new int[tagList.size()];
		String loadedItemStr[] = new String[tagList.size()];

		try {
			if (loadFile != null) {
				System.out.println("LOADING WIT CONFIG FILE... "
						+ loadFile.getAbsoluteFile());
				BufferedReader bin = new BufferedReader(
						new FileReader(loadFile));

				// load the file
				String fileContents = "";

				while (bin.ready()) {
					String ln = bin.readLine();
					fileContents += ln;
				}

				for (int i = 0; i < tagList.size(); i++) {

					String identifier = (String) tagList.get(i);
					String closure = identifier.substring(0, 1) + "/"
					+ identifier.substring(1);
					int itemStart = fileContents.indexOf(identifier)
					+ identifier.length();
					int itemEnd = fileContents.indexOf(closure);
					String dataStr = fileContents.substring(itemStart, itemEnd);

					dataStr.trim();

					// need to clean up matching of tags and WIT variables
					if (identifier.equalsIgnoreCase("<MAX_THREADS_QUEUED>")) {
						MAX_THREADS_QUEUED = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<MAX_THREADS_ACTIVE>")) {
						MAX_THREADS_ACTIVE = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					}  else if (identifier.equalsIgnoreCase("<DISPLAY_WIDTH>")) {
						viewportX = (Integer.parseInt(dataStr));

						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<DISPLAY_HEIGHT>")) {
						viewportY = (Integer.parseInt(dataStr));

						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<SCA_FOCUS>")) {
						SCA_FOCUS = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<DEFAULT_CLASSIFICATION_LABEL>")) {
						productClassificationLabelStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<DEFAULT_TITLE_LABEL>")) {
						productTitleLabelStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<FFMPEG_SCRATCH_DIR>")) {
						defaultFfmpegScratchDirStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<INPUT_DIR>")) {
						defaultLoadDirStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<OUTPUT_DIR>")) {
						defaultSaveDirStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<RESOURCE_DIR>")) {
						defaultResourceDirStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<MAP_DATA_DIR>")) {
						defaultMapDataDirStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<MAP_GRAPHIC>")) {
						defaultMapGraphicStr = dataStr;
						loadedItemChecklist[i] = 1;
					}  else if (identifier.equalsIgnoreCase("<KML_POLY_TEMPLATE>")) {
						kmlPolyTemplateLocationStr = dataStr;
						loadedItemChecklist[i] = 1;
					}  else if (identifier.equalsIgnoreCase("<COT_POLY_TEMPLATE>")) {
						cotPolyTemplateLocationStr = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<RECONSTRUCT_FULL_SCANS>")) {
						reconstructFullScans = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier
							.equalsIgnoreCase("<WEB_HELP_LOCATION>")) {
						webHelpLocation = dataStr;
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<UI_AUTO_SCROLL>")) {
						lockPlayhead = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<AUTO_RELOAD_TOGGLE>")) {
						autoReloadState = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					} else if (identifier.equalsIgnoreCase("<AUTO_RELOAD_FREQUENCY>")) {
						autoReloadSeconds = (Integer.parseInt(dataStr));
						loadedItemChecklist[i] = 1;
					}

					if (loadedItemChecklist[i] == 1) {
						loadedItemStr[i] = dataStr;
					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		for (int i = 0; i < loadedItemChecklist.length; i++) {
			System.out.println("   LOADED SETTINGS FOR "
					+ (String) tagList.get(i) + " - " + loadedItemStr[i]);
		}
	}

	public void histogramZoom(int dir) {
		if (dir == 1) { // in
			histogramZoomLevel *= 2;
		} else if (dir == -1) { // out
			histogramZoomLevel /= 2;
		}
		if (histogramZoomLevel < histogramMinZoomLevel) {
			histogramZoomLevel = histogramMinZoomLevel;
		}
		if (histogramZoomLevel > histogramMaxZoomLevel) {
			histogramZoomLevel = histogramMaxZoomLevel;
		}
		System.out.println("histogram zoom level " + histogramZoomLevel);
		contrastBarSpaceX = histogramZoomLevel;
		histClusterSize = histogramMaxZoomLevel / histogramZoomLevel;
	}

	public void initColors() {
		statusColors[WC.THREAD_LOAD] = new Color(190, 180, 180);
		statusColors[WC.THREAD_LOAD_HDF5R] = new Color(170, 180, 190);
		statusColors[WC.THREAD_CONV] = new Color(80, 120, 255);
		statusColors[WC.THREAD_SEGMENT] = new Color(40, 80, 255);
		statusColors[WC.THREAD_DIFF] = new Color(40, 80, 255);
		statusColors[WC.THREAD_TIMELAPSE] = new Color(40, 80, 255);
		statusColors[WC.THREAD_FILT] = new Color(255, 100, 255);
		statusColors[WC.THREAD_THRS] = new Color(0, 200, 50);
		statusColors[WC.THREAD_CONTRAST] = new Color(0, 140, 250);
		statusColors[WC.THREAD_HISTOGRAM] = new Color(0, 140, 250);
		statusColors[WC.THREAD_REGISTRATION] = new Color(0, 140, 250);
		statusColors[WC.THREAD_EXPORT_VIDEO] = new Color(110, 0, 0);
		statusColors[WC.THREAD_EXPORT_IMAGES] = new Color(110, 0, 0);

		uiColors[WC.COLOR_TIVO_PLAYHEAD] = new Color(255, 255, 255);
		uiColors[WC.COLOR_TIVO_SELECTION_WORKING] = new Color(255, 20, 0);
		uiColors[WC.COLOR_TIVO_SELECTION_COMPLETE] = new Color(150, 0, 0);

		uiColors[WC.COLOR_TIVO_PLAYHEAD_PEER] = new Color(255, 255, 255);
		uiColors[WC.COLOR_TIVO_PLAYHEAD_LOCKED] = new Color(255, 255, 100);

		uiColors[WC.COLOR_HIST_IN] = new Color(0, 140, 250);
		uiColors[WC.COLOR_HIST_OUT] = new Color(40, 80, 255);

		uiColors[WC.COLOR_TIVO_FILTER_REGION_COMPLETE] = new Color(0, 200, 0);
		uiColors[WC.COLOR_TIVO_FILTER_REGION_WORKING] = new Color(0, 200, 0);

		uiColors[WC.COLOR_TIVO_TIMELINE_EMPTY] = new Color(60, 60, 70); 
		uiColors[WC.COLOR_TIVO_TIMELINE_READY] = new Color(40, 80, 255); 
		uiColors[WC.COLOR_TIVO_TIMELINE_WORKING] = new Color(0, 140, 250); 
		uiColors[WC.COLOR_TIVO_TIMELINE_COMPLETE] = new Color(0, 255, 0); 
		uiColors[WC.COLOR_TIVO_TIMELINE_CALLOUT1] = new Color(80, 0, 200); 

		uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_OLD] = new Color(0, 90, 0);
		uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_INFO] = new Color(0, 255, 0);
		uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_NEW] = new Color(200,200,200);
		uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_SELECTED_REAL] = new Color(255,50, 0);
		uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_SELECTED_INFO] = new Color(0,255, 0);

		// missing data in the files
		uiColors[WC.COLOR_TIVO_TIMELINE_MISSING_GEOLOCATION] = new Color(255,30, 0);
		uiColors[WC.COLOR_TIVO_TIMELINE_MISSING_TIME] = new Color(255, 30, 0);
		uiColors[WC.COLOR_TIVO_TIMELINE_MISSING_INTENSITIES] = new Color(255, 30, 0);

		uiColors[WC.COLOR_TIVO_SCA_SELECT_ON] = new Color(0, 230, 0);
		uiColors[WC.COLOR_TIVO_SCA_SELECT_OFF] = new Color(80, 80, 80);
		uiColors[WC.COLOR_TIVO_SCA_SELECT_SWIR] = new Color(255, 255, 255);
		uiColors[WC.COLOR_TIVO_SCA_SELECT_MWIR] = new Color(0, 0, 250);
		uiColors[WC.COLOR_TIVO_SCA_SELECT_STG] = new Color(80, 0, 200);
	}

	public void initFrameLists() {
		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				witFrameList[flight][k] = new ArrayList();
			}
		}
	}




	public void initMiniMap() {

		miniMapSize[CURRENT][WC.X] = (int) (miniMapScale * (8.3f * 768f));
		miniMapSize[CURRENT][WC.Y] = (int) (miniMapScale * MAX_SCAN_LENGTH);
		miniMapPos[CURRENT][WC.X] = viewportX - miniMapSize[CURRENT][WC.X] - 20;
		miniMapPos[CURRENT][WC.Y] = viewportY - miniMapSize[CURRENT][WC.Y] - 80;

		miniMapInsetPos[CURRENT][WC.X] = 0;
		miniMapInsetPos[CURRENT][WC.Y] = 0;
		miniMapInsetSize[CURRENT][WC.X] = (int) (miniMapScale * viewportX);

		miniMapInsetSize[CURRENT][WC.Y] = (int) (miniMapScale * viewportY);


		// globe
		miniGlobeSize[CURRENT][WC.X] = (int) (miniGlobeScale * (360f));
		miniGlobeSize[CURRENT][WC.Y] = (int) (miniGlobeScale * 180f);
		miniGlobePos[CURRENT][WC.X] = viewportX - miniMapSize[CURRENT][WC.X]
		                                                               - 20 - miniGlobeSize[CURRENT][WC.X] - 20;
		miniGlobePos[CURRENT][WC.Y] = viewportY - miniGlobeSize[CURRENT][WC.Y]
		                                                                 - 80;

		BufferedImage tempImage = loadImageBI(defaultMapGraphicStr);
		miniGlobeImage = new BufferedImage((int) (miniGlobeScale * (360f)),
				(int) (miniGlobeScale * (180f)), BufferedImage.TYPE_INT_RGB);
		Graphics2D gmini = (Graphics2D) miniGlobeImage.getGraphics();

		gmini.setRenderingHint(RenderingHints.KEY_RENDERING,
				RenderingHints.VALUE_RENDER_QUALITY);
		gmini.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
				RenderingHints.VALUE_INTERPOLATION_BICUBIC);

		if (tempImage != null){
			int nudge = 1;
			for (int yOff = -nudge; yOff <= nudge; yOff++) {
				for (int xOff = -nudge; xOff <= nudge; xOff++) {
					gmini.drawImage(tempImage, 0, 0,
							(int) (miniGlobeScale * (360f)) + xOff,
							(int) (miniGlobeScale * (180f)) + yOff, null);
				}
			}
		}
	}

	public void initWidgets() {
		for (int i = 0; i < WC.MAX_WIDGETS; i++) {
			widgetVisibility[i] = 0;
		}
		widgetVisibility[WC.WIDGET_MINIMAP] = 1;
		widgetVisibility[WC.WIDGET_MINIGLOBE] = 1;
	}

	public void initPlaybackParams() {
		for (int f = 0; f < WC.TOTAL_FLIGHTS; f++) {
			for (int i = 0; i < WC.SCAN_SEQ_INDEX_MAX_VAL; i++) {
				playbackScanSeqIndexMask[f][i] = WC.STATUS_ON;
				sosScanSeqIndexLabel[i] = "";
			}
		}
	}

	public void initFormats() {
		for (int i = 0; i < outputFormatExtStr.length; i++) {
			outputFormatExtStr[i] = new String("");
		}

		outputFormatExtStr[FORMAT_PNG] = ".png";
		outputFormatExtStr[FORMAT_JPG] = ".jpg";
		outputFormatExtStr[FORMAT_MP4] = ".mp4";
		outputFormatExtStr[FORMAT_MPG] = ".mpg";
		outputFormatExtStr[FORMAT_WMV] = ".wmv";
	}

	public void initGraphicsElements() {
		stroke1 = new BasicStroke(pointerW1 * 2 + 1);
		stroke2 = new BasicStroke(1);

		strokeWidth1 = new BasicStroke(1);
		strokeWidth2 = new BasicStroke(2);
		strokeWidth3 = new BasicStroke(3);

		gMain = (Graphics2D) viewportImage.getGraphics();

		graphicComposites[c_WORKING] = makeComposite(.6f);
		graphicComposites[c_LOOP_SELECTION] = makeComposite(.45f);
		graphicComposites[c_COMPLETE] = makeComposite(1.0f);

		graphicsStatus = WC.STATUS_READY;
	}

	public void initVidExportUI() {
		vidExportUI = new VideoExportUI();

		vidExportUI.init();
		vidExportUI.securityLabel.setText(productClassificationLabelStr);
		vidExportUI.titleLabel.setText(productTitleLabelStr);

		vidExportUI.setLocation(400, 400);

	}

	public void initSCAselectorGraphics() {
		int selectorGraphicW = 200;
		int selectorGraphicH = 200;
		int selectorGraphicMargin = 20;
		int selectorGraphicEvenOddOffset = -100;
		int selectorGraphicMBoffset = selectorGraphicH + selectorGraphicMargin;

		int selectorGraphicWcenter = viewportX / 2
		- (3 * (selectorGraphicW + selectorGraphicMargin));
		int selectorGraphicHcenter = viewportY / 2 - (2 * (selectorGraphicH));
		for (int i = 0; i < 6; i++) {
			scaSelectorGraphic[i][WC.X] = i
			* (selectorGraphicW + selectorGraphicMargin)
			+ selectorGraphicWcenter;
			scaSelectorGraphic[i][WC.Y] = (selectorGraphicH + selectorGraphicMargin)
			+ selectorGraphicHcenter;
			if (i % 2 == 0) {
				scaSelectorGraphic[i][WC.Y] += selectorGraphicEvenOddOffset;
			}
		}
		scaSelectorGraphic[6][WC.X] = scaSelectorGraphic[1][WC.X];
		scaSelectorGraphic[6][WC.Y] = scaSelectorGraphic[1][WC.Y]
		                                                    - selectorGraphicMBoffset;

		scaSelectorGraphic[7][WC.X] = scaSelectorGraphic[3][WC.X];
		scaSelectorGraphic[7][WC.Y] = scaSelectorGraphic[3][WC.Y]
		                                                    - selectorGraphicMBoffset;

		for (int i = 0; i < WC.TOTAL_SCAS; i++) {
			scaSelectorGraphic[i][2] = selectorGraphicW;
			scaSelectorGraphic[i][3] = selectorGraphicH;
		}

		// set bands and strings
		for (int i = 0; i < 6; i++) {
			scaSelectorBand[i] = WC.COLOR_TIVO_SCA_SELECT_SWIR;
			scaSelectorString[i] = "SCA " + (i + 1) + " - SWIR";
		}

		scaSelectorBand[6] = WC.COLOR_TIVO_SCA_SELECT_STG;
		scaSelectorString[6] = "SCA " + (7) + " - STG";

		scaSelectorBand[7] = WC.COLOR_TIVO_SCA_SELECT_MWIR;
		scaSelectorString[7] = "SCA " + (8) + " - MWIR";
	}

	public void initUserElements() {

		userContrastCPList = new ArrayList();

		int compassSize = 50;
		compassImage = new BufferedImage(compassSize, compassSize,
				BufferedImage.TYPE_INT_ARGB);
		compassImageRot = new BufferedImage(compassSize, compassSize,
				BufferedImage.TYPE_INT_ARGB);

		Graphics2D g = (Graphics2D) compassImage.getGraphics();

		g.setColor(statusColors[WC.THREAD_DIFF]);
		g.fillRect(compassSize / 2 - 1, 1, 2, compassSize - 1);
		g.fillRect(1, compassSize / 2 - 1, compassSize - 1, 2);

		g.setColor(Color.GREEN);
		g.fillRect(compassSize / 2 - 2, compassSize / 2, 4, compassSize - 1);

		int radiusComp = 12;

		g.setColor(statusColors[WC.THREAD_DIFF]);
		g.fillOval(compassSize / 2 - radiusComp, compassSize / 2 - radiusComp,
				radiusComp * 2, radiusComp * 2);

		g.setColor(Color.WHITE);
		g.drawString("N", compassSize / 2 - 4, 30);
		g.drawString("N", compassSize / 2 - 5, 30);

	}

	public void initXmlTemplates(){

		String kmlTemplateCompletePath = defaultResourceDirStr+""+kmlPolyTemplateLocationStr;
		String cotTemplateCompletePath = defaultResourceDirStr+""+cotPolyTemplateLocationStr;
		try {
			BufferedReader binKml = new BufferedReader(
					new FileReader(kmlTemplateCompletePath));

			String line;
			while (binKml.ready()){
				line = binKml.readLine();
				kmlPolyTemplateStr += line+"\n";	
			}
		} catch (Exception e){
			e.printStackTrace();
		}

		try {
			BufferedReader binCot = new BufferedReader(
					new FileReader(cotTemplateCompletePath));

			String line;
			while (binCot.ready()){
				line = binCot.readLine();
				cotPolyTemplateStr += line+"\n";
			}
		} catch (Exception e){
			e.printStackTrace();
		}

	}

	public void createKmlMessageStr(){
		if (kmlPolyTemplateStr!= null){
			if (kmlPolyTemplateStr.length() > 0){
				kmlPolyMessageStr = kmlPolyTemplateStr;

				int insertCoordsIndex = kmlPolyMessageStr.indexOf("</coordinates>");

				String coordStr = "";
				if (poly!=null){
					if (poly != null){
						if (poly.polyPoints!= null){
							if (poly.polyPoints.size() > 0){
								for (int i=0; i<poly.polyPoints.size(); i++){
									WxPolyPoint wxp = (WxPolyPoint)poly.polyPoints.get(i);

									coordStr += wxp.lon;
									coordStr += ",";
									coordStr += wxp.lat;
									coordStr += ",0";
									if (i<poly.polyPoints.size()-1){
										coordStr+= " ";
									}
								}
							}
						}
					}
				}

				String coordInsertStr = "";
				coordInsertStr = kmlPolyMessageStr.substring(0, insertCoordsIndex);
				coordInsertStr += coordStr;
				coordInsertStr += kmlPolyMessageStr.substring(insertCoordsIndex, kmlPolyMessageStr.length());
				kmlPolyMessageStr = coordInsertStr;

				int insertNameIndex = kmlPolyMessageStr.indexOf("</name>");
				String nameInsertStr = "";
				nameInsertStr = kmlPolyMessageStr.substring(0, insertNameIndex);
				nameInsertStr += "WX_POLY";
				nameInsertStr += kmlPolyMessageStr.substring(insertNameIndex, kmlPolyMessageStr.length());
				kmlPolyMessageStr = nameInsertStr;


				insertNameIndex = kmlPolyMessageStr.lastIndexOf("</name>");
				nameInsertStr = "";
				nameInsertStr = kmlPolyMessageStr.substring(0, insertNameIndex);
				nameInsertStr += "WX_POLY";
				nameInsertStr += kmlPolyMessageStr.substring(insertNameIndex, kmlPolyMessageStr.length());
				kmlPolyMessageStr = nameInsertStr;

			}
		}
	}

	public void createCotMessageStr(){
		if (cotPolyTemplateStr!= null){

			if (cotPolyTemplateStr.length() > 0){

				cotPolyMessageStr = cotPolyTemplateStr;

				int insertCoordsIndex = cotPolyMessageStr.indexOf("</polyline>");

				String coordStr = "";
				if (poly!=null){
					if (poly != null){
						if (poly.polyPoints!= null){
							if (poly.polyPoints.size() > 0){
								for (int i=0; i<poly.polyPoints.size(); i++){
									WxPolyPoint wxp = (WxPolyPoint)poly.polyPoints.get(i);

									coordStr += "<vertex lat=\""+wxp.lat+"\" lon=\""+wxp.lon+"\" hae=\"0.0\"/>";

									if (i<poly.polyPoints.size()-1){
										coordStr += "\n";
									}
								}
							}
						}
					}
				}

				String coordInsertStr = "";
				coordInsertStr = cotPolyMessageStr.substring(0, insertCoordsIndex);
				coordInsertStr += coordStr;
				coordInsertStr += cotPolyMessageStr.substring(insertCoordsIndex, cotPolyMessageStr.length());
				cotPolyMessageStr = coordInsertStr;
			}
		}
	}

	public String createCotTimeStr(float secsOfDay){
		String timeStr = "";

		return timeStr;
	}

	public void initOpMasks() {
		for (int i = 0; i < opMask.length; i++) {
			opMask[i] = false; 
			filterRegionReqMask[i] = 0; 
		}
		opMask[WC.THREAD_LOAD] = false;
		opMask[WC.THREAD_DIFF] = false; // 1
		opMask[WC.THREAD_FEAT] = false;
		opMask[WC.THREAD_THRS] = false;
		opMask[WC.THREAD_CONV] = false;
		opMask[WC.THREAD_DEJITTER] = false;
		opMask[WC.THREAD_SEGMENT] = false;// 1;
		opMask[WC.THREAD_FILT] = false;
		opMask[WC.THREAD_MON] = false;
		opMask[WC.THREAD_HISTOGRAM] = false;
		opMask[WC.THREAD_HISTOGRAM_EQ] = false;
		opMask[WC.THREAD_TEMPORAL] = false;// 1;
		opMask[WC.THREAD_HISTOGRAM] = false;
		opMask[WC.THREAD_HISTOGRAM_EQ] = false;
		opMask[WC.THREAD_DEJITTER_ADV] = false;
		opMask[WC.THREAD_CONTRAST] = false;
		opMask[WC.THREAD_PREFILTER] = false;//true;

		filterRegionReqMask[WC.THREAD_DIFF] = 1;
		filterRegionReqMask[WC.THREAD_FEAT] = 1;
		filterRegionReqMask[WC.THREAD_DEJITTER] = 1;
		filterRegionReqMask[WC.THREAD_TEMPORAL] = 1;
		filterRegionReqMask[WC.THREAD_CONTRAST] = 1;
		filterRegionReqMask[WC.THREAD_HISTOGRAM] = 1;
		filterRegionReqMask[WC.THREAD_REGISTRATION] = 1;
		filterRegionReqMask[WC.THREAD_PREFILTER] = 0;
	}

	public void reloadTimeline() {
		System.out.println("RELOADING TIMELINE");
		initTimeline();
		loadMetadataQuickpassAndScanCheck(inputFileSeqCount, 0);
		findDataChunks();
		// drawTimelineImage();
	}

	// set which processed images are used for video out
	public int[] getVideoExportSelection() {

		int channels[] = new int[WC.MODE_COUNT];

		return channels;
	}


	public void resetContrastEtc() {

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {

			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				for (int i = 0; i < witFrameList[flight][k].size(); i++) {

					WITFrame wfi = (WITFrame) witFrameList[flight][k].get(i);
					wfi.layerStatus[WC.THREAD_CONTRAST] = WC.THREAD_STATUS_READY;
					// wfi.biRay[WC.THREAD_CONTRAST] = null;

					// reset any layers which depend upon it - need to automate
					wfi.layerStatus[WC.THREAD_DIFF] = WC.THREAD_STATUS_READY;
					wfi.layerStatus[WC.THREAD_TIMELAPSE] = WC.THREAD_STATUS_READY;
					wfi.layerStatus[WC.THREAD_REGISTRATION] = WC.THREAD_STATUS_READY;

					witFrameList[flight][k].remove(i);
					witFrameList[flight][k].add(i, wfi);
				}
			}
		}
	}



	public void populateMenus(CV_MT_Disp cvt) {

		MenuBar menuBar = new MenuBar();
		// JMenuBar menuBar = new JMenuBar();
		cvt.setMenuBar(menuBar);

		// JMenu menuSession = new JMenu("Session");
		Menu menuSession = new Menu("Session");
		Menu menuFile = new Menu("File");
		Menu menuPlayback = new Menu("Playback");
		Menu menuContrast = new Menu("Contrast");
		Menu menuEdit = new Menu("Edit");
		Menu menuFilter = new Menu("Filter");
		Menu menuStream = new Menu("Stream");
		Menu menuShare = new Menu("Sharing");
		Menu menuHelp = new Menu("Help");


		ItemListener actionListenerGlobeData = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				globeDataMode++;
				globeDataMode = globeDataMode % 2;
			}
		};

		// gain controls
		ActionListener actionListenerLTGainButton = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doGain();
			}
		};

		// HELP
		ActionListener actionListenerHelpWeb = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showWebHelp();
			}
		};
		ActionListener actionListenerHelpKeyboard = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showKeyboardHelp();
			}
		};

		// FILTER
		ActionListener actionListenerFilterTemporal = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				toggleOpMask(WC.THREAD_DIFF);
			}
		};

		ActionListener actionListenerFilterTimelapse = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				toggleOpMask(WC.THREAD_TIMELAPSE);
			}
		};

		ItemListener actionListenerFilterRegistration = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				toggleOpMask(WC.THREAD_REGISTRATION);
			}
		};
		ItemListener actionListenerFilterGeoreg = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				toggleOpMask(WC.THREAD_DEJITTER_ADV);
			}
		};
		ItemListener actionListenerFilterLatLonOverlay = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				toggleOpMask(WC.THREAD_MAP_OVERLAY);

				if (opMask[WC.THREAD_MAP_OVERLAY] == true) {
					latLonOverlayUpdateFlag = 1;
				}
			}
		};
		ItemListener actionListenerFilterDejitter = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				toggleOpMask(WC.THREAD_DEJITTER);
			}
		};
		ItemListener actionListenerFilterDwtCpu = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				toggleOpMask(WC.THREAD_TEMPORAL);
			}
		};
		ItemListener actionListenerAutoContrast = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				toggleOpMask(WC.THREAD_CONTRAST);
			}
		};
		ItemListener actionListenerManualContrast = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				toggleOpMask(WC.THREAD_CONTRAST);
			}
		};
		ItemListener actionListenerFilterDejitterAdv = new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				toggleOpMask(WC.THREAD_DEJITTER_ADV);
			}
		};

		// FILE I/O
		ActionListener actionListenerLoadFrames2 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(2, -1, -1);
			}
		};
		ActionListener actionListenerLoadFrames10 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(10, -1, -1);
			}
		};
		ActionListener actionListenerLoadFrames60 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(60, -1, -1);
			}
		};
		ActionListener actionListenerLoadFrames120 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(120, -11, -1);
			}
		};
		ActionListener actionListenerLoadFrames180 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(180, -1, -1);
			}
		};
		ActionListener actionListenerLoadFrames300 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(300, -1, -1);
			}
		};

		ActionListener actionListenerLoadFrames600 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(600, -1, -1);
			}
		};

		ActionListener actionListenerLoadFrames900 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(900,-1, -1);
			}
		};
		ActionListener actionListenerLoadFrames1200 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(1200, -1, -1);
			}
		};

		ActionListener actionListenerLoadFrames1800 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(1800, -1, -1);
			}
		};

		ActionListener actionListenerLoadFrames3600 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(3600, -1, -1);
			}
		};

		ActionListener actionListenerLoadFrames7200 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(7200, -1, -1);
			}
		};

		ActionListener actionListenerLoadFrames10800 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(10800, -1, -1);
			}
		};

		ActionListener actionListenerLoadFrames14400 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(14400, -1, -1);
			}
		};

		ActionListener actionListenerLoadFrames36000 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(36000, -1, -1);
			}
		};

		ActionListener actionListenerSkipSeconds1 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1,1,-1);
			}
		};
		ActionListener actionListenerSkipSeconds5 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1,5,-1);
			}
		};
		ActionListener actionListenerSkipSeconds10 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1,10,-1);
			}
		};
		ActionListener actionListenerSkipSeconds15 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1,15,-1);
			}
		};
		ActionListener actionListenerSkipSeconds30 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1,30,-1);
			}
		};
		ActionListener actionListenerSkipSeconds60 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1,60,-1);
			}
		};

		ActionListener actionListenerSkipSeconds120 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1,120,-1);
			}
		};

		ActionListener actionListenerSkipSeconds300 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1,300,-1);
			}
		};

		ActionListener actionListenerSkipSeconds600 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1,600,-1);
			}
		};

		ActionListener actionListenerSkipSeconds1800 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1,1800,-1);
			}
		};

		ActionListener actionListenerSkipSeconds3600 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setLoadFrames(-1,3600,-1);
			}
		};

		ActionListener actionListenerSetAutoReload15 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_ON,15);
			}
		};
		ActionListener actionListenerSetAutoReload30 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_ON,30);
			}
		};
		ActionListener actionListenerSetAutoReload60 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_ON,60);
			}
		};
		ActionListener actionListenerSetAutoReload120 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_ON,120);
			}
		};
		ActionListener actionListenerSetAutoReload300 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_ON,300);
			}
		};
		ActionListener actionListenerSetAutoReload600 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_ON,600);
			}
		};
		ActionListener actionListenerSetAutoReloadOff = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setAutoReload(WC.STATUS_OFF,-1);
			}
		};


		ActionListener actionListenerLoadSCAs = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (uiState == WC.UI_STATE_SCA_SELECT) {
					uiState = WC.UI_STATE_VIEW;
				} else {
					uiState = WC.UI_STATE_SCA_SELECT;
				}
			}
		};
		// FILE IO

		// open the stream
		ActionListener actionListenerSetInputSource = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setInputSource();
			}
		};
		// open the files
		ActionListener actionListenerOpenFiles = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openFiles();
			}
		};

		ActionListener actionListenerSetInputAppend = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setInputAppend();
			}
		};

		ActionListener actionListenerExportImageSeq = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportImageSeq(".png");
			}
		};

		ActionListener actionListenerExportMarkedImageSeq = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportMarkedImageSeq(".png");
			}
		};

		ActionListener actionListenerExportWeatherImageSeq = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportWeatherImageSeq(".png");
			}
		};


		ActionListener actionListenerExportVideoMPEG = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportVideo(".mpg");
			}
		};

		ActionListener actionListenerExportVideoMP4 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportVideo(".mp4");
			}
		};

		ActionListener actionListenerExportVideoH264 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportVideo(".h264");
			}
		};

		ActionListener actionListenerExportVideoAVI = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportVideo(".avi");
			}
		};

		ActionListener actionListenerExportVideoWMV = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportVideo(".wmv");
			}
		};

		ActionListener actionListenerExportVideoMOV = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportVideo(".mov");
			}
		};

		ActionListener actionListenerExportVideoSWF = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportVideo(".swf");
			}
		};

		ActionListener actionListenerExportVideoFLV = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportVideo(".flv");
			}
		};

		ActionListener actionListenerExportReport = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportReport();
			}
		};


		// export video size
		ActionListener actionListenerExportVideoMagnification1 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVideoExportMagnification(1);
			}
		};
		ActionListener actionListenerExportVideoMagnification2 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVideoExportMagnification(2);
			}
		};
		ActionListener actionListenerExportVideoMagnification4 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVideoExportMagnification(4);
			}
		};
		ActionListener actionListenerExportVideoMagnification8 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVideoExportMagnification(8);
			}
		};

		// PLAYBACK THROTTLE
		ActionListener actionListenerPlaybackSlower = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showKeyboardHelp();
			}
		};

		ActionListener actionListenerPlaybackFaster = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showKeyboardHelp();
			}
		};

		// PLAYBACK SPECIFIC
		ActionListener actionListenerPlayback1X = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showKeyboardHelp();
			}
		};

		ActionListener actionListenerPlayback2X = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showKeyboardHelp();
			}
		};

		// PLAYBACK LOOP MODE
		ActionListener actionListenerPlaybackLoop = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				toggleLoopMode();
			}
		};
		ActionListener actionListenerPlaybackSelectionClear = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearSelection();
			}
		};
		ActionListener actionListenerPlaybackSelectionAll = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				allSelection();
			}
		};
		ActionListener actionListenerPlaybackSelectionGrow = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				growUserSelectionT();
			}
		};

		// SHARING
		ActionListener actionListenerShareNotify = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				toggleShareNotify();
			}
		};

		ActionListener actionListenerShareLockPlayheads = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				toggleShareLockPlayheads();
			}
		};

		// SESSION
		ActionListener actionListenerOpenSession = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				restoreState(RESTORE_STATE_DIALOG_BOX);
			}
		};
		ActionListener actionListenerSaveSession = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveState(SAVE_STATE_DIALOG_BOX);
			}
		};
		ActionListener actionListenerRestoreSession = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				restoreState(RESTORE_STATE_ON_LAUNCH);
			}
		};
		ActionListener actionListenerQuitSession = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tivoExit();
			}
		};

		// contrast
		ActionListener actionListenerContrastOff = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		};
		ActionListener actionListenerContrastGain = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		};

		// handle the events for the contrast modes
		ActionListener actionListenerContrastAuto = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleContrastModeChange(CONTRAST_AUTO);
			}
		};
		ActionListener actionListenerContrastUser = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleContrastModeChange(CONTRAST_USER);

			}
		};
		ActionListener actionListenerContrastWindow = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleContrastModeChange(CONTRAST_WINDOW);
			}
		};
		ActionListener actionListenerContrastClearCPs = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				userContrastCPList = new ArrayList();
			}
		};

		ActionListener actionListenerContrastCurves = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		};
		ActionListener actionListenerHistogram = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				toggleOpMask(WC.THREAD_HISTOGRAM);
				toggleWidgetVisibility(WC.WIDGET_HISTOGRAM);

			}
		};

		ActionListener actionListenerHistogramDisplayToggle = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				histogramDisplayState = toggleBinaryItem(histogramDisplayState);
			}
		};



		ActionListener actionListenerPanL = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panViewX(1);
			}
		};
		ActionListener actionListenerPanR = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panViewX(-1);
			}
		};

		ActionListener actionListenerTimelineR = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panTime(-1);
			}
		};
		ActionListener actionListenerTimelineL = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panTime(1);
			}
		};

		// reconstruct timeline from the metadata
		ActionListener actionListenerReloadTimeline = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		};

		// create a bookmark
		ActionListener actionListenerAddBookmarkEvent = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				addBookmarkEvent();
			}
		};

		// scroll between bookmarks
		ActionListener actionListenerMoveBookmarkR = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				panBookmarkEvent(-1);
			}
		};
		ActionListener actionListenerMoveBookmarkL = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				panBookmarkEvent(1);
			}
		};
		ActionListener actionListenerMoveBookmarkC = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				panBookmarkEvent(0);
			}
		};

		ActionListener actionListenerSwapFlights = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				toggleFlight();

			}
		};

		ActionListener actionListenerScanDir0 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetLastDrawIndex();
				setPlaybackScanMode(SCAN_DIR_EVEN);
			}
		};
		ActionListener actionListenerScanDir1 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetLastDrawIndex();
				setPlaybackScanMode(SCAN_DIR_ODD);
			}
		};
		ActionListener actionListenerScanDir3 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetLastDrawIndex();
				setPlaybackScanMode(SCAN_DIR_BOTH);
			}
		};

		ActionListener actionListenerScanDir4 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetLastDrawIndex();
				setPlaybackScanMode(SCAN_SEGMENT_ONE);
			}
		};

		ActionListener actionListenerLensMagnify = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				toggleLensM();
			}
		};
		ActionListener actionListenerCompassRotation = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				toggleCompassRotation();
			}
		};
		ActionListener actionListenerLensFilter = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				toggleLensF();
			}
		};
		ActionListener actionListenerLensInfo = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				toggleLensInfo();
			}
		};

		ActionListener actionListenerLoadNextStep = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// need to determine min loaded SCA
				int scaID = 0;

				int jumpDistance = 1;
				int loadDistance = loadSeconds;
				int timeJump = maxSeconds;

				dynamicLoad3(timeJump + jumpDistance, loadDistance, 0,
						skipSeconds);
			}
		};


		MenuItem itemLoadNextStep = new MenuItem();
		itemLoadNextStep.setLabel("Load Next Timeline Region (j)");
		itemLoadNextStep.addActionListener(actionListenerLoadNextStep);

		MenuItem itemTimelineL = new MenuItem();
		itemTimelineL.setLabel("Pan Timeline Right (shift-right)");
		itemTimelineL.addActionListener(actionListenerTimelineL);

		MenuItem itemTimelineR = new MenuItem();
		itemTimelineR.setLabel("Pan Timeline Left (shift-left))");
		itemTimelineR.addActionListener(actionListenerTimelineR);


		MenuItem itemSwapFlights = new MenuItem();
		itemSwapFlights.setLabel("Toggle 1/2 (f)");
		itemSwapFlights.addActionListener(actionListenerSwapFlights);

		// 0 direction
		MenuItem itemScanDir2 = new MenuItem();
		itemScanDir2.setLabel("Force 0-Direction Scans (comma)");
		itemScanDir2.addActionListener(actionListenerScanDir0);

		// 1 direction
		MenuItem itemScanDir1 = new MenuItem();
		itemScanDir1.setLabel("Force 1-Direction Scans (period)");
		itemScanDir1.addActionListener(actionListenerScanDir1);

		// all frames
		MenuItem itemScanDir3 = new MenuItem();
		itemScanDir3.setLabel("Play Both 0/1-Direction Scans");
		itemScanDir3.addActionListener(actionListenerScanDir3);


		MenuItem itemLensMagnify = new MenuItem();
		itemLensMagnify.setLabel("Toggle Magnifier (m)");
		itemLensMagnify.addActionListener(actionListenerLensMagnify);



		// AWT
		MenuItem itemOpenSession = new MenuItem();
		itemOpenSession.setLabel("Open Session");
		itemOpenSession.addActionListener(actionListenerOpenSession);

		MenuItem itemSaveSession = new MenuItem();
		itemSaveSession.setShortcut(new MenuShortcut(KeyEvent.VK_S));
		itemSaveSession.setLabel("Save Session");
		itemSaveSession.addActionListener(actionListenerSaveSession);


		MenuItem itemQuitSession = new MenuItem();
		itemQuitSession.setShortcut(new MenuShortcut(KeyEvent.VK_Q));
		itemQuitSession.setLabel("Quit Session");
		itemQuitSession.addActionListener(actionListenerQuitSession);

		menuSession.add(itemQuitSession);

		MenuItem itemContrastGain = new MenuItem();
		itemContrastGain.setLabel("Manual");
		itemContrastGain.addActionListener(actionListenerContrastGain);

		MenuItem itemContrastOff = new MenuItem();
		itemContrastOff.setLabel("Reset");
		itemContrastOff.addActionListener(actionListenerContrastOff);


		MenuItem itemContrastUser = new MenuItem();
		itemContrastUser.setLabel("Toggle Contrast (c)");
		itemContrastUser.setShortcut(new MenuShortcut(KeyEvent.VK_C));
		itemContrastUser.addActionListener(actionListenerContrastUser);


		MenuItem itemContrastClearCPs = new MenuItem();
		itemContrastClearCPs.setLabel("Clear Contrast Curve Control Points");
		itemContrastClearCPs.addActionListener(actionListenerContrastClearCPs);


		MenuItem itemHistogram = new MenuItem();
		itemHistogram.setLabel("Toggle Histogram / Contrast Selector (h)");
		itemHistogram.addActionListener(actionListenerHistogram);

		MenuItem itemHistogramDisplayToggle = new MenuItem();
		itemHistogramDisplayToggle
		.setLabel("Toggle Histogram Scale (linear/log)");
		itemHistogramDisplayToggle
		.addActionListener(actionListenerHistogramDisplayToggle);

		MenuItem itemContrastCurves = new MenuItem();
		itemContrastCurves.setLabel("Curves");
		itemContrastCurves.addActionListener(actionListenerContrastCurves);

		menuContrast.add(itemHistogram);
		menuContrast.add(itemHistogramDisplayToggle);
		menuContrast.addSeparator();
		menuContrast.add(itemContrastUser);

		menuContrast.add(itemContrastClearCPs);	

		menuPlayback.add(itemLoadNextStep);

		menuPlayback.addSeparator();
		menuPlayback.add(itemTimelineL);
		menuPlayback.add(itemTimelineR);

		menuPlayback.addSeparator();
		menuPlayback.add(itemSwapFlights);

		menuPlayback.addSeparator();
		menuPlayback.add(itemLensMagnify);

		menuPlayback.addSeparator();
		menuPlayback.add(itemScanDir1);
		menuPlayback.add(itemScanDir2);
		menuPlayback.add(itemScanDir3);

		MenuItem itemFilterTemporal = new MenuItem();
		itemFilterTemporal.setLabel("Toggle Diffs (t)");
		itemFilterTemporal.addActionListener(actionListenerFilterTemporal);

		MenuItem itemFilterTimelapse = new MenuItem();
		itemFilterTimelapse.setLabel("Toggle Timelapse (shift-t)");
		itemFilterTimelapse.addActionListener(actionListenerFilterTimelapse);

		CheckboxMenuItem itemFilterDejitterAdv = new CheckboxMenuItem();
		itemFilterDejitterAdv.setLabel("Dejitter Method2");
		itemFilterDejitterAdv.addItemListener(actionListenerFilterDejitterAdv);
		itemFilterDejitterAdv.setState(opMask[WC.THREAD_DEJITTER_ADV]);

		CheckboxMenuItem itemAutoContrast = new CheckboxMenuItem();
		itemAutoContrast.setLabel("Auto-Contrast");
		itemAutoContrast.addItemListener(actionListenerAutoContrast);

		itemAutoContrast.setState(opMask[WC.THREAD_CONTRAST]);

		CheckboxMenuItem itemManualContrast = new CheckboxMenuItem();
		itemManualContrast.setLabel("Manual Contrast");
		itemManualContrast.addItemListener(actionListenerManualContrast);
		itemManualContrast.setState(opMask[WC.THREAD_CONTRAST]);

		CheckboxMenuItem itemFilterDwtCpu = new CheckboxMenuItem();
		itemFilterDwtCpu.setLabel("Dejittered Diffs");
		// itemFilterDwtCpu.setLabel("DWT CPU");
		itemFilterDwtCpu.addItemListener(actionListenerFilterDwtCpu);
		itemFilterDwtCpu.setState(opMask[WC.THREAD_TEMPORAL]);

		CheckboxMenuItem itemFilterDejitter = new CheckboxMenuItem();
		itemFilterDejitter.setLabel("Dejitter");
		itemFilterDejitter.addItemListener(actionListenerFilterDejitter);


		CheckboxMenuItem itemGlobeToggleData = new CheckboxMenuItem();
		itemGlobeToggleData.setLabel("Enable Data Overlay");
		itemGlobeToggleData.addItemListener(actionListenerGlobeData);

		menuFilter.add(itemFilterTemporal);
		menuFilter.add(itemFilterTimelapse);

		CheckboxMenuItem itemShareNotify = new CheckboxMenuItem();
		itemShareNotify.setLabel("Share Playhead Position");
		itemShareNotify.addActionListener(actionListenerShareNotify);

		CheckboxMenuItem itemShareLockPlayheads = new CheckboxMenuItem();
		itemShareLockPlayheads.setLabel("Sync Playheads");
		itemShareLockPlayheads
		.addActionListener(actionListenerShareLockPlayheads);

		menuShare.add(itemShareNotify);
		menuShare.add(itemShareLockPlayheads);

		MenuItem itemHelpWeb = new MenuItem();
		itemHelpWeb.setLabel("Launch HTML User Guide");
		itemHelpWeb.addActionListener(actionListenerHelpWeb);

		menuHelp.add(itemHelpWeb);

		MenuItem itemExportVideoMPEG = new MenuItem();
		itemExportVideoMPEG.setLabel("Export Video (v)");
		itemExportVideoMPEG.addActionListener(actionListenerExportVideoMPEG);


		MenuItem itemExportVideoMagnification1 = new MenuItem();
		itemExportVideoMagnification1.setLabel("Set Export Magnification - 1x");
		itemExportVideoMagnification1
		.addActionListener(actionListenerExportVideoMagnification1);

		MenuItem itemExportVideoMagnification2 = new MenuItem();
		itemExportVideoMagnification2.setLabel("Set Export Magnification - 2x");
		itemExportVideoMagnification2
		.addActionListener(actionListenerExportVideoMagnification2);

		MenuItem itemExportVideoMagnification4 = new MenuItem();
		itemExportVideoMagnification4.setLabel("Set Export Magnification - 4x");
		itemExportVideoMagnification4
		.addActionListener(actionListenerExportVideoMagnification4);

		MenuItem itemExportVideoMagnification8 = new MenuItem();
		itemExportVideoMagnification8.setLabel("Set Export Magnification - 8x");
		itemExportVideoMagnification8
		.addActionListener(actionListenerExportVideoMagnification8);

		MenuItem itemExportImageSeq = new MenuItem();
		itemExportImageSeq.setLabel("Export Raw PNG Image Sequence");
		itemExportImageSeq.addActionListener(actionListenerExportImageSeq);

		MenuItem itemExportReport = new MenuItem();
		itemExportReport.setLabel("Export Report");
		itemExportReport.addActionListener(actionListenerExportReport);
		itemExportReport.setShortcut(new MenuShortcut(KeyEvent.VK_E));

		MenuItem itemSetInputSource = new MenuItem();
		itemSetInputSource.setLabel("Connect to Input Stream");
		itemSetInputSource.addActionListener(actionListenerSetInputSource);
		itemSetInputSource.setShortcut(new MenuShortcut(KeyEvent.VK_I));

		MenuItem itemOpenFiles = new MenuItem();
		itemOpenFiles.setLabel("Open Files (o)");
		itemOpenFiles.addActionListener(actionListenerOpenFiles);

		MenuItem itemSetSkipSeconds1 = new MenuItem();
		itemSetSkipSeconds1.setLabel("Load - Skip 1 Seconds");
		itemSetSkipSeconds1.addActionListener(actionListenerSkipSeconds1);

		MenuItem itemSetSkipSeconds5 = new MenuItem();
		itemSetSkipSeconds5.setLabel("Load - Skip 5 Seconds");
		itemSetSkipSeconds5.addActionListener(actionListenerSkipSeconds5);

		MenuItem itemSetSkipSeconds10 = new MenuItem();
		itemSetSkipSeconds10.setLabel("Load - Skip 10 Seconds");
		itemSetSkipSeconds10.addActionListener(actionListenerSkipSeconds10);

		MenuItem itemSetSkipSeconds15 = new MenuItem();
		itemSetSkipSeconds15.setLabel("Load - Skip 15 Seconds");
		itemSetSkipSeconds15.addActionListener(actionListenerSkipSeconds15);

		MenuItem itemSetSkipSeconds30 = new MenuItem();
		itemSetSkipSeconds30.setLabel("Load - Skip 30 Seconds");
		itemSetSkipSeconds30.addActionListener(actionListenerSkipSeconds30);

		MenuItem itemSetSkipSeconds60 = new MenuItem();
		itemSetSkipSeconds60.setLabel("Load - Skip 1 Minute");
		itemSetSkipSeconds60.addActionListener(actionListenerSkipSeconds60);

		MenuItem itemSetSkipSeconds120 = new MenuItem();
		itemSetSkipSeconds120.setLabel("Load - Skip 2 Minutes");
		itemSetSkipSeconds120.addActionListener(actionListenerSkipSeconds120);

		MenuItem itemSetSkipSeconds300 = new MenuItem();
		itemSetSkipSeconds300.setLabel("Load - Skip 5 Minutes");
		itemSetSkipSeconds300.addActionListener(actionListenerSkipSeconds300);

		MenuItem itemSetSkipSeconds600 = new MenuItem();
		itemSetSkipSeconds600.setLabel("Load - Skip 10 Minutes");
		itemSetSkipSeconds600.addActionListener(actionListenerSkipSeconds600);

		MenuItem itemSetSkipSeconds1800 = new MenuItem();
		itemSetSkipSeconds1800.setLabel("Load - Skip 30 Minutes");
		itemSetSkipSeconds1800.addActionListener(actionListenerSkipSeconds1800);

		MenuItem itemSetSkipSeconds3600 = new MenuItem();
		itemSetSkipSeconds3600.setLabel("Load - Skip 1 Hour");
		itemSetSkipSeconds3600.addActionListener(actionListenerSkipSeconds3600);


		MenuItem itemSetLoadFrames2 = new MenuItem();
		itemSetLoadFrames2.setLabel("Load - 2 Seconds");
		itemSetLoadFrames2.addActionListener(actionListenerLoadFrames2);
		MenuItem itemSetLoadFrames10 = new MenuItem();
		itemSetLoadFrames10.setLabel("Load - 10 Seconds");
		itemSetLoadFrames10.addActionListener(actionListenerLoadFrames10);
		MenuItem itemSetLoadFrames60 = new MenuItem();
		itemSetLoadFrames60.setLabel("Load - 1 Minute");
		itemSetLoadFrames60.addActionListener(actionListenerLoadFrames60);
		MenuItem itemSetLoadFrames120 = new MenuItem();
		itemSetLoadFrames120.setLabel("Load - 2 Minutes");
		itemSetLoadFrames120.addActionListener(actionListenerLoadFrames120);
		MenuItem itemSetLoadFrames180 = new MenuItem();
		itemSetLoadFrames180.setLabel("Load - 3 Minutes");
		itemSetLoadFrames180.addActionListener(actionListenerLoadFrames180);
		MenuItem itemSetLoadFrames300 = new MenuItem();
		itemSetLoadFrames300.setLabel("Load - 5 Minutes");
		itemSetLoadFrames300.addActionListener(actionListenerLoadFrames300);

		MenuItem itemSetLoadFrames600 = new MenuItem();
		itemSetLoadFrames600.setLabel("Load - 10 Minutes");
		itemSetLoadFrames600.addActionListener(actionListenerLoadFrames600);

		MenuItem itemSetLoadFrames900 = new MenuItem();
		itemSetLoadFrames900.setLabel("Load - 15 Minutes");
		itemSetLoadFrames900.addActionListener(actionListenerLoadFrames900);

		MenuItem itemSetLoadFrames1200 = new MenuItem();
		itemSetLoadFrames1200.setLabel("Load - 20 Minutes");
		itemSetLoadFrames1200.addActionListener(actionListenerLoadFrames1200);

		MenuItem itemSetLoadFrames1800 = new MenuItem();
		itemSetLoadFrames1800.setLabel("Load - 30 Minutes");
		itemSetLoadFrames1800.addActionListener(actionListenerLoadFrames1800);

		MenuItem itemSetLoadFrames3600 = new MenuItem();
		itemSetLoadFrames3600.setLabel("Load - 1 Hour");
		itemSetLoadFrames3600.addActionListener(actionListenerLoadFrames3600);

		MenuItem itemSetLoadFrames7200 = new MenuItem();
		itemSetLoadFrames7200.setLabel("Load - 2 Hours");
		itemSetLoadFrames7200.addActionListener(actionListenerLoadFrames7200);

		MenuItem itemSetLoadFrames10800 = new MenuItem();
		itemSetLoadFrames10800
		.setLabel("Load - 3 Hours Seconds");
		itemSetLoadFrames10800.addActionListener(actionListenerLoadFrames10800);

		MenuItem itemSetLoadFrames14400 = new MenuItem();
		itemSetLoadFrames14400.setLabel("Load - 4 Hours");
		itemSetLoadFrames14400.addActionListener(actionListenerLoadFrames14400);

		MenuItem itemSetLoadFrames36000 = new MenuItem();
		itemSetLoadFrames36000.setLabel("Load - 10 Hours");
		itemSetLoadFrames36000.addActionListener(actionListenerLoadFrames36000);

		MenuItem itemSetInputAppend = new MenuItem();
		itemSetInputAppend.setLabel("Append Timeline");
		itemSetInputAppend.addActionListener(actionListenerSetInputAppend);


		MenuItem itemSetAutoReload15 = new MenuItem();
		itemSetAutoReload15.setLabel("Auto-Reload - 15 Seconds");
		itemSetAutoReload15.addActionListener(actionListenerSetAutoReload15);

		MenuItem itemSetAutoReload30 = new MenuItem();
		itemSetAutoReload30.setLabel("Auto-Reload - 30 Seconds");
		itemSetAutoReload30.addActionListener(actionListenerSetAutoReload30);

		MenuItem itemSetAutoReload60 = new MenuItem();
		itemSetAutoReload60.setLabel("Auto-Reload - 1 Minute");
		itemSetAutoReload60.addActionListener(actionListenerSetAutoReload60);

		MenuItem itemSetAutoReload120 = new MenuItem();
		itemSetAutoReload120.setLabel("Auto-Reload - 2 Minutes");
		itemSetAutoReload120.addActionListener(actionListenerSetAutoReload120);

		MenuItem itemSetAutoReload300 = new MenuItem();
		itemSetAutoReload300.setLabel("Auto-Reload - 5 Minutes");
		itemSetAutoReload300.addActionListener(actionListenerSetAutoReload300);

		MenuItem itemSetAutoReload600 = new MenuItem();
		itemSetAutoReload600.setLabel("Auto-Reload - 10 Minutes");
		itemSetAutoReload600.addActionListener(actionListenerSetAutoReload600);

		MenuItem itemSetAutoReloadOff = new MenuItem();
		itemSetAutoReloadOff.setLabel("Auto-Reload - Off");
		itemSetAutoReloadOff.addActionListener(actionListenerSetAutoReloadOff);


		menuFile.add(itemOpenFiles);
		menuFile.addSeparator();

		menuFile.add(itemSetLoadFrames2);
		menuFile.add(itemSetLoadFrames10);
		menuFile.add(itemSetLoadFrames60);
		menuFile.add(itemSetLoadFrames120);
		menuFile.add(itemSetLoadFrames180);
		menuFile.add(itemSetLoadFrames300);
		menuFile.add(itemSetLoadFrames600);
		menuFile.add(itemSetLoadFrames900);
		menuFile.add(itemSetLoadFrames1200);
		menuFile.add(itemSetLoadFrames1800);
		menuFile.add(itemSetLoadFrames3600);
		menuFile.add(itemSetLoadFrames7200);
		menuFile.add(itemSetLoadFrames10800);
		menuFile.add(itemSetLoadFrames14400);
		menuFile.add(itemSetLoadFrames36000);

		menuFile.addSeparator();

		menuFile.add(itemSetSkipSeconds1);
		menuFile.add(itemSetSkipSeconds5);
		menuFile.add(itemSetSkipSeconds10);
		menuFile.add(itemSetSkipSeconds15);
		menuFile.add(itemSetSkipSeconds30);
		menuFile.add(itemSetSkipSeconds60);
		menuFile.add(itemSetSkipSeconds120);
		menuFile.add(itemSetSkipSeconds300);
		menuFile.add(itemSetSkipSeconds600);
		menuFile.add(itemSetSkipSeconds1800);
		menuFile.add(itemSetSkipSeconds3600);

		menuFile.addSeparator();

		menuFile.add(itemSetAutoReload15);
		menuFile.add(itemSetAutoReload30);
		menuFile.add(itemSetAutoReload60);
		menuFile.add(itemSetAutoReload120);
		menuFile.add(itemSetAutoReload300);
		menuFile.add(itemSetAutoReload600);
		menuFile.add(itemSetAutoReloadOff);

		menuFile.addSeparator();

		menuFile.add(itemExportVideoMPEG);

		MenuItem itemHelpKeyboard = new MenuItem();
		itemHelpKeyboard.setLabel("Show Keyboard Shortcuts");
		MenuItem itemHelpDocs = new MenuItem();
		itemHelpDocs.setLabel("Open HTML User Guide");

		menuBar.add(menuSession);

		menuBar.add(menuFile);
		menuBar.add(menuPlayback);
		menuBar.add(menuContrast);
		menuBar.add(menuFilter);
		menuBar.add(menuHelp);

	}

	public void doGain() {

	}

	public void handleContrastModeChange(int cMode) {
		if (contrastMode == cMode) {
			toggleOpMask(WC.THREAD_CONTRAST);
		} else {
			contrastMode = cMode;
			toggleOpMask(WC.THREAD_CONTRAST);
		}
		setRasterLayer(WC.THREAD_CONTRAST);

	}

	public void toggleLensF() {
		lensFilterActive++;
		lensFilterActive = lensFilterActive % 2;

	}

	public void toggleFlight() {
		userFlight++;
		userFlight = userFlight % 2;

	}

	public void toggleGeoMouse() {

	}

	public void toggleCompassRotation() {
		uiCompassRotationState++;
		uiCompassRotationState = uiCompassRotationState % 2;

		if (uiCompassRotationState == 1) {

			userInterfaceInfoStr = "COMPASS ROTATION ON";
		} else {

			userInterfaceInfoStr = "COMPASS ROTATION OFF";
		}
	}

	public void toggleLensM() {
		lensMagnifyActive++;
		lensMagnifyActive = lensMagnifyActive % 2;

		if (lensMagnifyActive == 1) {

			statusInterp = 0; 
			lensMagImage = new BufferedImage(lensW, lensH,
					BufferedImage.TYPE_INT_ARGB);
			userInterfaceInfoStr = "MAGNIFIER ON";
		} else {

			userInterfaceInfoStr = "MAGNIFIER OFF";
		}
		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
	}

	public void toggleLensInfo() {
		lensTextColorMode++;
		lensTextColorMode = lensTextColorMode % 3;

		if (lensTextColorMode == LAT_LON_COLOR_AUTO) {

			userInterfaceInfoStr = "OVERLAY COLOR: AUTO";
		} else if (lensTextColorMode == LAT_LON_COLOR_DARK) {

			userInterfaceInfoStr = "OVERLAY COLOR: DARK";
		} else if (lensTextColorMode == LAT_LON_COLOR_LIGHT) {

			userInterfaceInfoStr = "OVERLAY COLOR: LIGHT";
		}
		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
	}

	public void setPlaybackScanMode(int scanDir) {

		if (scanDir == WC.SCAN_DIR_ODD) {
			if (playbackModeDir[userFlight] == WC.SCAN_DIR_ODD) {

			} else if (playbackModeDir[userFlight] == WC.SCAN_DIR_EVEN) {
				playbackModeDir[userFlight] = WC.SCAN_DIR_BOTH;
			} else if (playbackModeDir[userFlight] == WC.SCAN_DIR_BOTH) {
				playbackModeDir[userFlight] = WC.SCAN_DIR_ODD;
			}
		} else if (scanDir == WC.SCAN_DIR_EVEN) {
			if (playbackModeDir[userFlight] == WC.SCAN_DIR_ODD) {
				playbackModeDir[userFlight] = WC.SCAN_DIR_BOTH;
			} else if (playbackModeDir[userFlight] == WC.SCAN_DIR_EVEN) {

			} else if (playbackModeDir[userFlight] == WC.SCAN_DIR_BOTH) {
				playbackModeDir[userFlight] = WC.SCAN_DIR_EVEN;
			}
		} else if (scanDir == WC.SCAN_DIR_BOTH) {
			if (playbackModeDir[userFlight] == WC.SCAN_DIR_ODD) {
				playbackModeDir[userFlight] = WC.SCAN_DIR_BOTH;
			} else if (playbackModeDir[userFlight] == WC.SCAN_DIR_EVEN) {
				playbackModeDir[userFlight] = WC.SCAN_DIR_BOTH;
			} else if (playbackModeDir[userFlight] == WC.SCAN_DIR_BOTH) {

			}
		}

		System.out.println("SCAN DIR " + scanDir);
	}

	public void setPlaybackScanSeg(int scanSeg) {
		playbackModeSeg = scanSeg;
		System.out.println("SCAN SEG " + scanSeg);
	}


	public void panViewX(int dir) {
		userPanOffset[GOAL][WC.X] += (dir * 768.0 / 2f);

		if (userPanOffset[GOAL][WC.X] < minPanX) {
			userPanOffset[GOAL][WC.X] = minPanX;
		}
		if (userPanOffset[GOAL][WC.X] > maxPanX) {
			userPanOffset[GOAL][WC.X] = maxPanX;
		}


	}

	public void panViewY(int dir) {
		userPanOffset[GOAL][WC.Y] += (dir * 768.0 / 2f);

		if (userPanOffset[GOAL][WC.Y] < minPanY) {
			userPanOffset[GOAL][WC.Y] = minPanY;
		}
		if (userPanOffset[GOAL][WC.Y] > maxPanY) {
			userPanOffset[GOAL][WC.Y] = maxPanY;
		}

	}

	public void checkTimelineOffet() {
		if (userTimelineOffset[GOAL] < minTimeOffset) {
			userTimelineOffset[GOAL] = minTimeOffset;
		}
		if (userTimelineOffset[GOAL] > maxTimeOffset) {
			userTimelineOffset[GOAL] = maxTimeOffset;
		}
	}

	public void panTime(int dir) {
		userTimelineOffset[GOAL] += (dir * WC.TEN_MIN_TICK_OFFSET / 2);
		checkTimelineOffet();

	}

	public void addBookmarkEvent() {

		if (mouseOverSCA != WC.STATUS_ERROR){
			// nudge the items
			String eventStr = "USER DETECTED EVENT";
			int eventIndex = (int) userTimelineOffset[CURRENT] + timelineCenterX;

			int markPrev = 0;
			int markNext = 0;

			BookmarkEvent be = new BookmarkEvent();
			be.satID = userFlight;
			be.scaID = mouseOverSCA;
			be.rasterX = cursorX;
			be.rasterY = cursorY;
			be.lat = mouseLat;
			be.lon = mouseLon;
			//be.el
			be.intensity = mouseIntensity;

			WITFrame rasterFrame = (WITFrame) witFrameList[userFlight][mouseOverSCA].get(witSCAPlayhead[userFlight][mouseOverSCA]);										                                             
			be.timeStampSecOfDay = rasterFrame.timeStampSecOfDay;
			be.eventLabel = eventStr;
			be.eventDetectors[WC.EVENT_DETECTOR_OPERATOR] = true;

			bookmarkList.add(be);
			userEventFlash = userEventFlashDefault;

			System.out.println("ADD BOOKMARK");
		} else {
			System.out.println("BOOKMARK ERROR");
		}
	}

	public void panBookmarkEvent(int dir) {

		int minDelta = Integer.MAX_VALUE;
		int minDeltaIndex = WC.STATUS_ERROR;
		int deltaDir = 0;

		int filterOkFlag = WC.STATUS_ON;

		BookmarkEvent currBe = (BookmarkEvent) bookmarkList
		.get(bookmarkListIndex[userFlight]);

		for (int i = 0; i < bookmarkList.size(); i++) {
			if (i != bookmarkListIndex[userFlight]) {
				BookmarkEvent be = (BookmarkEvent) bookmarkList.get(i);


				if (be.satID == userFlight) {

					// filter
					if (filterOkFlag == WC.STATUS_ON) {

						int delta = currBe.timeStampSecOfDay
						- be.timeStampSecOfDay;

						if (delta > 0) {
							deltaDir = -1;
						} else {
							deltaDir = 1;
						}

						if (delta == 0) {
							deltaDir = 0;
							if (dir == -1) {
								if ((be.scaID > currBe.scaID)
										|| (be.scaID < currBe.scaID && dir == 1)) {
									deltaDir = dir;
								}
							} else if (dir == 1) {
								if ((be.scaID > currBe.scaID)
										|| (be.scaID < currBe.scaID && dir == -1)) {
									deltaDir = dir;
								}
							}
						}

						if (deltaDir == dir) {
							int deltaAbs = Math.abs(delta);

							if (deltaAbs < minDelta) {
								minDelta = deltaAbs;
								minDeltaIndex = i;
							}
						}

					}
				}
			}
		}

		if (dir != 0 && minDeltaIndex != WC.STATUS_ERROR) {
			bookmarkListIndex[userFlight] = minDeltaIndex;
		}

		BookmarkEvent be = (BookmarkEvent) bookmarkList
		.get(bookmarkListIndex[userFlight]);

		if (be.rasterX != WC.STATUS_ERROR && be.rasterY != WC.STATUS_ERROR){
			//userEventFlash = userEventFlashDefault;
		}

		userTimelineOffset[GOAL] = -be.timeStampSecOfDay + timelineCenterX;

		if (be.timeStampSecOfDay < userSelection[WC.END][WC.T] && be.timeStampSecOfDay > userSelection[WC.START][WC.T]){
			witFrameListJump(be.timeStampSecOfDay);
			syncDrawSegments();
		}
	}

	public int toggleBinaryItem(int item) {
		int i = item;
		i++;
		i = i % 2;
		return i;
	}

	public void setRasterLayer(int mode) {
		if (opMask[mode] == true) {
			rasterLayerOpa[mode][GOAL] = defaultOpOpacity[mode];
		} else {

			rasterLayerOpa[mode][GOAL] = 0.0f;
		}
	}

	public void toggleOpMask(int mode) {

		if (opMask[mode] == false) {
			opMask[mode] = true;
		} else {
			opMask[mode] = false;
		}

		// cue rendering
		if (opMask[mode] == true) {
			rasterLayerOpa[mode][GOAL] = defaultOpOpacity[mode];
		} else {

			rasterLayerOpa[mode][GOAL] = 0.0f;
		}
	}

	public void toggleOutputFormatMask(int mode) {
		if (outputFormatMask[mode] == false) {
			outputFormatMask[mode] = true;
		} else {
			outputFormatMask[mode] = false;
		}
	}

	public void toggleOutputModeMask(int mode) {
		if (outputModeMask[mode] == false) {
			outputModeMask[mode] = true;
		} else {
			outputModeMask[mode] = false;
		}
	}

	public void toggleWidgetVisibility(int mode) {

		widgetVisibility[mode] += 1;
		widgetVisibility[mode] = widgetVisibility[mode] % 2;

	}

	public void toggleMasterSlave() {
		if (nodeState == NODE_STATE_SLAVE) {

			takeControl();
		} else if (nodeState == NODE_STATE_MASTER) {
			relinquishControl();
		}
	}

	public void toggleShareLockPlayheads() {
		nodePlayheadLocked += 1;
		nodePlayheadLocked = nodePlayheadLocked % 2;
	}

	public void toggleShareNotify() {
		nodePlayheadShared += 1;
		nodePlayheadShared = nodePlayheadShared % 2;
	}

	public void takeControl() {
		nodeState = NODE_STATE_MASTER;

	}

	public void relinquishControl() {
		nodeState = NODE_STATE_SLAVE;

	}

	public void initNodeList() {

	}

	public void getSocket() {

	}

	public void unloadTimeline() {
		for (int sat = 0; sat < 2; sat++) {
			for (int i = 0; i < WC.TOTAL_SCAS; i++) {
				for (int j = 0; j < WC.SEC_IN_DAY; j++) {
					if (dataLoadStatus[sat][i][j] == WC.STATUS_WORKING
							|| dataLoadStatus[sat][i][j] == WC.STATUS_COMPLETE) {
						dataLoadStatus[sat][i][j] = WC.STATUS_READY;
						dataLoadInfo[sat][i][j] = WC.INFO_ERROR;

					}
				}
			}
		}
	}

	public void initTimelineImage() {
		// init the image
		timelineImage = new BufferedImage(timelineImageW, timelineImageH,
				BufferedImage.TYPE_INT_ARGB);
		timelineGraphics = (Graphics2D) timelineImage.getGraphics();

		timelineDrawThread = new TimelineDrawThread();
		timelineDrawThread.uiColors = uiColors;
		timelineDrawThread.graphicComposites = graphicComposites;

	}

	public void initTimelineRefs() {
		for (int sat = 0; sat < WC.TOTAL_FLIGHTS; sat++) {
			for (int i = 0; i < WC.TOTAL_SCAS; i++) {
				witFileList[sat][i] = new ArrayList();

				for (int j = 0; j < WC.SEC_IN_DAY; j++) {
					dataRefWITFile[sat][i][j] = WC.STATUS_ERROR;
				}

			}
		}
	}

	public void initTimeline() {
		for (int sat = 0; sat < WC.TOTAL_FLIGHTS; sat++) {
			for (int i = 0; i < WC.TOTAL_SCAS; i++) {
				// witFileList[i] = new ArrayList();
				for (int j = 0; j < WC.SEC_IN_DAY; j++) {
					dataLoadStatus[sat][i][j] = WC.STATUS_ERROR;
					dataLoadInfo[sat][i][j] = WC.INFO_ERROR;

					for (int e = 0; e < ERROR_STATE_COUNT; e++) {
						dataErrorHandling[sat][i][j][e] = 0;
					}
				}
			}

		}

	}

	public void notifyMulticast() {

	}

	public void quit() {

		// tear-down, free ports
	}

	public void initNetworkFeatures() {

		try {

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void syncOverSocket() {

		// sync two instances over a TCP socket
	}

	// load parameters to pass to processing
	public void loadParamLists() {

	}

	public void loadMapData() {
		System.out.println("LOADING MAP DATA ");
		map = new MapLoader();
		String dir = defaultMapDataDirStr;
		File mapDataDir = new File(dir);

		String mapSegStr[] = mapDataDir.list();
		for (int i = 0; i < mapSegStr.length; i++) {
			if (!mapSegStr[i].contains("riv.txt")
					&& (mapSegStr[i].contains("europe") || mapSegStr[i]
					                                                 .contains("europe"))) {
				System.out.println("   " + mapSegStr[i]);
				map.loadBoundaryList(dir + mapSegStr[i]);
			}
		}

		// System.out.print(" - COMPLETE");

		System.out.println(map.coordList.size() + " SEGMENTS");
		for (int i = 0; i < map.coordList.size(); i++) {
			ArrayList a = (ArrayList) map.coordList.get(i);

			String sName = ((MapCoord) a.get(0)).segmentName;
			System.out.println("   SEGMENT COORDS: " + a.size() + " (" + sName
					+ ")");
		}
		System.out.println();
	}

	// load last state of the tivo
	public void loadPlaybackState() {

	}

	// load user settings
	public void loadUserState() {

	}

	public String getModeStr(int mode) {
		String str = "";

		if (mode == WC.THREAD_LOAD) {
			str = "WC.THREAD_LOAD";
		} else if (mode == WC.THREAD_DIFF) {
			str = "WC.THREAD_DIFF";
		} else if (mode == WC.THREAD_SEGMENT) {
			str = "WC.THREAD_SEGMENT";
		} else if (mode == WC.THREAD_CONV) {
			str = "WC.THREAD_CONV";
		} else if (mode == WC.THREAD_THRS) {
			str = "WC.THREAD_THRS";
		} else if (mode == WC.THREAD_FILT) {
			str = "WC.THREAD_FILT";
		} else if (mode == WC.THREAD_FEAT) {
			str = "WC.THREAD_FEAT";
		} else if (mode == WC.THREAD_MON) {
			str = "WC.THREAD_MON";
		} else if (mode == WC.THREAD_IDLE) {
			str = "WC.THREAD_IDLE";
		}

		return str;
	}

	public void getTimeMetaData() {

	}

	public int getNumValidFramesInHDF5R(String localPathStr) {
		HDF5_R h5;
		int numFrames = 0;
		try {
			h5 = new HDF5_R(localPathStr);

			CalRawData calRawData = h5.getCalRawData();
			FileMetaData fileMetaData = h5.getFileMetaData();

			int tempFrames = fileMetaData.getNumberOfFrames();

			FrameMetaData frameMetaData = h5.getFrameMetaData();

			if (frameMetaData != null) {
				FrameMetaData.MetaData theData = frameMetaData.getMetaData();

				for (int i = 0; i < tempFrames; i++) {
					if (theData.beginLine[i] == 0) {
						numFrames++;
					}
				}
			}

			h5.finalize();

			h5 = null;
			System.out.println("   FILE " + localPathStr + " CONTAINS "
					+ tempFrames + " FRAMES - " + numFrames
					+ " BEGIN WITH SCANLINE 0");
		} catch (Exception e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return numFrames;
	}

	public int getNumTotalFramesInHDF5R(String localPathStr) {
		HDF5_R h5;
		int numFrames = 0;
		try {
			h5 = new HDF5_R(localPathStr);

			FileMetaData fileMetaData = h5.getFileMetaData();

			numFrames = fileMetaData.getNumberOfFrames();

			h5.finalize();
			h5 = null;
		} catch (Exception e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return numFrames;
	}

	public void checkForNewHDF5RFiles() {

	}

	public void printFileOrderNext(ArrayList w, int loc) {
		try {
			if (loc != -1 && loc < w.size()) {
				WITFile wfa = (WITFile) w.get(loc);

				System.out.println(" " + wfa.minYear + " " + wfa.minDay + " "
						+ wfa.minSeconds);
				if (wfa != null && w != null) {
					if (wfa.nextID != -1) {
						printFileOrderNext(w, wfa.nextID);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(WC.STATUS_ERROR);
		}

	}

	public void printFileOrderPrev(ArrayList w, int loc) {

		try {
			if (loc != -1 && loc < w.size()) {
				WITFile wfa = (WITFile) w.get(loc);

				System.out.println(" " + wfa.minYear + " " + wfa.minDay + " "
						+ wfa.minSeconds);
				if (wfa != null && w != null) {
					if (wfa.prevID != -1) {
						printFileOrderPrev(w, wfa.prevID);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(WC.STATUS_ERROR);
		}

	}

	public void createFileOrderNext(ArrayList w, int loc, int stackDepth) {

		if (loc >= 0) { // catch IDs which haven't been toggled to valid
			// locations
			WITFile wfa = (WITFile) w.get(loc);

			if (wfa.prepNextCompleted == -1) {

				wfa.prepNextCompleted = 1;
				w.set(loc, wfa); // replace object with modifications

				// find next
				if (wfa.nextID == -1) { // prevent redundant computation
					int aYear = wfa.minYear;
					int aDay = wfa.minDay;
					int aSec = (int) wfa.minSeconds;

					long diffN = Long.MAX_VALUE;
					// System.out.println("DEPTH "+stackDepth+" - TRAVERSING "+loc+" NEXT");
					for (int b = 0; b < w.size(); b++) {
						if (b != loc) {

							WITFile wfb = (WITFile) w.get(b);
							int bYear = wfb.minYear;
							int bDay = wfb.minDay;
							int bSec = (int) wfb.minSeconds;

							if (bYear >= aYear) {
								if (bDay >= aDay) {
									if (bSec >= aSec) {
										int dYear = bYear - aYear;
										int dDay = bDay - aDay;
										int dSec = (int) (bSec - aSec);

										long diff = SECONDS_IN_DAY * dDay
										+ dSec;
										if (diff < diffN) {
											diffN = diff;
											wfa.nextID = b;
										}
									}
								}
							}

						}
					}
					w.set(loc, wfa); // replace object with modifications

					if (wfa.nextID >= 0) {
						stackDepth++;
						createFileOrderNext(w, wfa.nextID, stackDepth);
						stackDepth--;
					}
				}

			}
		}
	}

	public void createFileOrderPrev(ArrayList w, int loc, int stackDepth) {

		if (loc >= 0) { // catch IDs which haven't been toggled to valid
			// locations
			WITFile wfa = (WITFile) w.get(loc);

			if (wfa.prepPrevCompleted == -1) {

				wfa.prepPrevCompleted = 1;
				w.set(loc, wfa); // replace object with modifications

				if (wfa.prevID == -1) { // prevent redundant computation

					int aYear = wfa.minYear;
					int aDay = wfa.minDay;
					int aSec = (int) wfa.minSeconds;
					long diffP = Long.MAX_VALUE;
					for (int b = 0; b < w.size(); b++) {
						if (b != loc) {

							WITFile wfb = (WITFile) w.get(b);
							int bYear = wfb.minYear;
							int bDay = wfb.minDay;
							int bSec = (int) wfb.minSeconds;

							if (bYear <= aYear) {
								if (bDay <= aDay) {
									if (bSec <= aSec) {
										int dYear = aYear - bYear;
										int dDay = aDay - bDay;
										int dSec = (int) (aSec - bSec);
										long diff = SECONDS_IN_DAY * dDay
										+ dSec;

										if (diff < diffP) {
											diffP = diff;
											wfa.prevID = b;
										}
									}
								}
							}

						}
					}
					// wfa.prepPrevCompleted = 1;
					w.set(loc, wfa); // replace object with modifications
					if (wfa.prevID >= 0) {
						stackDepth++;
						createFileOrderPrev(w, wfa.prevID, stackDepth);
						stackDepth--;
					}
				}

			}
		}
	}

	public void createFileOrder(ArrayList w, int loc, int stackDepth) {

		if (true) {
			// if (stackDepth < 100000){

			if (loc >= 0) { // catch IDs which haven't been toggled to valid
				// locations
				WITFile wfa = (WITFile) w.get(loc);

				if (wfa.preprocessCompleted == -1) {
					// find prev

					wfa.preprocessCompleted = 1;

					long diffN = Long.MAX_VALUE;
					long diffP = Long.MAX_VALUE;

					int aYear = wfa.minYear;
					int aDay = wfa.minDay;
					int aSec = (int) wfa.minSeconds;

					// find next
					if (wfa.nextID == -1) { // prevent redundant computation

						for (int b = 0; b < w.size(); b++) {
							if (b != loc) {

								WITFile wfb = (WITFile) w.get(b);
								int bYear = wfb.minYear;
								int bDay = wfb.minDay;
								int bSec = (int) wfb.minSeconds;

								if (bYear >= aYear) {
									if (bDay >= aDay) {
										if (bSec >= aSec) {

											int dYear = bYear - aYear;
											int dDay = bDay - aDay;
											int dSec = (int) (bSec - aSec);

											long diff = SECONDS_IN_DAY * dDay
											+ dSec;

											if (diff < diffN) {
												diffN = diff;
												wfa.nextID = b;
											}
										}
									}
								}

							}
						}

					}

					// find prev
					if (wfa.prevID == -1) { // prevent redundant computation

						for (int b = 0; b < w.size(); b++) {
							if (b != loc) {

								WITFile wfb = (WITFile) w.get(b);
								int bYear = wfb.minYear;
								int bDay = wfb.minDay;
								int bSec = (int) wfb.minSeconds;

								if (bYear <= aYear) {
									if (bDay <= aDay) {
										if (bSec <= aSec) {

											int dYear = aYear - bYear;
											int dDay = aDay - bDay;
											int dSec = (int) (aSec - bSec);

											long diff = SECONDS_IN_DAY * dDay
											+ dSec;

											if (diff < diffP) {
												diffP = diff;
												wfa.prevID = b;
											}
										}
									}
								}
							}
						}
					}

					if (wfa.prevID >= 0) {
						stackDepth++;
						createFileOrder(w, wfa.prevID, stackDepth);
						stackDepth--;
					}
					if (wfa.nextID >= 0) {
						stackDepth++;
						createFileOrder(w, wfa.nextID, stackDepth);
						stackDepth--;
					}

					w.set(loc, wfa); // replace object with modifications

				}

			}
		}
	}

	public int findListIndex(ArrayList w, String path) {
		// fetch the index in the ArrayList for the root node
		int index = -1;

		for (int a = 0; a < w.size(); a++) {
			WITFile wfa = (WITFile) w.get(a);
			if (wfa.path.equalsIgnoreCase(path)) {

				return a;
			}
		}

		return index;
	}

	public int findListIndexSCA(ArrayList w, int year, int day, int secs) {
		// fetch the index in the ArrayList for the root node
		int index = -1;

		for (int a = 0; a < w.size(); a++) {
			WITFile wfa = (WITFile) w.get(a);
			if (wfa.minYear == year && wfa.minDay == day
					&& (int) wfa.minSeconds == secs) {

				return a;
			}
		}

		return index;
	}

	public void getDataCacheInfo(String dir, int modYear, int modDay,
			int modSecs) {
		// public void getDataCacheInfo(String dir, long minModDate){

		String[] allList = new File(dir).list();

		ArrayList matchList = new ArrayList();

		for (int i = 0; i < allList.length; i++) {

			// SCID33_SCA5_2010_028_001665
			int b1 = allList[i].indexOf("_", 9);
			int b2 = allList[i].indexOf("_", b1 + 1);
			int b3 = allList[i].indexOf("_", b2 + 1);
			int b4 = allList[i].indexOf(".", b3 + 1);

			String sYear = allList[i].substring(b1 + 1, b2);
			String sDay = allList[i].substring(b2 + 1, b3);
			String sSecs = allList[i].substring(b3 + 1, b4);

			int fYear = Integer.parseInt(sYear);
			int fDay = Integer.parseInt(sDay);
			int fSecs = Integer.parseInt(sSecs);

			// parse filename and filter

			int addFlag = 1; // revisit - filter the data being added to the
			// queue

			if (addFlag == 1) {
				matchList.add(allList[i]);
			} else {
				System.out.println("(ignore file " + allList[i] + ")");
			}

		}

		long metaStartTime = System.currentTimeMillis();
		for (int a = 0; a < matchList.size(); a++) {
			HDF5_R h5;
			WITFile wf = new WITFile();
			wf.path = dir + "/" + (String) matchList.get(a);

			if (a % 50 == 0) {

				System.out.println("PARSING METADATA - FILE " + a + " of "
						+ matchList.size() + " - "
						+ ((System.currentTimeMillis() - metaStartTime) / 1000)
						+ " secs");
			}

			try {
				if (wf.path.endsWith(".h5")) {
					h5 = new HDF5_R(wf.path);

					int arrayIndexSca = -1;
					int satID = 0;

					if (h5 != null) {
						FileMetaData fileMetaData = h5.getFileMetaData();
						wf.minYear = fileMetaData.getMinYear();
						wf.maxYear = fileMetaData.getMaxYear();
						wf.minDay = fileMetaData.getMinDay();
						wf.maxDay = fileMetaData.getMaxDay();
						wf.minSeconds = fileMetaData.getMinSeconds();
						wf.maxSeconds = fileMetaData.getMaxSeconds();
						wf.SCA = fileMetaData.getSca() - 1;// !!
						arrayIndexSca = wf.SCA;
						wf.SCID = fileMetaData.getScid();

						wf.minMinutes = (int) ((float) wf.minSeconds / 60f);
						wf.maxMinutes = (int) ((float) wf.maxSeconds / 60f);

						if (wf.SCID == 33) {
							satID = 0;
						} else if (wf.SCID == 34) {
							satID = 1;
						}

						if (scaLoadMask[satID][(wf.SCA)] == 1) { 
							for (int tSec = (int) Math.floor(wf.minSeconds) - 1; tSec <= (int) Math
							.ceil(wf.maxSeconds) + 1; tSec++) { // handle
								// fractional
								// seconds
								dataLoadStatus[satID][(wf.SCA)][tSec] = WC.STATUS_READY;
								// dataFilenames[satID][(wf.SCA)][tSec] =
								// wf.path;
								if (arrayIndexSca >= 0) {
									// System.out.println("ADD TO FILE LIST 1");
									dataRefWITFile[satID][(wf.SCA)][tSec] = witFileList[satID][arrayIndexSca]
									                                                           .size();
								}

							}
						}

						if (arrayIndexSca >= 0) {
							witFileList[satID][arrayIndexSca].add(wf);
						}

					} else {
						wf.fileLoadStatus = WC.STATUS_ERROR;
					}

					h5.finalize();

					h5 = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			} catch (Throwable e) {
				e.printStackTrace();
			}

		}

	}

	public void getDataCacheFileList(String dir, File[] fList) {
		// public void getDataCacheInfo(String dir, long minModDate){

		String[] allList = new String[fList.length];
		for (int i = 0; i < fList.length; i++) {
			allList[i] = new String();
			allList[i] = fList[i].getName();
		}

		ArrayList matchList = new ArrayList();

		for (int i = 0; i < allList.length; i++) {

			matchList.add(allList[i]);

		}
		// !! ADDRESS MISSING PL4

		long metaStartTime = System.currentTimeMillis();
		for (int a = 0; a < matchList.size(); a++) {
			HDF5_R h5;
			WITFile wf = new WITFile();
			wf.path = dir + "/" + (String) matchList.get(a);

			if (a % 50 == 0) {

				System.out.println("PARSING METADATA - FILE " + a + " of "
						+ matchList.size() + " - "
						+ ((System.currentTimeMillis() - metaStartTime) / 1000)
						+ " secs");
			}

			try {
				if (wf.path.endsWith(".h5")) {
					h5 = new HDF5_R(wf.path);

					int arrayIndexSca = -1;
					int satID = 0;

					if (h5 != null) {
						FileMetaData fileMetaData = h5.getFileMetaData();

						wf.minYear = fileMetaData.getMinYear();
						wf.maxYear = fileMetaData.getMaxYear();
						wf.minDay = fileMetaData.getMinDay();
						wf.maxDay = fileMetaData.getMaxDay();
						wf.minSeconds = fileMetaData.getMinSeconds();// Math.floor(fileMetaData.getMinSeconds());
						// // !!
						// 1/12/2011
						// mod
						// via
						// floor
						wf.maxSeconds = fileMetaData.getMaxSeconds();// Math.ceil(fileMetaData.getMaxSeconds());
						wf.SCA = fileMetaData.getSca() - 1;// !!
						arrayIndexSca = wf.SCA;
						wf.SCID = fileMetaData.getScid();

						wf.minMinutes = (int) ((float) wf.minSeconds / 60f);
						wf.maxMinutes = (int) ((float) wf.maxSeconds / 60f);

						if (wf.SCID == 33) {
							satID = 0;
						} else if (wf.SCID == 34) {
							satID = 1;
						}



						if ((wf.SCA) >= 0) {
							if (scaLoadMask[satID][(wf.SCA)] == 1) { // hacky
								// filtering
								// of the
								// data //
								// array at
								// -1 !!
								for (int tSec = (int) Math.floor(wf.minSeconds) - 1; tSec < (int) Math
								.ceil(wf.maxSeconds) + 1; tSec++) { 
									dataLoadStatus[satID][(wf.SCA)][tSec] = WC.STATUS_READY;

									if (arrayIndexSca >= 0) {
										dataRefWITFile[satID][(wf.SCA)][tSec] = witFileList[satID][arrayIndexSca]
										                                                           .size();
									}
									dataErrorHandling[satID][(wf.SCA)][tSec][MISSING_ITEM_GEOLOCATION] = wf.missingDataItems[MISSING_ITEM_GEOLOCATION];
								}
							}
						} else {
							System.out.println("INVALID SCA");
						}

						if (arrayIndexSca >= 0) {
							witFileList[satID][arrayIndexSca].add(wf);
							if (wf.SCA == 4) {

								System.out.println("CACHED SCA " + wf.SCA
										+ " - TIME " + wf.minSeconds + " "
										+ wf.maxSeconds);
							}
						}

					} else {
						wf.fileLoadStatus = WC.STATUS_ERROR;
					}

					h5.finalize();

					h5 = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			} catch (Throwable e) {
				e.printStackTrace();
			}

		}

	}

	public void loadSingleSCAfromList() {

	}

	public String autoFetchRootRecent(String dir, int segs) {
		String path = "";

		// find the file #segs back in time...

		String[] allList = new File(dir + "/").list();

		System.out.println(allList.length + " FILES IN DIR");

		int fileAgeHint = segs + 0;

		String recStr[] = new String[fileAgeHint];
		int recDays[] = new int[fileAgeHint];
		long recSecs[] = new long[fileAgeHint];

		for (int i = 0; i < recStr.length; i++) {
			recStr[i] = "";
			recDays[i] = 0;
			recSecs[i] = 0;
		}

		for (int a = 0; a < allList.length; a++) {
			if (allList[a].contains("SCA4")) { // match on our popular
				// SCA...needs to be more robust

				int breakPos1 = allList[a].indexOf("_", 0);
				int breakPos2 = allList[a].indexOf("_", breakPos1 + 1);
				int breakPos3 = allList[a].indexOf("_", breakPos2 + 1);
				int breakPos4 = allList[a].indexOf("_", breakPos3 + 1);
				int breakPos5 = allList[a].indexOf(".", breakPos4 + 1);

				int thisDay = Integer.parseInt(allList[a].substring(
						breakPos3 + 1, breakPos4));
				long thisSec = Integer.parseInt(allList[a].substring(
						breakPos4 + 1, breakPos5));

				if (thisDay > recDays[0]
				                      || (thisDay == recDays[0] && thisSec > recSecs[0])) {
					// nudge
					for (int k = recStr.length - 1; k > 0; k--) {
						recStr[k] = recStr[k - 1];
						recDays[k] = recDays[k - 1];
						recSecs[k] = recSecs[k - 1];
					}
					// new
					recStr[0] = allList[a];
					recDays[0] = thisDay;
					recSecs[0] = thisSec;
				}
			}
		}

		path = recStr[recStr.length - 1];
		System.out.println("NEWEST FILE " + recStr[0]);

		System.out.println("STARTING FILE " + path);

		return path;
	}

	public void updateBookmarkScrollOrder() {

	}

	public void scrollBookmarks(int dir) {

	}


	public void copyBookmarksFromWF() {
		if (bookmarkSyncFlag == WC.STATUS_ON) {
			for (int sat = 0; sat < WC.TOTAL_FLIGHTS; sat++) {
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					for (int i = 0; i < witFrameList[sat][k].size(); i++) {

						WITFrame w = (WITFrame) witFrameList[sat][k].get(i);

						for (int j = 0; j < w.bookmarkList.size(); j++) {
							bookmarkList.add(w.bookmarkList.get(j));
							w.bookmarkList.remove(j);
							// optionally purge from wfl
						}
					}
				}
			}
		}
	}


	public void findDataChunks() {

		int timeGap = 10;

		for (int sat = 0; sat < 2; sat++) {
			for (int i = 10; i < WC.SEC_IN_DAY; i++) {
				for (int s = 0; s < WC.TOTAL_SCAS; s++) {
					if (i >= timeGap) {
						if (dataLoadStatus[sat][s][i] == WC.STATUS_READY
								&& dataLoadStatus[sat][s][i - timeGap] == WC.STATUS_ERROR
								&& dataLoadStatus[sat][s][i - 1] == WC.STATUS_ERROR) {

							BookmarkEvent be = new BookmarkEvent();
							be.statusCheckedByAuto = WC.STATUS_ON;
							be.eventLabel = "DATA SEGMENT START";
							be.timeStampSecOfDay = i;
							be.satID = sat;
							be.scaID = s;
							be.eventType = WC.EVENT_DATA_FEED;
							bookmarkList.add(be);

							userTimelineOffset[GOAL] = -i;
						}
					}

					if (i < WC.SEC_IN_DAY - timeGap) {
						if (dataLoadStatus[sat][s][i] == WC.STATUS_READY
								&& dataLoadStatus[sat][s][i + timeGap] == WC.STATUS_ERROR
								&& dataLoadStatus[sat][s][i + 1] == WC.STATUS_ERROR) {

							BookmarkEvent be = new BookmarkEvent();
							be.statusCheckedByAuto = WC.STATUS_ON;
							be.eventLabel = "DATA SEGMENT STOP";
							be.timeStampSecOfDay = i;
							be.satID = sat;
							be.scaID = s;
							be.eventType = WC.EVENT_DATA_FEED;
							bookmarkList.add(be);

						}
					}
				}
			}
		}

	}

	public void addBookmark() {
		BookmarkEvent be = new BookmarkEvent();

		be.detectionConfidence[WC.EVENT_DETECTOR_OPERATOR] = 1.0f;
		be.statusCheckedByOperator = WC.STATUS_ON;

		be.scaID = mouseOverSCA;
		be.lat = mouseLat;
		be.lon = mouseLon;

		bookmarkList.add(be);
	}

	public void loadMetadataExplicitFileList() { // !! NULL ERROR IN THIS FUNC
		// choose the files explicitly
		long modDate = 0; // to avoid filtering all the data, only parse
		// metadata of files modified after this date

		System.out.println("LOADING METADATA");

		// update the UI
		userInterfaceInfoStr = "IMPORTING METADATA";
		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;

		long selectedModDate = 0;
		String localPathStr = "";
		String fNameStr = "";
		String selDir = "";
		int SCIDno = 33;

		int minYear = 0;
		int minDay = 0;
		int minSecs = 0;

		int modYear = 0;
		int modDay = 0;
		int modSecs = 0;

		systemState = WC.SYSTEM_STATE_OFFLINE; // cease animation and processing
		// while we queue data
		JFileChooser fc = new JFileChooser();

		String loadDir = new String(defaultLoadDirStr);

		fc.setCurrentDirectory(new File(loadDir)); // dev data - known
		// content

		fc.setMultiSelectionEnabled(true);
		fc.showOpenDialog(cvt);

		localPathStr = fc.getSelectedFile().getAbsolutePath();

		selDir = fc.getSelectedFile().getParentFile().getAbsolutePath();

		File[] fileList = fc.getSelectedFiles();

		lastLoadedDirStr = selDir;

		System.out.println("DIR " + lastLoadedDirStr);
		getDataCacheFileList(lastLoadedDirStr, fileList); //

		systemState = WC.SYSTEM_STATE_ONLINE;

	}

	public void loadMetadataExplicitFileListNewest() { // !! NULL ERROR IN THIS FUNC
		// choose the files explicitly
		long modDate = 0; // to avoid filtering all the data, only parse
		// metadata of files modified after this date

		System.out.println("LOADING METADATA");

		// update the UI
		userInterfaceInfoStr = "IMPORTING METADATA";
		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;

		long selectedModDate = 0;
		String localPathStr = "";
		String fNameStr = "";
		String selDir = "";
		int SCIDno = 33;

		int minYear = 0;
		int minDay = 0;
		int minSecs = 0;

		int modYear = 0;
		int modDay = 0;
		int modSecs = 0;

		systemState = WC.SYSTEM_STATE_OFFLINE; // cease animation and processing
		// while we queue data
		JFileChooser fc = new JFileChooser();

		String loadDir = new String("/export/data/hdf5/r");

		fc.setCurrentDirectory(new File(loadDir)); // dev data - known
		// content

		fc.setMultiSelectionEnabled(true);
		fc.showOpenDialog(cvt);

		localPathStr = fc.getSelectedFile().getAbsolutePath();

		selDir = fc.getSelectedFile().getParentFile().getAbsolutePath();

		File[] fileList = fc.getSelectedFiles();

		lastLoadedDirStr = selDir;

		System.out.println("DIR " + lastLoadedDirStr);
		getDataCacheFileList(lastLoadedDirStr, fileList); //

		systemState = WC.SYSTEM_STATE_ONLINE;

	}

	public void loadMetadataQuickpassAndScanCheck(int segments, int userPrompt) {

		long modDate = 0; // to avoid filtering all the data, only parse
		// metadata of files modified after this date

		System.out.println("LOADING METADATA");

		// update the UI
		userInterfaceInfoStr = "IMPORTING METADATA";
		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;

		long selectedModDate = 0;
		String localPathStr = "";
		String fNameStr = "";
		String selDir = "";
		int SCIDno = 33;

		int minYear = 0;
		int minDay = 0;
		int minSecs = 0;

		int modYear = 0;
		int modDay = 0;
		int modSecs = 0;

		systemState = WC.SYSTEM_STATE_OFFLINE; // cease animation and processing
		// while we queue data
		JFileChooser fc = new JFileChooser();
		// tivoRootDir
		// fc.setCurrentDirectory(new File("/export/data/hdf5/"));
		String loadDir = new String(defaultLoadDirStr);

		if (userPrompt == 1) {
			fc.setCurrentDirectory(new File(loadDir)); // dev data - known
			// content

			fc.showOpenDialog(cvt);

			localPathStr = fc.getSelectedFile().getAbsolutePath();

			selDir = fc.getSelectedFile().getParentFile().getAbsolutePath();

			fNameStr = fc.getSelectedFile().getName();
			selectedModDate = new File(localPathStr).lastModified();

			lastLoadedFileStr = localPathStr;
			lastLoadedDirStr = selDir;

			HDF5_R h5;

			WITFile rootFile = new WITFile();
			try {
				h5 = new HDF5_R(localPathStr);

				CalRawData calRawData = h5.getCalRawData();
				FileMetaData fileMetaData = h5.getFileMetaData();

				rootFile.minYear = fileMetaData.getMinYear();
				rootFile.maxYear = fileMetaData.getMaxYear();
				rootFile.minDay = fileMetaData.getMinDay();
				rootFile.maxDay = fileMetaData.getMaxDay();
				rootFile.minSeconds = fileMetaData.getMinSeconds();
				rootFile.maxSeconds = fileMetaData.getMaxSeconds();
				rootFile.SCA = fileMetaData.getSca();
				rootFile.SCID = fileMetaData.getScid();

				rootFile.path = localPathStr;

				h5.finalize();

				h5 = null;

				SCIDno = rootFile.SCID;

				minYear = rootFile.minYear;
				minDay = rootFile.minDay;
				minSecs = (int) rootFile.minSeconds;

				modYear = rootFile.minYear;
				modDay = rootFile.minDay;
				modSecs = (int) rootFile.minSeconds;

			} catch (Throwable e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		} else if (userPrompt == 0) {

			HDF5_R h5;

			WITFile rootFile = new WITFile();
			try {
				h5 = new HDF5_R(lastLoadedFileStr);

				CalRawData calRawData = h5.getCalRawData();
				FileMetaData fileMetaData = h5.getFileMetaData();

				rootFile.minYear = fileMetaData.getMinYear();
				rootFile.maxYear = fileMetaData.getMaxYear();
				rootFile.minDay = fileMetaData.getMinDay();
				rootFile.maxDay = fileMetaData.getMaxDay();
				rootFile.minSeconds = fileMetaData.getMinSeconds();
				rootFile.maxSeconds = fileMetaData.getMaxSeconds();
				rootFile.SCA = fileMetaData.getSca();
				rootFile.SCID = fileMetaData.getScid();

				rootFile.path = localPathStr;

				h5.finalize();

				h5 = null;

				SCIDno = rootFile.SCID;

				minYear = rootFile.minYear;
				minDay = rootFile.minDay;
				minSecs = (int) rootFile.minSeconds;

			} catch (Throwable e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		cvt.setTitle("Wideband Imagery Tool - " + fNameStr);

		System.out.println("DIR " + lastLoadedDirStr);
		getDataCacheInfo(lastLoadedDirStr, modYear, modDay, modSecs); //

		systemState = WC.SYSTEM_STATE_ONLINE;

	}

	// use UI to designate a root file to span from in either direction
	public void dynamicLoadSingleEntry(String fName) {

	}

	public void loadNextStep(int phPos, int secsToLoad) {

	}

	public void tearDown3DGlobe() {

	}

	// start and stop are in seconds-after-midnight, skip is in seconds
	public void dynamicLoadSingleSCA(int scaID, int timeStart, int timeStop,
			int timeSkip) {

	}

	// multi-threaded load
	public void dynamicLoad3(int phPos, int secsToLoad, int resetTheFilters,
			int skipSeconds) {

		systemState = WC.SYSTEM_STATE_OFFLINE; // cease animation and processing
		// while we queue data

		if (autoReloadState == WC.STATUS_OFF){
			autoReloadTime2 = System.currentTimeMillis();
		}

		int startTimeSecs = phPos;
		int stopTimeSecs = phPos + secsToLoad;

		loopStart = startTimeSecs;
		loopEnd = stopTimeSecs;

		userSelection[WC.START][WC.T] = loopStart;
		userSelection[WC.END][WC.T] = loopEnd;

		tearDown3DGlobe();

		witTimePlayhead = 0;

		for (int f = 0; f < WC.TOTAL_FLIGHTS; f++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				witSCAPlayhead[f][k] = 0;
			}
		}

		System.out.println("LOAD INITIATED " + phPos + " " + secsToLoad);
		dataState = WC.STATUS_READY;

		resetThreads();

		resetLastDrawIndex();

		clearSelection();

		// initOpMasks();
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			witLoadListSizePrev[k] = 0;
		}

		System.runFinalization();

		// timelineImageUpdateFlag = TIMELINE_UPDATE_ALL;
		loadedFlight = userFlight;


		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				witFrameList[flight][k].removeAll(witFrameList[flight][k]);
			}
		}

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				witFrameList[flight][k] = null;
			}
		}
		unloadTimeline();

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				witFrameList[flight][k] = new ArrayList();
			}
		}
		
		ArrayList timeCentricLists[] = new ArrayList[WC.TOTAL_SCAS];

		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			if (scaLoadMask[userFlight][k] == 1) {
				timeCentricLists[k] = new ArrayList();
			}
		}

		checkThreadActivityLevel();

		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			for (int t = 0; t <= secsToLoad; t += skipSeconds) { // !!
				// for (int t = 0; t <= secsToLoad; t+=skipSeconds) { // !!

				if (scaLoadMask[userFlight][k] == 1
						&& witFileList[userFlight][k].size() > 0) {
					int t1 = Math.min(startTimeSecs + t, SECONDS_IN_DAY);
					int t2 = Math.min(startTimeSecs + t + skipSeconds,
							SECONDS_IN_DAY);

					if (dataRefWITFile[userFlight][k][t1] != -1) {
						WITFile wf1 = (WITFile) witFileList[userFlight][k]
						                                                .get(dataRefWITFile[userFlight][k][t1]);

						String name = wf1.path;
						String name2 = "";

						WITFile wf2 = null;
						if (dataRefWITFile[userFlight][k][t2] != -1) {
							wf2 = (WITFile) witFileList[userFlight][k]
							                                        .get(dataRefWITFile[userFlight][k][t2]);
							name2 = wf2.path;
						}

						if (dataLoadStatus[userFlight][k][startTimeSecs + t] == WC.STATUS_READY) {
							dataLoadStatus[userFlight][k][startTimeSecs + t] = WC.STATUS_WORKING;
							// timelineImageUpdateFlag = 1;
						}

						// construct the list of files to load from
						if (!name.equalsIgnoreCase(name2)
								|| timeCentricLists[k].size() == 0) {
							if (name2.length() > 1) {
								timeCentricLists[k].add(name2);
								System.out.println("SCA " + k + " RESOURCE: "
										+ name2);
							}
						}
					}
				}
			}
		}

		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			if (timeCentricLists[k] != null) {
				if (timeCentricLists[k].size() > 0) {
					for (int i = 0; i < timeCentricLists[k].size(); i++) {
						System.out.println("LOAD LIST " + k + ": "
								+ timeCentricLists[k].get(i));
					}
				}
			}
		}


		HDF5_R h5[] = new HDF5_R[WC.TOTAL_SCAS];
		for (int k = 0; k < WC.TOTAL_SCAS; k += 1) {

			int errorHandlingCode = 0;

			frameCountAlloc = 0;
			if (scaLoadMask[userFlight][k] == 1
					&& timeCentricLists[k].size() > 0) {
				// for (int ff = 0; ff < 1; ff++) {
				for (int ff = 0; ff < timeCentricLists[k].size(); ff++) {

					// update the UI
					userInterfaceInfoStr = "IMPORTING DATA - SCA " + (k + 1);
					tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;

					System.out.println("DYNAMIC LOADER");

					long selectedModDate = 0;
					String localPathStr = "";
					String fNameStr = "";
					String selDir = "";

					int SCIDno = 33;
					if (userFlight == 0) {

					} else {
						SCIDno = 34;
					}

					int mode = WC.THREAD_LOAD_HDF5R;

					int listIndex = 0;
					int recListIndex = 0;

					System.out.println("LOADING HDF5R STITCHED - SCA " + k
							+ "(" + (k + 1) + ")");

					ArrayList pList = new ArrayList();

					try {
						h5[k] = new HDF5_R((String) timeCentricLists[k].get(ff));
					} catch (Throwable e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					int scid = userScid;


					pList.add(k); // 0
					pList.add(userFlight); // 1
					pList.add(h5[k]); // 2

					pList.add(frameCountAlloc); 

					pList.add(startTimeSecs); // 4
					pList.add(stopTimeSecs); // 5
					pList.add(skipSeconds); // 6

					pList.add(burstSeconds); // 7
					pList.add(errorHandlingCode); // 8
					pList.add(playbackScanSeqIndexMask); // 9

					int ref1 = dataRefWITFile[userFlight][k][startTimeSecs];
					int ref2 = dataRefWITFile[userFlight][k][stopTimeSecs];

					if (ref1 == -1) {
						if (ref2 != -1) {
							ref1 = ref2;
						}
					}

					if (ref1 != -1) {
						WITFile wf1 = (WITFile) witFileList[userFlight][k]
						                                                .get(ref1);



						int threadID = getThreadID();
						System.out.println("THREAD ID " + threadID);
						if (threadID != -1) {

							createParamList(mode, k);
							imprRay[threadID] = new ImProcThread(
									getModeStr(mode), mode, witFrameList[userFlight][k],
									getIndexFromTime(minSeconds, userFlight, k,
											skipSeconds, SCAN_DIR_BOTH),
											getIndexFromTime(maxSeconds, userFlight,  k,
													skipSeconds, SCAN_DIR_BOTH), pList);

							imprRay[threadID].threadStatus = WC.THREAD_STATUS_QUEUED;
							System.out.println("SETTING THREAD " + threadID
									+ " AS QUEUED ");

							pList = null;
						}

					}

				}

			}
		}

		System.runFinalization();
		systemState = WC.SYSTEM_STATE_ONLINE;
		timelineImageUpdateFlag = WC.TIMELINE_UPDATE_ALL;
		syncAndForceTimelineRefresh();
		dynamicLoadStatus = WC.STATUS_COMPLETE;

		// tag the start/stop for histogram and other filters
		int scaID = 0;// get a loaded SCA

		minSeconds = phPos;
		maxSeconds = phPos + secsToLoad;

		activateQueueThreads();

	}

	public void startImageExport(String extStr, int channelMask[], int markings) {

		JFileChooser fc = new JFileChooser();
		// tivoRootDir
		fc.setCurrentDirectory(new File(defaultSaveDirStr));
		fc.showSaveDialog(cvt);
		String expFileStr = fc.getSelectedFile().getAbsolutePath();

		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			// UI files

			int mode = WC.THREAD_EXPORT_IMAGES;

			System.out.println("EXPORTING IMAGES");
			int threadID = getThreadID();
			if (threadID != -1) {
				ArrayList pList = new ArrayList();

				pList.add(userSelection[WC.START][WC.X]);
				pList.add(userSelection[WC.END][WC.X]);
				pList.add(userSelection[WC.START][WC.Y]);
				pList.add(userSelection[WC.END][WC.Y]);
				pList.add(expFileStr);
				pList.add(extStr);
				pList.add(channelMask);
				pList.add(playbackModeDir); // pList.add(frameSelectionMode);
				// set flags for what channels to output

				pList.add(userVideoMagnification);

				imprRay[threadID] = new ImProcThread(getModeStr(mode), mode,
						witFrameList[userFlight][k], userSelection[WC.START][WC.T],
						userSelection[WC.END][WC.T], pList);

				new Thread(imprRay[threadID]).start();
			}

		}
	}

	public void startImageExportProj(String extStr, int channelMask[],
			int markings, int[][] bounds, float scale, int addUnprojected) {

		JFileChooser fc = new JFileChooser();
		// tivoRootDir
		fc.setCurrentDirectory(new File(defaultSaveDirStr));
		fc.showSaveDialog(cvt);
		String expFileStr = fc.getSelectedFile().getAbsolutePath();

		// UI files

		int mode = WC.THREAD_EXPORT_PROJ_IMAGES;

		for (int k = 0; k < WC.TOTAL_SCAS; k++) {

			System.out.println("EXPORTING REPROJECTED IMAGES");
			int threadID = getThreadID();
			if (threadID != -1) {
				ArrayList pList = new ArrayList();

				pList.add(userSelection[WC.START][WC.X]);
				pList.add(userSelection[WC.END][WC.X]);
				pList.add(userSelection[WC.START][WC.Y]);
				pList.add(userSelection[WC.END][WC.Y]);
				pList.add(expFileStr);
				pList.add(extStr);
				pList.add(channelMask);
				pList.add(playbackModeDir); 

				pList.add(userVideoMagnification);
				pList.add(bounds); // 9
				pList.add(scale); // 10
				pList.add(addUnprojected); // 11

				ArrayList contrastParamList = new ArrayList();
				contrastParamList.add(userContrast[WC.START] * histClusterSize);
				contrastParamList.add(userContrast[WC.END] * histClusterSize);
				contrastParamList.add(userContrastCPList);
				pList.add(contrastParamList); // 12

				imprRay[threadID] = new ImProcThread(getModeStr(mode), mode,
						witFrameList[userFlight][k], 0, witFrameList[userFlight][k].size(), pList);
				// imprRay[threadID].setPriority(threadPriorities[WC.THREAD_EXPORT_PROJ_IMAGES]);
				Thread t = new Thread(imprRay[threadID]);
				t.setPriority(threadPriorities[WC.THREAD_EXPORT_PROJ_IMAGES]);
				// threadAllocations[threadID] = 1;
				try {
					t.join(threadTimeouts[WC.THREAD_EXPORT_PROJ_IMAGES]);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				t.start();

			}
		}

	}

	public void nudgeGLwindow() { // keep the GPU processing aligned with
		// additional UI

	}



	public void startVideoExport(boolean formatMask[], boolean channelMask[],
			int frameSelectionMode) {

		userInterfaceInfoStr = "EXPORTING VIDEO";
		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;

		// propmt for data versions to save

		JFileChooser fc = new JFileChooser();
		// tivoRootDir
		fc.setCurrentDirectory(new File(defaultSaveDirStr));
		fc.showSaveDialog(cvt);
		String expFileStr = fc.getSelectedFile().getAbsolutePath();

		// UI files

		int mode = WC.THREAD_EXPORT_VIDEO;

		System.out.println("EXPORTING VIDEO");
		int threadID = getThreadID();
		if (threadID != -1) {

			// ArrayList pListRay = new ArrayList();
			ArrayList selectedScaWitFrameList = new ArrayList();

			ArrayList pList = new ArrayList();
			pList.add(userSelectionSCA);	// 0
			pList.add(expFileStr);			// 1
			// pList.add(extStr);

			pList.add(formatMask);			// 2
			pList.add(channelMask);			// 3
			pList.add(playbackModeDir[userFlight]); // pList.add(frameSelectionMode);
			// set flags for what channels to output

			pList.add(userVideoMagnification);	// 5
			pList.add(userSelectionSCAtouched);	// 6
			pList.add(userVideoExportSpeed);	// 7
			// pListRay.add(pList);

			pList.add(userSelection[WC.START][WC.T]);	// 8
			pList.add(userSelection[WC.END][WC.T]);		// 9

			pList.add(productClassificationLabelStr);	// 10
			pList.add(productTitleLabelStr);			// 11

			pList.add(playbackScanSeqIndexMask[userFlight]);			// 12

			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				// if (userSelectionSCAtouched[k]==1){
				selectedScaWitFrameList.add(witFrameList[userFlight][k]);
				// }
			}

			imprRay[threadID] = new ImProcThread(getModeStr(mode), mode,
					selectedScaWitFrameList, minSeconds, maxSeconds - 1, pList);

			// threadAllocations[threadID] = 1;
			imprRay[threadID].threadStatus = WC.THREAD_STATUS_QUEUED;
			System.out.println("SETTING THREAD " + threadID + " AS QUEUED ");

		}
	}

	public void returnThread() {

	}

	public String degreesDecimalToDegreesMinutes(float decDeg, int latLonToggle) {

		int wholeDeg = (int) decDeg;
		float fracDeg = Math.abs(decDeg - wholeDeg);

		float minDeg = fracDeg * 60f;
		int wholeMin = (int) minDeg;
		float fracMin = minDeg - wholeMin;
		float secDeg = fracMin * 60f;
		int wholeSec = (int) secDeg;
		float fracSec = secDeg - wholeSec;

		int lenReq = 0;
		if (latLonToggle == WC.GEODATA_LON) {
			lenReq = 3;
		} else if (latLonToggle == WC.GEODATA_LAT) {
			lenReq = 2;
		}

		String degStr = "" + wholeDeg;
		while (degStr.length() < lenReq) {
			degStr = "0" + degStr;
		}
		String minStr = "" + wholeMin;
		while (minStr.length() < 2) {
			minStr = "0" + minStr;
		}
		String secStr = "" + wholeSec;
		while (secStr.length() < 2) {
			secStr = "0" + secStr;
		}

		String secFracStr = "" + fracSec;
		while (secFracStr.length() < 2) {
			secFracStr = "0" + secFracStr;
		}
		secFracStr = secFracStr.substring(1);
		if (secFracStr.length() > 4) {
			secFracStr = secFracStr.substring(0, 4);
		}

		StringBuilder s = new StringBuilder();
		s.append(degStr);
		s.append((char) 0x00b0);
		s.append(minStr);
		s.append("'");
		s.append(secStr);
		s.append(secFracStr);
		s.append("''");

		if (latLonToggle == WC.GEODATA_LON) {
			if (decDeg < 0) {
				s.append("W");
			} else if (decDeg > 0) {
				s.append("E");
			}
		} else if (latLonToggle == WC.GEODATA_LAT) {
			if (decDeg < 0) {
				s.append("S");
			} else if (decDeg > 0) {
				s.append("N");
			}
		}

		return s.toString();
	}

	public void revisePriorities() {

	}

	public void reloadNewData() {

		userInterfaceInfoStr = "AUTO-RELOADING...";

		int loadJumpOffset = 0;
		if (loadTriggerState == WC.STATUS_ON) {
			loadJumpOffset = jumpLoadStart;
		}

		int jumpDistance = 1;
		int loadDistance = loadSeconds;
		int timeJump = maxSeconds;

		jumpLoadStart = loadJumpOffset + timeJump + jumpDistance;
		jumpLoadDistance = loadDistance;
		dynamicLoad3(timeJump + jumpDistance, loadDistance, 0,
				skipSeconds);

		uiLoadTriggerTimer = WC.UI_LOAD_TRIGGER_TIMER;

	}


	public void drawMiniMap(Graphics2D g) {

		g.setColor(Color.black);
		g.setComposite(graphicComposites[c_WORKING]);
		g.fillRect(miniMapPos[CURRENT][WC.X], miniMapPos[CURRENT][WC.Y],
				miniMapSize[CURRENT][WC.X], miniMapSize[CURRENT][WC.Y]);

		g.setColor(Color.white);
		g.setComposite(graphicComposites[c_COMPLETE]);
		g.drawRect(miniMapPos[CURRENT][WC.X], miniMapPos[CURRENT][WC.Y],
				miniMapSize[CURRENT][WC.X], miniMapSize[CURRENT][WC.Y]);

		float scanIndicator = 200f;
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			g.setColor(Color.GREEN);
			if (scaLoadMask[userFlight][k] == 1) {
				g.fillRect(miniMapPos[CURRENT][WC.X]
				                               + (int) (scaOffsets[k][WC.X] * miniMapScale) + 2,
				                               miniMapPos[CURRENT][WC.Y]
				                                                   + (int) (scaOffsets[k][WC.Y] * miniMapScale)
				                                                   + 2, (int) (768f * miniMapScale),
				                                                   (int) (scanIndicator * miniMapScale));
			}
			if (k < 6) {
				g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_SWIR]);
			} else if (k == 6) {
				g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_STG]);
			} else if (k == 7) {
				g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_MWIR]);
			}
			g.drawRect(miniMapPos[CURRENT][WC.X]
			                               + (int) (scaOffsets[k][WC.X] * miniMapScale) + 2,
			                               miniMapPos[CURRENT][WC.Y]
			                                                   + (int) (scaOffsets[k][WC.Y] * miniMapScale) + 2,
			                                                   (int) (768f * miniMapScale), (int) (scanIndicator * miniMapScale));
		}


		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			if (scaLoadMask[userFlight][k] == WC.STATUS_ON){
				if (playbackScanLengthPrev[userFlight][k] >0){
					g.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_READY]);
					if (scaLoadMask[userFlight][k] == 1) {
						g.fillRect(miniMapPos[CURRENT][WC.X]
						                               + (int) (scaOffsets[k][WC.X] * miniMapScale) + 2,
						                               miniMapPos[CURRENT][WC.Y]
						                                                   + (int) (scaOffsets[k][WC.Y] * miniMapScale)
						                                                   + 2, (int) (768f * miniMapScale),
						                                                   (int) ((float)playbackScanLengthPrev[userFlight][k] * miniMapScale));
					}
					if (k < 6) {
						g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_SWIR]);
					} else if (k == 6) {
						g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_STG]);
					} else if (k == 7) {
						g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_MWIR]);
					}
					g.drawRect(miniMapPos[CURRENT][WC.X]
					                               + (int) (scaOffsets[k][WC.X] * miniMapScale) + 2,
					                               miniMapPos[CURRENT][WC.Y]
					                                                   + (int) (scaOffsets[k][WC.Y] * miniMapScale) + 2,
					                                                   (int) (768f * miniMapScale), (int) ((float)playbackScanLengthPrev[userFlight][k] * miniMapScale));
				}
			}
		}

		//gMain.setColor(Color.white);
		gMain.setColor(uiColors[WC.COLOR_TIVO_SELECTION_COMPLETE]);
		g.drawRect(miniMapPos[CURRENT][WC.X] - miniMapInsetPos[CURRENT][WC.X],
				miniMapPos[CURRENT][WC.Y] - miniMapInsetPos[CURRENT][WC.Y],
				miniMapInsetSize[CURRENT][WC.X],
				miniMapInsetSize[CURRENT][WC.Y]);

		// globe
		g.setColor(Color.black);
		g.setComposite(graphicComposites[c_WORKING]);
		g.fillRect(miniGlobePos[CURRENT][WC.X], miniGlobePos[CURRENT][WC.Y],
				miniGlobeSize[CURRENT][WC.X], miniGlobeSize[CURRENT][WC.Y]);

		g.drawImage(miniGlobeImage, miniGlobePos[CURRENT][WC.X],
				miniGlobePos[CURRENT][WC.Y], null);

		// lat lon
		if (latLonOverlayEnabled == 1 && (mouseLon != 0 || mouseLat != 0)
				&& mouseLon > INVALID_GEOLOCATION
				&& mouseLat > INVALID_GEOLOCATION) {
			g.setColor(statusColors[WC.THREAD_DIFF]);
			g.fillRect(miniGlobePos[CURRENT][WC.X], miniGlobePos[CURRENT][WC.Y]
			                                                              + miniGlobeSize[CURRENT][WC.Y] - 20,
			                                                              miniGlobeSize[CURRENT][WC.X], 20);
			g.setColor(Color.WHITE);

			g.drawRect(miniGlobePos[CURRENT][WC.X], miniGlobePos[CURRENT][WC.Y]
			                                                              + miniGlobeSize[CURRENT][WC.Y] - 20, miniGlobeSize[CURRENT][WC.X], 20);

			String mouseLonStr = mouseLon + "";
			String mouseLatStr = mouseLat + "";

			int desiredLonLatStrLength = 12;
			if (mouseLonStr.length() > desiredLonLatStrLength) {

				mouseLonStr = mouseLonStr.substring(0, desiredLonLatStrLength);
			}
			if (mouseLatStr.length() > desiredLonLatStrLength) {

				mouseLatStr = mouseLatStr.substring(0, desiredLonLatStrLength);
			}
			int xOff1 = 100;
			int xOff2 = 30;
			int textYoff = 5;
			g.drawString("LAT: " + mouseLatStr, miniGlobePos[CURRENT][WC.X]
			                                                          + miniGlobeSize[CURRENT][WC.X] / 2 - xOff1, miniGlobePos[CURRENT][WC.Y] + miniGlobeSize[CURRENT][WC.Y] - textYoff);
			g.drawString("LAT: " + mouseLatStr, miniGlobePos[CURRENT][WC.X]
			                                                          + miniGlobeSize[CURRENT][WC.X] / 2 - xOff1 + 1, miniGlobePos[CURRENT][WC.Y] + miniGlobeSize[CURRENT][WC.Y] - textYoff);

			g.drawString("LON: " + mouseLonStr, miniGlobePos[CURRENT][WC.X]
			                                                          + miniGlobeSize[CURRENT][WC.X] / 2 + xOff2, miniGlobePos[CURRENT][WC.Y] + miniGlobeSize[CURRENT][WC.Y] - textYoff);
			g.drawString("LON: " + mouseLonStr, miniGlobePos[CURRENT][WC.X]
			                                                          + miniGlobeSize[CURRENT][WC.X] / 2 + xOff2 + 1, miniGlobePos[CURRENT][WC.Y] + miniGlobeSize[CURRENT][WC.Y] - textYoff);

		}

		g.setColor(Color.white);
		g.setComposite(graphicComposites[c_COMPLETE]);

		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			if (scaLoadMask[userFlight][k] == 1 && witFrameList[userFlight][k] != null) {
				if (witSCAPlayhead[userFlight][k] != -1
						&& witFrameList[userFlight][k].size() > 0) {
					WITFrame rasterFrame = (WITFrame) witFrameList[userFlight][k]
					                                                           .get(witSCAPlayhead[userFlight][k]);
					if (rasterFrame.offEarthFlag == 0) {

						int rasterXave = 0;
						int rasterYave = 0;

						g.setColor(Color.WHITE);

						for (int gy = 0; gy < 4; gy++) {
							int gy2 = gy + 1;
							if (gy2 == 4)
								gy2 = 0;

							int xRasterCoord1 = miniGlobePos[CURRENT][WC.X]
							                                          + (int) ((rasterFrame.scanBounds[GEODATA_LON][gy] + 180f) * miniGlobeScale);
							int yRasterCoord1 = miniGlobePos[CURRENT][WC.Y]
							                                          - (int) ((rasterFrame.scanBounds[GEODATA_LAT][gy] - 90f) * miniGlobeScale);

							int xRasterCoord2 = miniGlobePos[CURRENT][WC.X]
							                                          + (int) ((rasterFrame.scanBounds[GEODATA_LON][gy2] + 180f) * miniGlobeScale);
							int yRasterCoord2 = miniGlobePos[CURRENT][WC.Y]
							                                          - (int) ((rasterFrame.scanBounds[GEODATA_LAT][gy2] - 90f) * miniGlobeScale);

							rasterXave += xRasterCoord1;
							rasterYave += yRasterCoord1;

							g.drawLine(xRasterCoord1, yRasterCoord1, xRasterCoord2, yRasterCoord2);
						}

						rasterXave /= 4;
						rasterYave /= 4;

						if (drawMiniMapSCALabels == 1) {
							if (!(rasterFrame.scanBounds[GEODATA_LON][0] == 0)) { // mitigate
								// loss
								// of
								// metadata

								g.setColor(Color.BLACK);
								g.drawString((k + 1) + "", rasterXave - 5, rasterYave - 15);
								g.drawString((k + 1) + "", rasterXave - 2,
										rasterYave - 15);
								g.drawString((k + 1) + "", rasterXave - 5,
										rasterYave - 14);
								g.drawString((k + 1) + "", rasterXave - 2,
										rasterYave - 14);
								g.drawString((k + 1) + "", rasterXave - 5,
										rasterYave - 16);
								g.drawString((k + 1) + "", rasterXave - 2,
										rasterYave - 16);
								g.drawString((k + 1) + "", rasterXave - 4,
										rasterYave - 14);
								g.drawString((k + 1) + "", rasterXave - 3,
										rasterYave - 14);
								g.drawString((k + 1) + "", rasterXave - 4,
										rasterYave - 16);
								g.drawString((k + 1) + "", rasterXave - 3,
										rasterYave - 16);

								g.setColor(Color.WHITE);
								g.drawString((k + 1) + "", rasterXave - 4,
										rasterYave - 15);
								g.drawString((k + 1) + "", rasterXave - 3,
										rasterYave - 15);
							}
						}

					}
				}
			}

		}

		g.drawRect(miniGlobePos[CURRENT][WC.X], miniGlobePos[CURRENT][WC.Y],
				miniGlobeSize[CURRENT][WC.X], miniGlobeSize[CURRENT][WC.Y]);

		// mouseover coord
		if ((mouseLon != INVALID_GEOLOCATION && mouseLat != INVALID_GEOLOCATION)
				&& !(mouseLon == 0 && mouseLat == 0)) {

			g.setColor(Color.RED);
			g.fillOval(miniGlobePos[CURRENT][WC.X]
			                                 + (int) ((mouseLon + 180f) * miniGlobeScale) - 2,
			                                 miniGlobePos[CURRENT][WC.Y]
			                                                       - (int) ((mouseLat - 90f) * miniGlobeScale) - 2, 5,
			                                                       5);

		}

	}

	public void drawUIcommonItems(Graphics2D g) {
		// label flights
		g.setColor(Color.gray);
		if (userFlight == 0) {
			g.setColor(Color.green);
		}
		g.drawString("1", 40, 20 + tivoStatusBarY + 10);
		if (playbackScanSeqIndexPrev[0] != -1){
			g.drawString("     STEP "+playbackScanSeqIndexPrev[0], 40, 20 + tivoStatusBarY + 22);
		}

		g.setColor(Color.gray);
		if (userFlight == 1) {
			g.setColor(Color.green);
		}
		g.drawString("2", 40, 50 + tivoStatusBarY + 10);
		if (playbackScanSeqIndexPrev[1] != -1){
			g.drawString("     STEP "+playbackScanSeqIndexPrev[1], 40, 50 + tivoStatusBarY + 22);
		}

		if (playbackModeDir[1] == WC.SCAN_DIR_EVEN){
			g.setColor(Color.green);
			g.drawString("<   ", 40, 50 + tivoStatusBarY + 22);
			g.setColor(Color.gray);
			g.drawString(" >", 40, 50 + tivoStatusBarY + 22);
		} else if (playbackModeDir[1] == WC.SCAN_DIR_ODD){	
			g.setColor(Color.gray);
			g.drawString("<   ", 40, 50 + tivoStatusBarY + 22);
			g.setColor(Color.green);
			g.drawString(" >", 40, 50 + tivoStatusBarY + 22);
		} else {
			g.setColor(Color.green);
			g.drawString("<   ", 40, 50 + tivoStatusBarY + 22);
			g.drawString(" >", 40, 50 + tivoStatusBarY + 22);
		}

		if (playbackModeDir[0] == WC.SCAN_DIR_EVEN){
			g.setColor(Color.green);
			g.drawString("<   ", 40, 20 + tivoStatusBarY + 22);
			g.setColor(Color.gray);
			g.drawString(" >", 40, 20 + tivoStatusBarY + 22);
		} else if (playbackModeDir[0] == WC.SCAN_DIR_ODD){	
			g.setColor(Color.gray);
			g.drawString("<   ", 40, 20 + tivoStatusBarY + 22);
			g.setColor(Color.green);
			g.drawString(" >", 40, 20 + tivoStatusBarY + 22);
		} else {
			g.setColor(Color.green);
			g.drawString("<   ", 40, 20 + tivoStatusBarY + 22);
			g.drawString(" >", 40, 20 + tivoStatusBarY + 22);
		}

		int yOffsetSat = 0;
		for (int sat = 0; sat < 2; sat++) {
			if (sat == 1)
				yOffsetSat = 30;
			for (int s = 0; s < WC.TOTAL_SCAS; s++) {

				// +(int)userTimelineOffset[CURRENT];

				if (scaLoadMask[sat][s] == 1) {

					g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_ON]);
				} else {

					g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_OFF]);
				}
				g.fillRect(scaOpMaskX, tivoStatusBarY + yOffsetSat
						+ (s * tivoStatusBarTickYsliver) + 22, scaOpMaskW,
						tivoStatusBarTickYsliver - 1);
				// g.fillRect(60, tivoStatusBarY, 100, 100);
			}
		}
	}

	public void drawSCAselector() {
		Graphics2D g = (Graphics2D) viewportImage.getGraphics();

		// outer - band
		int borderWidth = 6;
		int halfBorder = borderWidth / 2;
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			g.setColor(uiColors[scaSelectorBand[k]]);

			g.fillRect(scaSelectorGraphic[k][WC.X] - halfBorder,
					scaSelectorGraphic[k][WC.Y] - halfBorder,
					scaSelectorGraphic[k][WC.W] + borderWidth,
					scaSelectorGraphic[k][WC.H] + borderWidth);
		}
		// inner - on/off
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			if (scaLoadMask[userFlight][k] == 0) { // off

				g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_OFF]);
			} else if (scaLoadMask[userFlight][k] == 1) {

				g.setColor(uiColors[WC.COLOR_TIVO_SCA_SELECT_ON]);
			}
			g.fillRect(scaSelectorGraphic[k][WC.X],
					scaSelectorGraphic[k][WC.Y], scaSelectorGraphic[k][WC.W],
					scaSelectorGraphic[k][WC.H]);
		}
		// labels
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			if (scaLoadMask[userFlight][k] == 1) {
				g.setColor(Color.black);
			} else if (scaLoadMask[userFlight][k] == 0) {
				g.setColor(Color.white);
			}
			g.drawString(scaSelectorString[k],
					scaSelectorGraphic[k][WC.X] + 20,
					scaSelectorGraphic[k][WC.Y] + 20);
		}

	}

	public int intensityToContrastX(int intensity) {
		// non-linear mapping of the intensities to the histogram
		int xPos = intensity / histClusterSize;

		return xPos;
	}


	public void resetLastDrawIndex() {
		for (int f = 0; f < WC.TOTAL_FLIGHTS; f++) {
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				for (int s = 0; s < WC.SCA_MAX_SCAN_SEGMENTS; s++) {

					//lastDrawIndex[f][k][s] = -1;
				}
				lastDrawIndexList[f][k] = new ArrayList();
			}
		}
	}


	public String secondsOfDayToReadableF(float seconds) {
		String secStr = "";
		int secInt = (int) Math.floor(seconds);

		secStr = secondsOfDayToReadable(secInt);

		float secsFrac = seconds - secInt;
		String secsFracStr = secsFrac + "";

		secsFracStr = secsFracStr.substring(2, secsFracStr.length()); // get rid
		// of
		// leading
		// "0."
		int fracStrLen = 3;
		while (secsFracStr.length() < fracStrLen) {
			secsFracStr = secsFracStr + "0";
		}
		if (secsFracStr.length() > fracStrLen) {
			secsFracStr = secsFracStr.substring(0, fracStrLen);
		}
		secStr = secStr + "." + secsFracStr;

		return secStr;

	}


	public String secondsOfDayToReadable(int seconds) {

		int tPos = seconds;
		int hour = tPos / (WC.SEC_IN_HOUR);
		String hourStr = hour + "";
		if (hour < 10) {
			hourStr = "0" + hour;
		}
		int min = (tPos - hour * WC.SEC_IN_HOUR) / (60);
		String minStr = "" + min;
		if (min < 10)
			minStr = "0" + minStr;

		int sec = (tPos - hour * WC.SEC_IN_HOUR - min * 60);
		String secStr = "" + sec;
		if (sec < 10)
			secStr = "0" + secStr;

		hourStr += ":" + minStr + ":" + secStr;

		return hourStr;
	}

	public void syncAndForceTimelineRefresh() {

		if (timelineDrawThread != null) {

			if (timelineImageUpdateFlag != WC.TIMELINE_UPDATE_NONE
					&& timelineDrawThread.timelineImageUpdateFlag == WC.TIMELINE_UPDATE_NONE) {

				timelineDrawThread.dataLoadStatus = dataLoadStatus;
				timelineDrawThread.dataLoadInfo = dataLoadInfo;
				timelineDrawThread.userFlight = userFlight;
				timelineDrawThread.witFrameList = witFrameList;
				timelineDrawThread.timelineGraphics = timelineGraphics;
				timelineDrawThread.timelineImageUpdateFlag = timelineImageUpdateFlag;
				timelineDrawThread.drawTimelineImage();

				timelineImageUpdateFlag = WC.TIMELINE_UPDATE_NONE;
			}
		}
	}

	public void drawWIT() {

		// display
		gMain.setComposite(graphicComposites[c_COMPLETE]);
		gMain.setColor(Color.BLACK);
		gMain.fillRect(0, 0, viewportImage.getWidth() * 2, viewportImage
				.getHeight() * 2);

		gMain.setColor(Color.WHITE);
		int textMarginX = 10;
		int textMarginY = 20;

		// start with nothing
		// gMain.drawImage(missingDataImage, 0, 0, null);

		// scale the full FOV to frame width
		float imWidth = 768f * 6f;
		float imHeight = 864f;

		float scaleFactor = 1.0f;

		// current data
		for (int flight=userFlight; flight<=userFlight; flight++){
			//for (int flight=0; flight<WC.TOTAL_FLIGHTS; flight++){
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				if (scaLoadMask[flight][k] == 1) {
					if (witFrameList[flight][k] != null) {
						if (witFrameList[flight][k].size() > 0
								&& witSCAPlayhead[flight][k] >= 0
								&& witSCAPlayhead[flight][k] < witFrameList[flight][k]
								                                                    .size()) {

							WITFrame rasterFrame = null;



							if (scanDirAgreementDrawFlag[flight][k] == 1
									&& timeAgreementDrawFlag[flight][k] == 1 && scanSeqAgreementDrawFlag[flight][k] == 1) {

								rasterFrame = (WITFrame) witFrameList[flight][k]
								                                              .get(witSCAPlayhead[flight][k]);

							} else { // draw previous otherwise
								// if (lastDrawIndex[userFlight][k] != -1){
								if (lastDrawIndexList[flight][k] != null) {
									if (lastDrawIndexList[flight][k].size() != 0) {
										rasterFrame = (WITFrame) witFrameList[flight][k]
										                                              .get((Integer) lastDrawIndexList[flight][k]
										                                                                                       .get(lastDrawIndexList[flight][k]
										                                                                                                                      .size() - 1));
									}
								}
							}

							if (rasterFrame != null) {
								for (int i = 0; i < rasterLayerOrder.length; i++) {
									if (rasterLayerOrder[i] != RASTER_OMIT){
										if (rasterFrame.biRay != null) {
											int mode = rasterLayerOrder[i];

											if (rasterFrame.biRay[mode] != null) {
												if (rasterFrame.layerStatus[mode] == WC.THREAD_STATUS_COMPLETE) {

													int imX = (int) (scaleFactor * rasterFrame.biRay[mode]
													                                                 .getWidth());
													int imY = (int) (scaleFactor * rasterFrame.biRay[mode]
													                                                 .getHeight());

													if (opMask[mode] == true
															|| mode == WC.THREAD_LOAD_HDF5R) {


														gMain.drawImage(
																rasterFrame.biRay[mode],
																(int) userPanOffset[CURRENT][WC.X]
																                             + rasterFrame.layerOffet[mode][WC.X]
																                                                            + scaOffsets[k][WC.X],
																                                                            (int) userPanOffset[CURRENT][WC.Y]
																                                                                                         + rasterFrame.layerOffet[mode][WC.Y]
																                                                                                                                        + scaOffsets[k][WC.Y],
																                                                                                                                        imX, imY, null);


													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// user selection
		if (selectionStatus == SELECTION_WORKING
				|| selectionStatus == SELECTION_COMPLETE) {

			if (selectionStatus == SELECTION_COMPLETE) {
				// reprojectMap(overlayMapScale);
			}

			int selX = Math.min(userSelection[WC.START][WC.X],
					userSelection[WC.END][WC.X]);
			int selY = Math.min(userSelection[WC.START][WC.Y],
					userSelection[WC.END][WC.Y]);
			int selW = Math.abs(userSelection[WC.START][WC.X]
			                                            - userSelection[WC.END][WC.X]) - 1;
			int selH = Math.abs(userSelection[WC.START][WC.Y]
			                                            - userSelection[WC.END][WC.Y]) - 1;



			gMain.setColor(uiColors[WC.COLOR_TIVO_SELECTION_COMPLETE]);
			gMain.drawRect(selX + (int) userPanOffset[CURRENT][WC.X], selY
					+ (int) userPanOffset[CURRENT][WC.Y], selW, selH);


		}

		// draw poly
		if (poly != null){
			if (poly.polyPoints!= null){
				if (poly.polyPoints.size() > 0){


					gMain.setColor(new Color(poly.polyColor[WC.R],poly.polyColor[WC.G],poly.polyColor[WC.B]));

					for (int i=0; i<poly.polyPoints.size()-1; i++){
						WxPolyPoint wxp1 = (WxPolyPoint)poly.polyPoints.get(i);
						WxPolyPoint wxp2 = (WxPolyPoint)poly.polyPoints.get(i+1);
						gMain.drawLine(wxp1.rasterX+ (int) userPanOffset[CURRENT][WC.X], wxp1.rasterY+ (int) userPanOffset[CURRENT][WC.Y], wxp2.rasterX+ (int) userPanOffset[CURRENT][WC.X], wxp2.rasterY+ (int) userPanOffset[CURRENT][WC.Y]);
					}

					// close the loop
					WxPolyPoint wxpStart = (WxPolyPoint)poly.polyPoints.get(poly.polyPoints.size()-1);
					WxPolyPoint wxpEnd = (WxPolyPoint)poly.polyPoints.get(0);
					gMain.drawLine(wxpStart.rasterX+ (int) userPanOffset[CURRENT][WC.X], wxpStart.rasterY+ (int) userPanOffset[CURRENT][WC.Y], wxpEnd.rasterX+ (int) userPanOffset[CURRENT][WC.X], wxpEnd.rasterY+ (int) userPanOffset[CURRENT][WC.Y]);

					int dotSizeWx = 5;
					int dotSizeWxHalf = 3;
					for (int i=0; i<poly.polyPoints.size(); i++){
						WxPolyPoint wxp1 = (WxPolyPoint)poly.polyPoints.get(i);
						gMain.fillOval(wxp1.rasterX+ (int) userPanOffset[CURRENT][WC.X] - dotSizeWxHalf, wxp1.rasterY+ (int) userPanOffset[CURRENT][WC.Y] - dotSizeWxHalf, dotSizeWx, dotSizeWx);
					}

					// label coords
					int labelWxPolyCoords = 1;
					float labelDist = 2f;
					gMain.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_READY]);
					//gMain.setComposite(graphicComposites[c_WORKING]);

					String lonPointStr = "";
					String latPointStr = "";

					float labelDistLimit = 4;

					int charSpaceX = 7;
					if (labelWxPolyCoords == 1){
						for (int i=0; i<poly.polyPoints.size(); i++){
							WxPolyPoint wxp1 = (WxPolyPoint)poly.polyPoints.get(i);
							float dX = wxp1.rasterX - poly.centerPoint.rasterX;
							float dY = wxp1.rasterY - poly.centerPoint.rasterY;

							int startX = wxp1.rasterX+ (int) userPanOffset[CURRENT][WC.X];
							int startY = wxp1.rasterY+ (int) userPanOffset[CURRENT][WC.Y];

							//gMain.drawLine(wxp1.rasterX+ (int) userPanOffset[CURRENT][WC.X], wxp1.rasterY+ (int) userPanOffset[CURRENT][WC.Y], (int)((dX*2f)+  userPanOffset[CURRENT][WC.X]), (int)((dY*2f)+  userPanOffset[CURRENT][WC.Y]));
							int endX = (int)(poly.centerPoint.rasterX + labelDist*dX+ userPanOffset[CURRENT][WC.X]);
							int endY = (int)(poly.centerPoint.rasterY+ labelDist*dY+ userPanOffset[CURRENT][WC.Y]);

							int desiredLonLatStrLength = 7;

							lonPointStr = wxp1.lon+"";
							latPointStr = wxp1.lat+"";

							if (lonPointStr.length() > desiredLonLatStrLength) {

								lonPointStr = lonPointStr.substring(0, desiredLonLatStrLength);
							}
							if (latPointStr.length() > desiredLonLatStrLength) {

								latPointStr = latPointStr.substring(0, desiredLonLatStrLength);
							}

							float dLineX = endX - startX;
							float dLineY = endY - startY;

							float lenLine = dLineX*dLineX+dLineY*dLineY;
							lenLine = (float) Math.pow(lenLine, .5f);

							float scaleLine = labelDistLimit/lenLine;

							dLineX *= scaleLine;
							dLineY *= scaleLine;

							String labelStr = latPointStr+" / "+lonPointStr;

							gMain.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_READY]);
							gMain.drawLine(startX, startY, (int)(endX), (int)(endY));
							//gMain.drawLine(startX, startY, (int)(startX + dLineX), (int)(startY + dLineY));

							if (dX > 0){
								gMain.setColor(Color.black);
								gMain.drawString(labelStr, endX+7, endY+3);
								gMain.drawString(labelStr, endX+10, endY+3);
								gMain.drawString(labelStr, endX+8, endY+2);
								gMain.drawString(labelStr, endX+8, endY+4);
								//gMain.setColor(Color.green);
								gMain.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_WORKING]);
								gMain.drawString(labelStr, endX+8, endY+3);
								gMain.drawString(labelStr, endX+9, endY+3);
							} else {
								gMain.setColor(Color.black);
								gMain.drawString(labelStr, endX-labelStr.length()*charSpaceX -1, endY+3);
								gMain.drawString(labelStr, endX-labelStr.length()*charSpaceX +2, endY+3);
								gMain.drawString(labelStr, endX-labelStr.length()*charSpaceX, endY+2);
								gMain.drawString(labelStr, endX-labelStr.length()*charSpaceX, endY+4);
								//gMain.setColor(Color.green);
								gMain.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_WORKING]);
								gMain.drawString(labelStr, endX-labelStr.length()*charSpaceX, endY+3);
								gMain.drawString(labelStr, endX-labelStr.length()*charSpaceX+1, endY+3);
							}


						}
					}

				}
			}
		}

		// end draw poly


		// draw ruler

		float dist =0;

		float timeDiff = 0;

		float speed = 0f;
		if (timeDiff != 0){
			speed = dist/timeDiff;
		}

		if (ruler != null){
			if (ruler.polyPoints!= null){
				if (ruler.polyPoints.size() > 0){


					gMain.setColor(new Color(ruler.polyColor[WC.R],ruler.polyColor[WC.G],ruler.polyColor[WC.B]));

					for (int i=0; i<ruler.polyPoints.size()-1; i++){
						WxPolyPoint wxp1 = (WxPolyPoint)ruler.polyPoints.get(i);
						WxPolyPoint wxp2 = (WxPolyPoint)ruler.polyPoints.get(i+1);
						gMain.drawLine(wxp1.rasterX+ (int) userPanOffset[CURRENT][WC.X], wxp1.rasterY+ (int) userPanOffset[CURRENT][WC.Y], wxp2.rasterX+ (int) userPanOffset[CURRENT][WC.X], wxp2.rasterY+ (int) userPanOffset[CURRENT][WC.Y]);

					}

					int dotSizeWx = 5;
					int dotSizeWxHalf = 3;
					for (int i=0; i<ruler.polyPoints.size(); i++){
						WxPolyPoint wxp1 = (WxPolyPoint)ruler.polyPoints.get(i);

						gMain.fillOval(wxp1.rasterX+ (int) userPanOffset[CURRENT][WC.X] - dotSizeWxHalf, wxp1.rasterY+ (int) userPanOffset[CURRENT][WC.Y] - dotSizeWxHalf, dotSizeWx, dotSizeWx);
					}

					// label coords
					int labelWxPolyCoords = 1;
					float labelDist = 2f;
					gMain.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_READY]);
					//gMain.setComposite(graphicComposites[c_WORKING]);

					String lonPointStr = "";
					String latPointStr = "";
					int charSpaceX = 7;
					if (labelWxPolyCoords == 1){
						for (int i=0; i<ruler.polyPoints.size(); i++){
							WxPolyPoint wxp1 = (WxPolyPoint)ruler.polyPoints.get(i);
							float dX = 10;//wxp1.rasterX - ruler.centerPoint.rasterX;
							float dY = 20;//wxp1.rasterY - ruler.centerPoint.rasterY;

							float cSq = dX*dX+dY*dY;

							//gMain.drawLine(wxp1.rasterX+ (int) userPanOffset[CURRENT][WC.X], wxp1.rasterY+ (int) userPanOffset[CURRENT][WC.Y], (int)((dX*2f)+  userPanOffset[CURRENT][WC.X]), (int)((dY*2f)+  userPanOffset[CURRENT][WC.Y]));
							int endX = (int)(wxp1.rasterX + labelDist*dX+ userPanOffset[CURRENT][WC.X]);
							int endY = (int)(wxp1.rasterY+ labelDist*dY+ userPanOffset[CURRENT][WC.Y]);

							int desiredLonLatStrLength = 7;

							lonPointStr = wxp1.lon+"";
							latPointStr = wxp1.lat+"";

							if (lonPointStr.length() > desiredLonLatStrLength) {

								lonPointStr = lonPointStr.substring(0, desiredLonLatStrLength);
							}
							if (latPointStr.length() > desiredLonLatStrLength) {

								latPointStr = latPointStr.substring(0, desiredLonLatStrLength);
							}

							String labelStr = latPointStr+" / "+lonPointStr;

							String shortLabelStr = labelStr;
							if (i>=1){
								WxPolyPoint wxpPrev = (WxPolyPoint)ruler.polyPoints.get(i-1);
								float dT = wxp1.secsOfDay-wxpPrev.secsOfDay;
								labelStr = labelStr+" +"+dT+"s";
							}

							gMain.setColor(uiColors[WC.COLOR_TIVO_SELECTION_COMPLETE]);
							//gMain.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_READY]);
							gMain.drawLine(wxp1.rasterX+ (int) userPanOffset[CURRENT][WC.X], wxp1.rasterY+ (int) userPanOffset[CURRENT][WC.Y], endX, endY);
							if (dX > 0){
								gMain.setColor(Color.black);
								gMain.drawString(labelStr, endX+7, endY+3);
								gMain.drawString(labelStr, endX+10, endY+3);
								gMain.drawString(labelStr, endX+8, endY+2);
								gMain.drawString(labelStr, endX+8, endY+4);
								//gMain.setColor(Color.green);
								gMain.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_WORKING]);
								gMain.drawString(labelStr, endX+8, endY+3);
								gMain.drawString(labelStr, endX+9, endY+3);

								gMain.setColor(Color.red);
								gMain.drawString(shortLabelStr, endX+8, endY+3);
								gMain.drawString(shortLabelStr, endX+9, endY+3);

							} else {
								gMain.setColor(Color.black);
								gMain.drawString(labelStr, endX-labelStr.length()*charSpaceX -1, endY+3);
								gMain.drawString(labelStr, endX-labelStr.length()*charSpaceX +2, endY+3);
								gMain.drawString(labelStr, endX-labelStr.length()*charSpaceX, endY+2);
								gMain.drawString(labelStr, endX-labelStr.length()*charSpaceX, endY+4);
								//gMain.setColor(Color.green);
								gMain.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_WORKING]);
								gMain.drawString(labelStr, endX-labelStr.length()*charSpaceX, endY+3);
								gMain.drawString(labelStr, endX-labelStr.length()*charSpaceX+1, endY+3);

								gMain.setColor(Color.red);
								gMain.drawString(shortLabelStr, endX-labelStr.length()*charSpaceX, endY+3);
								gMain.drawString(shortLabelStr, endX-labelStr.length()*charSpaceX+1, endY+3);


							}


						}
					}

				}
			}
		}
		// end ruler


		// draw the timeline

		int timelineXpos = tivoStatusBarX + (int) userTimelineOffset[CURRENT];

		// gMain.setComposite(graphicComposites[c_COMPLETE]);

		gMain.setComposite(makeComposite(1.0f));
		gMain.setColor(Color.black);
		gMain.fillRect(timelineXpos, tivoStatusBarY, timelineImage.getWidth(),
				timelineImage.getHeight() + 400);
		gMain.drawImage(timelineImage, timelineXpos, tivoStatusBarY, null);

		// draw bookmarks
		int bookmarkTickY1 = tivoStatusBarY;
		int bookmarkTickY2 = tivoStatusBarY + 20;
		int bookmarkLabelY = tivoStatusBarY - 20;
		int selectedBookmarkID = -1;

		gMain.setComposite(makeComposite(.3f));
		for (int i = 0; i < bookmarkList.size(); i++) {
			BookmarkEvent be = (BookmarkEvent) bookmarkList.get(i);
			int timelineBookmarkX = be.timeStampSecOfDay + timelineXpos;
			if (timelineBookmarkX > tivoStatusBarX) {
				if (be.eventType == WC.EVENT_DATA_FEED) {
					gMain.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_INFO]);
				} else {
					if (be.statusCheckedByOperator == WC.STATUS_OFF) {
						gMain
						.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_NEW]);
					} else if (be.statusCheckedByOperator == WC.STATUS_ON) {
						gMain
						.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_OLD]);
					}
				}

				gMain.drawLine(timelineBookmarkX, bookmarkTickY1,
						timelineBookmarkX, bookmarkTickY2);

				if (bookmarkListIndex[userFlight] == i) {
					selectedBookmarkID = i;

				}
			}
		}

		gMain.setComposite(makeComposite(1f));
		if (selectedBookmarkID != -1) {
			int timelineOffsetY = 22;
			int yOffsetSat = 0;// 0;//timelineLayerOrder[j][Y];

			BookmarkEvent be = (BookmarkEvent) bookmarkList
			.get(selectedBookmarkID);
			if (be.satID > 0) {
				yOffsetSat = 30;
			}
			int tivoStatusBarTickYsliver = 3;

			int bookmarkTickY3 = tivoStatusBarY + yOffsetSat
			+ (be.scaID * tivoStatusBarTickYsliver) + timelineOffsetY;
			int timelineBookmarkX = be.timeStampSecOfDay + timelineXpos;
			if (timelineBookmarkX > tivoStatusBarX) {
				if (be.eventType == WC.EVENT_DATA_FEED) {
					gMain
					.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_SELECTED_INFO]);
				} else {
					// gMain.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_NEW]);
					gMain
					.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_SELECTED_REAL]);
				}

				gMain.drawLine(timelineBookmarkX, bookmarkTickY1,
						timelineBookmarkX, bookmarkTickY3);
				gMain.fillOval(timelineBookmarkX - 1, bookmarkTickY3 - 1, 3, 3);

				// gMain.setColor(Color.GREEN);
				String drawStr = be.eventLabel;


				if (be.lat != WC.INVALID_GEOLOCATION && be.lon != WC.INVALID_GEOLOCATION){
					drawStr+="  (LAT:"+be.lat+" LON:"+be.lon+")";
				}
				gMain.drawString(drawStr, timelineBookmarkX,
						bookmarkLabelY);

			}


		}

		// show processing status as ticker
		gMain.setComposite(graphicComposites[c_COMPLETE]);
		gMain.setColor(Color.white);
		String layerStr = "";// "RAW WIDEBAND - "; // create per layer

		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			if (witFrameList[userFlight][k] != null) {

				// bookmark items
				Composite c_REGION_HINT = makeComposite(Math.min(1.0f,
						regionHintAlpha));
				gMain.setComposite(c_REGION_HINT);
				int pointerX = timelineCenterX + tivoStatusBarX;

				gMain.setColor(Color.green);

				gMain.setStroke(stroke2);
				gMain.drawLine(pointerX - pointerW1 / 2 + 1, tivoStatusBarY
						- pointerH1, pointerX - pointerW1 / 2 + 1,
						tivoStatusBarY - pointerH2);

				gMain.setStroke(stroke2);
				gMain.drawLine(pointerX, tivoStatusBarY - pointerH1, pointerX,
						tivoStatusBarY - pointerH3);

				gMain.setColor(Color.green);
				if (regionHintStr != null) {

					gMain.drawString(regionHintStr, pointerX + 10,
							tivoStatusBarY - 30);
				}

				gMain.setComposite(graphicComposites[c_COMPLETE]);

				if (witFrameList[userFlight][k] != null) {
					for (int i = 0; i < witFrameList[userFlight][k].size(); i++) { // !!
						// NULL
						// ERROR
						// for (int i=0; i<frameCount; i++){
						WITFrame statusFrame = (WITFrame) witFrameList[userFlight][k].get(i);

						int tickXpos = tivoStatusBarX
						+ statusFrame.timeStampSecOfDay
						+ (int) userTimelineOffset[CURRENT];

						int mode = 0;

						// ghost of data to come
						// gMain.setComposite(graphicComposites[c_WORKING]);
						gMain.setColor(Color.WHITE);
						int borderHint = tivoStatusBarX;


						// int tivoBarOrderOffset = 2; // allow this constant so
						// we
						// can
						// wedge other non-display layers in, ie geolocation
						for (int j = 0; j < timelineLayerOrder.length; j++) {
							// for (int j=0; j<rasterLayerOrder.length; j++){
							// mode= WC.THREAD_HISTOGRAM;
							mode = j;
							int yBarPos = timelineLayerOrder[j][WC.Y];
							// gMain.setColor(statusColors[mode]);
							if (yBarPos != RASTER_OMIT
									&& timelineLayerOrder[j][WC.Z] == 0) { 

								gMain.setColor(statusColors[mode]);
								// gMain.setColor(Color.WHITE);
								if (tickXpos > tivoStatusBarX) {
									if (mode == WC.THREAD_LOAD_HDF5R
											&& statusFrame.fileBorderFrame == 1) {
										gMain.setColor(Color.WHITE);
									}
									if (mode == WC.THREAD_LOAD_METADATA
											&& statusFrame.fileBorderFrame == 1) {
										gMain.setColor(Color.WHITE);
									}
									if (mode != WC.THREAD_LOAD_HDF5R) {
										if (statusFrame.layerStatus[mode] == WC.STATUS_WORKING) {
											// gMain.setComposite(graphicComposites[c_WORKING]);
											gMain.fillRect(tickXpos,
													tivoStatusBarYRay[yBarPos],
													tivoStatusBarTickX,
													tivoStatusBarTickY);
										} else if (statusFrame.layerStatus[mode] == WC.STATUS_COMPLETE) {
											// gMain.setComposite(graphicComposites[c_COMPLETE]);
											gMain.fillRect(tickXpos,
													tivoStatusBarYRay[yBarPos],
													tivoStatusBarTickX,
													tivoStatusBarTickY);
										}
									}
								}

							}
						}

						statusFrame = null;
					}
				}
			}
		}

		// draw temporal selection

		gMain.setColor(uiColors[WC.COLOR_TIVO_SELECTION_COMPLETE]);

		loopBoundStartX = tivoStatusBarX + (int) userTimelineOffset[CURRENT]
		                                                            + userSelection[WC.START][WC.T];
		loopBoundEndX = tivoStatusBarX + (int) userTimelineOffset[CURRENT]
		                                                          + userSelection[WC.END][WC.T];

		gMain.drawLine(loopBoundStartX, loopSelectorY, loopBoundStartX,
				loopSelectorY2);
		gMain.drawLine(loopBoundEndX, loopSelectorY, loopBoundEndX,
				loopSelectorY2);
		gMain.fillRect(loopBoundStartX - handleFlagW + 1, loopSelectorY2,
				handleFlagW, handleFlagH);
		gMain.fillRect(loopBoundEndX, loopSelectorY2, handleFlagW, handleFlagH);

		gMain.setColor(Color.WHITE);
		gMain.drawString(secondsOfDayToReadable(userSelection[WC.START][WC.T]),
				loopBoundStartX - 74, loopSelectorY2 + 16);
		gMain.drawString(secondsOfDayToReadable(userSelection[WC.START][WC.T]),
				loopBoundStartX - 73, loopSelectorY2 + 16);
		gMain.drawString(secondsOfDayToReadable(userSelection[WC.END][WC.T]),
				loopBoundEndX + 20, loopSelectorY2 + 16);
		gMain.drawString(secondsOfDayToReadable(userSelection[WC.END][WC.T]),
				loopBoundEndX + 19, loopSelectorY2 + 16);
		// end temporal selection

		// render peer playhead
		// render playhead
		gMain.setComposite(graphicComposites[c_COMPLETE]);
		// outline
		gMain.setColor(Color.BLACK);

		// int curMin = tf[tivoPlayhead].timeStampMin+
		// tf[tivoPlayhead].timeStampHour*60;
		int curMin = tivoPlayheadXpos;
		// playheadXpos = tivoStatusBarX+tivoPlayhead*tivoStatusBarTickX -2;
		// //
		// -2 just for round rect indicator
		int playheadXpos = tivoStatusBarX + curMin * tivoStatusBarTickX - 2; // -2


		String labelStr = "";
		if (dynamicLoadStatus == WC.STATUS_COMPLETE){
			if (playbackStepSeconds<1.0){
				labelStr = secondsOfDayToReadableF(witTimePlayheadFloat);//witTimePlayheadTimestampStr;
			} else {
				labelStr = secondsOfDayToReadableF((int)(witTimePlayheadFloat));
				//labelStr = secondsOfDayToReadable(witTimePlayheadFloat);
			}
		} else {
			labelStr = secondsOfDayToReadableF((witTimePlayhead));
		}
		labelStr +="Z";

		if (labelStr.length() > 0) {
			gMain.setColor(Color.white);

			gMain.setComposite(graphicComposites[c_COMPLETE]);
			// timestamp string
			// if (dynamicLoadStatus == WC.STATUS_COMPLETE) {
			gMain.drawString(labelStr, playheadXpos - 27, tivoGraphicsY2 + 15);
			gMain.drawString(labelStr, playheadXpos - 26, tivoGraphicsY2 + 15);
			// }
		}

		if (playheadXpos > tivoStatusBarX) {
			gMain.setColor(Color.black);
			gMain.fillRoundRect(playheadXpos - 1, tivoGraphicsY2 - 1
					- tivoGraphicsH2, 4 + 2, tivoGraphicsH2 + 2, 2, 2);

			gMain.setColor(Color.white);
			gMain.fillRoundRect(playheadXpos, tivoGraphicsY2 - tivoGraphicsH2,
					4, tivoGraphicsH2, 2, 2);

			// middle
			if (nodePlayheadLocked == 1) {
				gMain.setColor(uiColors[WC.COLOR_TIVO_PLAYHEAD_LOCKED]);
			} else {
				gMain.setColor(uiColors[WC.COLOR_TIVO_PLAYHEAD]);
			}

			if (dynamicLoadStatus == WC.STATUS_WORKING) { // draw the timestamp
				gMain.setColor(Color.WHITE);
				int tPos = tivoPlayheadXpos - (int) userTimelineOffset[CURRENT];
				int hour = tPos / (WC.SEC_IN_HOUR);
				String hourStr = hour + "";
				if (hour < 10) {
					hourStr = "0" + hour;
				}
				int min = (tPos - hour * WC.SEC_IN_HOUR) / (60);
				String minStr = "" + min;
				if (min < 10)
					minStr = "0" + minStr;

				int sec = (tPos - hour * WC.SEC_IN_HOUR - min * 60);
				String secStr = "" + sec;
				if (sec < 10)
					secStr = "0" + secStr;

				hourStr += ":" + minStr + ":" + secStr;
			}

		}

		gMain.setComposite(graphicComposites[c_COMPLETE]);

		// underpaint to cover timeline area that goes too far
		gMain.setColor(Color.black);
		gMain.fillRect(0, tivoStatusBarY, tivoStatusBarX, viewportY);

		drawUIcommonItems(gMain);

		// draw mini map for context

		// draw funtion labels
		for (int j = 0; j < timelineLayerOrder.length; j++) {
			int mode = j;
			int yBarPos = timelineLayerOrder[j][WC.Y];
			// gMain.setColor(statusColors[mode]);
			if (yBarPos != RASTER_OMIT && timelineLayerOrder[j][WC.Z] == 0) { // add

				// label the status bars
				int labelTextYoffset = 10;
				int labelTextY = tivoStatusBarYRay[yBarPos] + labelTextYoffset;
				gMain.setComposite(makeComposite(1.0f));
				if (opMask[j] == true) {
					gMain.setColor(Color.white);
				} else {
					gMain.setColor(Color.gray);
				}

				gMain.drawString(opIDtoName(j), tivoInfoBarX, labelTextY);
			}
		}
		// end function labels

		if (masterOverlayToggle == 1) {
			if (widgetVisibility[WC.WIDGET_MINIMAP] == WC.STATUS_ON) {
				drawMiniMap(gMain);
			}
		}

		// gMain.setComposite(graphicComposites[c_COMPLETE]);

		gMain.setComposite(makeComposite(1.0f));
		// new draw histogram
		WITFrame wfRaster = null;
		// if (uiState == WC.UI_STATE_CONTRAST){
		if (widgetVisibility[WC.WIDGET_HISTOGRAM] == 1) {
			for (int k = histogramSCAselector; k <= histogramSCAselector; k++) {
				// if (mouseOverSCA != -1){

				if (k != -1) {
					// for (int k=0; k<WC.TOTAL_SCAS; k++){

					// histY = k*200;

					if (witFrameList[userFlight][k].size() > 0) {
						if (scanDirAgreementDrawFlag[userFlight][k] == 1
								&& timeAgreementDrawFlag[userFlight][k] == 1 && scanSeqAgreementDrawFlag[userFlight][k] == 1) {

							wfRaster = (WITFrame) witFrameList[userFlight][k]
							                                               .get(witSCAPlayhead[userFlight][k]);

						} else { // draw previous otherwise

							if (lastDrawIndexList[userFlight][k].size() > 0) {
								wfRaster = (WITFrame) witFrameList[userFlight][k]
								                                               .get((Integer) lastDrawIndexList[userFlight][k]
								                                                                                            .get(lastDrawIndexList[userFlight][k]
								                                                                                                                               .size() - 1));
							}
						}
					}

					// gMain.setComposite(makeComposite(1.0f));
					if (wfRaster != null) {
						// /System.out.println("HIST 1");
						if (wfRaster.layerStatus[WC.THREAD_HISTOGRAM] == WC.STATUS_COMPLETE) {
							// System.out.println("HIST 2");
							if (wfRaster.histogram != null
									&& widgetVisibility[WC.WIDGET_HISTOGRAM] == 1) {

								float hScale = ((float) histWindowH * 10.0f / (float) wfRaster.totalPixels);
								float hScaleExp = .5f;
								// float hScale =
								// ((float)histWindowH/(float)tf[tivoPlayhead].histStats[STATS_MAX_BIN]);

								float maxScale = .1f;
								if (hScale > maxScale)
									hScale = maxScale;

								int histBins = wfRaster.histBins;

								int w = wfRaster.width;
								int h = wfRaster.height;

								int histW = 0;
								int histH = 0;

								int binX = 0;
								int binY = 0;
								int binW = 0;
								int binH = 0;

								gMain.setComposite(graphicComposites[c_WIDGET]);
								gMain.setColor(Color.black);
								// gMain.setComposite(graphicComposites[c_COMPLETE]);
								gMain.fillRect(histX, histY - histWindowH,
										histWindowW, histWindowH);

								gMain
								.setComposite(graphicComposites[c_COMPLETE]);

								gMain
								.setColor(uiColors[WC.COLOR_TIVO_SELECTION_COMPLETE]); // default

								int contrastBarSpaceXSlice = Math.max(
										contrastBarSpaceX - 1, 1);
								int contrastBarMaxDrawPosX = histX
								+ histWindowW - contrastBarSpaceXSlice; // don't
								// draw
								// beyond
								// this
								for (int i = 0; i < histBins; i++) {

									int clampedH = 0;
									binH = wfRaster.histogram[i];
									if (binH > 0) {
										// gMain.setColor(statusColors[WC.THREAD_HISTOGRAM]);
										gMain
										.setColor(uiColors[WC.COLOR_HIST_OUT]);
									}

									if (histogramDisplayState == HISTOGRAM_DISPLAY_LINEAR) {
										binH = (int) ((float) binH * hScale);
									} else if (histogramDisplayState == HISTOGRAM_DISPLAY_EXPONENTIAL) {
										binH = (int) (Math.pow(binH, .5f) * hScaleExp);
									}

									if (binH > histWindowH) {
										clampedH = 1;
										binH = histWindowH;
									}
									binY = histY - binH;

									if (clampedH == 1) {
										gMain.setColor(Color.gray);
									}

									int drawPosX = histX
									+ (i / histClusterSize * contrastBarSpaceX);
									if (drawPosX < contrastBarMaxDrawPosX) {
										gMain.fillRect(drawPosX, binY,
												contrastBarSpaceXSlice, binH);
									}
								}

								// quartiles
								for (int i = wfRaster.histStats[STATS_Q1]; i <= wfRaster.histStats[STATS_Q3]; i++) {

									int clampedH = 0;
									binH = wfRaster.histogram[i];
									if (binH > 0) {
										gMain
										.setColor(uiColors[WC.COLOR_HIST_IN]);
									}

									// scale to fit

									if (histogramDisplayState == HISTOGRAM_DISPLAY_LINEAR) {
										binH = (int) ((float) binH * hScale);
									} else if (histogramDisplayState == HISTOGRAM_DISPLAY_EXPONENTIAL) {
										binH = (int) (Math.pow(binH, .5f) * hScaleExp);
									}

									if (binH > histWindowH) {
										clampedH = 1;
										binH = histWindowH;
									}

									binY = histY - binH;

									if (clampedH == 1) {
										gMain.setColor(Color.gray);
									}
									int drawPosX = histX
									+ (i / histClusterSize * contrastBarSpaceX);
									if (drawPosX < contrastBarMaxDrawPosX) {
										gMain.fillRect(drawPosX, binY,
												contrastBarSpaceXSlice, binH);
									}
								}
								// median
								for (int i = wfRaster.histStats[STATS_Q2]; i <= wfRaster.histStats[STATS_Q2] + 1; i++) {

									int clampedH = 0;
									binH = wfRaster.histogram[i];
									if (binH > 0) {
										gMain.setColor(Color.green);
									}

									// scale to fit

									if (histogramDisplayState == HISTOGRAM_DISPLAY_LINEAR) {
										binH = (int) ((float) binH * hScale);
									} else if (histogramDisplayState == HISTOGRAM_DISPLAY_EXPONENTIAL) {
										binH = (int) (Math.pow(binH, .5f) * hScaleExp);
									}

									if (binH > histWindowH) {
										clampedH = 1;
										binH = histWindowH;
									}
									binY = histY - binH;

									if (clampedH == 1) {
										gMain.setColor(Color.gray);
									}
									int drawPosX = histX
									+ (i / histClusterSize * contrastBarSpaceX);
									if (drawPosX < contrastBarMaxDrawPosX) {
										gMain.fillRect(drawPosX, binY,
												contrastBarSpaceXSlice, binH);
									}
								}

								// histogram magnification
								if (histogramZoomEnabled == 1) {
									gMain.setColor(Color.white);
									gMain.fillRect(histX + histWindowW
											- histogramZoomButtonSize, histY
											- histWindowH + 1,
											histogramZoomButtonSize,
											histogramZoomButtonSize);
									gMain.fillRect(histX + histWindowW
											- histogramZoomButtonSize * 2 - 1,
											histY - histWindowH + 1,
											histogramZoomButtonSize,
											histogramZoomButtonSize);
									// gMain.setColor(Color.green); // minus
									gMain.setColor(uiColors[WC.COLOR_HIST_OUT]);// minus

									gMain.setStroke(strokeWidth3);
									gMain.drawLine(histX + histWindowW
											- histogramZoomButtonSize - 5,
											histY - histWindowH
											+ histogramZoomButtonSize
											/ 2, histX + histWindowW
											- histogramZoomButtonSize
											- 17, histY - histWindowH
											+ histogramZoomButtonSize
											/ 2);
									// plus
									gMain.drawLine(histX + histWindowW - 4,
											histY - histWindowH
											+ histogramZoomButtonSize
											/ 2, histX + histWindowW
											- 16, histY - histWindowH
											+ histogramZoomButtonSize
											/ 2);
									gMain.drawLine(histX + histWindowW
											- histogramZoomButtonSize / 2,
											histY - histWindowH + 4, histX
											+ histWindowW
											- histogramZoomButtonSize
											/ 2, histY - histWindowH
											+ 16);
									gMain.setStroke(strokeWidth1);
								}

								// border
								gMain.setColor(Color.WHITE);
								gMain.drawRect(histX, histY - histWindowH,
										histWindowW, histWindowH);

								gMain.setColor(Color.white);
								String scaleStr = "";
								if (histogramDisplayState == HISTOGRAM_DISPLAY_LINEAR) {
									scaleStr = "LIN SCALE";
								} else if (histogramDisplayState == HISTOGRAM_DISPLAY_EXPONENTIAL) {
									scaleStr = "LOG SCALE";
								}
								String q1Str = "Q1 "
									+ wfRaster.histStats[STATS_Q1];
								String q2Str = "Q2 "
									+ wfRaster.histStats[STATS_Q2];
								String q3Str = "Q3 "
									+ wfRaster.histStats[STATS_Q3];
								int histTextYoffset = 20;
								if (histogramZoomEnabled == 1) {
									histTextYoffset = 40;
								}
								gMain.drawString(scaleStr, histX + histWindowW
										- 70, histY - histWindowH
										+ histTextYoffset);
								gMain.setColor(uiColors[WC.COLOR_HIST_IN]);
								gMain.drawString(q1Str, histX + histWindowW
										- 70, histY - histWindowH
										+ histTextYoffset + 1
										* (tivoBarYSeparation));
								gMain.drawString(q3Str, histX + histWindowW
										- 70, histY - histWindowH
										+ histTextYoffset + 3
										* (tivoBarYSeparation));
								gMain.setColor(Color.green);
								gMain.drawString(q2Str, histX + histWindowW
										- 70, histY - histWindowH
										+ histTextYoffset + 2
										* (tivoBarYSeparation));

								// draw the value of current mouse-over
								// intensity
								gMain
								.setColor(uiColors[WC.COLOR_TIVO_SELECTION_COMPLETE]);
								int mouseOverIntensityX = histX
								+ intensityToContrastX(mouseIntensity);

								gMain.drawLine(mouseOverIntensityX, histY,
										mouseOverIntensityX, histY + 20);

								// draw the user selection bounds for contrast

								gMain
								.setColor(uiColors[WC.COLOR_TIVO_SELECTION_COMPLETE]);
								int cSelPosX1 = histX
								+ (userContrast[WC.START] * contrastBarSpaceX)
								+ 1;
								int cSelPosX2 = histX
								+ (userContrast[WC.END] * contrastBarSpaceX)
								- 1;

								gMain.drawLine(cSelPosX2, histY - histWindowH,
										cSelPosX2, histY);
								gMain.fillRect(cSelPosX1 - handleFlagW, histY,
										handleFlagW, handleFlagH);
								gMain.fillRect(cSelPosX2, histY, handleFlagW,
										handleFlagH);

								// draw contrast curve
								if (userContrastCPList.size() == 0) {
									gMain.drawLine(cSelPosX1, histY, cSelPosX2,
											histY - histWindowH);
								} else {
									gMain
									.setColor(uiColors[WC.COLOR_TIVO_SELECTION_COMPLETE]);
									int firstCurveInt = ((UserContrastCP) userContrastCPList
											.get(0)).histIntensityBin
											* contrastBarSpaceX;
									int firstCurveIntRast = ((UserContrastCP) userContrastCPList
											.get(0)).rasterIntensity;

									gMain.drawLine(cSelPosX1, histY,
											firstCurveInt + histX, histY
											- firstCurveIntRast);

									for (int i = 1; i < userContrastCPList
									.size(); i++) {
										UserContrastCP ucp1 = (UserContrastCP) userContrastCPList
										.get(i - 1);
										UserContrastCP ucp2 = (UserContrastCP) userContrastCPList
										.get(i);

										int uci1 = ucp1.histIntensityBin
										* contrastBarSpaceX;
										int ucir1 = ucp1.rasterIntensity;

										int uci2 = ucp2.histIntensityBin
										* contrastBarSpaceX;
										int ucir2 = ucp2.rasterIntensity;

										gMain.drawLine(histX + uci1, histY
												- ucir1, histX + uci2, histY
												- ucir2);

									}

									int lastCurveInt = ((UserContrastCP) userContrastCPList
											.get(userContrastCPList.size() - 1)).histIntensityBin
											* contrastBarSpaceX;
									int lastCurveIntRast = ((UserContrastCP) userContrastCPList
											.get(userContrastCPList.size() - 1)).rasterIntensity;

									gMain.drawLine(lastCurveInt + histX, histY
											- lastCurveIntRast, cSelPosX2,
											histY - histWindowH);

									// dots for actual CPs
									int padding = 2;
									int paddingOffset = padding / 2;
									for (int i = 0; i < userContrastCPList
									.size(); i++) {
										UserContrastCP ucp1 = (UserContrastCP) userContrastCPList
										.get(i);
										int cpX = ucp1.histIntensityBin
										* contrastBarSpaceX;
										int cpY = ucp1.rasterIntensity;
										gMain
										.setColor(uiColors[WC.COLOR_TIVO_SELECTION_WORKING]);
										gMain.fillOval(histX + cpX
												- contrastCurveDotOffsetRadius
												- paddingOffset, histY - cpY
												- contrastCurveDotOffsetRadius
												- paddingOffset,
												contrastCurveDotRadius
												+ padding,
												contrastCurveDotRadius
												+ padding);

										gMain
										.setColor(uiColors[WC.COLOR_TIVO_SELECTION_COMPLETE]);
										gMain
										.fillOval(
												histX
												+ cpX
												- contrastCurveDotOffsetRadius,
												histY
												- cpY
												- contrastCurveDotOffsetRadius,
												contrastCurveDotRadius,
												contrastCurveDotRadius);
									}
								}
							}

							wfRaster = null;
						}
					}
				}
			}
		}

		// overlays
		Composite c_OVERLAY = makeComposite(Math.min(1.0f,
				tivoSpeedOverlayAlpha));
		gMain.setColor(uiColors[WC.COLOR_TIVO_PLAYHEAD]);
		// gMain.setComposite(c_OVERLAY);
		// gMain.setFont(new java.awt.Font(fontNameStr, 60, Font.PLAIN));
		gMain.drawString(userInterfaceInfoStr, tivoInfoBarX, tivoInfoBarY);

		// timeline magnifier
		if (timelineMouseoverX > -1) {
			gMain.setComposite(graphicComposites[c_COMPLETE]);
		}

		// overlay features

		gMain.setComposite(graphicComposites[c_LATLON_OVERLAY]);
		gMain.drawImage(viewportImageOverlay,
				(int) userPanOffset[CURRENT][WC.X],
				(int) userPanOffset[CURRENT][WC.Y], null);

		// end the overlay

		// magnifier flip

		if (cursorY > magTogYBottom) {
			magnifierToggle = 0;

		}
		if (cursorY < magTogYTop) {
			magnifierToggle = 1;
		}

		int magYoff = lensW*2+100;//300;
		int lensZoomX = lensW * lensScale;
		int lensZoomY = lensH * lensScale;
		int lensRasterXoff = lensPosX - lensZoomX / 2;
		int lensRasterYoff = lensPosY - lensZoomY / 2 + magYoff;

		int latLonTextHeightBlock = 30;

		// flip offsets

		int yTogDiff = 0;
		int yTopTextDiff = 0;
		if (magnifierToggle == 0) { // draw bottom version
			yTogDiff = (int) (-(float) lensZoomY * 1.4f)
			- latLonTextHeightBlock;
			yTopTextDiff = -yTogDiff - 155 - latLonTextHeightBlock;// -(1+latLonTextHeightBlock);
		} else if (magnifierToggle == 1) { // draw top version
			yTogDiff = latLonTextHeightBlock;
			yTopTextDiff = -(latLonTextHeightBlock * 2) + 6;
		}

		// image magnifier
		if (lensMagnifyActive == 1 && cursorY < tivoStatusBarY
				&& cursorOverWidget == WC.STATUS_OFF) {

			gMain.setComposite(graphicComposites[c_COMPLETE]);

			for (int x = 0; x < lensW; x++) {
				for (int y = 0; y < lensH; y++) {

					int pullX = lensPosX + x - lensW / 2;
					int pullY = lensPosY + y - lensH / 2;
					// viewportImage.getHeight()-

					if (pullX > 0 && pullY > 0) {
						if (pullX < viewportImage.getWidth()
								&& pullY < viewportImage.getHeight()) {
							int c = viewportImage.getRGB(pullX, pullY);
							lensMagImage.setRGB(x, y, c);
						}
					}
				}
			}

			if (latLonOverlayEnabled == 1 && (mouseLon != 0 || mouseLat != 0)) {

				// centered
				// int lensRasterYoff = lensPosY-lensZoomY/2;
				gMain.setColor(statusColors[WC.THREAD_DIFF]);
				if (magnifierToggle == 0) {
					gMain.drawLine(lensPosX, cursorY, lensPosX, lensPosY
							- magYoff / 2);
				} else if (magnifierToggle == 1) {
					gMain.drawLine(lensPosX, cursorY, lensPosX, lensPosY
							+ magYoff / 2);
				}
			}

			gMain.setColor(statusColors[WC.THREAD_DIFF]);
			if (magnifierToggle == 0) { // draw bottom version
				gMain.fillRect(lensRasterXoff - 1, yTogDiff + lensRasterYoff
						- 1, lensZoomX + 2, lensZoomY + 2
						+ latLonTextHeightBlock * 2);
			} else if (magnifierToggle == 1) { // draw top version
				gMain.fillRect(lensRasterXoff - 1, yTogDiff + lensRasterYoff
						- 1 - (2 * latLonTextHeightBlock), lensZoomX + 2,
						lensZoomY + 2 + latLonTextHeightBlock * 2);
			}

			// gMain.drawRect(lensRasterXoff - 1, lensRasterYoff - 1, lensZoomX
			// + 1, lensZoomY + 1);
			gMain.drawImage(lensMagImage, lensRasterXoff, yTogDiff
					+ lensRasterYoff, lensZoomX, lensZoomY, null);



			if (mouseLon != INVALID_GEOLOCATION
					&& mouseLat != INVALID_GEOLOCATION
					&& (mouseLon != 0 || mouseLat != 0)) {

				gMain.setColor(Color.green);
				StringBuilder mouseLonStr = new StringBuilder();
				mouseLonStr.append(mouseLon);// + "";
				StringBuilder mouseLatStr = new StringBuilder();
				mouseLatStr.append(mouseLat);// + "";

				int desiredLonLatStrLength = 12;
				if (mouseLonStr.length() > desiredLonLatStrLength) {

					mouseLonStr.substring(0, desiredLonLatStrLength);
				}
				if (mouseLatStr.length() > desiredLonLatStrLength) {

					mouseLatStr.substring(0, desiredLonLatStrLength);
				}

				// invalid geolocation
				if (mouseLon <= -9999 || mouseLat <= -9999) {
					// mouseLonStr = "OFF EARTH";
					// mouseLatStr = "OFF EARTH";
				}

				gMain.setColor(Color.WHITE);
				mouseLonStr.insert(0, "LON: ");
				mouseLatStr.insert(0, "LAT: ");

				gMain.drawString(mouseLatStr.toString(), cursorX - lensZoomX
						/ 2 + 50, yTogDiff + cursorY + 100 + 1
						+ latLonTextHeightBlock - 10 + yTopTextDiff);
				gMain.drawString(mouseLatStr.toString(), cursorX - lensZoomX
						/ 2 + 51, yTogDiff + cursorY + 100 + 1
						+ latLonTextHeightBlock - 10 + yTopTextDiff);

				gMain.drawString(mouseLonStr.toString(), cursorX + 50, yTogDiff
						+ cursorY + 100 + 1 + latLonTextHeightBlock - 10
						+ yTopTextDiff);
				gMain.drawString(mouseLonStr.toString(), cursorX + 51, yTogDiff
						+ cursorY + 100 + 1 + latLonTextHeightBlock - 10
						+ yTopTextDiff);

				// second representation

				String mouseLonDMSStr = degreesDecimalToDegreesMinutes(
						mouseLon, WC.GEODATA_LON);
				String mouseLatDMSStr = degreesDecimalToDegreesMinutes(
						mouseLat, WC.GEODATA_LAT);

				int degMinSecTextHeightBlock = 18;
				gMain.drawString(mouseLatDMSStr, cursorX - lensZoomX / 2 + 50,
						yTogDiff + cursorY + 100 + 1 + degMinSecTextHeightBlock
						+ latLonTextHeightBlock - 10 + yTopTextDiff);
				gMain.drawString(mouseLatDMSStr, cursorX - lensZoomX / 2 + 51,
						yTogDiff + cursorY + 100 + 1 + degMinSecTextHeightBlock
						+ latLonTextHeightBlock - 10 + yTopTextDiff);

				gMain.drawString(mouseLonDMSStr, cursorX + 50, yTogDiff
						+ cursorY + 100 + 1 + degMinSecTextHeightBlock
						+ latLonTextHeightBlock - 10 + yTopTextDiff);
				gMain.drawString(mouseLonDMSStr, cursorX + 51, yTogDiff
						+ cursorY + 100 + 1 + degMinSecTextHeightBlock
						+ latLonTextHeightBlock - 10 + yTopTextDiff);

				int crosshairLength = 8;

				gMain.setColor(Color.GREEN);
				if (userEventFlash > userEventFlashDefault/2){
					gMain.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_SELECTED_REAL]);
				}
				// gMain.setColor(statusColors[WC.THREAD_DIFF]);
				gMain.drawLine(cursorX - crosshairLength, cursorY, cursorX
						+ crosshairLength, cursorY);
				gMain.drawLine(cursorX, cursorY - crosshairLength, cursorX,
						cursorY + crosshairLength);

				int innerCrosshairTick = (int) ((float) lensZoomX * .4f);
				int lensHalfX = (lensRasterXoff + lensZoomX / 2);
				int lensHalfY = (lensRasterYoff + lensZoomY / 2);

				// tics inside the magnifier

				gMain.drawLine(lensRasterXoff + innerCrosshairTick, yTogDiff
						+ lensHalfY, lensRasterXoff, yTogDiff + lensHalfY);
				gMain.drawLine(lensHalfX, yTogDiff + lensRasterYoff
						+ innerCrosshairTick, lensHalfX, yTogDiff
						+ lensRasterYoff + 1);
				gMain.drawLine(lensRasterXoff + lensZoomX - innerCrosshairTick,
						yTogDiff + lensHalfY, lensRasterXoff + lensZoomX - 1,
						yTogDiff + lensHalfY);
				gMain.drawLine(lensHalfX, yTogDiff + lensRasterYoff + lensZoomY
						- innerCrosshairTick, lensHalfX, yTogDiff
						+ lensRasterYoff + lensZoomY - 1);

				// show the mouse-over intensity on the histogram

			}
		} else {

			// magnify the timeline
		}

		// draw the NORTH arrows and georeference cues
		if (drawNorthArrowsStatus == 1 && lensMagnifyActive == 1
				&& compassIsValid == 1 && cursorY < tivoStatusBarY) {

			if (cursorOverWidget == WC.STATUS_OFF) { // if cursor is not over a
				// widget

				int cursorXoffset = -100;

				int compassSize = 50;
				gMain.setColor(Color.black);
				gMain.fillOval(cursorX + cursorXoffset, cursorY, compassSize,
						compassSize);

				gMain.setColor(Color.green);

				gMain.setColor(statusColors[WC.THREAD_DIFF]);
				gMain.drawOval(cursorX + cursorXoffset, cursorY, compassSize,
						compassSize);

				Graphics2D gRot = (Graphics2D) compassImageRot.getGraphics();
				// gRot.setColor(Color.BLACK);
				// gRot.fillRect(0, 0, compassSize, compassSize);

				AffineTransform compAffine = new AffineTransform();

				// compAffine.setToRotation(compassAngle, compassSize/2,
				// compassSize/2);

				if (uiCompassRotationState == WC.STATUS_OFF) {
					compAffine.setToRotation(Math.PI - compassAngle,
							compassSize / 2, compassSize / 2);

					AffineTransformOp affineTransformOp = new AffineTransformOp(
							compAffine, AffineTransformOp.TYPE_BICUBIC);

					affineTransformOp.filter(compassImage, compassImageRot);
				}

				gMain.drawImage(compassImageRot, cursorX + cursorXoffset,
						cursorY, null);
			}
		}


		// end geo cues

	}

	public void drawFinalScreen() {
		// flush to screen

		if (gwc != null) {
			gwc.setComposite(graphicComposites[c_COMPLETE]);
			gwc.drawImage(viewportImage, 0, 0, null);
			// gwc.drawImage(viewportImageOverlay, 0, 0, null);
		} else {

			gwc = (Graphics2D) tivoCanvas.getGraphics();
		}

		// save frames for creation of a demo video
		if (exportDemoVideoState == WC.STATUS_ON){
			try{
				String fName = defaultSaveDemoVideoDirStr+demoVideoFrameCount+ ".png";
				File pngFile = new File(fName);
				pngFile.setReadable(true, false);

				ImageIO.write(viewportImage, "png", pngFile);
				demoVideoFrameCount++;

			} catch (Exception e){
				e.printStackTrace();
			}
		}
	}

	public int getThreadID() {

		int threadID = -1;
		int threadSearch = 1;

		for (int i = 0; i < MAX_THREADS_QUEUED; i++) {
			if (imprRay[i] != null) {

				if (imprRay[i].threadStatus == WC.THREAD_STATUS_READY
						&& threadID == -1) {// && threadAllocations[i] == 0) {
					if (threadSearch == 1) {

						threadID = i;
						threadSearch = 0;
					}

				}
			}
		}

		System.out.println("THREAD ALLOCATED: " + threadID);

		return threadID;
	}

	public void checkThreadActivityLevel() {
		// activeThreadCount
		int availThreads = 0;
		int activeThreads = 0;
		for (int i = 0; i < MAX_THREADS_QUEUED; i++) {
			if (imprRay[i].threadStatus == WC.THREAD_STATUS_COMPLETE) {
				imprRay[i].threadStatus = WC.THREAD_STATUS_READY;
				// threadAllocations[i] = 0;
				System.out.println("RECLAIMED THREAD " + i);
			}
		}

		for (int i = 0; i < MAX_THREADS_QUEUED; i++) {
			if (imprRay[i].threadStatus == WC.THREAD_STATUS_READY) {
				availThreads++;
			} else {
				activeThreads++;
			}
		}
		int workingThreads = 0;

		int loadingThreads = 0;
		for (int i = 0; i < MAX_THREADS_QUEUED; i++) {
			if (imprRay[i].threadStatus == WC.THREAD_STATUS_WORKING) {
				workingThreads++;
				/*
				 * if (imprRay[i].mode == WC.THREAD_LOAD_HDF5R){
				 * loadingThreads++; }
				 */

			}
		}

		activeThreadCount = workingThreads;// MAX_THREADS-availThreads;

	}

	public int getThreadQueueCount() {
		int queuedThreads = 0;

		for (int i = 0; i < MAX_THREADS_QUEUED; i++) {
			// System.out.println("   THREAD "+i+" QUEUED "+imprRay[i].threadStatus+" TOTAL "+queuedThreads);
			if (imprRay[i].threadStatus == WC.THREAD_STATUS_QUEUED) {// &&
				// threadAllocations[i]==1){

				queuedThreads++;
			}
		}

		queuedThreadCount = queuedThreads;

		return queuedThreads;
	}

	public void activateQueueThreads() {

		// System.out.println(getThreadQueueCount()+" QUEUED THREADS");
		for (int i = 0; i < MAX_THREADS_QUEUED; i++) {

			if (activeThreadCount < MAX_THREADS_ACTIVE
					&& getThreadQueueCount() > 0) {
				if (imprRay[i].threadStatus == WC.THREAD_STATUS_QUEUED) {
					imprRay[i].threadStatus = WC.THREAD_STATUS_WORKING;

					Thread t = new Thread(imprRay[i]);
					t.setPriority(threadPriorities[imprRay[i].mode]);
					try {
						t.join(threadTimeouts[imprRay[i].mode]);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					activeThreadCount++;
					System.out.println("ACTIVATED THREAD " + i);
					t.start();

				}
			}
		}
		System.runFinalization();
	}

	public void processWIT() {

		checkThreadActivityLevel();

		for (int k = 0; k < WC.TOTAL_SCAS; k++) {

			if (witFrameList[userFlight][k] != null) { // if SCA has laoded data

				if (threadScheme == WC.THREAD_SCHEME_BATCH) {

					for (int m = 0; m < WC.MODE_COUNT; m++) {

						if ((userSelectionSCAtouched[k] == 1 && filterRegionReqMask[m] == 1)
								|| filterRegionReqMask[m] == 0) { // if SCA is
							// part of
							// selection region

							int mode = m;
							int threadID = -1;

							// if (opMask[mode] == 1) {

							if (opMask[mode] == true
									&& checkNeedForThread(witFrameList[userFlight][k], 0,
											witFrameList[userFlight][k].size(), mode) != -1) {

								threadID = getThreadID();


								StringBuilder strBdr = new StringBuilder();

								if (threadID != -1) {

									// will have to revisit to fix import/export
									// params
									createParamList(mode, k); // refresh params
									// in case
									// GUI changes were made

									imprRay[threadID] = new ImProcThread(
											getModeStr(mode), mode,
											witFrameList[userFlight][k], 0, witFrameList[userFlight][k]
											                                                         .size(),
											                                                         paramLists[k][mode]);

									imprRay[threadID].threadStatus = WC.THREAD_STATUS_QUEUED;

									// strBdr = new StringBuilder();
									strBdr.append("SETTING THREAD ");
									strBdr.append(threadID);
									strBdr.append(" AS QUEUED");
									System.out.println(strBdr);

								}
							}
						}
					}
				}
			}
		}

		activateQueueThreads();
	}

	public void syncDrawSegments() {

		int playbackTimeMargin = loadSeconds;

		for (int flight = 0; flight < WC.TOTAL_FLIGHTS; flight++) {

			if (flightLoadMask[flight] == 1) {
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					witSCAPlayhead[flight][k] = getIndexFromTime(
							witTimePlayhead, flight, k, playbackTimeMargin,
							playbackModeDir[flight]);//

					if (lastDrawIndexList[flight][k] != null) {
						while (lastDrawIndexList[flight][k].size() > 1) {
							lastDrawIndexList[flight][k].remove(0); // !!
							// 1/12/2011
						} 

						lastDrawIndexList[flight][k]
						                          .add(witSCAPlayhead[flight][k]);


						if (lastDrawIndexList[flight][k].get(0) != lastDrawIndexList[flight][k]
						                                                                     .get(lastDrawIndexList[flight][k].size() - 1)) {
							//dwtBufferStepTrigger = 1;
						}
					}
				}
			}
		}

	}

	public void animatePlayback() {

		//determineIndexSca();

		if (playbackPaused == 0 && playheadDir != 0
				&& mouseState != WC.UI_STATE_TIMELINE_LOAD) {
			witFrameListStep(playheadDir, playbackStepSeconds);

		} 

		syncDrawSegments();
	}

	public int getIndexFromTime(int secs, int flight, int scaID,
			int searchSecs, int scanDir) {
		int index = 0;
		int threshDelta = searchSecs;// 5;// searchSecs+5;//5;
		int minDelta = threshDelta;

		timeAgreementDrawFlag[flight][scaID] = -1;
		scanSeqAgreementDrawFlag[flight][scaID] = -1;
		int timeResult = 0;
		for (int i = 0; i < witFrameList[flight][scaID].size(); i++) {

			WITFrame w = (WITFrame) witFrameList[flight][scaID].get(i);
			int tDelta = Math.abs(w.timeStampSecOfDay - secs);
			if (tDelta < threshDelta) {

				if (tDelta < minDelta) {
					// scan dir
					if (scanDir == SCAN_SELECT_ALL
							&& (playbackScanSeqIndexMask[flight][w.scanSeqIndex] == WC.STATUS_ON || w.scanSeqIndex >= WC.SCAN_SEQ_INDEX_MAX_VAL)) {
						minDelta = tDelta;
						index = i;
						timeResult = w.timeStampSecOfDay;
						scanDirAgreementDrawFlag[flight][scaID] = 1;
						scanSeqAgreementDrawFlag[flight][scaID] = 1;
						playbackScanLengthPrev[flight][scaID] = w.numLines;
						playbackScanSeqIndexPrev[flight] = w.scanSeqIndex;
						timeAgreementDrawFlag[flight][scaID] = 1;
					} else if (scanDir == SCAN_SELECT_EVEN) {

						if (w.scanDirection == SCAN_SELECT_EVEN
								&& (playbackScanSeqIndexMask[flight][w.scanSeqIndex] == WC.STATUS_ON || w.scanSeqIndex >= WC.SCAN_SEQ_INDEX_MAX_VAL)) {
							minDelta = tDelta;
							index = i;
							timeResult = w.timeStampSecOfDay;
							scanDirAgreementDrawFlag[flight][scaID] = 1;
							scanSeqAgreementDrawFlag[flight][scaID] = 1;
							playbackScanLengthPrev[flight][scaID] = w.numLines;
							playbackScanSeqIndexPrev[flight] = w.scanSeqIndex;
							timeAgreementDrawFlag[flight][scaID] = 1;
						}
					} else if (scanDir == SCAN_SELECT_ODD) {
						if (w.scanDirection == SCAN_SELECT_ODD
								&& (playbackScanSeqIndexMask[flight][w.scanSeqIndex] == WC.STATUS_ON || w.scanSeqIndex >= WC.SCAN_SEQ_INDEX_MAX_VAL)) {
							minDelta = tDelta;
							index = i;
							timeResult = w.timeStampSecOfDay;
							scanDirAgreementDrawFlag[flight][scaID] = 1;
							scanSeqAgreementDrawFlag[flight][scaID] = 1;
							playbackScanLengthPrev[flight][scaID] = w.numLines;
							playbackScanSeqIndexPrev[flight] = w.scanSeqIndex;
							timeAgreementDrawFlag[flight][scaID] = 1;
						}
					}

				}
			}
		}

		return index;
	}


	public void witFrameListStep(int dir) {

		determineIndexSca();

		int prevPlayhead = witTimePlayhead;

		int scaID = indexSca[userFlight];

		if (dir > 0) {
			witTimePlayhead += 1;// skipSeconds;

		} else if (dir < 0) {
			witTimePlayhead -= 1;// skipSeconds;
		}

		if (witTimePlayhead > userSelection[WC.END][WC.T]) {
			witTimePlayhead = userSelection[WC.START][WC.T];
		}
		if (witTimePlayhead < userSelection[WC.START][WC.T]) {
			witTimePlayhead = userSelection[WC.END][WC.T];
		}

		cvt.checkWitFrameLoop();


		playheadToXPos();

		statusInterp = 0;
		doMouseLatLon();

	}

	// set to a specific time, as from the bookmarks
	public void witFrameListJump(int destinationTime){

		int prevPlayhead = witTimePlayhead;
		witTimePlayhead =destinationTime;

		if (witTimePlayhead > userSelection[WC.END][WC.T]) {
			witTimePlayhead = userSelection[WC.START][WC.T];
		}
		if (witTimePlayhead < userSelection[WC.START][WC.T]) {
			witTimePlayhead = userSelection[WC.END][WC.T];
		}

		cvt.checkWitFrameLoop();

		playheadToXPos();

		statusInterp = 0;
		doMouseLatLon();
	}

	public void playheadToXPos() {
		tivoPlayheadXpos = witTimePlayhead + (int) userTimelineOffset[CURRENT];
	}

	public void playheadFromXPos(int xPos) {
		witTimePlayhead = xPos - (int) userTimelineOffset[CURRENT];

	}


	public void uiWIT() {

		// int scaID=0;



		int scaID = indexSca[userFlight];

		// for (int k=0; k<WC.TOTAL_SCAS; k++){
		// gui animation stuff
		for (int i = 0; i < rasterLayerOpa.length; i++) {
			rasterLayerOpa[i][CURRENT] = rasterLayerOpa[i][GOAL];
		}

		// view animation
		if (Math.abs(userPanOffset[GOAL][WC.X] - userPanOffset[CURRENT][WC.X]) > .01
				|| Math.abs(userPanOffset[GOAL][WC.Y]
				                                - userPanOffset[CURRENT][WC.Y]) > .01) {
			userPanOffset[CURRENT][WC.X] = vaRate * userPanOffset[GOAL][WC.X]
			                                                            + (1.0f - vaRate) * userPanOffset[CURRENT][WC.X];

			userPanOffset[CURRENT][WC.Y] = vaRate * userPanOffset[GOAL][WC.Y]
			                                                            + (1.0f - vaRate) * userPanOffset[CURRENT][WC.Y];

			miniMapInsetPos[CURRENT][WC.X] = (int) (userPanOffset[CURRENT][WC.X] * miniMapScale);
			miniMapInsetPos[CURRENT][WC.Y] = (int) (userPanOffset[CURRENT][WC.Y] * miniMapScale);

			// sync GPU rendering
			if (gpuState == 1) {

			}

			// update the lat/lon overlay
			if (lensMagnifyActive == 1 && witFrameList[userFlight][scaID].size() > 0
					&& dynamicLoadStatus == WC.STATUS_COMPLETE) {
				getMouseOverSCA(cursorX, cursorY);
				statusInterp = 0;
				doMouseLatLon();

			}
		}
		if (userTimelineOffset[GOAL] != userTimelineOffset[CURRENT]) {
			userTimelineOffset[CURRENT] = taRate * userTimelineOffset[GOAL]
			                                                          + (1.0f - taRate) * userTimelineOffset[CURRENT];

			if (dynamicLoadStatus == WC.STATUS_COMPLETE) {
				if (witFrameList[scaID] != null) {
					if (witFrameList[userFlight][scaID].size() > 0) {
						tivoPlayheadXpos = witTimePlayhead
						+ (int) userTimelineOffset[CURRENT];
						// System.out.println("NEW POS "+tivoPlayheadXpos);
					}
				}
			}

		}

		if (userEventFlash > WC.STATUS_OFF){
			if (userEventFlash > 10){
				userEventFlash-=5;
			} else {
				userEventFlash--;
			}

		}
		// }

		tivoSpeedOverlayAlpha = alphaFadeRate * tivoSpeedOverlayAlpha;
		regionHintAlpha = alphaFadeRate * regionHintAlpha;
		playheadToXPos();
	}

	public BufferedImage cutoutBoundaries(float latMin, float latMax,
			float lonMin, float lonMax, float scale) {

		int biW = (int) ((lonMax - lonMin) * scale);
		int biH = (int) ((latMax - latMin) * scale);

		BufferedImage cutoutRegion = new BufferedImage(biW, biH,
				BufferedImage.TYPE_INT_ARGB);

		return cutoutRegion;
	}

	private BufferedImage loadImageBI(String name) {
		// System.out.println("LOAD FILE " + name);
		Image imageRay = Toolkit.getDefaultToolkit().getImage(name);
		MediaTracker mediaTracker = new MediaTracker(new Container());
		mediaTracker.addImage(imageRay, 0);
		try {
			mediaTracker.waitForID(0);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		int width = imageRay.getWidth(null);
		int height = imageRay.getHeight(null);
		System.out.println(width + " X " + height);

		BufferedImage b = null;
		if (width >0 && height > 0){
			b = new BufferedImage(width, height,
					BufferedImage.TYPE_INT_ARGB);
			Graphics2D g = (Graphics2D) b.getGraphics();
			g.drawImage(imageRay, 0, 0, null);
		}

		return b;
	}

	public void determineNorthArrowsMouse(float coord1[], float coord2[]) {

		float degToRadScale = (float) (Math.PI / 180f);
		float lat1rad = coord1[GEODATA_LAT] * degToRadScale;
		float lat2rad = coord2[GEODATA_LAT] * degToRadScale;

		float lon1rad = coord1[GEODATA_LON] * degToRadScale;
		float lon2rad = coord2[GEODATA_LON] * degToRadScale;

		float deltaLatRad = lat2rad - lat1rad;
		float deltaLonRad = lon2rad - lon1rad;

		float deltaLat = coord1[GEODATA_LAT] - coord2[GEODATA_LAT];
		float deltaLon = coord1[GEODATA_LON] - coord2[GEODATA_LON];

		float compY = (float) (Math.sin(deltaLonRad) * Math.cos(lat2rad));
		float compX = (float) (Math.cos(lat1rad) * Math.sin(lat2rad) - Math
				.sin(lat1rad)
				* Math.cos(lat2rad) * Math.cos(deltaLonRad));

		if (deltaLat != 0 && deltaLon != 0 && deltaLat < 180 && deltaLon < 360
				&& coord1[GEODATA_LAT] > -999 && coord2[GEODATA_LAT] > -999
				&& coord1[GEODATA_LON] > -999 && coord2[GEODATA_LON] > -999) {

			float m = (float) Math.atan2(compY, compX);

			compassAngle = m;

			int rastX = 0;
			int rastY = 0;

			float b = (float) rastY - (m * (float) rastX);

			int rastY2 = rastY + 100;
			int rastX2 = (int) (((float) rastY2 - b) / m);

			float vecLength = 64f;

			float dist = rastY2 * rastY2 + rastX2 * rastX2;

			rastY2 = (int) (rastY2 * (vecLength / dist) * 20);
			rastX2 = (int) (rastX2 * (vecLength / dist) * 20);
			// convert to unit vector

			northArrowRasters[WC.START][WC.X] = rastX;
			northArrowRasters[WC.START][WC.Y] = rastY;

			northArrowRasters[WC.END][WC.X] = rastX2;
			northArrowRasters[WC.END][WC.Y] = rastY2;

			compassIsValid = 1;
		} else {
			compassIsValid = 0;
		}

	}

	private void doSystemLoop() {

		if (autoReloadState == 1) {
			autoReloadTime1 = System.currentTimeMillis();
			if (autoReloadTime1 - autoReloadTime2 > autoReloadSeconds*1000) {
				//	if (autoReloadTime1 - autoReloadTime2 > autoReloadSeconds*1000) {
				autoReloadTime2 = autoReloadTime1;

				reloadNewData();
			}
		}

		guiTime1 = System.currentTimeMillis();
		if (guiTime1 - guiTime2 > guiTimeDeltaPlaybackMS) {
			guiTime2 = guiTime1;

			uiWIT();

		}

		bookmarkRefreshInfoTime1 = System.currentTimeMillis();
		if (bookmarkRefreshInfoTime1 - bookmarkRefreshInfoTime2 > bookmarkRefreshInfoTimeDelta) {
			bookmarkRefreshInfoTime2 = bookmarkRefreshInfoTime1;

			copyBookmarksFromWF();

		}

		timelineRefreshInfoTime1 = System.currentTimeMillis();
		if (timelineRefreshInfoTime1 - timelineRefreshInfoTime2 > timelineRefreshInfoTimeDelta) {
			timelineRefreshInfoTime2 = timelineRefreshInfoTime1;

			loaderInfoFramesPrev = loaderInfoFrames;

			loaderInfoFrames = 0;
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				if (witFrameList[userFlight][k] != null) {
					for (int i = 0; i < witFrameList[userFlight][k].size(); i++) {
						WITFrame w = (WITFrame) witFrameList[userFlight][k].get(i);

						if (w.layerStatus[WC.THREAD_PREFILTER] == WC.THREAD_STATUS_COMPLETE) {
							// w.layerStatus[WC.THREAD_PREFILTER] =
							// WC.THREAD_STATUS_COMPLETE
							if (w.bookmarkList.size() > 0) {
								dataLoadInfo[userFlight][k][w.timeStampSecOfDay] = WC.INFO_EVENT;
								loaderInfoFrames++;
							}
						}
					}
				}
			}

			if (Math.abs(loaderInfoFramesPrev - loaderInfoFrames) > 0
					&& timelineImageUpdateFlag == WC.TIMELINE_UPDATE_NONE) {

				timelineImageUpdateFlag = WC.TIMELINE_UPDATE_PROGRESS;
			}
			syncAndForceTimelineRefresh();
		}

		timelineRefreshStatusTime1 = System.currentTimeMillis();
		if (timelineRefreshStatusTime1 - timelineRefreshStatusTime2 > timelineRefreshStatusTimeDelta) {
			timelineRefreshStatusTime2 = timelineRefreshStatusTime1;

			loaderProgressFramesPrev = loaderProgressFrames;
			loaderProgressFrames = 0;
			// tally loaded frames
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				if (witFrameList[userFlight][k] != null) {
					loaderProgressFrames += witFrameList[userFlight][k].size();
				}
			}

			if (Math.abs(loaderProgressFramesPrev - loaderProgressFrames) > 0
					&& timelineImageUpdateFlag == WC.TIMELINE_UPDATE_NONE) {
				timelineImageUpdateFlag = WC.TIMELINE_UPDATE_PROGRESS;
			}
			syncAndForceTimelineRefresh();
		}

		playheadTime1 = System.currentTimeMillis();
		if (playheadTime1 - playheadTime2 > playheadTimeDelta) {
			playheadTime2 = playheadTime1;

			if (systemState == WC.SYSTEM_STATE_ONLINE
					&& dynamicLoadStatus != WC.STATUS_WORKING) {
				// && dynamicLoadStatus != WC.STATUS_WORKING && cvt != null) {

				if (playheadDir != 0) {
					animatePlayback();
				}

				// determineNorthArrows();

				mouseOverSCA = getMouseOverSCA(cursorX, cursorY);

				statusInterp = 0;
				doMouseLatLon();

			}
		}

		if (systemState == WC.SYSTEM_STATE_ONLINE) {
			processTime1 = System.currentTimeMillis();

			if (processTime1 - processTime2 > processTimeMS) {
				processTime2 = processTime1;

				processWIT();
			}
		}

		time1 = System.currentTimeMillis();

		if (time1 - time2 > timeDeltaPlaybackMS && drawCyclePaused == 0) {
			time2 = time1;

			if ((uiState == WC.UI_STATE_VIEW && graphicsStatus == WC.STATUS_READY)
					|| uiState == WC.UI_STATE_CONTRAST) {

				drawWIT();
			} else if (uiState == WC.UI_STATE_SCA_SELECT
					&& graphicsStatus == WC.STATUS_READY) {
				drawWIT();
				drawSCAselector();
			}

			drawFinalScreen();

			// }
		}
	}

	public String formatIDtoName(int id) {
		String idStr = "[UNKNOWN FORMAT]";

		int FORMAT_MPG = 0;
		int FORMAT_MP4 = 1;
		int FORMAT_MP4_H264 = 2;
		int FORMAT_WMV = 3;
		int FORMAT_PNG = 10;
		int FORMAT_JPG = 11;
		int FORMAT_GEOTIFF = 12;
		if (id == FORMAT_PNG) {
			idStr = "FORMAT_PNG";
		} else if (id == FORMAT_JPG) {
			idStr = "FORMAT_JPG";
		} else if (id == FORMAT_MPG) {
			idStr = "FORMAT_MPG";
		} else if (id == FORMAT_MP4) {
			idStr = "FORMAT_MP4";
		} else if (id == FORMAT_MP4_H264) {
			idStr = "FORMAT_MP4_H264";
		} else if (id == FORMAT_WMV) {
			idStr = "FORMAT_WMV";
		} else if (id == FORMAT_GEOTIFF) {
			idStr = "FORMAT_GEOTIFF";
		}

		return idStr;
	}

	public String opIDtoName(int op) {
		String opStr = "[UNKNOWN OP]";

		if (op == WC.THREAD_LOAD) {
			opStr = "LOAD DATA";
		} else if (op == WC.THREAD_LOAD_HDF5R) {

			opStr = "LOAD DATA";
		} else if (op == WC.THREAD_LOAD_GEOLOCATION) {

			opStr = "LOAD GEOLOCATION";
		} else if (op == WC.THREAD_FIX_GEOLOCATION) {

			opStr = "INTERPOLATE GEOLOC";
		} else if (op == WC.THREAD_HISTOGRAM) {

			opStr = "HISTOGRAM";
		} else if (op == WC.THREAD_CONTRAST) {

			if (contrastMode == CONTRAST_AUTO) {
				opStr = "CONTRAST - AUTO";
			} else if (contrastMode == CONTRAST_WINDOW) {
				opStr = "CONTRAST - AUTO (REGION)";
			} else if (contrastMode == CONTRAST_USER) {
				opStr = "CONTRAST";
			}

			// opStr = "CONTRAST - MANUAL";
		} else if (op == WC.THREAD_DIFF) {

			opStr = "DIFFS";
		} else if (op == WC.THREAD_TIMELAPSE) {

			opStr = "TIMELAPSE";
		} else if (op == WC.THREAD_TEMPORAL) {

			opStr = "TEMPORAL1";
		} else if (op == WC.THREAD_EXPORT_VIDEO) {

			// opStr = "EXPORT VIDEO";
			opStr = "EXPORT";
		} else if (op == WC.THREAD_EXPORT_WEATHER_VIDEO) {

			// opStr = "EXPORT VIDEO";
			opStr = "EXPORT";
		} else if (op == WC.THREAD_EXPORT_IMAGES) {

			// opStr = "EXPORT IMAGES";
			opStr = "EXPORT";
		} else if (op == WC.THREAD_LOAD_METADATA) {

			opStr = "LOAD METADATA";
		} else if (op == WC.THREAD_DEJITTER_ADV) {

			opStr = "DEJITTER";
		} else if (op == WC.THREAD_PREFILTER) {

			opStr = "PREFILTER";
		} else if (op == WC.THREAD_REGISTRATION) {

			opStr = "REGISTER BOUNDARIES";
		}

		return opStr;
	}

	public void resetDejitterPlayback() {
		dejitterPlaybackX = 0;
		dejitterPlaybackY = 0;
	}


	public void checkPlayheadXposLoopBounds(int boundMode) {

		if (tivoPlayheadXpos >= WC.SEC_IN_DAY) {
			tivoPlayheadXpos = WC.SEC_IN_DAY - 1;

		}
		if (tivoPlayheadXpos < 0) {
			tivoPlayheadXpos = 0;

		}

	}

	public int checkNeedForThread(ArrayList wfl, int a, int b, int mode) {
		int need = -1;
		int scaID = -1;
		for (int i = a; i < b; i++) {
			if (wfl.size() > i) {
				WITFrame wfi = (WITFrame) wfl.get(i);

				if (wfi.timeStampSecOfDay > userSelection[WC.START][WC.T]
				                                                    && wfi.timeStampSecOfDay < userSelection[WC.END][WC.T]) {
					scaID = wfi.scaID;

					if (wfi.layerStatus[mode] == WC.STATUS_READY) {
						need = 1;
						i = b; // break
					} else if (mode == WC.THREAD_HISTOGRAM) {
						// System.out.println("STATE HIST LAYER "+wfi.layerStatus[mode]);
					}
				}
			}
		}

		if (need != -1) {

			StringBuilder strBdr = new StringBuilder();
			strBdr.append("THREAD REQUESTED FOR SCA ");
			strBdr.append(scaID);
			strBdr.append(" - FRAMES: ");
			strBdr.append(a);
			strBdr.append("-");
			strBdr.append(b);
			strBdr.append(" - TIME: ");
			strBdr
			.append(secondsOfDayToReadable(userSelection[WC.START][WC.T]));
			strBdr.append("-");
			strBdr.append(secondsOfDayToReadable(userSelection[WC.END][WC.T]));
			strBdr.append(" - MODE: ");
			strBdr.append(opIDtoName(mode));
			System.out.println(strBdr);

		} else {
			// System.out.println("THREAD REQUEST DECLINED");
		}
		return need;
	}

	public static Composite makeComposite(float a) {
		Composite c = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, a);

		return c;

	}

	public void resetThreads() {
		for (int i = 0; i < MAX_THREADS_QUEUED; i++) {
			// imprRay[i].interrupt();
			try {
				imprRay[i] = null;
			} catch (Exception e) {
				e.printStackTrace();
			}

			imprRay[i] = new ImProcThread("WC.THREAD_IDLE", WC.THREAD_IDLE,
					witFrameList[userFlight][0], 0, 0, null);
			imprRay[i].threadStatus = WC.THREAD_STATUS_READY;

			// threadAllocations[i] = 0;
		}
	}

	public void restartSystem() {
		systemState = WC.SYSTEM_STATE_OFFLINE;

		resetThreads();

		systemState = WC.SYSTEM_STATE_ONLINE;

	}

	public void pauseSystem() {

		if (pauseFlag == PAUSED) {
			pauseFlag = UNPAUSED;
			systemPlaybackRate = systemPlaybackRatePause;
			// systemPlaybackRate = SYSTEM_PLAYBACK_RATE_PAUSE;
		} else if (pauseFlag == UNPAUSED) {
			pauseFlag = PAUSED;
			systemPlaybackRatePause = systemPlaybackRate;
			systemPlaybackRate = SYSTEM_PLAYBACK_RATE_PAUSE;
		}

		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
	}

	public void clearContrastSelection() {

	}

	public void checkContrastSelection() {

		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
	}

	public void swapThreadSchemes() {
		if (systemState == WC.THREAD_SCHEME_BATCH) {
			systemState = WC.THREAD_SCHEME_PLAYHEAD;

			System.out.println("WC.THREAD_SCHEME_PLAYHEAD");
		} else {
			systemState = WC.THREAD_SCHEME_BATCH;

			System.out.println("WC.THREAD_SCHEME_BATCH");
		}
	}

	public void checkWitFrameLoop() {

		// int scaID=0;

		int scaID = indexSca[userFlight];

		if (witTimePlayhead < minSeconds)
			witTimePlayhead = maxSeconds;
		if (witTimePlayhead > maxSeconds)
			witTimePlayhead = minSeconds;

	}

	public void tivoStepPlaybackSpeed(int speedChange) {
		if (speedChange == 1) {

			if (SYSTEM_PLAYBACK_RATE_R16X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 8;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 8X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R8X;
			} else if (SYSTEM_PLAYBACK_RATE_R8X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 4;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 4X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R4X;
			} else if (SYSTEM_PLAYBACK_RATE_R4X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 2;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 2X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R2X;
			} else if (SYSTEM_PLAYBACK_RATE_R2X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 1X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R1X;
			} else if (SYSTEM_PLAYBACK_RATE_R1X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed;
				playheadDir = 0;
				userInterfaceInfoStr = "PAUSED";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_PAUSE;
			} else if (SYSTEM_PLAYBACK_RATE_PAUSE == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 1X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F1X;
			} else if (SYSTEM_PLAYBACK_RATE_F1X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 2;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 2X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F2X;
			} else if (SYSTEM_PLAYBACK_RATE_F2X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 4;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 4X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F4X;
			} else if (SYSTEM_PLAYBACK_RATE_F4X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 8;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 8X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F8X;
			} else if (SYSTEM_PLAYBACK_RATE_F8X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 16;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 16X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F16X;
			} else if (SYSTEM_PLAYBACK_RATE_F16X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 16;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 16X (MAX)";
			}
		} else if (speedChange == -1) {
			if (SYSTEM_PLAYBACK_RATE_R16X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 16;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 16X (MAX)";
			} else if (SYSTEM_PLAYBACK_RATE_R8X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 16;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 16X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R16X;
			} else if (SYSTEM_PLAYBACK_RATE_R4X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 8;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 8X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R8X;
			} else if (SYSTEM_PLAYBACK_RATE_R2X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 4;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 4X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R4X;
			} else if (SYSTEM_PLAYBACK_RATE_R1X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 2;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 2X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R2X;
			} else if (SYSTEM_PLAYBACK_RATE_PAUSE == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed;
				playheadDir = -1;
				userInterfaceInfoStr = "REV 1X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_R1X;
			} else if (SYSTEM_PLAYBACK_RATE_F1X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed;
				playheadDir = 0;
				userInterfaceInfoStr = "PAUSED";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_PAUSE;
			} else if (SYSTEM_PLAYBACK_RATE_F2X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 1X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F1X;
			} else if (SYSTEM_PLAYBACK_RATE_F4X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 2;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 2X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F2X;
			} else if (SYSTEM_PLAYBACK_RATE_F8X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 4;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 4X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F4X;
			} else if (SYSTEM_PLAYBACK_RATE_F16X == systemPlaybackRate) {
				playheadTimeDelta = basePlaybackSpeed / 8;
				playheadDir = 1;
				userInterfaceInfoStr = "FWD 8X";
				systemPlaybackRate = SYSTEM_PLAYBACK_RATE_F8X;
			}

		}

		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;

		if (systemPlaybackRate == SYSTEM_PLAYBACK_RATE_PAUSE) {
			// playbackPaused = 1;
		} else {
			// playbackPaused = 0;
		}
	}

	public void showKeyboardHelp() {

	}

	public void showFilterPriorities() {

	}

	public void showWebHelp() {

		String commandStr = webHelpLocation;

		Runtime rt = Runtime.getRuntime();
		Process p = null;

		// InputStream is = new InputStream();
		try {
			p = rt.exec(commandStr);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void doPlaybackPause() {
		if (playheadDir == 0) {
			playheadDir = playheadDirPrev;
			playbackPaused = 0;
			//userInterfaceInfoStr = "UNPAUSED";
		} else {
			playheadDirPrev = playheadDir;
			playheadDir = 0;
			playbackPaused = 1;
			//userInterfaceInfoStr = "PAUSED";
		}
	}

	public void keyPressed(KeyEvent e) {

		float globeNudgeAmount = .01f;

		if (e.getKeyCode() == KeyEvent.VK_F1) {
			setLoadFrames(10, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F2) {
			setLoadFrames(60, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F3) {
			setLoadFrames(120, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F4) {
			setLoadFrames(180, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F5) {
			setLoadFrames(300, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F6) {
			setLoadFrames(600, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F7) {
			setLoadFrames(900, 1, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F8) {
			setLoadFrames(1200, 30, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F9) {
			setLoadFrames(1800, 30, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F10) {
			setLoadFrames(3600, 120, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F11) {
			setLoadFrames(7200, 120, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_F12) {
			setLoadFrames(14400, 300, -1);
		} else if (e.getKeyCode() == KeyEvent.VK_D) {
			if (e.isShiftDown() == true){
				userPanOffset[GOAL][WC.X] += WASD_speed_fast;
			} else {
				userPanOffset[GOAL][WC.X] += WASD_speed;
			}

			checkPanBounds();
		} else if (e.getKeyCode() == KeyEvent.VK_A) {
			if (e.isShiftDown() == true){
				userPanOffset[GOAL][WC.X] -= WASD_speed_fast;
			} else {
				userPanOffset[GOAL][WC.X] -= WASD_speed;
			}

			checkPanBounds();
		} else if (e.getKeyCode() == KeyEvent.VK_W) {
			if (e.isShiftDown() == true){
				userPanOffset[GOAL][WC.Y] -= WASD_speed_fast;
			} else {

				userPanOffset[GOAL][WC.Y] -= WASD_speed;
			}

			checkPanBounds();
		} else if (e.getKeyCode() == KeyEvent.VK_S) {
			if (e.isShiftDown() == true){
				userPanOffset[GOAL][WC.Y] += WASD_speed_fast;
			} else{	
				userPanOffset[GOAL][WC.Y] += WASD_speed;
			}

			checkPanBounds();
		} else if (e.getKeyCode() == KeyEvent.VK_Q) {

		} else if (e.getKeyCode() == KeyEvent.VK_E) {

		} else if (e.getKeyCode() == KeyEvent.VK_SPACE) {

			if (e.isShiftDown()) {

			} else {

				doPlaybackPause();
			}

		} else if (e.getKeyCode() == KeyEvent.VK_PLUS) {

			// panViewX(1);
		} else if (e.getKeyCode() == KeyEvent.VK_MINUS) {
			// userXoffset[GOAL]-= 100f;
			// panViewX(-1);
		} else if (e.getKeyCode() == KeyEvent.VK_K) {
			// userXoffset[GOAL]-= 100f;
			// panViewX(-1);

			if (e.isShiftDown()){
				createCotMessageStr();
				xeui.glsleui.glslText.setText(cotPolyMessageStr);
				xeui.cvt = cvt;
				xeui.setTitle("POLYGON CoT");
				xeui.showGLSLEditor();
			} else {
				createKmlMessageStr();
				xeui.glsleui.glslText.setText(kmlPolyMessageStr);
				xeui.cvt = cvt;
				xeui.setTitle("POLYGON KML");
				xeui.showGLSLEditor();
			}

		} else if (e.getKeyCode() == KeyEvent.VK_G) {
			//changeCoordinateMode();
		} else if (e.getKeyCode() == KeyEvent.VK_1) {
			if (e.isShiftDown() == true) {
				// determine majority on / off
				int activeScaCount = 0;
				int activeFlight = 0;
				for (int j = 0; j < WC.TOTAL_SCAS; j++) {
					if (scaLoadMask[activeFlight][j] == 1) {
						activeScaCount++;
					}
				}

				if (activeScaCount >= 3) {
					for (int j = 0; j < WC.TOTAL_SCAS; j++) {
						scaLoadMask[activeFlight][j] = 0;
					}
				} else {
					for (int j = 0; j < WC.TOTAL_SCAS; j++) {
						scaLoadMask[activeFlight][j] = 1;
					}
				}
			} else {

				int scaID = 0;
				scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;

			}
		} else if (e.getKeyCode() == KeyEvent.VK_2) {
			if (e.isShiftDown() == true) {
				int activeScaCount = 0;
				int activeFlight = 1;
				for (int j = 0; j < WC.TOTAL_SCAS; j++) {
					if (scaLoadMask[activeFlight][j] == 1) {
						activeScaCount++;
					}
				}

				if (activeScaCount >= 3) {
					for (int j = 0; j < WC.TOTAL_SCAS; j++) {
						scaLoadMask[activeFlight][j] = 0;
					}
				} else {
					for (int j = 0; j < WC.TOTAL_SCAS; j++) {
						scaLoadMask[activeFlight][j] = 1;
					}
				}
			} else {

				int scaID = 1;
				scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;

			}
		} else if (e.getKeyCode() == KeyEvent.VK_3) {
			int scaID = 2;
			scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;


		} else if (e.getKeyCode() == KeyEvent.VK_4) {
			int scaID = 3;
			scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;


		} else if (e.getKeyCode() == KeyEvent.VK_5) {
			int scaID = 4;
			scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;


		} else if (e.getKeyCode() == KeyEvent.VK_6) {
			int scaID = 5;
			scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;


		} else if (e.getKeyCode() == KeyEvent.VK_7) {
			int scaID = 6;
			scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;


		} else if (e.getKeyCode() == KeyEvent.VK_8) {
			int scaID = 7;
			scaLoadMask[userFlight][scaID] = (scaLoadMask[userFlight][scaID] + 1) % 2;


		} else if (e.getKeyCode() == KeyEvent.VK_Y) {



		} else if (e.getKeyCode() == KeyEvent.VK_Z) {
			// undo
			if (e.isShiftDown() == true) {

			} else {

			}
		} else if (e.getKeyCode() == KeyEvent.VK_X) { // toggle scan seq

			if (e.isShiftDown() == true) {

				for (int i = 0; i < WC.SCAN_SEQ_INDEX_MAX_VAL; i++) {
					playbackScanSeqIndexMask[userFlight][i] = WC.STATUS_ON;
				}
				userInterfaceInfoStr = "LOAD/PLAY ALL SCAN SEQS";
			} else if (e.isControlDown() == true) {
				int seqIndex = playbackScanSeqIndexPrev[userFlight];


				for (int i = 0; i < WC.SCAN_SEQ_INDEX_MAX_VAL; i++) {
					playbackScanSeqIndexMask[userFlight][i] = WC.STATUS_OFF;
				}

				playbackScanSeqIndexMask[userFlight][seqIndex] = 1;
				userInterfaceInfoStr = "LOAD/PLAY ONLY CURRENT SCAN SEQ";
			} else {
				int seqIndex = playbackScanSeqIndexPrev[userFlight];
				if (seqIndex != WC.STATUS_ERROR) {
					if (playbackScanSeqIndexMask[userFlight][seqIndex] == 0) {
						playbackScanSeqIndexMask[userFlight][seqIndex] = 1;
					} else {
						playbackScanSeqIndexMask[userFlight][seqIndex] = 0;
					}
					userInterfaceInfoStr = "TOGGLE LOAD/PLAY SCAN SEQ "
						+ seqIndex;
				}
			}
		} else if (e.getKeyCode() == KeyEvent.VK_LEFT) { // toggle scan seq

			if (e.isShiftDown() == true) {
				if (e.isControlDown()) {

				} else {
					panTime(1);
				}
			} else {
				witFrameListStep(-1, playbackStepSeconds);

				syncDrawSegments();
			}
		} else if (e.getKeyCode() == KeyEvent.VK_RIGHT) { // toggle scan seq

			if (e.isShiftDown() == true) {
				if (e.isControlDown()) {

				} else {
					panTime(-1);
				}
			} else {
				witFrameListStep(1, playbackStepSeconds);

				syncDrawSegments();
			}
		} else if (e.getKeyCode() == KeyEvent.VK_UP) { // toggle scan seq

			if (e.isShiftDown() == true) {
				panTime(0);
			} else {
				tivoStepPlaybackSeconds(1);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_DOWN) { // toggle scan seq

			if (e.isShiftDown() == true) {
				panTime(0);
			} else {
				tivoStepPlaybackSeconds(-1);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_L) { // toggle scan seq

			if (e.isShiftDown() == true) {
				lockPlayhead = (lockPlayhead + 1) % 2;
			} else {
				playheadDir *= -1;
			}
		} else if (e.getKeyCode() == KeyEvent.VK_COMMA) { // toggle scan seq

			if (e.isShiftDown() == true) {

			} else {
				resetLastDrawIndex();
				setPlaybackScanMode(SCAN_DIR_EVEN);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_PERIOD) { // toggle scan seq

			if (e.isShiftDown() == true) {

			} else {
				resetLastDrawIndex();
				setPlaybackScanMode(SCAN_DIR_ODD);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_J) { // jump

			if (e.isShiftDown() == true) {
				// uiLoadDelay = WC.UI_LOAD_DELAY;
				int scaID = 0;

				int loadJumpOffset = 0;
				if (loadTriggerState == WC.STATUS_ON) {
					loadJumpOffset = jumpLoadStart;
				}

				int loadDistance = loadSeconds;
				int timeJump = maxSeconds;
				int jumpDistance = -2 * loadDistance;

				jumpLoadStart = loadJumpOffset + timeJump + jumpDistance;
				jumpLoadDistance = loadDistance;

				uiLoadTriggerTimer = WC.UI_LOAD_TRIGGER_TIMER;
				dynamicLoad3(timeJump + jumpDistance, loadDistance, 0,
						skipSeconds);

				// loadTriggerState = WC.STATUS_ON;

			} else if (e.isControlDown() == true) {
				// reload
				int scaID = 0;

				int loadJumpOffset = 0;
				if (loadTriggerState == WC.STATUS_ON) {
					loadJumpOffset = jumpLoadStart;
				}

				uiLoadTriggerTimer = WC.UI_LOAD_TRIGGER_TIMER;
				//
				int loadDistance = userSelection[WC.END][WC.T]
				                                         - userSelection[WC.START][WC.T];
				dynamicLoad3(userSelection[WC.START][WC.T], loadDistance, 0,
						skipSeconds);

			} else {
				int scaID = 0;

				int loadJumpOffset = 0;
				if (loadTriggerState == WC.STATUS_ON) {
					loadJumpOffset = jumpLoadStart;
				}

				int jumpDistance = 1;
				int loadDistance = loadSeconds;
				int timeJump = maxSeconds;

				jumpLoadStart = loadJumpOffset + timeJump + jumpDistance;
				jumpLoadDistance = loadDistance;
				dynamicLoad3(timeJump + jumpDistance, loadDistance, 0,
						skipSeconds);

				uiLoadTriggerTimer = WC.UI_LOAD_TRIGGER_TIMER;

				// loadTriggerState = WC.STATUS_ON;
			}
		} else if (e.getKeyCode() == KeyEvent.VK_F) {

			if (e.isShiftDown() == true) {

			} else {
				toggleFlight();

			}
		} else if (e.getKeyCode() == KeyEvent.VK_C) {
			if (e.isShiftDown() == true) {

			} else {
				handleContrastModeChange(CONTRAST_USER);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_T) {
			if (e.isShiftDown() == true) {

				toggleOpMask(WC.THREAD_TIMELAPSE);

			} else {
				toggleOpMask(WC.THREAD_DIFF);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_R) {

			//toggleOpMask(WC.THREAD_REGISTRATION);

		} else if (e.getKeyCode() == KeyEvent.VK_B) {
			if (e.isShiftDown() == true) {
				toggleOpMask(WC.THREAD_GPU_FRAG_BURNIN);
			} else {
				toggleOpMask(WC.THREAD_GPU_FRAG_TIMELAPSE);
			}
		} else if (e.getKeyCode() == KeyEvent.VK_M) {
			if (e.isShiftDown() == true) {

			} else {
				toggleLensM();
			}
		} else if (e.getKeyCode() == KeyEvent.VK_V) {
			if (e.isShiftDown() == true) {
				if (e.isControlDown() == true){ // make WIT demo videos

				}
			} else {
				exportVideo(".mpg");

			}
		} else if (e.getKeyCode() == KeyEvent.VK_H) {
			if (e.isShiftDown() == true) {

			} else {
				toggleOpMask(WC.THREAD_HISTOGRAM);
				toggleWidgetVisibility(WC.WIDGET_HISTOGRAM);

			}
		} else if (e.getKeyCode() == KeyEvent.VK_O){
			openFiles();
		}

	}


	public void tivoStepPlaybackSeconds(int speedChange) {
		float prevSpeed = playbackStepSeconds;
		if (speedChange == 1) {
			playbackStepSeconds *= 2;
		} else if (speedChange == -1) {
			playbackStepSeconds /= 2;
		}

		if (playbackStepSeconds < WC.SKIP_SECONDS_PLAYBACK_MIN) {
			playbackStepSeconds = WC.SKIP_SECONDS_PLAYBACK_MIN;
		}
		if (playbackStepSeconds > WC.SKIP_SECONDS_PLAYBACK_MAX) {
			playbackStepSeconds = WC.SKIP_SECONDS_PLAYBACK_MAX;
		}

		if (playbackStepSeconds > loadSeconds / 2) {
			playbackStepSeconds = prevSpeed;
		}

		userInterfaceInfoStr = "PLAYBACK INTERVAL " + playbackStepSeconds
		+ " SECONDS";
	}


	public void witFrameListStep(int dir, float secs) {

		if (dir > 0) {
			witTimePlayheadFloat += secs;// skipSeconds;

		} else if (dir < 0) {
			witTimePlayheadFloat -= secs;// skipSeconds;
		}

		if (witTimePlayheadFloat > userSelection[WC.END][WC.T]) {
			witTimePlayheadFloat = userSelection[WC.START][WC.T];


		}
		if (witTimePlayheadFloat < userSelection[WC.START][WC.T]) {
			witTimePlayheadFloat = userSelection[WC.END][WC.T];
		}

		cvt.checkWitFrameLoop();

		witTimePlayhead = (int) Math.floor(witTimePlayheadFloat);

		witTimePlayheadTimestampStr = secondsOfDayToReadableF(witTimePlayheadFloat);
		witTimePlayheadTimestampOutputStr = witTimePlayheadTimestampStr + "Z";

		playheadToXPos();

		if (lockPlayhead == 1 && playbackPaused == 0
				&& dataState == WC.STATUS_COMPLETE && witTimePlayhead != 0) {
			userTimelineOffset[CURRENT] = -witTimePlayhead+100;
			userTimelineOffset[GOAL] = -witTimePlayhead+100;
		}

	}



	public void tivoExit() {
		// if (saveStateMode == ){
		saveState(SAVE_STATE_ON_EXIT);
		// }
		System.exit(0);
	}

	public void toggleLoopMode() {

		if (selectionStatus == SELECTION_COMPLETE) {
			if (loopMode == LOOP_MODE_ALL) {
				loopMode = LOOP_MODE_SELECTION;
			} else {

				loopMode = LOOP_MODE_ALL;
			}
		}
	}

	public void clearSelection() {

		// selectionStatus = SELECTION_READY;
		loopMode = LOOP_MODE_ALL;
	}

	public void allSelection() {

		// int scaID=0;

		int scaID = indexSca[userFlight];

		if (witFrameList[userFlight][scaID].size() > 0) {
			WITFrame wfa = (WITFrame) witFrameList[userFlight][scaID].get(0);
			userSelection[WC.START][WC.T] = 0;// 0+witFrameLoadStartSec;
			userSelection[WC.END][WC.T] = witFrameList[userFlight][scaID].size() - 1;// witFrameList.size();//frameCount-1;

			userSelection[WC.START][T_SECS] = ((WITFrame) witFrameList[userFlight][scaID]
			                                                                       .get(userSelection[WC.START][WC.T])).timeStampSecOfDay;
			userSelection[WC.END][T_SECS] = ((WITFrame) witFrameList[userFlight][scaID]
			                                                                     .get(userSelection[WC.END][WC.T])).timeStampSecOfDay;

			userSelection[WC.START][WC.X] = 0;
			userSelection[WC.END][WC.X] = wfa.biRay[WC.THREAD_LOAD_HDF5R]
			                                        .getWidth();
			userSelection[WC.START][WC.Y] = 0;
			userSelection[WC.END][WC.Y] = wfa.biRay[WC.THREAD_LOAD_HDF5R]
			                                        .getHeight();

			userSelectionArea = (Math.abs(userSelection[WC.START][WC.X]
			                                                      - userSelection[WC.END][WC.X]))
			                                                      * (Math.abs(userSelection[WC.START][WC.Y]
			                                                                                          - userSelection[WC.END][WC.Y]));

			selectionStatus = SELECTION_COMPLETE;
			loopMode = LOOP_MODE_SELECTION;
		}
	}

	// get additional data for the timeline
	public void setInputAppend() {

	}

	public void setAutoReload(int toggle, int freqHint){

		if (freqHint != -1){
			autoReloadSeconds = freqHint;
			userInterfaceInfoStr = "AUTO-RELOAD EVERY "+freqHint+" SECONDS";
		}

		if (toggle != -1){
			autoReloadState = toggle;
			userInterfaceInfoStr = "AUTO-RELOAD TOGGLED ";
		}
	}

	public void setLoadFrames(int loadHint, int skipHint, int burstHint) {

		// check bounds

		if (loadHint != -1){
			if (loadHint > MAX_LOAD_SECONDS){
				loadHint = (int)MAX_LOAD_SECONDS;
			}

			if (loadHint < MIN_LOAD_SECONDS){
				loadHint = (int)MIN_LOAD_SECONDS;
			}
		}

		if (skipHint != -1){
			if (skipHint > MAX_SKIP_SECONDS){
				skipHint = (int)MAX_SKIP_SECONDS;
			}

			if (skipHint < MIN_SKIP_SECONDS){
				skipHint = (int)MIN_SKIP_SECONDS;
			}
		}

		if (burstHint != -1){
			if (burstHint > MAX_BURST_SECONDS){
				burstHint = (int)MAX_BURST_SECONDS;
			}

			if (burstHint < MIN_BURST_SECONDS){
				burstHint = (int)MIN_BURST_SECONDS;
			}
		}

		// end check bounds

		if (burstHint != -1){

			burstSeconds = burstHint;

		}

		if (loadHint != -1){

			loadSeconds = loadHint;

		}

		if (skipHint != -1){


			skipSeconds = skipHint;


		}

		String loadTimeUnitStr = "SEC";
		int displayLoadUnits = loadSeconds;

		String skipTimeUnitStr = "SEC";
		int displaySkipUnits = skipHint;

		String burstTimeUnitStr = "SEC";
		int displayBurstUnits = burstHint;



		if (loadHint >= 60 && loadHint < 3600) {
			displayLoadUnits = loadHint / 60;
			if (displayLoadUnits == 1) {
				loadTimeUnitStr = "MIN";
			} else {
				loadTimeUnitStr = "MIN";
			}
		} else if (loadHint >= 3600) {
			displayLoadUnits = loadHint / 3600;
			if (displayLoadUnits == 1) {
				loadTimeUnitStr = "HR";
			} else {
				loadTimeUnitStr = "HR";
			}
		}

		if (skipHint >= 60 && skipHint < 3600) {
			displaySkipUnits = skipHint / 60;

			if (displaySkipUnits == 1) {
				skipTimeUnitStr = "MIN";
			} else {
				skipTimeUnitStr = "MIN";
			}

		} else if (skipHint >= 3600) {
			displaySkipUnits = skipHint / 3600;
			if (displaySkipUnits == 1) {
				skipTimeUnitStr = "HR";
			} else {
				skipTimeUnitStr = "HR";
			}
		}

		if (burstHint >= 60 && burstHint < 3600) {
			displayBurstUnits = burstHint / 60;

			if (displayBurstUnits == 1) {
				burstTimeUnitStr = "MIN";
			} else {
				burstTimeUnitStr = "MIN";
			}

		} else if (burstHint >= 3600) {
			displayBurstUnits = burstHint / 3600;
			if (displayBurstUnits == 1) {
				burstTimeUnitStr = "HR";
			} else {
				burstTimeUnitStr = "HR";
			}
		}

		if (skipHint != -1) {
			skipSeconds = skipHint;
		}

		StringBuilder strBdr = new StringBuilder();
		strBdr.append("LOAD BUFFER CHANGED - ");
		strBdr.append(displayLoadUnits);
		strBdr.append(" ");
		strBdr.append(loadTimeUnitStr);
		strBdr.append(" ... SKIPPING ");
		strBdr.append(displaySkipUnits);
		strBdr.append(" ");
		strBdr.append(skipTimeUnitStr);
		userInterfaceInfoStr = strBdr.toString();


		if (loadHint != -1){
			loadWindowStr = displayLoadUnits + " " + loadTimeUnitStr;
		}

		if (skipHint != -1){
			loadSkipStr = displaySkipUnits + " " + skipTimeUnitStr;
		}

		if (burstHint != -1){
			loadBurstStr = displayBurstUnits + " "+burstTimeUnitStr;
		}
		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
	}

	public void setLoadSkipShortScans() {

	}

	public void setLoadSkipOverscans() {

	}

	public void setLoadSkipSeconds(int skipHint) {
		skipSeconds = skipHint;

		int displaySkipUnits = skipHint;

		String skipTimeUnitStr = "";

		if (displaySkipUnits == 1) {
			skipTimeUnitStr = "SECOND";
		} else {
			skipTimeUnitStr = "SECONDS";
		}

		if (skipHint >= 60 && skipHint < 3600) {
			displaySkipUnits = skipHint / 60;

			if (displaySkipUnits == 1) {
				skipTimeUnitStr = "MINUTE";
			} else {
				skipTimeUnitStr = "MINUTES";
			}

		} else if (skipHint >= 3600) {
			displaySkipUnits = skipHint / 3600;
			if (displaySkipUnits == 1) {
				skipTimeUnitStr = "HOUR";
			} else {
				skipTimeUnitStr = "HOURS";
			}
		}

		StringBuilder strBdr = new StringBuilder();
		strBdr.append("LOAD SKIP CHANGED - ");
		strBdr.append(displaySkipUnits);
		strBdr.append(" ");
		strBdr.append(skipTimeUnitStr);
		userInterfaceInfoStr = strBdr.toString();

		tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
	}

	public void openFilesNewest(){

		initTimeline();
		initTimelineRefs();

		loadMetadataExplicitFileList();

		findDataChunks();

		BookmarkEvent be = (BookmarkEvent) bookmarkList.get(0);
		userFlight = be.satID;

		// checkTimelineOffet();
		timelineImageUpdateFlag = WC.TIMELINE_UPDATE_ALL;

	}

	public void openFiles() {
		initTimeline();
		initTimelineRefs();

		loadMetadataExplicitFileList();

		findDataChunks();

		BookmarkEvent be = (BookmarkEvent) bookmarkList.get(0);
		userFlight = be.satID;

		// checkTimelineOffet();
		timelineImageUpdateFlag = WC.TIMELINE_UPDATE_ALL;


	}

	public void setInputSource() {

		systemState = WC.SYSTEM_STATE_OFFLINE;

		resetThreads();

		systemState = WC.SYSTEM_STATE_ONLINE;

	}

	public void exportImageSeq(String ext) {

		int[] channels = getVideoExportSelection();

		// setupVideoExportUI(ext);

		channels[WC.THREAD_LOAD_HDF5R] = 1;
		channels[WC.THREAD_DIFF] = 1;
		channels[WC.THREAD_CONTRAST] = 1;
		channels[WC.THREAD_TIMELAPSE] = 1;

		startImageExport(ext, channels, 0);
	}

	public void exportMarkedImageSeq(String ext) {
		int[] channels = getVideoExportSelection();

		// setupVideoExportUI(ext);

		channels[WC.THREAD_LOAD_HDF5R] = 1;
		channels[WC.THREAD_DIFF] = 1;
		channels[WC.THREAD_CONTRAST] = 1;
		channels[WC.THREAD_TIMELAPSE] = 1;

		startImageExport(ext, channels, 1);
	}

	public void exportWeatherImageSeq(String ext) {
		int[] channels = getVideoExportSelection();

		int[][] bounds = new int[2][2];

		// setupVideoExportUI(ext);

		channels[WC.THREAD_LOAD_HDF5R] = 1;
		channels[WC.THREAD_DIFF] = 0;
		channels[WC.THREAD_CONTRAST] = 1;
		channels[WC.THREAD_TIMELAPSE] = 0;

		bounds[WC.START][GEODATA_LON] = -180;
		bounds[WC.END][GEODATA_LON] = 180;
		bounds[WC.START][GEODATA_LAT] = -90;
		bounds[WC.END][GEODATA_LAT] = 90;

		float scale = 13;

		startImageExportProj(ext, channels, 0, bounds, scale, 1);
	}

	
	public void setVideoExportMagnification(int magScale) {
		userVideoMagnification = magScale;
	}

	public void exportVideo(String ext) {
		// start the export
		vidExportUI.cvt = cvt;
		vidExportUI.showVideoExport();
	}

	public void exportVideoUI() {
		System.out.println("STARTING VID EXPORT");

		startVideoExport(outputFormatMask, outputModeMask, scanExportMode);
		// /vidExportUI.inputStatus = WC.STATUS_READY;

	}

	public void polyPointsAddCurrent(){
		if (poly == null){
			poly = new WxPoly();
		}

		if (poly.polyPoints == null){
			poly.polyPoints = new ArrayList();			
		}

		poly.polyColor[WC.R] = 0;
		poly.polyColor[WC.G] = 1;
		poly.polyColor[WC.B] = 0;

		WxPolyPoint wxpp = new WxPolyPoint();
		wxpp.rasterX = cursorX - (int)userPanOffset[WC.CURRENT][WC.X];
		wxpp.rasterY = cursorY - (int)userPanOffset[WC.CURRENT][WC.Y];

		wxpp.lat = mouseLat;
		wxpp.lon = mouseLon;

		wxpp.secsOfDay = witTimePlayheadFloat;

		poly.polyPoints.add(wxpp);

		determinePolyCenter(poly);
	}

	public void rulerPointsAddCurrent(){
		if (ruler == null){
			ruler = new WxPoly();
		}

		if (ruler.polyPoints == null){
			ruler.polyPoints = new ArrayList();

		}

		ruler.polyColor[WC.R] = 1f;
		ruler.polyColor[WC.G] = 0f;
		ruler.polyColor[WC.B] = 0f;


		WxPolyPoint wxpp = new WxPolyPoint();
		wxpp.rasterX = cursorX - (int)userPanOffset[WC.CURRENT][WC.X];
		wxpp.rasterY = cursorY - (int)userPanOffset[WC.CURRENT][WC.Y];

		wxpp.lat = mouseLat;
		wxpp.lon = mouseLon;

		wxpp.secsOfDay = witTimePlayheadFloat;

		ruler.polyPoints.add(wxpp);

		determinePolyCenter(ruler);
	}

	public void rulerPointsRemoveLast(){
		if (ruler != null){
			if (ruler.polyPoints != null){
				if (ruler.polyPoints.size() > 0){
					ruler.polyPoints.remove(ruler.polyPoints.size()-1);
				}
			}
		}
		determinePolyCenter(ruler);
	}

	public void determinePolyCenter(WxPoly wp){

		float rasterXsum = 0;
		float rasterYsum = 0;

		float rasterXave = 0;
		float rasterYave = 0;

		if (wp != null){
			if (wp.polyPoints != null){
				for (int i=0; i<wp.polyPoints.size(); i++){
					WxPolyPoint wxp1 = (WxPolyPoint)wp.polyPoints.get(i);

					rasterXsum+= wxp1.rasterX;
					rasterYsum+= wxp1.rasterY;
				}

				rasterXave = rasterXsum/(float)wp.polyPoints.size();
				rasterYave = rasterYsum/(float)wp.polyPoints.size();

				wp.centerPoint.rasterX = (int) rasterXave;
				wp.centerPoint.rasterY = (int) rasterYave;
			}
		}
	}

	public void polyPointsRemoveAll(){
		if (poly != null){
			if (poly.polyPoints != null){
				poly.polyPoints = new ArrayList();
				for (int i=0; i<poly.polyPoints.size(); i++){
					poly.polyPoints.remove(i);
				}
			}
		}
		determinePolyCenter(poly);
	}

	public void polyPointsRemoveLast(){
		if (poly != null){
			if (poly.polyPoints != null){
				if (poly.polyPoints.size() > 0){
					poly.polyPoints.remove(poly.polyPoints.size()-1);
				}
			}
		}
		determinePolyCenter(poly);
	}

	public void exportReport() {

	}

	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseClicked(MouseEvent e) {

		if (uiState == WC.UI_STATE_VIEW) {
			// TODO Auto-generated method stub

			// System.out.println("MOUSE CLICKED");
		}
	}

	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

		if (uiState == WC.UI_STATE_VIEW) {

		}
	}

	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

		if (uiState == WC.UI_STATE_VIEW) {

		}
	}

	public void mousePressed(MouseEvent e) {

		if (uiState == WC.UI_STATE_VIEW) {
			int posX = e.getX();
			int posY = e.getY();

			if (e.isControlDown() || e.isAltDown()) {
				if (e.getButton() == e.BUTTON1){
					// add points
					rulerPointsAddCurrent();
				} else if(e.getButton() == e.BUTTON3){
					// reset
					rulerPointsRemoveLast();
				}
			} if (e.isShiftDown()) {
				if (e.getButton() == e.BUTTON1){
					// add points
					polyPointsAddCurrent();
				} else if(e.getButton() == e.BUTTON3){
					// reset
					polyPointsRemoveLast();
				}
			} else if (e.isShiftDown() && widgetVisibility[WC.WIDGET_PLOT_TOOL] == 1) { // do
				// plot
				// point



			} else { // do selection and playhead stuff

				if (widgetVisibility[WC.WIDGET_HISTOGRAM] == 1 && posX >= histX
						&& posX <= histX + histWindowW
						&& posY < histY + histAdjustHandleSize
						&& posY >= histY - histWindowH) {

					if (histogramZoomEnabled == 1) {
						if (posX >= histX + histWindowW
								- histogramZoomButtonSize * 2
								&& posY <= histY + histogramZoomButtonSize) {
							if (posX <= histX + histWindowW
									- histogramZoomButtonSize) {

								mouseState = WC.UI_STATE_CONTRAST_ZOOM_OUT;
								histogramZoom(-1);
							} else {

								mouseState = WC.UI_STATE_CONTRAST_ZOOM_IN;
								histogramZoom(1);
							}

						} else {
							mouseState = WC.UI_STATE_CONTRAST;

							if (posY > histY) {
								userContrastRangeStatus = SELECTION_WORKING;
								touchContrastSelector(posX);
								// System.out.println("RANGE SELECTOR");
							} else {
								userContrastCPStatus = SELECTION_WORKING;
								touchContrastCPs(posX, posY, e.getButton());
								// System.out.println("CP SELECTOR");
							}
						}
					} else if (histogramZoomEnabled == 0) {
						mouseState = WC.UI_STATE_CONTRAST;

						if (posY > histY) {
							userContrastRangeStatus = SELECTION_WORKING;
							touchContrastSelector(posX);
							// System.out.println("RANGE SELECTOR");
						} else {
							userContrastCPStatus = SELECTION_WORKING;
							touchContrastCPs(posX, posY, e.getButton());
							// System.out.println("CP SELECTOR");
						}
					}

				} else if (posX >= miniMapPos[CURRENT][WC.X]
				                                       && posX <= miniMapPos[CURRENT][WC.X]
				                                                                      + miniMapSize[CURRENT][WC.X]
				                                                                                             && posY >= miniMapPos[CURRENT][WC.Y]
				                                                                                                                            && posY <= miniMapPos[CURRENT][WC.Y]
				                                                                                                                                                           + miniMapSize[CURRENT][WC.Y]) { // drag view
					// region
					mouseState = WC.UI_STATE_PAN_VIEW;
					mousePan(posX, posY);

				} else if (posY > tivoStatusBarY + 22
						&& posX < scaOpMaskX + scaOpMaskW && posX >= scaOpMaskX) {// switch
					// to
					// SCA
					// selection

					mouseState = WC.UI_STATE_SCA_SELECT;
					uiState = WC.UI_STATE_SCA_SELECT;
					System.out.println("MODE CHANGE ");
				} else if (false){//(posY > tivoStatusBarY + 22 && posX < scaOpMaskX) {// toggle
					// 33/34

					mouseState = WC.UI_STATE_SCA_SELECT;
					toggleFlight();
					// auto re-center
					//panBookmarkEvent(0);

					// uiState = WC.UI_STATE_SCA_SELECT;
				} else if (posX < viewportX
						&& posY < userSelectionLowerBoundary) { 

					if (e.getButton() == e.BUTTON1){
						mouseState = WC.UI_STATE_PROCESS_WINDOW;
						cursorX = posX + cursorUnblockX;
						cursorY = posY + cursorUnblockY;

						userSelection[WC.START][WC.X] = cursorX
						- (int) userPanOffset[CURRENT][WC.X];
						userSelection[WC.START][WC.Y] = cursorY
						- (int) userPanOffset[CURRENT][WC.Y];

						// start us at click location
						userSelection[WC.END][WC.X] = cursorX
						- (int) userPanOffset[CURRENT][WC.X];
						userSelection[WC.END][WC.Y] = cursorY
						- (int) userPanOffset[CURRENT][WC.Y];

						if (selectionStatus == SELECTION_READY) {

							// setSelectionTimeToPlayhead();//
						}

						mapOverlayUpdateFlag = 1;
						selectionStatus = SELECTION_WORKING;

					} else if (e.getButton() == e.BUTTON3){
						mouseState = WC.UI_STATE_DRAG_VIEW;

						mouseDragStartX = posX;
						mouseDragStartY = posY;
					}

				} else if (posY > tivoGraphicsY2 - tivoGraphicsH2
						&& posY < tivoGraphicsY2) {

					mouseState = WC.UI_STATE_TIMELINE_LOAD;

					touchPlayhead(posX);
					// touchPlayhead(posX-(int)userXoffset[CURRENT]);
				} else if (posY > loopSelectorY2 - handleFlagH
						&& posY < loopSelectorY2 + handleFlagH * 2) {

					mouseState = WC.UI_STATE_TIMELINE_SELECT;
					touchLoopSelector(posX);

				}
			}

		} else if (uiState == WC.UI_STATE_SCA_SELECT) {
			int posX = e.getX();
			int posY = e.getY();
			int scaSelectedID = -1;

			if (posY > tivoStatusBarY + 22 && posX < scaOpMaskX) {// toggle
				// 33/34
				toggleFlight();

			} else {

				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					if (posX > scaSelectorGraphic[k][WC.X]
					                                 && posX < scaSelectorGraphic[k][WC.X]
					                                                                 + scaSelectorGraphic[k][WC.W]
					                                                                                         && posY > scaSelectorGraphic[k][WC.Y]
					                                                                                                                         && posY < scaSelectorGraphic[k][WC.Y]
					                                                                                                                                                         + scaSelectorGraphic[k][WC.H]) {
						scaLoadMask[userFlight][k] += 1;
						scaLoadMask[userFlight][k] = scaLoadMask[userFlight][k] % 2;

						scaSelectedID = k;
					}
				}
				if (scaSelectedID == -1) { // dismiss the selector if user
					// clicks
					// outside the SCAs
					uiState = WC.UI_STATE_VIEW;

					mouseState = WC.STATUS_READY;
					;
				} else {

				}
			}
		}

	}

	public void setSelectionTimeToPlayhead() {

		int scaID = indexSca[userFlight];

		userSelection[WC.START][WC.T] = 0;// 0+witFrameLoadStartSec;
		userSelection[WC.END][WC.T] = witFrameList[userFlight][scaID].size() - 1;// witFrameList.size();//frameCount-1;

		userSelection[WC.START][T_SECS] = ((WITFrame) witFrameList[userFlight][scaID]
		                                                                       .get(userSelection[WC.START][WC.T])).timeStampSecOfDay;
		userSelection[WC.END][T_SECS] = ((WITFrame) witFrameList[userFlight][scaID]
		                                                                     .get(userSelection[WC.END][WC.T])).timeStampSecOfDay;
	}

	public void sortCPList() {

		// check the control points
		for (int i = 0; i < userContrastCPList.size(); i++) {
			UserContrastCP uc = (UserContrastCP) userContrastCPList.get(i);
			if (uc.histIntensityBin < userContrast[WC.START]) {
				userContrastCPList.remove(i);
			}
			if (uc.histIntensityBin > userContrast[WC.END]) {
				userContrastCPList.remove(i);
			}
		}

		if (userContrastCPList.size() > 1) {
			int swaps = 1;
			while (swaps > 0) {
				swaps = 0;

				for (int i = 1; i < userContrastCPList.size(); i++) {

					UserContrastCP u1 = (UserContrastCP) userContrastCPList
					.get(i - 1);
					UserContrastCP u2 = (UserContrastCP) userContrastCPList
					.get(i);

					if (u1.intensity > u2.intensity) {
						swaps++;
						userContrastCPList.set(i - 1, u2);
						userContrastCPList.set(i, u1);
					}
				}
			}
		}

		for (int i = 0; i < userContrastCPList.size(); i++) {

			UserContrastCP u2 = (UserContrastCP) userContrastCPList.get(i);

		}

	}

	public void touchContrastCPs(int posX, int posY, int BUTTON_FLAG) {

		// if (userContrastCPStatus == WC.STATUS_READY){
		// detect if we're clicking near a current CP
		int modCP = 0;
		float minDist = Float.MAX_VALUE;
		int minID = -1;
		for (int i = 0; i < userContrastCPList.size(); i++) {
			UserContrastCP uc = (UserContrastCP) userContrastCPList.get(i);
			float distSq = (uc.clickX - posX) * (uc.clickX - posX)
			+ (uc.clickY - posY) * (uc.clickY - posY);

			if (distSq <= (float) (contrastCurveDotRadius * contrastCurveDotRadius) * 1.1f) {
				minDist = distSq;
				minID = i;
			}
		}

		// System.out.println("MIN DIST "+minDist+" ID "+minID);
		if (minDist <= 300) {
			modCP = 1;
		}

		if (modCP == 0 && BUTTON_FLAG == MouseEvent.BUTTON1) { // new
			UserContrastCP uccp = new UserContrastCP();
			uccp.histIntensityBin = (posX - histX);
			uccp.intensity = uccp.histIntensityBin * histClusterSize;
			uccp.rasterIntensity = (histY - posY);
			uccp.clickX = posX;
			uccp.clickY = posY;
			userContrastCPList.add(uccp);

			resetContrastEtc();

		}

		if (modCP == 1 && BUTTON_FLAG == MouseEvent.BUTTON3) { // delete

			userContrastCPList.remove(minID);
		}

		if (modCP == 1 && BUTTON_FLAG == MouseEvent.BUTTON1 && minID >= 0) { // modify

			userContrastCPStatus = SELECTION_WORKING;
			userContrastCPmodID = minID;

			UserContrastCP uc = (UserContrastCP) userContrastCPList.get(minID);
			uc.clickX = posX;
			uc.clickY = posY;
			uc.histIntensityBin = (posX - histX);
			uc.intensity = uc.histIntensityBin * histClusterSize;
			uc.rasterIntensity = histY - posY;
			userContrastCPList.set(minID, uc);

			// userContrastCPStatus = SELECTION_WORKING;
		}

		sortCPList();
	}

	public void touchContrastSelector(int posX) {

		int phX1 = posX;

		int phX2 = posX;

		int cSelPosX1 = contrastBarX
		+ (userContrast[WC.START] * contrastBarSpaceX);
		int cSelPosX2 = contrastBarX
		+ (userContrast[WC.END] * contrastBarSpaceX);

		int diff1 = Math.abs(phX1 - cSelPosX1);
		int diff2 = Math.abs(phX2 - cSelPosX2);

		int cGap = 1;

		if (diff1 <= diff2) {
			userContrast[WC.START] = (phX1 - contrastBarX) / contrastBarSpaceX;

			if (userContrast[WC.START] > userContrast[WC.END] - cGap) {
				userContrast[WC.START] = userContrast[WC.END] - cGap;
			}
		} else {
			userContrast[WC.END] = (phX2 - contrastBarX) / contrastBarSpaceX;

			if (userContrast[WC.END] < userContrast[WC.START] + cGap) {
				userContrast[WC.END] = userContrast[WC.START] + cGap;
			}
		}

		if (userContrast[WC.END] > histBins / histClusterSize) {
			userContrast[WC.END] = histBins / histClusterSize;
		}
		if (userContrast[WC.START] < 0) {
			userContrast[WC.START] = 0;
		}

		sortCPList();
	}

	public int getHistIntensityRasterX() {
		int xPos = 0;

		return xPos;
	}

	public void touchLoopSelector(int posX) {
		int playheadT1pos = userSelection[WC.START][WC.T];
		int playheadT2pos = userSelection[WC.END][WC.T];

		posX = posX - tivoStatusBarX - (int) userTimelineOffset[CURRENT];

		int phX1 = posX;
		// int phX1 = posX - tivoStatusBarX;
		phX1 = phX1 / tivoStatusBarTickX;

		int phX2 = posX;
		// int phX2 = posX - tivoStatusBarX;
		phX2 = phX2 / tivoStatusBarTickX;

		int diff1 = Math.abs(phX1 - playheadT1pos);
		int diff2 = Math.abs(phX2 - playheadT2pos);

		if (diff1 <= diff2) {
			userSelection[WC.START][WC.T] = phX1;
			if (userSelection[WC.START][WC.T] > userSelection[WC.END][WC.T]) {
				userSelection[WC.START][WC.T] = userSelection[WC.END][WC.T];
			}
		} else {
			userSelection[WC.END][WC.T] = phX2;
			if (userSelection[WC.END][WC.T] < userSelection[WC.START][WC.T]) {
				userSelection[WC.END][WC.T] = userSelection[WC.START][WC.T];
			}
		}

		checkTimeSelectorBounds();

		loopBoundStartX = tivoStatusBarX + (int) userTimelineOffset[CURRENT]
		                                                            + userSelection[WC.START][WC.T];
		loopBoundEndX = tivoStatusBarX + (int) userTimelineOffset[CURRENT]
		                                                          + userSelection[WC.END][WC.T];

	}

	public void checkTimeSelectorBounds() {
		// error checking

		if (userSelection[WC.START][WC.T] < loopStart)
			userSelection[WC.START][WC.T] = loopStart;
		if (userSelection[WC.END][WC.T] > loopEnd)
			userSelection[WC.END][WC.T] = loopEnd;
	}


	public void touchPlayhead(int posX) {
		dynamicLoadStatus = WC.STATUS_WORKING;

		int phX = posX - (tivoStatusBarX);
		tivoPlayheadXpos = phX;

		int xReleaseLoc = tivoPlayheadXpos - (int) userTimelineOffset[CURRENT];
		witTimePlayhead = xReleaseLoc;

		checkPlayheadXposLoopBounds(CHECK_BOUNDS_LOCK);

	}

	public void clearFilterLayers() {
		// int scaID =0;

		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			for (int i = 0; i < witFrameList[userFlight][k].size(); i++) {

				WITFrame wfi = (WITFrame) witFrameList[userFlight][k].get(i);

				wfi.layerStatus[WC.THREAD_CONTRAST] = WC.THREAD_STATUS_READY;
				wfi.biRay[WC.THREAD_CONTRAST] = null;
				wfi.layerStatus[WC.THREAD_DIFF] = WC.THREAD_STATUS_READY;
				wfi.biRay[WC.THREAD_DIFF] = null;
				wfi.layerStatus[WC.THREAD_TIMELAPSE] = WC.THREAD_STATUS_READY;
				wfi.biRay[WC.THREAD_TIMELAPSE] = null;
				wfi.layerStatus[WC.THREAD_REGISTRATION] = WC.THREAD_STATUS_READY;
				wfi.biRay[WC.THREAD_REGISTRATION] = null;

				// witFrameList[userFlight][k].set(i,wfi);
			}
		}

	}

	public void mouseReleased(MouseEvent e) {

		if (uiState == WC.UI_STATE_VIEW) {
			if (selectionStatus == SELECTION_WORKING) {


				if (mouseState == WC.UI_STATE_PROCESS_WINDOW) {
					translateSelectionToSCAs();

					// triggers processing
					selectionStatus = SELECTION_COMPLETE;

					userSelectionArea = (Math.abs(userSelection[WC.START][WC.X]
					                                                      - userSelection[WC.END][WC.X]))
					                                                      * (Math.abs(userSelection[WC.START][WC.Y]
					                                                                                          - userSelection[WC.END][WC.Y]));

					clearFilterLayers();
				}
			}

			if (mouseState == WC.UI_STATE_TIMELINE_LOAD) {

				selectionTimeStatus = SELECTION_READY;

				if (mouseState == WC.UI_STATE_TIMELINE_LOAD) {

					int xReleaseLoc = tivoPlayheadXpos
					- (int) userTimelineOffset[CURRENT];

					if (xReleaseLoc < loopStart || xReleaseLoc > loopEnd
							|| userFlight != loadedFlight) {
						dynamicLoad3(xReleaseLoc, loadSeconds, 0, skipSeconds);

					} else {
						touchPlayhead(e.getX());

					}
					dynamicLoadStatus = WC.STATUS_COMPLETE;
				}

			} else if (mouseState == WC.UI_STATE_CONTRAST) {

				if (userContrastRangeStatus == SELECTION_WORKING
						|| userContrastCPStatus == SELECTION_WORKING) {
					userContrastCPStatus = SELECTION_READY;
					userContrastRangeStatus = SELECTION_READY;

					resetContrastEtc();

					StringBuilder strBdr = new StringBuilder();
					strBdr.append("CONTRAST RANGE ");
					strBdr.append(userContrast[WC.START]);
					strBdr.append(" ");
					strBdr.append(userContrast[WC.END] * histClusterSize);
					userInterfaceInfoStr = strBdr.toString();
					tivoSpeedOverlayAlpha = tivoSpeedOverlayAlphaReset;
				}
			}
		}

		mouseState = WC.STATUS_READY;
	}

	public void determineIndexSca() {
		int maxLengthSca = 0;
		int maxLengthCount = 0;
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			if (witFrameList[userFlight][k].size() > maxLengthCount) {
				maxLengthCount = witFrameList[userFlight][k].size();
				maxLengthSca = k;
			}
		}

		indexSca[userFlight] = maxLengthSca;
	}

	public void growUserSelectionT() {

	}

	public void translateSelectionToSCAs() {

		int leftSca = 0;
		int rightSca = 0;

		for (int i = 0; i < WC.TOTAL_SCAS - 1; i++) {
			userSelectionSCAtouched[i] = 0;
		}

		int fxMin = Math.min(userSelection[WC.START][WC.X],
				userSelection[WC.END][WC.X]);
		int fxMax = Math.max(userSelection[WC.START][WC.X],
				userSelection[WC.END][WC.X]);
		int fyMin = Math.min(userSelection[WC.START][WC.Y],
				userSelection[WC.END][WC.Y]);
		int fyMax = Math.max(userSelection[WC.START][WC.Y],
				userSelection[WC.END][WC.Y]);

		//System.out.println("Y SELECT " + fyMin + " " + fyMax);

		for (int i = 0; i < WC.TOTAL_SCAS; i++) {
			if (fxMin >= scaOffsets[i][WC.X]
			                           && fxMin <= scaOffsets[i][WC.X] + WC.SCA_CHANNELS) {
				leftSca = i;
			}
			if (fxMax >= scaOffsets[i][WC.X]
			                           && fxMax <= scaOffsets[i][WC.X] + WC.SCA_CHANNELS) {
				rightSca = i;
			}
		}

		for (int i = 0; i < WC.TOTAL_SCAS; i++) {
			userSelectionSCA[i][WC.START][WC.X] = -1;
			userSelectionSCA[i][WC.END][WC.X] = -1;
			userSelectionSCA[i][WC.START][WC.Y] = -1;
			userSelectionSCA[i][WC.END][WC.Y] = -1;
		}

		// assign processing areas on SCAs, left to right
		if (leftSca == rightSca) {
			userSelectionSCA[leftSca][WC.START][WC.X] = fxMin
			- scaOffsets[leftSca][WC.X];
			userSelectionSCA[leftSca][WC.END][WC.X] = fxMax
			- scaOffsets[leftSca][WC.X];

			userSelectionSCA[leftSca][WC.START][WC.Y] = fyMin
			- scaOffsets[leftSca][WC.Y];
			userSelectionSCA[leftSca][WC.END][WC.Y] = fyMax
			- scaOffsets[leftSca][WC.Y];

			userSelectionSCAtouched[leftSca] = 1;
			userSelectionSCAtouched[rightSca] = 1;
		} else {
			userSelectionSCA[leftSca][WC.START][WC.X] = fxMin
			- scaOffsets[leftSca][WC.X];
			userSelectionSCA[leftSca][WC.END][WC.X] = WC.SCA_CHANNELS;

			userSelectionSCA[leftSca][WC.START][WC.Y] = fyMin
			- scaOffsets[leftSca][WC.Y];
			userSelectionSCA[leftSca][WC.END][WC.Y] = fyMax
			- scaOffsets[leftSca][WC.Y];

			for (int i = leftSca + 1; i < rightSca; i++) {
				userSelectionSCA[i][WC.START][WC.X] = 0;
				userSelectionSCA[i][WC.END][WC.X] = WC.SCA_CHANNELS;

				userSelectionSCA[i][WC.START][WC.Y] = fyMin
				- scaOffsets[i][WC.Y];
				userSelectionSCA[i][WC.END][WC.Y] = fyMax - scaOffsets[i][WC.Y];
				userSelectionSCAtouched[i] = 1;
			}

			userSelectionSCA[rightSca][WC.START][WC.X] = 0;
			userSelectionSCA[rightSca][WC.END][WC.X] = fxMax
			- scaOffsets[rightSca][WC.X];

			userSelectionSCA[rightSca][WC.START][WC.Y] = fyMin
			- scaOffsets[rightSca][WC.Y];
			userSelectionSCA[rightSca][WC.END][WC.Y] = fyMax
			- scaOffsets[rightSca][WC.Y];

			userSelectionSCAtouched[leftSca] = 1;
			userSelectionSCAtouched[rightSca] = 1;
		}

	}

	public void checkPanBounds(){
		// check limits
		if (userPanOffset[GOAL][WC.X] < minPanX) {
			userPanOffset[GOAL][WC.X] = minPanX;
		}
		if (userPanOffset[GOAL][WC.X] > maxPanX) {
			userPanOffset[GOAL][WC.X] = maxPanX;
		}
		if (userPanOffset[GOAL][WC.Y] < minPanY) {
			userPanOffset[GOAL][WC.Y] = minPanY;
		}
		if (userPanOffset[GOAL][WC.Y] > maxPanY) {
			userPanOffset[GOAL][WC.Y] = maxPanY;
		}
	}

	public void mouseDragWB(int x, int y){

		int diffX = x-mouseDragStartX;
		int diffY = y-mouseDragStartY;

		mouseDragStartX = x;
		mouseDragStartY = y;

		userPanOffset[GOAL][WC.X] += diffX;
		userPanOffset[GOAL][WC.Y] += diffY;

		userPanOffset[CURRENT][WC.X] = userPanOffset[GOAL][WC.X];
		userPanOffset[CURRENT][WC.Y] = userPanOffset[GOAL][WC.Y];

		checkPanBounds();

		miniMapInsetPos[CURRENT][WC.X] = (int) (userPanOffset[CURRENT][WC.X] * miniMapScale);
		miniMapInsetPos[CURRENT][WC.Y] = (int) (userPanOffset[CURRENT][WC.Y] * miniMapScale);


	}

	public void mousePan(int x, int y) {

		x -= miniMapInsetSize[CURRENT][WC.X] / 2;
		y -= miniMapInsetSize[CURRENT][WC.Y] / 2;

		float xFrac = (float) (x - miniMapPos[CURRENT][WC.X])
		/ (float) (miniMapSize[CURRENT][WC.X] - miniMapInsetSize[CURRENT][WC.X]);
		userPanOffset[GOAL][WC.X] = xFrac * (float) (minPanX);
		float yFrac = (float) (y - miniMapPos[CURRENT][WC.Y])
		/ (float) (miniMapSize[CURRENT][WC.Y] - miniMapInsetSize[CURRENT][WC.Y]);
		userPanOffset[GOAL][WC.Y] = yFrac * (float) (minPanY);

		checkPanBounds();

		userPanOffset[CURRENT][WC.X] = userPanOffset[GOAL][WC.X];
		userPanOffset[CURRENT][WC.Y] = userPanOffset[GOAL][WC.Y];

		miniMapInsetPos[CURRENT][WC.X] = (int) (userPanOffset[CURRENT][WC.X] * miniMapScale);
		miniMapInsetPos[CURRENT][WC.Y] = (int) (userPanOffset[CURRENT][WC.Y] * miniMapScale);

	}

	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

		if (uiState == WC.UI_STATE_VIEW) {
			int posX = e.getX();
			int posY = e.getY();

			if (e.isAltDown() == true) {

			} else {

				if (mouseState == WC.UI_STATE_DRAG_VIEW){
					mouseDragWB(posX, posY);

				} else if (mouseState == WC.UI_STATE_PAN_VIEW) { // pan view of data

					if (mouseState == WC.STATUS_READY
							|| mouseState == WC.UI_STATE_PAN_VIEW) {
						mousePan(posX, posY);

					}
				} else if (mouseState == WC.UI_STATE_PROCESS_WINDOW) { // selection
					// box for
					// processing

					if (mouseState == WC.STATUS_READY
							|| mouseState == WC.UI_STATE_PROCESS_WINDOW) {
						cursorX = posX + cursorUnblockX;
						cursorY = posY + cursorUnblockY;

						mouseOverSCA = getMouseOverSCA(cursorX, cursorY);

						statusInterp = 0;
						if (lensMagnifyActive == 1) {

							// createLens(posX, posY);
							lensPosX = cursorX;
							lensPosY = cursorY;

						}

						doMouseLatLon();

						userSelection[WC.END][WC.X] = cursorX
						- (int) userPanOffset[CURRENT][WC.X];
						userSelection[WC.END][WC.Y] = cursorY
						- (int) userPanOffset[CURRENT][WC.Y];

						// translateSelectionToSCAs();

						selectionStatus = SELECTION_WORKING;
					}

				} else if (mouseState == WC.UI_STATE_TIMELINE_SELECT) {
					touchLoopSelector(posX);
				} else if (mouseState == WC.UI_STATE_TIMELINE_LOAD) { // modify
					// playhead

					touchPlayhead(posX);

				} else if (mouseState == WC.UI_STATE_CONTRAST) {

					// allow drag events anywhere
					if (userContrastRangeStatus == SELECTION_WORKING) {
						touchContrastSelector(posX);
					} else if (userContrastCPStatus == SELECTION_WORKING) {
						touchContrastCPs(posX, posY, e.getButton());
					}

				}
			}
		}


	}

	public int getMouseOverSCA(int x, int y) {
		cursorOverWidget = WC.STATUS_OFF;
		int scaID = -1;

		int pX = x - (int) userPanOffset[CURRENT][WC.X];
		int pY = y - (int) userPanOffset[CURRENT][WC.Y];

		int widgetFlag = WC.STATUS_OFF; // check if we're over the widget

		if (x >= histX && x <= histX + histWindowW && y < histY
				&& y >= histY - histWindowH) {
			if (widgetVisibility[WC.WIDGET_HISTOGRAM] == WC.STATUS_ON) {
				cursorOverWidget = WC.STATUS_ON;
				widgetFlag = WC.STATUS_ON;
			}
		}

		if (x >= miniMapPos[CURRENT][WC.X]
		                             && x <= miniMapPos[CURRENT][WC.X] + miniMapSize[CURRENT][WC.X]
		                                                                                      && y >= miniMapPos[CURRENT][WC.Y]
		                                                                                                                  && y <= miniMapPos[CURRENT][WC.Y] + miniMapSize[CURRENT][WC.Y]) {
			if (widgetVisibility[WC.WIDGET_MINIGLOBE] == WC.STATUS_ON) {
				cursorOverWidget = WC.STATUS_ON;
				widgetFlag = WC.STATUS_ON;
			}
		}

		if (x >= miniGlobePos[CURRENT][WC.X]
		                               && x <= miniGlobePos[CURRENT][WC.X]
		                                                             + miniGlobeSize[CURRENT][WC.X]
		                                                                                      && y >= miniGlobePos[CURRENT][WC.Y]
		                                                                                                                    && y <= miniGlobePos[CURRENT][WC.Y]
		                                                                                                                                                  + miniGlobeSize[CURRENT][WC.Y]) {
			if (widgetVisibility[WC.WIDGET_MINIMAP] == WC.STATUS_ON) {
				cursorOverWidget = WC.STATUS_ON;
				widgetFlag = WC.STATUS_ON;
			}
		}

		if (y < tivoStatusBarY && widgetFlag == 0) {

			for (int i = 0; i < WC.TOTAL_SCAS; i++) {

				if (witFrameList[userFlight][i] != null) {
					if (witFrameList[userFlight][i].size() > 0) {
						WITFrame tempFrame = (WITFrame) witFrameList[userFlight][i]
						                                                         .get(witSCAPlayhead[userFlight][i]);
						int frameYoffset = tempFrame.yAlignGross;
						if (pX >= scaOffsets[i][WC.X]
						                        && pX <= scaOffsets[i][WC.X] + WC.SCA_CHANNELS) {
							scaID = i;

							// find the offset of the mouse within the sca
							int yAlignMouseData = 0;

							mouseX = pX - scaOffsets[i][WC.X] + cursorUnblockX;
							mouseY = pY - scaOffsets[i][WC.Y] + frameYoffset
							- yAlignMouseData + cursorUnblockY; // HACK

							mousePanoramaX = 0;
							mousePanoramaY = 0;
						}
					}
				}
			}
		}

		if (scaID != -1) {
			if (userSelectionSCAtouched[scaID] == WC.STATUS_ON) {
				histogramSCAselector = scaID;
			}

		}
		return scaID;

	}

	public void doMouseLatLon() {

		if (dynamicLoadStatus == WC.STATUS_COMPLETE && statusInterp == 0
				&& mouseOverSCA != -1) {
			if (witFrameList[userFlight][mouseOverSCA] != null) {

				if (mouseY >= 0 && mouseX >= 0) {

					scaOffsets = ImProcThread.initSCAoffsets(1);

					long timeSlow1 = System.currentTimeMillis();
					WITFrame tempFrame = null;

					long timeSlow2 = System.currentTimeMillis();

					long timeFast1 = System.currentTimeMillis();
					float[] fastCoords = null;
					float[] fastCoordsNorth2 = null;
					if (mouseOverSCA != -1) {
						int frameIndex = witSCAPlayhead[userFlight][mouseOverSCA];
						if (frameIndex < witFrameList[userFlight][mouseOverSCA].size()) {
							fastCoords = ImProcThread
							.interpolateLonLatFramePointFast(
									(WITFrame) witFrameList[userFlight][mouseOverSCA]
									                                    .get(frameIndex),
									                                    mouseOverSCA, mouseX, mouseY);
							fastCoordsNorth2 = ImProcThread
							.interpolateLonLatFramePointFast(
									(WITFrame) witFrameList[userFlight][mouseOverSCA]
									                                    .get(frameIndex),
									                                    mouseOverSCA, mouseX, mouseY - 1);

							determineNorthArrowsMouse(fastCoords,
									fastCoordsNorth2);

							long timeFast2 = System.currentTimeMillis();

							if (mouseX > 0 && mouseY > 0) {

								mouseLon = fastCoords[GEODATA_LON];
								mouseLat = fastCoords[GEODATA_LAT];
							}
						} else {
							mouseLon = -9999;
							mouseLat = -9999;
						}
					}

				}

				// grab the intensity too
				int pullX = cursorX - (int) userPanOffset[CURRENT][WC.X];
				int pullY = cursorY - (int) userPanOffset[CURRENT][WC.Y];

				if (mouseOverSCA != -1) {
					if (witFrameList[userFlight][mouseOverSCA].size() > 0) {
						WITFrame tempFrame2 = (WITFrame) witFrameList[userFlight][mouseOverSCA]
						                                                          .get(witSCAPlayhead[userFlight][mouseOverSCA]);

						if (tempFrame2.biRay[WC.THREAD_LOAD_HDF5R] != null
								&& tempFrame2.layerStatus[WC.THREAD_LOAD_HDF5R] == WC.STATUS_COMPLETE) {
							if (pullX > 0
									&& pullY > 0
									&& pullX < tempFrame2.biRay[WC.THREAD_LOAD_HDF5R]
									                            .getWidth()
									                            && pullY < tempFrame2.biRay[WC.THREAD_LOAD_HDF5R]
									                                                        .getHeight()) {
								int rgbaMouse = tempFrame2.hdrValsRaw[pullX][pullY];

								mouseIntensity = rgbaMouse;

							}
						}
						statusInterp = 1;
					}
				}
			}
		}
	}


	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		// System.out.println("MOUSE MOVED");

		if (uiState == WC.UI_STATE_VIEW) {
			int posX = e.getX();
			int posY = e.getY();

			cursorX = posX + cursorUnblockX;
			cursorY = posY + cursorUnblockY;

			mouseOverSCA = getMouseOverSCA(cursorX, cursorY);

			mouseOverSCAprev = mouseOverSCA;

			if (lensMagnifyActive == 1) {

				lensPosX = cursorX;
				lensPosY = cursorY;

				statusInterp = 0;

				doMouseLatLon();
			}

			if (posY > tivoStatusBarY) {
				timelineMouseoverX = posX - tivoInfoBarX;

			} else {

				timelineMouseoverX = -1;
			}

		}

		if (uiState == WC.UI_STATE_CONTRAST) {

			int posX = e.getX();
			int posY = e.getY();

			cursorX = posX + cursorUnblockX;
			cursorY = posY + cursorUnblockY;

			mouseOverSCA = getMouseOverSCA(cursorX, cursorY);

			if (lensMagnifyActive == 1) {

				lensPosX = cursorX;
				lensPosY = cursorY;

				statusInterp = 0;

				if (mouseOverSCA != -1) {
					doMouseLatLon();
				}

			}
		}

	}

	public void createLens(int x, int y) {
		lensStatus = WC.STATUS_WORKING;

		// create magnified image

		lensStatus = WC.STATUS_COMPLETE;
	}

	public void restoreState(int mode) {

		try {
			File loadFile = null;

			if (mode == RESTORE_STATE_ON_LAUNCH) {
				loadFile = new File(tivoRootDir + tivoLoadFile);
			} else if (mode == SAVE_STATE_DIALOG_BOX) {
				JFileChooser fc = new JFileChooser();
				fc.setCurrentDirectory(new File(tivoRootDir));
				fc.showOpenDialog(cvt);
				loadFile = fc.getSelectedFile();
			}

			if (loadFile != null) {
				System.out.println("RESTORING SESSION FROM FILE "
						+ loadFile.getAbsoluteFile());
				BufferedReader bin = new BufferedReader(
						new FileReader(loadFile));

				// load the file
				String fileContents = "";

				while (bin.ready()) {
					String ln = bin.readLine();
					fileContents += ln;
				}

				String varName = "";

				String vars[] = fileContents.split("</");
				for (int i = 0; i < vars.length; i++) {
					// System.out.println(vars[i]);
					varName = "witSCAPlayhead";
					if (vars[i].contains("<" + varName + ">")) {
						witSCAPlayhead[userFlight][0] = Integer // REVISIT
						.parseInt(vars[i]
						               .substring(
						            		   vars[i].lastIndexOf(">") + 1,
						            		   vars[i].length()));

					}
					varName = "tivoPlayheadMin";
					if (vars[i].contains("<" + varName + ">")) {
						minSeconds = Integer.parseInt(vars[i].substring(vars[i]
						                                                     .lastIndexOf(">") + 1, vars[i].length()));
					}
					varName = "tivoPlayheadMax";
					if (vars[i].contains("<" + varName + ">")) {
						maxSeconds = Integer.parseInt(vars[i].substring(vars[i]
						                                                     .lastIndexOf(">") + 1, vars[i].length()));
					}

					varName = "tivoPlayheadBuffer";
					if (vars[i].contains("<" + varName + ">")) {
						tivoPlayheadBuffer = Integer.parseInt(vars[i]
						                                           .substring(vars[i].lastIndexOf(">") + 1,
						                                        		   vars[i].length()));
					}
					varName = "loopMode";
					if (vars[i].contains("<" + varName + ">")) {
						loopMode = Integer.parseInt(vars[i].substring(vars[i]
						                                                   .lastIndexOf(">") + 1, vars[i].length()));
					}
					varName = "systemPlaybackRate";
					if (vars[i].contains("<" + varName + ">")) {
						systemPlaybackRate = Integer.parseInt(vars[i]
						                                           .substring(vars[i].lastIndexOf(">") + 1,
						                                        		   vars[i].length()));
					}
					varName = "systemPlaybackRatePause";
					if (vars[i].contains("<" + varName + ">")) {
						systemPlaybackRatePause = Integer.parseInt(vars[i]
						                                                .substring(vars[i].lastIndexOf(">") + 1,
						                                                		vars[i].length()));
					}

					varName = "selectionStatus";
					if (vars[i].contains("<" + varName + ">")) {
						selectionStatus = Integer
						.parseInt(vars[i]
						               .substring(
						            		   vars[i].lastIndexOf(">") + 1,
						            		   vars[i].length()));
					}
					varName = "selectionTimeStatus";
					if (vars[i].contains("<" + varName + ">")) {
						selectionTimeStatus = Integer.parseInt(vars[i]
						                                            .substring(vars[i].lastIndexOf(">") + 1,
						                                            		vars[i].length()));
					}

					for (int j = 0; j < 2; j++) {
						for (int k = 0; k < 3; k++) {

							varName = "userSelection_" + j + "_" + k;
							if (vars[i].contains("<" + varName + ">")) {
								userSelection[j][k] = Integer.parseInt(vars[i]
								                                            .substring(
								                                            		vars[i].lastIndexOf(">") + 1,
								                                            		vars[i].length()));
							}

						}
					}
					// check for selection
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void initPriorities() {

		for (int m = 0; m < WC.MODE_COUNT; m++) {
			threadPriorities[m] = WC.THREAD_PRIORITY_DEFAULT;
		}

		threadPriorities[WC.THREAD_LOAD] = 7;
		threadPriorities[WC.THREAD_DIFF] = 1;
		threadPriorities[WC.THREAD_EXPORT_VIDEO] = 1;
		threadPriorities[WC.THREAD_EXPORT_WEATHER_VIDEO] = 1;
		threadPriorities[WC.THREAD_HISTOGRAM] = 1;
		threadPriorities[WC.THREAD_HISTOGRAM_EQ] = 1;
		threadPriorities[WC.THREAD_TEMPORAL] = 2;
		threadPriorities[WC.THREAD_DEJITTER] = 3;

	}

	public void initTimeouts() {

		for (int m = 0; m < WC.MODE_COUNT; m++) {
			threadTimeouts[m] = WC.THREAD_TIMEOUT_DEFAULT;
		}

		// threadTimeouts[WC.THREAD_TEMPORAL] = WC.THREAD_TIMEOUT_DEFAULT*100;
	}

	public void initParamLists() {
		paramLists = new ArrayList[WC.TOTAL_SCAS][WC.MODE_COUNT];
		for (int k = 0; k < WC.TOTAL_SCAS; k++) {
			for (int m = 0; m < WC.MODE_COUNT; m++) {
				paramLists[k][m] = new ArrayList();
				paramLists[k][m].add(defaultInputSrc); // load source

				// add the region to process

			}

		}
	}

	public void createParamList(int mode, int scaID) {

		int fxMin = userSelectionSCA[scaID][WC.START][WC.X];
		int fxMax = userSelectionSCA[scaID][WC.END][WC.X];
		int fyMin = userSelectionSCA[scaID][WC.START][WC.Y];
		int fyMax = userSelectionSCA[scaID][WC.END][WC.Y];

		int ftMin = userSelection[WC.START][WC.T]-1;
		int ftMax = userSelection[WC.END][WC.T];

		if (fyMax - fyMin > 0 && fxMax - fxMin > 0) {

			// each sca may have varying region needing to be processed

			if (mode == WC.THREAD_DIFF) {
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(WC.THREAD_CONTRAST); // load source

				paramLists[scaID][mode].add(0);
				paramLists[scaID][mode].add(fxMax - fxMin);
				paramLists[scaID][mode].add(0);
				paramLists[scaID][mode].add(fyMax - fyMin);

				paramLists[scaID][mode].add(ftMin);
				paramLists[scaID][mode].add(ftMax);

				paramLists[scaID][mode].add(diffSkip);
				paramLists[scaID][mode].add(playbackModeDir[userFlight]);

				paramLists[scaID][mode].add(playbackScanSeqIndexMask[userFlight]);		

			} else if (mode == WC.THREAD_REGISTRATION) {
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(WC.THREAD_LOAD_HDF5R); // load source

				paramLists[scaID][mode].add(0);
				paramLists[scaID][mode].add(fxMax - fxMin);
				paramLists[scaID][mode].add(0);
				paramLists[scaID][mode].add(fyMax - fyMin);

				paramLists[scaID][mode].add(ftMin);
				paramLists[scaID][mode].add(ftMax);

				paramLists[scaID][mode].add(diffSkip);
				paramLists[scaID][mode].add(playbackModeDir[userFlight]);

				paramLists[scaID][mode].add(playbackScanSeqIndexMask[userFlight]);		

			} else if (mode == WC.THREAD_TIMELAPSE) {
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(WC.THREAD_DIFF); 

				paramLists[scaID][mode].add(0);
				paramLists[scaID][mode].add(fxMax - fxMin);
				paramLists[scaID][mode].add(0);
				paramLists[scaID][mode].add(fyMax - fyMin);

				paramLists[scaID][mode].add(ftMin);
				paramLists[scaID][mode].add(ftMax);

				paramLists[scaID][mode].add(timelapseHistory);
				paramLists[scaID][mode].add(timelapseSkip);

				paramLists[scaID][mode].add(playbackModeDir[userFlight]);

				paramLists[scaID][mode].add(playbackScanSeqIndexMask[userFlight]);

			} else if (mode == WC.THREAD_CONTRAST) {
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(defaultInputSrc); // load source

				// user's filter region
				paramLists[scaID][mode].add(fxMin);
				paramLists[scaID][mode].add(fxMax);
				paramLists[scaID][mode].add(fyMin);
				paramLists[scaID][mode].add(fyMax);

				paramLists[scaID][mode].add(ftMin);
				paramLists[scaID][mode].add(ftMax);

				paramLists[scaID][mode].add(contrastMode);
				paramLists[scaID][mode].add(userContrast[WC.START]
				                                         * histClusterSize);
				paramLists[scaID][mode].add(userContrast[WC.END]
				                                         * histClusterSize);
				paramLists[scaID][mode].add(userContrastCPList);
			} else if (mode == WC.THREAD_LOAD_HDF5R) {
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(scaID); // load source

			} else if (mode == WC.THREAD_HISTOGRAM) {
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(ftMin);
				paramLists[scaID][mode].add(ftMax);
			} else if (mode == WC.THREAD_PREFILTER) {
				paramLists[scaID][mode] = new ArrayList();
				paramLists[scaID][mode].add(defaultInputSrc); // load source

			}


		}

	}

	public void initTivoBars() {

		tivoStatusBarYRay = new int[20]; // up to 10 layers of processing
		for (int i = 0; i < tivoStatusBarYRay.length; i++) {
			tivoStatusBarYRay[i] = tivoStatusBarY + (tivoBarYSeparation) * i
			+ 40;
		}
	}

	public void initUserContrast() {

		userContrast[WC.START] = 0;
		userContrast[WC.END] = 50;
	}

	public void initLayerProperties() {

		for (int i = 0; i < WC.MODE_COUNT; i++) {
			rasterLayerOrder[i] = RASTER_OMIT; // set to 'not drawn'
			rasterLayerOpa[i][CURRENT] = 0.0f;
			rasterLayerOpa[i][GOAL] = 0.0f;

			defaultOpOpacity[i] = 1f;

			// not drawn
			for (int k = 0; k < 3; k++) {
				timelineLayerOrder[i][k] = -1;
			}
		}

		defaultOpOpacity[WC.THREAD_CONTRAST] = 1.0f;

		defaultOpOpacity[WC.THREAD_REGISTRATION] = 0.0f;

		rasterLayerOpa[WC.THREAD_LOAD][GOAL] = 1.0f;
		rasterLayerOpa[WC.THREAD_LOAD_HDF5R][GOAL] = 1.0f;
		// no delay on raw data
		rasterLayerOpa[WC.THREAD_LOAD][CURRENT] = 1.0f;
		rasterLayerOpa[WC.THREAD_LOAD_HDF5R][CURRENT] = 1.0f;

		//rasterLayerOpa[WC.THREAD_REGISTRATION][GOAL] = 1.0f;
		//rasterLayerOpa[WC.THREAD_REGISTRATION][CURRENT] = 1.0f;

		rasterLayerOrder[0] = WC.THREAD_LOAD_HDF5R;
		// rasterLayerOrder[1] = WC.THREAD_LOAD;
		// rasterLayerOrder[1] = WC.THREAD_HISTOGRAM;
		rasterLayerOrder[2] = WC.THREAD_CONTRAST;
		rasterLayerOrder[3] = WC.THREAD_DIFF;
		//rasterLayerOrder[4] = WC.THREAD_TEMPORAL;
		//rasterLayerOrder[5] = WC.THREAD_STATIC;
		rasterLayerOrder[6] = WC.THREAD_TIMELAPSE;
		//rasterLayerOrder[7] = WC.THREAD_REGISTRATION;

		timelineLayerOrder[WC.THREAD_HISTOGRAM][WC.Y] = 4;
		timelineLayerOrder[WC.THREAD_HISTOGRAM][WC.Z] = 0;
		timelineLayerOrder[WC.THREAD_CONTRAST][WC.Y] = 5;
		timelineLayerOrder[WC.THREAD_CONTRAST][WC.Z] = 0;

		timelineLayerOrder[WC.THREAD_DIFF][WC.Y] = 6;
		timelineLayerOrder[WC.THREAD_DIFF][WC.Z] = 0;

		timelineLayerOrder[WC.THREAD_TIMELAPSE][WC.Y] = 7;
		timelineLayerOrder[WC.THREAD_TIMELAPSE][WC.Z] = 0;

		//timelineLayerOrder[WC.THREAD_REGISTRATION][WC.Y] = 8;
		//timelineLayerOrder[WC.THREAD_REGISTRATION][WC.Z] = 0;

	}

	public void initOpBuffers() {
		witOpBuffers = new int[WC.MODE_COUNT];
		for (int m = 0; m < WC.MODE_COUNT; m++) {
			witOpBuffers[m] = WIT_OP_BUFFER_DEFAULT;
		}

		witOpBuffers[WC.THREAD_HISTOGRAM] = 20; // computationally light
		witOpBuffers[WC.THREAD_DIFF] = 2;// 10;
		witOpBuffers[WC.THREAD_CONTRAST] = 2;// 10;
		witOpBuffers[WC.THREAD_REGISTRATION] = 2;
		witOpBuffers[WC.THREAD_TIMELAPSE] = 1; // computationally expensive
		witOpBuffers[WC.THREAD_REGISTRATION] = 20;
		// threadTimeouts[WC.THREAD_TEMPORAL] = WC.THREAD_TIMEOUT_DEFAULT*100;
	}

	// !!TODO
	// show what files are actually loaded in the timelin
	public static void whatFilesLoaded() {

	}

	// save state so system can restart
	public void saveState(int mode) {

		whatFilesLoaded();

		try {

			File saveFile = null;

			// current session
			if (mode == SAVE_STATE_ON_EXIT) {
				saveFile = new File(tivoRootDir + tivoSaveFile);
			} else if (mode == SAVE_STATE_DIALOG_BOX) {
				JFileChooser fc = new JFileChooser();
				fc.setCurrentDirectory(new File(tivoRootDir));
				fc.showSaveDialog(cvt);
				saveFile = fc.getSelectedFile();
			}

			if (saveFile != null) {

				BufferedWriter bout = new BufferedWriter(new FileWriter(
						saveFile));

				String fileContents = "";
				String fileElement = "";

				// playhead position
				for (int k = 0; k < WC.TOTAL_SCAS; k++) {
					fileElement = "<witSCAPlayhead>"
						+ witSCAPlayhead[userFlight][k]
						                             + "</witSCAPlayhead>";
				}
				fileContents += fileElement + "\n";
				fileElement = "<tivoPlayheadMin>" + minSeconds
				+ "</tivoPlayheadMin>";
				fileContents += fileElement + "\n";
				fileElement = "<tivoPlayheadMax>" + maxSeconds
				+ "</tivoPlayheadMax>";
				fileContents += fileElement + "\n";
				fileElement = "<tivoPlayheadBuffer>" + tivoPlayheadBuffer
				+ "</tivoPlayheadBuffer>";
				fileContents += fileElement + "\n";

				fileElement = "<loopMode>" + loopMode + "</loopMode>";
				fileContents += fileElement + "\n";

				fileElement = "<systemPlaybackRate>" + systemPlaybackRate
				+ "</systemPlaybackRate>";
				fileContents += fileElement + "\n";
				fileElement = "<systemPlaybackRatePause>"
					+ systemPlaybackRatePause
					+ "</systemPlaybackRatePause>";
				fileContents += fileElement + "\n";

				for (int j = 0; j < 2; j++) {
					for (int k = 0; k < 3; k++) {

						fileElement = "<userSelection_" + j + "_" + k + ">"
						+ userSelection[j][k] + "</userSelection_" + j
						+ "_" + k + ">";
						fileContents += fileElement + "\n";
					}
				}
				fileElement = "<selectionStatus>" + selectionStatus
				+ "</selectionStatus>";
				fileContents += fileElement + "\n";
				fileElement = "<selectionTimeStatus>" + selectionTimeStatus
				+ "</selectionTimeStatus>";
				fileContents += fileElement + "\n";

				// save user settings re: visible layers
				for (int i = 0; i < 4; i++) {
					fileElement = "<viewMask_" + i + ">" + viewMask[i]
					                                                + "</viewMask_" + i + ">";
					fileContents += fileElement + "\n";
				}
				// save user settings re: filter / processing operations
				for (int i = 0; i < WC.MODE_COUNT; i++) {
					fileElement = "<opMask_" + i + ">" + opMask[i]
					                                            + "</opMask_" + i + ">";
					fileContents += fileElement + "\n";
				}

				bout.write(fileContents);
				bout.close();

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void componentHidden(ComponentEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void componentMoved(ComponentEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void componentResized(ComponentEvent e) {
		// TODO Auto-generated method stub
		cvt.viewportX = cvt.getWidth();
		cvt.viewportY = cvt.getHeight();
		//cvt.setSize(cvt.viewportX, cvt.viewportY);
		cvt.initUIDims();

		miniMapPos[CURRENT][WC.X] = viewportX - miniMapSize[CURRENT][WC.X] - 20;
		miniMapPos[CURRENT][WC.Y] = viewportY - miniMapSize[CURRENT][WC.Y] - 80;
		miniMapInsetSize[CURRENT][WC.X] = (int) (miniMapScale * viewportX);

		miniMapInsetSize[CURRENT][WC.Y] = (int) (miniMapScale * viewportY);
		miniGlobePos[CURRENT][WC.X] = viewportX - miniMapSize[CURRENT][WC.X]- 20 - miniGlobeSize[CURRENT][WC.X] - 20;
		miniGlobePos[CURRENT][WC.Y] = viewportY - miniGlobeSize[CURRENT][WC.Y]- 80;

		cvt.initTivoBars();
	}

	@Override
	public void componentShown(ComponentEvent e) {
		// TODO Auto-generated method stub

	}

}
