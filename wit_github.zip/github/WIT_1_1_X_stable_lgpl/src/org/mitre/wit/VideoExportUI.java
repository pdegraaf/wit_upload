/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

package org.mitre.wit;
/**
 * @author Adrian Johnson <abjohnson@mitre.org>
 *
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class VideoExportUI extends JFrame {

	static int THREAD_LOAD = 0;
	static int THREAD_CONV = 1;
	static int THREAD_FEAT = 2;
	static int THREAD_THRS = 3;
	static int THREAD_DIFF = 4;
	static int THREAD_SEGMENT = 5;
	static int THREAD_FILT = 6;
	static int THREAD_MON = 7;
	static int THREAD_EXPORT_VIDEO = 8;
	static int THREAD_DEJITTER = 9;
	static int THREAD_HISTOGRAM = 10;
	static int THREAD_HISTOGRAM_EQ = 11;
	static int THREAD_TEMPORAL = 12;
	static int THREAD_DIFF_DJ = 13;
	static int THREAD_DEJITTER_ADV = 14;
	static int THREAD_CONTRAST = 15;
	static int THREAD_LOAD_HDF5R = 16;
	static int THREAD_EXPORT_IMAGES = 17;
	static int THREAD_INTERNAL = 18;
	static int THREAD_EXPORT_MARKED_IMAGES = 19;
	static int THREAD_LOAD_METADATA = 20;
	static int THREAD_LOAD_GEOLOCATION = 21;
	static int THREAD_FIX_GEOLOCATION = 22;
	static int THREAD_STATICS = 23;
	static int THREAD_TIMELAPSE = 24;
	static int THREAD_LOAD_HDF5R_STITCH = 25;
	static int THREAD_EXPORT_KML = 26;
	static int THREAD_MAP_OVERLAY = 27;

	static int MODE_COUNT = 40;
	
	static CV_MT_Disp cvt = null;
	
	static int STATUS_ERROR = -1;
	static int STATUS_READY = 0;
	static int STATUS_WORKING = 1;
	static int STATUS_COMPLETE = 2;
	static int STATUS_INCOMPLETE = 3;

	// product formats
	static int FORMAT_COUNT = 30;
	static int FORMAT_MPG = 0;
	static int FORMAT_MP4 = 1;
	static int FORMAT_MP4_H264=2;
	static int FORMAT_WMV = 3;
	static int FORMAT_PNG=10;
	static int FORMAT_JPG=11;
	static int FORMAT_GEOTIFF=12;
	
	static int inputStatus = STATUS_READY;
	
	static int itemCounter = -1;
	static int progressCounter = -1;
	
	static VideoExportUI veui;// = new VideoExportUI();
	
	boolean layerMask[] = new boolean[MODE_COUNT];
	boolean formatMask[] = new boolean[FORMAT_COUNT];

	// image seq
	static JCheckBox cbLayerRaw;
	static JCheckBox cbLayerContrast;
	static JCheckBox cbLayerDiff;
	static JCheckBox cbLayerTimelapse;
	
	// formats
	static JCheckBox cbVideoWmv;
	static JCheckBox cbVideoMpg;
	static JCheckBox cbVideoMp4;
	static JCheckBox cbImagePng;
	static JCheckBox cbImageJpg;
	
	// magnification
	static JRadioButton rbMagHalf;
	static JRadioButton rbMag1x;
	static JRadioButton rbMag2x;
	static JRadioButton rbMag4x;
	static JRadioButton rbMag8x;
	
	// video speed
	static JRadioButton rbSpeedHalf;
	static JRadioButton rbSpeed1x;
	static JRadioButton rbSpeed2x;
	static JRadioButton rbSpeed4x;
	static JRadioButton rbSpeed10x;
	static JRadioButton rbSpeed25x;
	static JRadioButton rbSpeed50x;
	static JRadioButton rbSpeed100x;
	static JRadioButton rbSpeedOther;
	
	static float userVideoExportSpeedOther = 16.0f;
	
	// specific start/stop
	static JTextField startTime;
	static JTextField stopTime;

	static JTextField minLon;
	static JTextField maxLon;
	static JTextField minLat;
	static JTextField maxLat;
	
	static JTextField minPxX;
	static JTextField maxPxX;
	static JTextField minPxY;
	static JTextField maxPxY;
	
	static JLabel labelSpeed;
	static JLabel labelMag;
	static JLabel labelMode;
	static JLabel labelFormat;
	static JLabel labelSecMark;
	static JLabel labelTitle;
	

	public static JTextField securityLabel;
	public static JTextField titleLabel;
	
	// buttons
	static JButton buttonCancel;
	static JButton buttonOkay;
	
	// checkboxes to allow export of various layers
	
	// playback speed of exported video
	
	// formats
	
	public static void init(){
		// rb speed 
		ActionListener actionListenerSpeedHalf = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoExportSpeed = 1f;
			}
		};
		ActionListener actionListenerSpeed1x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoExportSpeed = 1f;
			}
		};
		ActionListener actionListenerSpeed2x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("SPEED 2");
				cvt.userVideoExportSpeed = 2f;
			}
		};
		ActionListener actionListenerSpeed4x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("SPEED 4");
				cvt.userVideoExportSpeed = 4f;
			}
		};
		ActionListener actionListenerSpeed10x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoExportSpeed = 10f;
			}
		};
		ActionListener actionListenerSpeed25x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoExportSpeed = 25f;
			}
		};
		ActionListener actionListenerSpeed50x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoExportSpeed = 50f;
			}
		};
		ActionListener actionListenerSpeed100x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoExportSpeed = 100f;
			}
		};
		
		// rb mag
		ActionListener actionListenerMagHalf = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoMagnification = .5f;
			}
		};
		ActionListener actionListenerMag1x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoMagnification = 1f;
			}
		};
		ActionListener actionListenerMag2x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoMagnification = 2f;
			}
		};
		ActionListener actionListenerMag4x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoMagnification = 4f;
			}
		};
		ActionListener actionListenerMag8x = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.userVideoMagnification = 8f;
			}
		};
	

		// cb format
		ActionListener actionListenerFormatWmv = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int format = FORMAT_WMV;
				cvt.toggleOutputFormatMask(format);
			}
		};
		ActionListener actionListenerFormatMpg = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int format = FORMAT_MPG;
				cvt.toggleOutputFormatMask(format);
			}
		};
		ActionListener actionListenerFormatMp4 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int format = FORMAT_MP4;
				cvt.toggleOutputFormatMask(format);
			}
		};
		ActionListener actionListenerFormatPng = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int format = FORMAT_PNG;
				cvt.toggleOutputFormatMask(format);
			}
		};
		ActionListener actionListenerFormatJpg = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int format = FORMAT_JPG;
				cvt.toggleOutputFormatMask(format);
			}
		};
		
		
		// cb modes
		ActionListener actionListenerModeRaw = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int mode = THREAD_LOAD_HDF5R;
				cvt.toggleOutputModeMask(mode);
			}
		};
		ActionListener actionListenerModeContrast = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int mode = THREAD_CONTRAST;
				cvt.toggleOutputModeMask(mode);
			}
		};
		ActionListener actionListenerModeDiff = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int mode = THREAD_DIFF;
				cvt.toggleOutputModeMask(mode);
			}
		};
		ActionListener actionListenerModeTimelapse = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int mode = THREAD_TIMELAPSE;
				cvt.toggleOutputModeMask(mode);
			}
		};
		
		// end action listeners
		
		veui = new VideoExportUI();

		veui.setLayout(null);
		
		veui.setTitle("PRODUCT EXPORT");
		veui.setVisible(false);

		veui.setSize(400, 600);
		
		System.out.println("VIDEO EXPORT");
				
		int marginX = 10;
		int marginY = 10;
		int spacingY = 20;
		int spacingX = 160;
		
		int widthX = spacingX;
		int heightY = spacingY;
		
		// image seq
		cbLayerRaw = new JCheckBox();
		cbLayerRaw.setText("RAW");
		cbLayerRaw.setSize(spacingX, spacingY);
		cbLayerRaw.setVisible(true);
		cbLayerRaw.setLocation(marginX, marginY+spacingY);
		cbLayerRaw.addActionListener(actionListenerModeRaw);
		
		cbLayerContrast = new JCheckBox();
		cbLayerContrast.setText("CONTRAST");
		cbLayerContrast.setSize(spacingX, spacingY);
		cbLayerContrast.setVisible(true);
		cbLayerContrast.setLocation(marginX, marginY+spacingY*2);
		cbLayerContrast.addActionListener(actionListenerModeContrast);
		
		cbLayerDiff = new JCheckBox();
		cbLayerDiff.setText("DIFF");
		cbLayerDiff.setSize(spacingX, spacingY);
		cbLayerDiff.setVisible(true);
		cbLayerDiff.setLocation(marginX, marginY+spacingY*3);
		cbLayerDiff.addActionListener(actionListenerModeDiff);
		
		cbLayerTimelapse = new JCheckBox();
		cbLayerTimelapse.setText("TIMELAPSE");
		cbLayerTimelapse.setSize(spacingX, spacingY);
		cbLayerTimelapse.setVisible(true);
		cbLayerTimelapse.setLocation(marginX, marginY+spacingY*4);
		cbLayerTimelapse.addActionListener(actionListenerModeTimelapse);
		
		// formats
		cbVideoWmv = new JCheckBox();
		cbVideoWmv.setText("WMV");
		cbVideoWmv.setSize(spacingX, spacingY);
		cbVideoWmv.setVisible(true);
		cbVideoWmv.setLocation(marginX, marginY+spacingY*7);
		cbVideoWmv.addActionListener(actionListenerFormatWmv);
		
		cbVideoMpg = new JCheckBox();
		cbVideoMpg.setText("MPEG");
		cbVideoMpg.setSize(spacingX, spacingY);
		cbVideoMpg.setVisible(true);
		cbVideoMpg.setLocation(marginX, marginY+spacingY*8);
		cbVideoMpg.addActionListener(actionListenerFormatMpg);
		
		cbVideoMp4 = new JCheckBox();
		cbVideoMp4.setText("MP4");
		cbVideoMp4.setSize(spacingX, spacingY);
		cbVideoMp4.setVisible(true);
		cbVideoMp4.setLocation(marginX, marginY+spacingY*9);
		cbVideoMp4.addActionListener(actionListenerFormatMp4);
		
		cbImagePng = new JCheckBox();
		cbImagePng.setText("PNG");
		cbImagePng.setSize(spacingX, spacingY);
		cbImagePng.setVisible(true);
		cbImagePng.setLocation(marginX, marginY+spacingY*10);
		cbImagePng.addActionListener(actionListenerFormatPng);
		
		cbImageJpg = new JCheckBox();
		cbImageJpg.setText("JPEG");
		cbImageJpg.setSize(spacingX, spacingY);
		cbImageJpg.setVisible(true);
		cbImageJpg.setLocation(marginX, marginY+spacingY*11);
		cbImageJpg.addActionListener(actionListenerFormatJpg);
		
		// magnification

		ButtonGroup bgMag = new ButtonGroup();
		
		rbMagHalf = new JRadioButton();
		rbMagHalf.setText("HALF");
		rbMagHalf.setSize(spacingX, spacingY);
		rbMagHalf.setLocation(2*marginX+spacingX, marginY+spacingY*12);
		rbMagHalf.setVisible(true);
		rbMagHalf.addActionListener(actionListenerMagHalf);
		bgMag.add(rbMagHalf);
		
		rbMag1x = new JRadioButton();
		rbMag1x.setText("1X");
		rbMag1x.setSize(spacingX, spacingY);
		rbMag1x.setLocation(2*marginX+spacingX, marginY+spacingY*13);
		rbMag1x.setVisible(true);
		rbMag1x.addActionListener(actionListenerMag1x);
		bgMag.add(rbMag1x);
		
		rbMag2x = new JRadioButton();
		rbMag2x.setText("2X");
		rbMag2x.setSize(spacingX, spacingY);
		rbMag2x.setLocation(2*marginX+spacingX, marginY+spacingY*14);
		rbMag2x.setVisible(true);
		rbMag2x.addActionListener(actionListenerMag2x);
		bgMag.add(rbMag2x);
		
		rbMag4x = new JRadioButton();
		rbMag4x.setText("4X");
		rbMag4x.setSize(spacingX, spacingY);
		rbMag4x.setLocation(2*marginX+spacingX, marginY+spacingY*15);
		rbMag4x.setVisible(true);
		rbMag4x.addActionListener(actionListenerMag4x);
		bgMag.add(rbMag4x);
		
		rbMag8x = new JRadioButton();
		rbMag8x.setText("8X");
		rbMag8x.setSize(spacingX, spacingY);
		rbMag8x.setLocation(2*marginX+spacingX, marginY+spacingY*16);
		rbMag8x.setVisible(true);
		rbMag8x.addActionListener(actionListenerMag8x);
		bgMag.add(rbMag8x);
		
		
		ActionListener actionListenerButtonOkay = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cvt.productClassificationLabelStr = securityLabel.getText();
				cvt.productTitleLabelStr = titleLabel.getText();
				
				System.out.println("*** EXPORT GUI ***");
				
				for (int i=0; i<FORMAT_COUNT; i++){
					if (cvt.outputFormatMask[i] == true){
						System.out.println("FORMAT "+cvt.formatIDtoName(i));
					}
				}
				
				for (int i=0; i<MODE_COUNT; i++){
					if (cvt.outputModeMask[i] == true){
						System.out.println("MODE "+cvt.opIDtoName(i));
					}
				}
				
				cvt.exportVideoUI();

				System.out.println("*** EXPORT GUI ***");	
				// show status		
				buttonOkay.setEnabled(false);
				
				hideVideoExport();
			}
		};
		
		ActionListener actionListenerButtonCancel = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// send kill signal to export threads
				hideVideoExport();
			}
		};
		
		
		// video speed

		ButtonGroup bgSpeed = new ButtonGroup();
		
		rbSpeedHalf = new JRadioButton();
		rbSpeedHalf.setText("HALF");
		rbSpeedHalf.setSize(spacingX, spacingY);
		rbSpeedHalf.setVisible(true);
		rbSpeedHalf.setLocation(2*marginX+spacingX, marginY+spacingY);
		rbSpeedHalf.addActionListener(actionListenerSpeedHalf);
		bgSpeed.add(rbSpeedHalf);
		
		rbSpeed1x = new JRadioButton();
		rbSpeed1x.setText("1X");
		rbSpeed1x.setSize(spacingX, spacingY);
		rbSpeed1x.setVisible(true);
		rbSpeed1x.setLocation(2*marginX+spacingX, marginY+spacingY*2);
		rbSpeed1x.addActionListener(actionListenerSpeed1x);
		bgSpeed.add(rbSpeed1x);
		
		rbSpeed2x = new JRadioButton();
		rbSpeed2x.setText("2X");
		rbSpeed2x.setSize(spacingX, spacingY);
		rbSpeed2x.setVisible(true);
		rbSpeed2x.setLocation(2*marginX+spacingX, marginY+spacingY*3);
		rbSpeed2x.addActionListener(actionListenerSpeed2x);
		bgSpeed.add(rbSpeed2x);
		
		rbSpeed4x = new JRadioButton();
		rbSpeed4x.setText("4X");
		rbSpeed4x.setSize(spacingX, spacingY);
		rbSpeed4x.setVisible(true);
		rbSpeed4x.setLocation(2*marginX+spacingX, marginY+spacingY*4);
		rbSpeed4x.addActionListener(actionListenerSpeed4x);
		bgSpeed.add(rbSpeed4x);
		
		rbSpeed10x = new JRadioButton();
		rbSpeed10x.setText("10X");
		rbSpeed10x.setSize(spacingX, spacingY);
		rbSpeed10x.setVisible(true);
		rbSpeed10x.setLocation(2*marginX+spacingX, marginY+spacingY*5);
		rbSpeed10x.addActionListener(actionListenerSpeed10x);
		bgSpeed.add(rbSpeed10x);
		
		rbSpeed25x = new JRadioButton();
		rbSpeed25x.setText("25X");
		rbSpeed25x.setSize(spacingX, spacingY);
		rbSpeed25x.setVisible(true);
		rbSpeed25x.setLocation(2*marginX+spacingX, marginY+spacingY*6);
		rbSpeed25x.addActionListener(actionListenerSpeed25x);
		bgSpeed.add(rbSpeed25x);
		
		rbSpeed50x = new JRadioButton();
		rbSpeed50x.setText("50X");
		rbSpeed50x.setSize(spacingX, spacingY);
		rbSpeed50x.setVisible(true);
		rbSpeed50x.setLocation(2*marginX+spacingX, marginY+spacingY*7);
		rbSpeed50x.addActionListener(actionListenerSpeed50x);
		bgSpeed.add(rbSpeed50x);
		
		rbSpeed100x = new JRadioButton();
		rbSpeed100x.setText("100X");
		rbSpeed100x.setSize(spacingX, spacingY);
		rbSpeed100x.setVisible(true);
		rbSpeed100x.setLocation(2*marginX+spacingX, marginY+spacingY*8);
		rbSpeed100x.addActionListener(actionListenerSpeed100x);
		bgSpeed.add(rbSpeed100x);
		
		/*
		rbSpeedOther = new JRadioButton();
		rbSpeedOther.setText("OTHER");
		rbSpeedOther.setSize(spacingX, spacingY);
		rbSpeedOther.setVisible(true);
		rbSpeedOther.setLocation(2*marginX+spacingX, marginY+spacingY*9);
		rbSpeedHalf.addActionListener(actionListenerSpeedOther);
		bgSpeed.add(rbSpeedOther);
		*/
		
		// markings
		securityLabel = new JTextField();
		securityLabel.setText("// SECRET // OT&E PRODUCT - NOT TO BE USED FOR TARGETING OR DECISION SUPPORT //");
		securityLabel.setLocation(marginX, marginY+spacingY*19);
		securityLabel.setSize(marginX+spacingX*2, heightY);
		securityLabel.setVisible(true);
		
		titleLabel = new JTextField();
		titleLabel.setText("SBIRS HEO WB");
		titleLabel.setLocation(marginX, marginY+spacingY*21);
		titleLabel.setSize(marginX+spacingX*2, heightY);
		titleLabel.setVisible(true);
		
		// buttons
		buttonOkay = new JButton();
		buttonOkay.setSize(widthX, heightY);
		buttonOkay.setText("EXPORT");
		buttonOkay.setLocation(marginX, veui.getHeight()-60);
		buttonOkay.setVisible(true);
		buttonOkay.setMnemonic('e');
		buttonOkay.addActionListener(actionListenerButtonOkay);
		
		buttonCancel = new JButton();
		buttonCancel.setSize(widthX, heightY);
		buttonCancel.setText("CANCEL");
		buttonCancel.setLocation(2*marginX+spacingX, veui.getHeight()-60);
		buttonCancel.setVisible(true);
		buttonCancel.setMnemonic('c');
		buttonCancel.addActionListener(actionListenerButtonCancel);
		
		// labels
		labelSpeed = new JLabel();
		labelSpeed.setText("MOVIE SPEED");
		labelSpeed.setLocation(2*marginX+spacingX, marginY);
		labelSpeed.setSize(widthX, heightY);
		labelSpeed.setVisible(true);
		
		labelMag = new JLabel();
		labelMag.setText("MAGNIFICATION");
		labelMag.setLocation(2*marginX+spacingX, marginY+spacingY*11);
		labelMag.setSize(widthX, heightY);
		labelMag.setVisible(true);
		
		labelMode = new JLabel();
		labelMode.setText("IMAGE MODES");
		labelMode.setLocation(marginX, marginY);
		labelMode.setSize(widthX, heightY);
		labelMode.setVisible(true);

		labelFormat = new JLabel();
		labelFormat.setText("OUTPUT FORMATS");
		labelFormat.setLocation(marginX, marginY+spacingY*6);
		labelFormat.setSize(widthX, heightY);
		labelFormat.setVisible(true);
		
		labelSecMark = new JLabel();
		labelSecMark.setText("CLASSIFICATION MARKING");
		labelSecMark.setLocation(marginX, marginY+spacingY*18);
		labelSecMark.setSize(marginX+spacingX*2, heightY);
		//labelSecMark.setVisible(true);
		
		labelTitle = new JLabel();
		labelTitle.setText("TITLE");
		labelTitle.setLocation(marginX, marginY+spacingY*20);
		labelTitle.setSize(marginX+spacingX*2, heightY);
		
		// add components

		veui.add(cbLayerRaw);
		veui.add(cbLayerContrast);
		veui.add(cbLayerDiff);
		veui.add(cbLayerTimelapse);
		
		veui.add(cbVideoWmv);
		veui.add(cbVideoMpg);
		veui.add(cbVideoMp4);
		veui.add(cbImagePng);
		//veui.add(cbImageJpg);
	
		veui.add(rbSpeedHalf);
		veui.add(rbSpeed1x);
		veui.add(rbSpeed2x);
		veui.add(rbSpeed4x);
		veui.add(rbSpeed10x);
		veui.add(rbSpeed25x);
		veui.add(rbSpeed50x);
		veui.add(rbSpeed100x);
		
		veui.add(rbMagHalf);
		veui.add(rbMag1x);
		veui.add(rbMag2x);
		veui.add(rbMag4x);
		veui.add(rbMag8x);
		
		veui.add(labelMode);
		veui.add(labelFormat);
		veui.add(labelSpeed);
		veui.add(labelMag);
		
		veui.add(labelSecMark);
		veui.add(labelTitle);
		veui.add(securityLabel);
		veui.add(titleLabel);
		
		//veui.add(rbSpeedOther);
		
		//veui.add(securityLabel);

		veui.add(buttonCancel);
		veui.add(buttonOkay);
		
		
	}
	
	/*
	 * 
	static int outputModeMask[] = new int[MODE_COUNT];
	static int outputFormatMask[] = new int[FORMAT_COUNT];
	static String outputFormatExtStr[] = new String[FORMAT_COUNT];
	static float userVideoMagnification=1f;
	static float userVideoExportSpeed=1f;
	 */
	
	
	
	public static void showVideoExport(){
		// sync the prefs
		buttonOkay.setEnabled(true);
		
		// set mag rb
		if (cvt.userVideoMagnification == .5){
			rbMagHalf.setSelected(true);
		} else if (cvt.userVideoMagnification == 1){
			rbMag1x.setSelected(true);
		} else if (cvt.userVideoMagnification == 2){
			rbMag2x.setSelected(true);
		} else if (cvt.userVideoMagnification == 4){
			rbMag4x.setSelected(true);
		} else if (cvt.userVideoMagnification == 8){
			rbMag8x.setSelected(true);
		} 
		
		//set speed rb
		if (cvt.userVideoExportSpeed == .5){
			rbSpeedHalf.setSelected(true);
		} else if (cvt.userVideoExportSpeed == 1){
			rbSpeed1x.setSelected(true);
		} else if (cvt.userVideoExportSpeed == 2){
			rbSpeed2x.setSelected(true);
		} else if (cvt.userVideoExportSpeed == 4){
			rbSpeed4x.setSelected(true);
		} else if (cvt.userVideoExportSpeed == 10){
			rbSpeed10x.setSelected(true);
		} else if (cvt.userVideoExportSpeed == 25){
			rbSpeed25x.setSelected(true);
		} else if (cvt.userVideoExportSpeed == 50){
			rbSpeed50x.setSelected(true);
		} else if (cvt.userVideoExportSpeed == 100){
			rbSpeed100x.setSelected(true);
		} else {
			rbSpeedOther.setSelected(true);
		}
		
		// set mode cb
			cbLayerRaw.setSelected(cvt.outputModeMask[THREAD_LOAD_HDF5R]);
		
			cbLayerContrast.setSelected(cvt.outputModeMask[THREAD_CONTRAST]);
		
			cbLayerDiff.setSelected(cvt.outputModeMask[THREAD_DIFF]);
		
			cbLayerTimelapse.setSelected(cvt.outputModeMask[THREAD_TIMELAPSE]);
		
		
		// set format cb
			cbVideoWmv.setSelected(cvt.outputFormatMask[FORMAT_WMV]);
		
			cbVideoMpg.setSelected(cvt.outputFormatMask[FORMAT_MPG]);
		
			cbVideoMp4.setSelected(cvt.outputFormatMask[FORMAT_MP4]);
		
			cbImagePng.setSelected(cvt.outputFormatMask[FORMAT_PNG]);
		
			cbImageJpg.setSelected(cvt.outputFormatMask[FORMAT_JPG]);
		
		
		veui.setVisible(true);
	}
	
	public static void hideVideoExport(){
		veui.setVisible(false);
		
	}
	
	public static void getInput(){
		
	}
	
	public static void main(String args[]) {
		init();
		showVideoExport();
		while (true){
		}
		//v.setVisible(true);
	}
	
	public static void setupVideoExportUI(final String ext) {

		//this = new JFrame();
		//videoExportFrame.setLayout(null);

		int fw = 260;
		int fh = 130;
		//videoExportFrame.setSize(fw, fh);

		int inputX1 = 20;
		int inputX2 = 170;

		int inputY1 = 20;
		int inputY2 = 60;
		int inputY3 = 90;
		int inputY4 = 130;

		/*
		 * JButton go = new JButton(); go.setText("Okay");
		 * go.setLocation(inputX1, inputY1);
		 * 
		 * go.setForeground(Color.red); go.setSize(50, 20);
		 * go.addActionListener(l) go.setVisible(true); gpan.add(go);;
		 */

		// final JTextField jtf = new JTextField();

		// final JTextField jtfb = new JTextField();



		/*
		 * JLabel labGain = new JLabel();
		 * labGain.setText("Gain  (multiplicative)");
		 * 
		 * labGain.setLocation(inputX1, inputY1);
		 * 
		 * labGain.setForeground(Color.DARK_GRAY); labGain.setSize(150, 20);
		 * labGain.setVisible(true); videoExportFrame.add(labGain);;
		 * 
		 * JLabel labBoost = new JLabel();
		 * labBoost.setText("Boost  (additive)");
		 * labBoost.setForeground(Color.DARK_GRAY);
		 * labBoost.setLocation(inputX1, inputY2); labBoost.setSize(150, 20);
		 * labBoost.setVisible(true); gpan.add(labBoost);
		 * 
		 * 
		 * 
		 * jtf.setText(""+loadTimeGain); jtf.setLocation(inputX2, inputY1);
		 * jtf.setSize(50, 20); jtf.setVisible(true);
		 * jtf.addActionListener(ltGainActionListener); gpan.add(jtf);
		 * 
		 * jtfb.setText(""+loadTimeBoost); jtfb.setLocation(inputX2, inputY2);
		 * jtfb.setSize(50, 20); jtfb.setVisible(true);
		 * jtfb.addActionListener(ltBoostActionListener);
		 * videoExportFrame.add(jtfb);
		 * 
		 * videoExportFrame.setVisible(true);
		 * 
		 * gfra.setLocation(800, 0); gfra.add(videoExportFrame);
		 * gfra.setTitle("Load-time Gain + Boost"); gfra.setVisible(true);
		 */

	}
}
