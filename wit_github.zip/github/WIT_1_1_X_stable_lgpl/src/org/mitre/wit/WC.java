/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

package org.mitre.wit;
/**
 * @author Adrian Johnson <abjohnson@mitre.org>
 *
 */

public class WC {
	// WIT constants
	static final int THREAD_LOAD = 0;
	static final int THREAD_CONV = 1;
	static final int THREAD_FEAT = 2;
	static final int THREAD_THRS = 3;
	static final int THREAD_DIFF = 4;
	static final int THREAD_SEGMENT = 5;
	static final int THREAD_FILT = 6;
	static final int THREAD_MON = 7;
	static final int THREAD_EXPORT_VIDEO = 8;
	static final int THREAD_DEJITTER = 9;
	static final int THREAD_HISTOGRAM = 10;
	static final int THREAD_HISTOGRAM_EQ = 11;
	static final int THREAD_TEMPORAL = 12;
	static final int THREAD_DIFF_DJ = 13;
	static final int THREAD_DEJITTER_ADV = 14;
	static final int THREAD_CONTRAST = 15;
	static final int THREAD_LOAD_HDF5R = 16;
	static final int THREAD_EXPORT_IMAGES = 17;
	static final int THREAD_REGISTRATION = 18;
	static final int THREAD_EXPORT_MARKED_IMAGES = 19;
	static final int THREAD_LOAD_METADATA = 20;
	static final int THREAD_LOAD_GEOLOCATION = 21;
	static final int THREAD_FIX_GEOLOCATION = 22;
	static final int THREAD_SCAN_DIR_Y_OFFSET = 23;
	static final int THREAD_TIMELAPSE = 24;
	static final int THREAD_LOAD_HDF5R_STITCH = 25;
	static final int THREAD_MAP_OVERLAY = 27;
	static final int THREAD_PREFILTER = 28;
	static final int THREAD_STAT_FILTER = 29;
	
	static final int THREAD_GPU_FRAG_DIFF = 30;
	static final int THREAD_GPU_FRAG_PIPELINE = 31;
	static final int THREAD_GPU_DIFF_BATCH = 32;
	static final int THREAD_GPU_FRAG_CONTRAST = 33;
	static final int THREAD_GPU_FRAG_DWT = 34;
	static final int THREAD_GPU_FRAG_TIMELAPSE = 35;
	static final int THREAD_GPU_FRAG_BURNIN = 36;
	static final int THREAD_GPU_FRAG_HDR = 37;

	//static final int THREAD_EXPORT_KML_FOOTPRINT = 33;
	//static final int THREAD_EXPORT_KML_INTENSITIES = 34;

	static final int THREAD_EXPORT_PROJ_IMAGES = 38;
	static final int THREAD_EXPORT_WEATHER_VIDEO = 39;
	static final int THREAD_IDLE = -1;

	static final int MODE_COUNT = 40;
	
	// widgets enabled
	static final int MAX_WIDGETS = 10;
	static final int WIDGET_HISTOGRAM = 1;
	static final int WIDGET_MINIMAP = 2;
	static final int WIDGET_MINIGLOBE = 3;
	static final int WIDGET_VIDEO_EXPORT = 4;
	static final int WIDGET_PLOT_TOOL = 5;
	static final int WIDGET_GLSL_TOOL = 6;
	
	// ui

	static final int CONTRAST_UI_SPECIAL_EDIT_NONE = 0;
	static final int CONTRAST_UI_SPECIAL_EDIT_MOVE_ALL = 1;
	static final int CONTRAST_UI_SPECIAL_EDIT_SHRINK = 2;
	//static final int CONTRAST_UI_HARD_LIMIT = 1024;////330;
	static final int CONTRAST_UI_HARD_LIMIT = 2048;//512;//1024*4;//Short.MAX_VALUE;////330;
	static final int CONTRAST_DATA_RANGE_HARD_LIMIT = Short.MAX_VALUE;
	static final float CONTRAST_RANGE_SCALE_SHIM = 16f; // make up for loss of precision xfering short->float for GPU tex
	
	// render constants
	static final float GLOBE_RADIUS = 1f;
	static final float SENSOR_PLANE_SCALE = .000004f*32f;
	
	static final int MAX_SAT_GROUND_TRACE_POINTS = 1000;
	//

	static final int UI_STATE_VIEW = 0;
	static final int UI_STATE_SCA_SELECT = 1;
	static final int UI_STATE_CONTRAST = 2;
	static final int UI_STATE_MINI_MAP = 3;
	static final int UI_STATE_PAN_VIEW = 4;
	static final int UI_STATE_VIDEO_EXPORT = 5;
	static final int UI_STATE_PROCESS_WINDOW = 6;
	static final int UI_STATE_TIMELINE_LOAD = 7;
	static final int UI_STATE_TIMELINE_SELECT = 8;
	static final int UI_STATE_CONTRAST_ZOOM_IN = 9;
	static final int UI_STATE_CONTRAST_ZOOM_OUT = 10;
	static final int UI_STATE_GLOBE_ROTATE = 12;
	static final int UI_STATE_LOS_ROTATE = 13;
	
	static final int UI_STATE_KNOB_LOAD = 14;
	static final int UI_STATE_KNOB_SKIP = 15;
	static final int UI_STATE_KNOB_BURST = 16;

	static final int UI_STATE_DRAG_VIEW = 17;
	static final int UI_STATE_OTHER = 20;
	
	// skip 
	static final int SNIPPET_SECONDS_LOAD = 5;
	static final int SNIPPET_SECONDS_PLAYBACK = 10;
	
	static final float SKIP_SECONDS_PLAYBACK_MIN = 1f/512f;
	static final float SKIP_SECONDS_PLAYBACK_MAX = 2048;
	
	// hist
	
	static final int HIST_BINS = (int) Math.pow(2,15)-1;
	
	// gpu
	static final int BUFFER_POS =0;
	static final int BUFFER_COL =1;
	
	static final int VBO_VERTICES =0;
	static final int VBO_VERTICES_INTERP=1;
	static final int VBO_COLORS =2;
	static final int VBO_COLORS_PROCESSED =3;
	static final int VBO_MODE_MAX=4;
	
	//static final int VBO_SIZE_X = 384;//12;//384;//12;//96;
	//static final int VBO_SIZE_Y = 384;//12;//384;//12;//96;
	
	static final int VBO_COLOR_COMPONENTS =3;
	static final int VBO_VERTEX_COMPONENTS =3;
	
	static final int COLOR_SCHEME_GRAYSCALE =0;
	static final int COLOR_SCHEME_HEATMAP =1;
	static final int COLOR_SCHEME_COUNT =2;
	
	
	
	static final int FRAG_PROGRAM_DWT = 0;
	static final int FRAG_PROGRAM_CONTRAST = 1;
	static final int FRAG_PROGRAM_DIFF = 2;

	static final int FRAG_PROGRAM_HDR = 3;
	//static final int FRAG_PROGRAM_DIFF_ACCUM = 3;
	static final int FRAG_PROGRAM_COUNT= 4;
	
	static final int DWT_BUFFER_COUNT = 15;
	static final int FRAG_PROGRAM_KERNEL_SIZE_XY = 5;
	
	static final int GLUI_CONTROLS_CONTRAST_OFF = 0;
	static final int GLUI_CONTROLS_CONTRAST_ON = 1;
	static final int GLUI_CONTROLS_CONTRAST = 2;
	
	// coords
	static final int COORDINATES_SENSOR =0;
	static final int COORDINATES_GLOBE =1;
	static final int COORDINATES_MERCATOR =2;
	static final int COORDINATES_WIT_UI_OLDSCHOOL =4;
	static final int COORDINATES_GLOBE_SENSOR =3;
	static final int COORDINATES_MODE_MAX=3; // skip old school for now
	
	// performance
	static final int THREAD_TIMEOUT_DEFAULT = 10000;
	static final int THREAD_PRIORITY_DEFAULT = 1;
	
	static final int THREAD_SCHEME_BATCH =0;
	static final int THREAD_SCHEME_PLAYHEAD =0;
	
	// SCA items
	static final int FLIGHT_ID_BASE = 33;
	static final int TOTAL_FLIGHTS = 2;
	static final int TOTAL_SCAS = 8;
	static final int SCA_Y_OFFSET = 0
	static final int SCA_CHANNELS = 800
	static final int SCA_SCAN_SEGMENT_LINES = 800
	static final int SCA_MAX_SCAN_SEGMENTS = 6;
	static final int SCA_MAX_DRAW_SEGMENTS = SCA_MAX_SCAN_SEGMENTS * 2;// allow multiple
															// scans to be
															// overlaid
	static final int SCA_MAX_SCAN_LENGTH = 2000;

	static final int SCA_X_OVERLAP = 16;// 20;
	static final int SCA_Y_RASTER_OFFSET = 20;
	
	static final int SCID_BASE_OFFSET = 33;
	
	// scan constants - can change to named
	static final int SCAN_SEQ_INDEX_MAX_VAL = 256;//Integer.MAX_VALUE;
	//static final int SCAN_SEQ_INDEX_MAX_VAL_UI = 11;
	
	// kernels

	static int KERNEL_SHARPEN1 = 0;
	static int KERNEL_BLUR1 = 1;
	static int KERNEL_WAVELET1 = 2;
	static int KERNEL_WAVELET2 = 3;
	static int KERNEL_WAVELET3 = 4;
	static int KERNEL_COUNT = 5;
	
	// system

	static final int SYSTEM_STATE_OFFLINE = 0;
	static final int SYSTEM_STATE_ONLINE = 1;
	
	//
	static final int CURRENT = 0;
	static final int GOAL = 1;
	
	//
	static final int X = 0;
	static final int Y = 1;
	static final int Z = 2;
	static final int T = 3;

	static final int R = 0;
	static final int G = 1;
	static final int B = 2;
	static final int A = 3;

	static final int W = 2;//2
	static final int H = 3;//3

	static final int START = 0;
	static final int END = 1;
	
	//
	// geolocation
	static final int GEODATA_LON = 0;
	static final int GEODATA_LAT = 1;
	
	static final int GEODATA_UL = 0;
	static final int GEODATA_UR = 1;
	static final int GEODATA_LR = 2;
	static final int GEODATA_LL = 3;

	//
	static final int SCAN_SELECT_ALL = 2;
	static final int SCAN_SELECT_EVEN = 0;
	static final int SCAN_SELECT_ODD = 1;
	//

	static final int MISSING_ITEM_GEOLOCATION = 0;
	static final int MISSING_ITEM_TIME = 1;
	static final int MISSING_ITEM_INTENSITIES = 2;
	
	// 
	static final int COLOR_GL_HIST_FOCUS = 0; // median/mean
	static final int COLOR_GL_HIST_IN = 1;
	static final int COLOR_GL_HIST_OUT = 2;
	static final int COLOR_GL_ACCENT1 = 3;
	static final int COLOR_GL_ACCENT2 = 4;
	static final int COLOR_GL_ACCENT3 = 5;
	static final int UI_GL_COLOR_COUNT =6;
	
	// UI colors
	static final int COLOR_TIVO_PLAYHEAD = 0;
	static final int COLOR_TIVO_SELECTION_WORKING = 1;
	static final int COLOR_TIVO_SELECTION_COMPLETE = 2;
	static final int COLOR_TIVO_ACCENT1 = 2;
	static final int COLOR_TIVO_ACCENT2 = 3;
	static final int COLOR_TIVO_PLAYHEAD_PEER = 4;
	static final int COLOR_TIVO_PLAYHEAD_LOCKED = 5;
	static final int COLOR_HIST_IN = 6;
	static final int COLOR_HIST_OUT = 7;
	static final int COLOR_TIVO_FILTER_REGION_WORKING = 8;
	static final int COLOR_TIVO_FILTER_REGION_COMPLETE = 9;

	static final int COLOR_TIVO_TIMELINE_EMPTY = 10;
	static final int COLOR_TIVO_TIMELINE_READY = 11;
	static final int COLOR_TIVO_TIMELINE_WORKING = 12;
	static final int COLOR_TIVO_TIMELINE_COMPLETE = 13;
	static final int COLOR_TIVO_TIMELINE_MISSING_GEOLOCATION = 14;
	static final int COLOR_TIVO_TIMELINE_MISSING_TIME = 15;
	static final int COLOR_TIVO_TIMELINE_MISSING_INTENSITIES = 16;
	
	static final int COLOR_TIVO_TEXT_HEADER = 19;

	static final int COLOR_TIVO_SCA_SELECT_ON = 20;
	static final int COLOR_TIVO_SCA_SELECT_OFF = 21;
	static final int COLOR_TIVO_SCA_SELECT_SWIR = 22;
	static final int COLOR_TIVO_SCA_SELECT_MWIR = 23;
	static final int COLOR_TIVO_SCA_SELECT_STG = 24;

	static final int COLOR_TIVO_TIMELINE_CALLOUT1 = 30;
	static final int COLOR_TIVO_TIMELINE_EVENT_INFO = 31;	// needs operator review
	static final int COLOR_TIVO_TIMELINE_EVENT_OLD = 32;	// event has been reviewed
	static final int COLOR_TIVO_TIMELINE_EVENT_NEW = 33;	// event has been reviewed
	static final int COLOR_TIVO_TIMELINE_EVENT_P1 = 34;	// event has been reviewed
	static final int COLOR_TIVO_TIMELINE_EVENT_P2 = 35;	// event has been reviewed
	static final int COLOR_TIVO_TIMELINE_EVENT_P3 = 36;	// event has been reviewed
	static final int COLOR_TIVO_TIMELINE_EVENT_P4 = 37;	// event has been reviewed
	static final int COLOR_TIVO_TIMELINE_EVENT_P5 = 38;	// event has been reviewed
	
	static final int COLOR_TIVO_TIMELINE_EVENT_SELECTED_INFO = 40;
	static final int COLOR_TIVO_TIMELINE_EVENT_SELECTED_REAL = 41;

	static final int COLOR_TIVO_SELECTION_TIME = 50;
	
	static final int UI_COLOR_COUNT = 60;
	
	// overlay
	static final int OVERLAY_GLOBE_BOUNDARIES = 0;
	static final int OVERLAY_GLOBE_CITIES = 1;
	static final int OVERLAY_GLOBE_TRANSPORT = 2;
	static final int OVERLAY_GLOBE_LINES = 5;
	static final int OVERLAY_GLOBE_COUNT = 10;
		
	
	// timeline
	static final int TIMELINE_UPDATE_NONE =0;
	static final int TIMELINE_UPDATE_ALL = 1;
	static final int TIMELINE_UPDATE_PROGRESS =2;
	static final int TIMELINE_UPDATE_RESET =9;


	// passed from playback
	static final int SCAN_DIR_UNKNOWN = -1;
	static final int SCAN_DIR_EVEN = 0;
	static final int SCAN_DIR_ODD = 1;
	static final int SCAN_DIR_BOTH = 2;

	// masks
	static short INVALID_DATA_MASK = (short) -1;
	static final int INVALID_GEOLOCATION = -9999;

	// stats
	static final int STATS_MIN = 0;
	static final int STATS_Q1 = 1;
	static final int STATS_Q2 = 2;
	static final int STATS_Q3 = 3;
	static final int STATS_MAX = 4;
	static final int STATS_MIN_BIN = 5;
	static final int STATS_MAX_BIN = 6;

	static final int CONTRAST_OFF = 0;
	static final int CONTRAST_GAIN = 1;
	static final int CONTRAST_CURVES = 2;
	static final int CONTRAST_AUTO = 3;
	static final int CONTRAST_WINDOW = 4;
	static final int CONTRAST_USER = 5;
	
	// status

	static final int THREAD_STATUS_ERROR = -1;
	static final int THREAD_STATUS_READY = 0;
	static final int THREAD_STATUS_QUEUED = 1;
	static final int THREAD_STATUS_WORKING = 2;
	static final int THREAD_STATUS_COMPLETE = 3;
	static final int THREAD_STATUS_INCOMPLETE = 4;

	static final int STATUS_ERROR = -1;
	static final int STATUS_READY = 0;
	static final int STATUS_QUEUED = 1;
	static final int STATUS_WORKING = 2;
	static final int STATUS_COMPLETE = 3;
	static final int STATUS_INCOMPLETE = 4;
	
	static final int STATUS_ON = 1;
	static final int STATUS_OFF = 0;

	// info + EVENT
	static final int EVENT_DETECTOR_OPERATOR =0;
	static final int EVENT_DETECTOR_AUTO_METADATA_MAGNITUDE =1;
	static final int EVENT_DETECTOR_AUTO_METADATA_DELTA =2;
	static final int EVENT_DETECTOR_AUTO_TEMPORAL =3;
	static final int EVENT_DETECTOR_AUTO_LOCATION_THRESHOLD =4;
	static final int EVENT_DETECTOR_AUTO_METADATA_INFO =5; // includes data start/stop
	static final int EVENT_FALSE_DETECT = -1;
	static final int EVENT_ERROR = -1; //used for init
	
	static final int EVENT_UNKNOWN = 0;

	static final int EVENT_DATA_FEED =6; // dropped metadata, data region start/stop

	static final int INFO_ERROR = -1;
	static final int INFO_EVENT = 1;
	
	// processing

	static final int MAX_DETECTORS = 10;	// flag all the detectors that triggered

	// product formats
	static final int FORMAT_COUNT = 30;
	static final int FORMAT_MPG = 0;
	static final int FORMAT_MP4 = 1;
	static final int FORMAT_MP4_H264=2;
	static final int FORMAT_WMV = 3;
	static final int FORMAT_PNG=10;
	static final int FORMAT_JPG=11;
	static final int FORMAT_GEOTIFF=12;
	
	// product options
	static final int OPTION_COUNT = 4;
	static final int OPTION_VIDEO_LOOP = 0;
	
	static final int MAX_VIDEO_FRAMES = 99999;
	
	// time constants
	static final int TOTAL_HOURS = 25; // wrap around midnight
	static final int MIN_IN_DAY = 60 * 24;
	static final int SEC_IN_DAY = 60 * 60 * TOTAL_HOURS;
	static final int SEC_IN_HOUR = 60 * 60;
	static final int HOUR_TICK_OFFSET = 60 * 60;
	static final int TEN_MIN_TICK_OFFSET = 10 * 60;
	
	// ui amenities
	static final int UI_LOAD_TRIGGER_TIMER = 10;

	// load styles
	static final int LOAD_FILE_CHOOSER = 0;
	static final int LOAD_FILE_RECENT = 1;
	static final int LOAD_SOCKET = 2;
}
