/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

package org.mitre.wit;

/**
 * @author Adrian Johnson <abjohnson@mitre.org>
 *
 */
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.util.ArrayList;


public class TimelineDrawThread extends Thread {

	static Graphics2D timelineGraphics;
	static int timelineImageUpdateFlag = 0;
	
	static Color statusColors[] = new Color[WC.MODE_COUNT];
	static Color uiColors[] = new Color[WC.UI_COLOR_COUNT];

	static int timelineImageW = WC.SEC_IN_DAY;
	static int timelineImageH = 100;
	
	static Composite graphicComposites[];
	static int c_WORKING;
	static int c_WIDGET;
	static int c_LOOP_SELECTION;
	static int c_COMPLETE;
	static int c_LATLON_OVERLAY;
	static int c_raster;
	
	static String threadIndentStr = "      OP UPDATE: ";

	// masks
	static short INVALID_DATA_MASK = (short) -1;
	static int INVALID_GEOLOCATION = -9999;

	static ArrayList witFrameList[][] = new ArrayList[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];
	static int witLoadListSizePrev[][] = new int[WC.TOTAL_FLIGHTS][WC.TOTAL_SCAS];

	static int dataLoadStatus[][][] = new int[2][WC.TOTAL_SCAS][WC.SEC_IN_DAY]; // flight,
	static int dataLoadInfo[][][] = new int[2][WC.TOTAL_SCAS][WC.SEC_IN_DAY]; 
	static int dataLoadScanSegment[][][] = new int[2][WC.TOTAL_SCAS][WC.SEC_IN_DAY]; 

	static int histWindowH = 255;
	static int histAdjustHandleSize = 20;

	static int tivoStatusBarTickX = 1;// 5;
	static int tivoStatusBarTickYmaster = 24;// 5;
	static int tivoStatusBarTickY = 8;// 5;
	static int tivoStatusBarTickYsliver = 3;// 5;
	static int tivoBarYSeparation = tivoStatusBarTickY + 1 + 5;
	
	///
	
	static int userFlight = 0;
	//
	
	int frameStart;
	int frameStop;
	
	int mode;
	
	ArrayList paramList = new ArrayList();
	
	static int threadStatus = WC.THREAD_STATUS_READY;

	static int frameCount =10;
	static WITFrame tf[];// = new TivoFrame[frameCount];
	static ArrayList wfl;
	
	String name;
	
	static Graphics2D gMain;
	
    public TimelineDrawThread() {

    	
    }
        
        @Override
		public void run() {

        }
        
        public void processFrames(){
        
        }


        public static void drawTimelineImage() {

        	if (graphicComposites!=null){
        	
    		int timelineOffsetY = 22;

    		for (int sat = 0; sat < 2; sat++) {
    			
    			int yOffsetSat = 0;// 0;//timelineLayerOrder[j][Y];

    			if (sat > 0) {
    				yOffsetSat = 30;
    			}


    			if (timelineImageUpdateFlag == WC.TIMELINE_UPDATE_ALL){
    			timelineGraphics.setComposite(graphicComposites[c_COMPLETE]);
    			timelineGraphics.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_EMPTY]);
    			for (int i = 0; i < WC.SEC_IN_DAY; i++) {
    				for (int s = 0; s < WC.TOTAL_SCAS; s++) {
    					if (dataLoadStatus[sat][s][i] == WC.STATUS_ERROR) {
    						int tickXpos = i * tivoStatusBarTickX;// +(int)userTimelineOffset[CURRENT];

    						
    						timelineGraphics.fillRect(tickXpos, timelineOffsetY
    								+ yOffsetSat + (s * tivoStatusBarTickYsliver),
    								tivoStatusBarTickX,
    								tivoStatusBarTickYsliver - 1);

    					}
    				}
    			}
    			// overdraw with candidate data
    			timelineGraphics
    			.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_READY]);
    			for (int i = 0; i < WC.SEC_IN_DAY; i++) {
    				for (int s = 0; s < WC.TOTAL_SCAS; s++) {
    					if (dataLoadStatus[sat][s][i] == WC.STATUS_READY) {
    						int tickXpos = i * tivoStatusBarTickX;// +(int)userTimelineOffset[CURRENT];
    						
    						timelineGraphics.fillRect(tickXpos, timelineOffsetY
    								+ yOffsetSat + (s * tivoStatusBarTickYsliver),
    								tivoStatusBarTickX,
    								tivoStatusBarTickYsliver - 1);

    					}
    				}
    			}
    			// overdraw with loading data
    			timelineGraphics
    			.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_WORKING]);
    			for (int i = 0; i < WC.SEC_IN_DAY; i++) {
    				for (int s = 0; s < WC.TOTAL_SCAS; s++) {
    					if (dataLoadStatus[sat][s][i] == WC.STATUS_WORKING) {
    						int tickXpos = i * tivoStatusBarTickX;// +(int)userTimelineOffset[CURRENT];
    						
    						timelineGraphics.fillRect(tickXpos, timelineOffsetY
    								+ yOffsetSat + (s * tivoStatusBarTickYsliver),
    								tivoStatusBarTickX,
    								tivoStatusBarTickYsliver - 1);

    					}
    				}
    			}
    			}
    			
    			// check the SCA lists
    			if (timelineImageUpdateFlag == WC.TIMELINE_UPDATE_PROGRESS){
    				for (int flight=0; flight<WC.TOTAL_FLIGHTS; flight++){
    			for (int k=0; k<WC.TOTAL_SCAS; k++){
    				if (witFrameList[flight][k] != null){
    					int lastSize = witLoadListSizePrev[flight][k];
    					lastSize = lastSize;
    					if (lastSize<0)lastSize=0;
    					witLoadListSizePrev[flight][k] = witFrameList[flight][k].size();
    				for (int i=lastSize; i<witLoadListSizePrev[flight][k]; i++){
    					WITFrame w = (WITFrame)witFrameList[flight][k].get(i);
    					int secs = w.timeStampSecOfDay;
    					dataLoadStatus[userFlight][k][secs] = WC.STATUS_COMPLETE;
    					if (w.beginLine==0){
    						dataLoadScanSegment[userFlight][k][secs] = 0;
    					} else {
    						dataLoadScanSegment[userFlight][k][secs] = 1;
    					}
    				}
    				}
    			}
    			}

    			// overdraw with loaded data
    			//timelineGraphics.setColor(Color.orange);
    			for (int i = 0; i < WC.SEC_IN_DAY; i++) {
    				for (int s = 0; s < WC.TOTAL_SCAS; s++) {
    					if (dataLoadStatus[sat][s][i] == WC.STATUS_COMPLETE) {
    						
    						if (dataLoadScanSegment[sat][s][i] ==0){
    			    			timelineGraphics.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_COMPLETE]);
    						} else {
    			    			timelineGraphics.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_CALLOUT1]);
    						}
    						int tickXpos = i * tivoStatusBarTickX;// +(int)userTimelineOffset[CURRENT];
    						
    						
    						
    						timelineGraphics.fillRect(tickXpos, timelineOffsetY
    								+ yOffsetSat + (s * tivoStatusBarTickYsliver),
    								tivoStatusBarTickX,
    								tivoStatusBarTickYsliver - 1);

    					}
    				}
    			}
    			}
    		
    			// overlay the time markers
    			for (int i = 0; i < WC.SEC_IN_DAY + 1; i += WC.TEN_MIN_TICK_OFFSET) {
    				int tickXpos = i * tivoStatusBarTickX;// +(int)userTimelineOffset[CURRENT];

    				timelineGraphics.setColor(Color.green);
    				timelineGraphics.fillRect(tickXpos, timelineOffsetY
    						+ yOffsetSat, tivoStatusBarTickX,
    						tivoStatusBarTickYmaster);

    				int hour = i / (WC.SEC_IN_HOUR);
    				String hourStr = hour + "";
    				if (hour < 10) {
    					hourStr = "0" + hour;
    				}
    				int min = (i - hour * WC.SEC_IN_HOUR) / (60);
    				String minStr = "" + min;
    				if (min < 10)
    					minStr = "0" + minStr;
    				hourStr += ":" + minStr + ":00";
    				if (sat == 0) { // only label timeline for one flight
    					timelineGraphics.drawString(hourStr, tickXpos + 10,
    							timelineOffsetY + yOffsetSat - 10);
    				}

    			}
    			
    			// overdraw with events

    			if (timelineImageUpdateFlag == WC.TIMELINE_UPDATE_PROGRESS){
    			for (int i = 0; i < WC.SEC_IN_DAY; i += 1) {
    				for (int s = 0; s < WC.TOTAL_SCAS; s++) {
    					if (dataLoadInfo[sat][s][i] == WC.INFO_EVENT) {
    						
    			    			timelineGraphics.setColor(uiColors[WC.COLOR_TIVO_TIMELINE_EVENT_NEW]);
    						
    						int tickXpos = i * tivoStatusBarTickX;// +(int)userTimelineOffset[CURRENT];
    						
    						timelineGraphics.fillRect(tickXpos, timelineOffsetY
    								+ yOffsetSat + (s * tivoStatusBarTickYsliver),
    								tivoStatusBarTickX,
    								tivoStatusBarTickYsliver - 1);
    					}
    				}
    			}
    			}
    		}

    		timelineImageUpdateFlag = WC.TIMELINE_UPDATE_NONE;
        	}
    	}    
}
