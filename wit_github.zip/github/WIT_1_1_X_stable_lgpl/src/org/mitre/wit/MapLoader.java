/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

package org.mitre.wit;

/**
 * @author Adrian Johnson <abjohnson@mitre.org>
 *
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class MapLoader {
	
	static ArrayList coordList = new ArrayList();
	
	public static void loadBoundaryList(String pathName){
		ArrayList segmentList = new ArrayList();
		
		try{
			
		
		BufferedReader bin = new BufferedReader(
				new FileReader(pathName));

		// load the file
		String fileContents = "";

		int segmentID = -1;
		
		while (bin.ready()) {
			String ln = bin.readLine();
			
			if (ln.contains("segment")){
				segmentID++;
			}
			
			if (!ln.contains("segment")){
			
			
			int period1 = ln.indexOf(".");
			int period2 = ln.indexOf(".", period1+1);
			
			int space1 = ln.indexOf(" ", period1);

			String latStr = ln.substring(1, space1);//+"0";
			String lonStr = ln.substring(space1+1, ln.length());//+"0";
			
			MapCoord mc = new MapCoord();
			
			// look at BigDecimal - not floats!
			
			mc.lat = Float.parseFloat(latStr);
			mc.lon = Float.parseFloat(lonStr);
			
			mc.segID = segmentID;

			//System.out.println(ln+" :: !"+latStr+"! !"+lonStr+"!"+" :: "+mc.lat+" "+mc.lon);
			
			if (segmentList.size() == 0){
				mc.segmentName = pathName;
			}
			
			segmentList.add(mc);
			//if (segmentList.size()%100000 == 0){
			//	System.out.println(segmentList.size()+" coords");
			//}
			}
		}
		
		// add the segment to the master list
		coordList.add(segmentList);
		
		} catch (Exception e){
			e.printStackTrace();
		}
	}
	
	public static void drawFeatures(WITFrame w){
		// use a full interpolation to now draw the boundaries...
		
	}

}
