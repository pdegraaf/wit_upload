/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

package org.mitre.wit;
/**
 * @author Adrian Johnson <abjohnson@mitre.org>
 *
 */

import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class WITFrame {
	
	int scaID=-1;
	int satID=-1;
	
	long WITFrameID = -1;
	
	static int GEODATA_LON=0;
	static int GEODATA_LAT=1;
	
	int tileSizeX = 48;
	int tileSizeY = 48;
	
	static int MODE_COUNT= 50;
	
	int framesInFile=0;
	int frameStatus=-1;
	
	//int glDrawListStatus = WC.STATUS_READY;
	int glTexStatus = WC.STATUS_READY;
	//int glDrawListID = WC.STATUS_ERROR;
	int glDrawListStatusPerCoordinateSystem[] = new int[WC.COORDINATES_MODE_MAX];
	int glDrawListIdPerCoordinateSystem[] = new int[WC.COORDINATES_MODE_MAX];
	
	int minCalIntensityFrame =0;
	int maxCalIntensityFrame =4096; // defaults

	int[] missingDataItems = new int[3];	// flag missing geolocation and other items
	
	int layerSCAstatus[] = new int[8];	// more detailed status on data loading
	
	ArrayList[] SCAcoordBounds = new ArrayList[8];
		
	int layerStatus[] = new int[MODE_COUNT];
	BufferedImage biRay[] = new BufferedImage[MODE_COUNT];
	int layerOffet[][] = new int[MODE_COUNT][2];	// x y offset of a layer
	
	int scanDirection = WC.SCAN_DIR_UNKNOWN;	// init to -1 to know if this has been explicitly set
	int scanSeqIndex = WC.STATUS_ERROR;
	
	String timeStampStr = "";
	int timeStampSecOfDay = 0;
	int timeStampSec = 0;
	int timeStampMin = 0;
	int timeStampHour = 0;
	int timeStampDay = 0;
	String timeStampStrKML = "";
	String timeStampStrKMLExpire = ""; // by default, put an expiration of 1 minute
	
	long lastTimeViewed = 0;	// store the last time this frame was used for the WIT tool, so we can start dropping infrequently viewed frames
	
	int histogram[];
	int histMaxBin=0;	// use for normalize view
	int histMinBin=0;
	static int histBins = WC.CONTRAST_UI_HARD_LIMIT;//(int) Math.pow(2, 14) - 1; 
	
	int[] histStats = new int[7];	// min, q1, q2, q3, max; minCount, maxCount
	
	int width = 0;
	int height = 0;
	int totalPixels = 0;
	
	// use these to traverse the sequence of data and more easily drop frames we don't need
	int nextWITFrame = -1;
	int prevWITFrame = -1;
	
	int beginLine = 0;
	int endLine = 0;
	int numLines = 0;	// actual number of scans
	
	int numChannels = 768;
	
	int linesReversed =0;
	int chansReversed = 0;
	
	int overscanSegment = 0;
	int fileBorderFrame = 0;	// first/last frame in a file
	int dayBorderFrame = 0;
	
	short hdrValsRaw[][];	// full dynamic range ints, used to re-generate the raster
	//short hdrValsFinal[][];
	
	int jitterWholePx[] = new int[3];	// simple translation jitter correction
	
	int jitterWholePxTiles[][];

	float geoLocDataCorners[][];
	float geoLocDataSparse[][][]; //  x, y, (lon/lat)
	int geoLocXskip = 12;
	int geoLocYskip = 12;
	int geoLocSparseRows = 64;
	int geoLocSparseCols = 64;
	float geoLocDataFull[][][];	// for the raster
	
	int yAlignGross = 0; // use this for massive y alignment difference for even/odd frames...use other variables for fine alignment
	
	int jitterSubPx[] = new int[3];
	
	float scaLatMin[] = new float[8];
	float scaLatMax[] = new float[8];
	float scaLonMin[] = new float[8];
	float scaLonMax[] = new float[8];
	
	float scanBounds[][] = new float[2][4]; // clockwise from UL LAT/LON UL/UR/LR/LL
	float scanBoundsEcf[][] = new float[3][4]; // clockwise from UL LAT/LON UL/UR/LR/LL
	int offEarthFlag=0;
	float UL_lat=0;
	float UR_lat=0;
	float LL_lat=0;
	float LR_lat=0;
	float UL_lon=0;
	float UR_lon=0;
	float LL_lon=0;
	float LR_lon=0;
	
	float focusLat = 0;
	float focusLon = 0;
	
	ArrayList jitterScanlines = new ArrayList();	// transforms per scanline
	
	ArrayList witFrameTiles = new ArrayList();
	int tileState = WC.STATUS_READY;
	int tileGPUoptimizationState = WC.STATUS_READY; // turn to COMPLETE when all VBOs are created for all tiles
	
	ArrayList bookmarkList = new ArrayList();
	
	String footprintKML;
	
	double satPosECF[] = new double[3];
	double satVelECF[] = new double[3];
	
	ArrayList polyPointList = new ArrayList();
	
	
}
