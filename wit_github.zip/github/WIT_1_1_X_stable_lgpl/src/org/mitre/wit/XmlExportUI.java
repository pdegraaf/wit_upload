/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

package org.mitre.wit;
/**
 * @author Adrian Johnson <abjohnson@mitre.org>
 *
 */
import java.awt.Color;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class XmlExportUI extends JFrame{


	static XmlExportUI glsleui;
	static CV_MT_Disp cvt = null;
	
	TextArea glslText = new TextArea();
	
	static Font codeFont;
	
	int uiW = 600;
	int uiH = 800;
	int uiBorder = 10;
	
	int buttonW = 200;
	int buttonH = 30;
	
	int uiTextW = uiW - uiBorder;
	int uiTextH = uiH-3*uiBorder-buttonH;
	
	JButton buttonCompile;
	JButton buttonLoad;
	JButton buttonSave;
	
	public static void init(){
		
		ActionListener actionListenerButtonCompileAndLink = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				glsleui.send();
			}
		};
		
		ActionListener actionListenerButtonSave = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				glsleui.doSave();
			}
		};
		ActionListener actionListenerButtonLoad = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				glsleui.doLoad();
			}
		};
		
		
		glsleui = new XmlExportUI();
		glsleui.setLayout(null);
		glsleui.setSize(glsleui.uiW, glsleui.uiH);
		glsleui.glslText = new TextArea();
		glsleui.glslText.setBackground(Color.black);
		glsleui.glslText.setForeground(Color.white);

		glsleui.glslText.setText("POLYGON XML");
		glsleui.glslText.setVisible(true);
		glsleui.glslText.setSize(glsleui.uiTextW, glsleui.uiTextH);
		glsleui.add(glsleui.glslText);
	
		glsleui.buttonCompile = new JButton();
		glsleui.buttonCompile.setVisible(true);
		glsleui.buttonCompile.setEnabled(true);
		glsleui.buttonCompile.setLocation(glsleui.buttonW, glsleui.uiTextH);
		glsleui.buttonCompile.setSize(glsleui.buttonW, glsleui.buttonH);
		glsleui.buttonCompile.setText("SEND MESSAGE");
		glsleui.buttonCompile.setEnabled(false);
		glsleui.buttonCompile.addActionListener(actionListenerButtonCompileAndLink);
		glsleui.add(glsleui.buttonCompile);
		
		glsleui.buttonSave = new JButton();
		glsleui.buttonSave.setVisible(true);
		glsleui.buttonSave.setEnabled(true);
		glsleui.buttonSave.setLocation(2*glsleui.buttonW, glsleui.uiTextH);
		glsleui.buttonSave.setSize(glsleui.buttonW, glsleui.buttonH);
		glsleui.buttonSave.setText("SAVE XML");
		glsleui.buttonSave.addActionListener(actionListenerButtonSave);
		glsleui.add(glsleui.buttonSave);
		
		glsleui.buttonLoad = new JButton();
		glsleui.buttonLoad.setVisible(true);
		glsleui.buttonLoad.setEnabled(true);
		glsleui.buttonLoad.setLocation(0, glsleui.uiTextH);
		glsleui.buttonLoad.setSize(glsleui.buttonW, glsleui.buttonH);
		glsleui.buttonLoad.setText("LOAD XML");
		glsleui.buttonLoad.addActionListener(actionListenerButtonLoad);
		glsleui.add(glsleui.buttonLoad);
		
		//glsleui.setVisible(true);
	}
	
	public void doSave(){
		JFileChooser fc = new JFileChooser();
		fc.setApproveButtonText("Save");
		fc.setCurrentDirectory(new File(cvt.defaultResourceDirStr));
		fc.showOpenDialog(cvt);
		
		// write
		File glslOutput = fc.getSelectedFile();
		
		try{
		
		BufferedWriter bout = new BufferedWriter(new FileWriter(glslOutput));
		String glslOutputStr = glsleui.glslText.getText();
		
		bout.write(glslOutputStr);
		bout.close();
		
		//System.out.println(glslOutputStr.length()+" CODE LEN");
		
		} catch (Exception e){
			e.printStackTrace();
		}
	}
	
	public void doLoad(){
		JFileChooser fc = new JFileChooser();
		fc.setCurrentDirectory(new File(cvt.defaultResourceDirStr));
		fc.showOpenDialog(cvt);
		
		// read
		File glslInput = fc.getSelectedFile();
		String glslInputStr = "";
		
		try {
			BufferedReader bin = new BufferedReader(new FileReader(glslInput));
			
			while (bin.ready() == true){
				glslInputStr+= bin.readLine();
				glslInputStr+="\n";
			}
		} catch (Exception e){
			e.printStackTrace();
		}
		glsleui.glslText.setText(glslInputStr);
	}
	
	public void send(){
		// send via TCP socket
	}
	
	public void showGLSLEditor(){
		glsleui.setVisible(true);
	}
	
	public static void main(String args[]) {
		init();
		
		while (true){
			
		}
	}
	
}
