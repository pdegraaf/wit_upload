package org.mitre.wit;

/**
 * Simple Geospatial location.
 * @author cappellj
 *
 */
public class Point {
	private double latitude;
	private double longitude;
	private double altitude;
	
	
	public Point() {
		
	}
	
	public Point(double lat, double lon, double alt) {
		this.latitude = lat;
		this.longitude = lon;
		this.altitude = alt;
	}

	public double getAltitude() {
		return altitude;
	}

	public void setAltitude(double altitude) {
		this.altitude = altitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	

}
