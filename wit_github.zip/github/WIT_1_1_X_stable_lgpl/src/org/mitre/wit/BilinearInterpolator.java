/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

package org.mitre.wit;

/**
 * @author Hugh Shane <hshane@mitre.org>
 *
 * Perform bilinear interpolation on the input array x by an interpolation 
 * factor m. (Interpolate by the same factor in both dimensions.)
 * 
 * Reference: http://en.wikipedia.org/wiki/Bilinear_interpolation
 *
 */
public class BilinearInterpolator {
	private float offEarth = -9999.0f;
	private int m = 12;
	
	public BilinearInterpolator(float offEarth, int m) {
		this.offEarth = offEarth;
		this.m = m;
	}
	
	public BilinearInterpolator() {
	}
	
	public H5RCoords[][] interpolate(
			H5RCoords[][] oldCoords) {
		int oldRows = oldCoords.length;
		int oldCols = oldCoords[0].length;
		float oldLat[][] = new float[oldRows][oldCols];
		float oldLon[][] = new float[oldRows][oldCols];
		float oldX[][] = new float[oldRows][oldCols];
		float oldY[][] = new float[oldRows][oldCols];
		float oldZ[][] = new float[oldRows][oldCols];
		
		for (int j = 0; j<oldRows; j++) {
			for (int k = 0; k<oldCols; k++) {
				oldLat[j][k] = oldCoords[j][k].latDeg;
				oldLon[j][k] = oldCoords[j][k].lonDeg;
				oldX[j][k] = oldCoords[j][k].xECEFUnit;
				oldY[j][k] = oldCoords[j][k].yECEFUnit;
				oldZ[j][k] = oldCoords[j][k].zECEFUnit;
			}	
		}
		
		float newLat[][] = interpolate(oldLat);
		float newLon[][] = interpolate(oldLon);
		float newX[][] = interpolate(oldX);
		float newY[][] = interpolate(oldY);
		float newZ[][] = interpolate(oldZ);

		int newRows = oldRows*m;
		int newCols = oldCols*m;
		H5RCoords[][] newCoords = 
			new H5RCoords[newRows][newCols];
		
		for (int j = 0; j<newRows; j++) {
			for (int k = 0; k<newCols; k++) {
				newCoords[j][k] = new H5RCoords();
				newCoords[j][k].latDeg = newLat[j][k];
				newCoords[j][k].lonDeg = newLon[j][k];
				newCoords[j][k].xECEFUnit = newX[j][k];
				newCoords[j][k].yECEFUnit = newY[j][k];
				newCoords[j][k].zECEFUnit = newZ[j][k];
			}	
		}
		
		return newCoords;
		
	}
	
	public float[][] interpolate(float[][] x) {
		int oldRows = x.length;
		int oldCols = x[0].length;
		int newRows = oldRows * m;
		int newCols = oldCols * m;
		float y[][] = new float[newRows][newCols];
				
		// iterate on the original data points
		float[][] f = new float[2][2];
		for (int j = 0; j<(oldRows-1); j++) {
			for (int k = 0; k<(oldCols-1); k++) {
				
				// assign the corner points of the sub-array
				// pad the last row or column with the previous one
				f[0][0] = x[j][k];
				
				if (k+1 == oldCols)
					f[0][1] = x[j][k];
				else
					f[0][1] = x[j][k+1];
				
				if (j+1 == oldRows)
					f[1][0] = x[j][k];
				else
					f[1][0] = x[j+1][k];
				
				if (j+1 == oldRows || k+1 == oldCols)
					f[1][1] = x[j][k];
				else
					f[1][1] = x[j+1][k+1];
				
				// if any corner is an off-earth value than fill
				// the entire sub-array with the off-earth value
				if (f[0][0] == offEarth || f[0][1] == offEarth ||
						f[1][0] == offEarth || f[1][1] == offEarth) {
					subFill(y,j,k,m,offEarth);
					continue;
				}

				// perform the interpolation
				for (int p = 0; p<m; p++) {
					for (int q = 0; q<m; q++) {
						double qm = (double)q/(double)m;
						double pm = (double)p/(double)m;						
						y[j*m+p][k*m+q] = (float)
							(f[0][0]*(1.0-pm)*(1.0-qm) +
							f[1][0]*pm*(1.0-qm) +
							f[0][1]*(1.0-pm)*qm +
							f[1][1]*pm*qm);							
					}
				}
				
			}
			
		}
		
		return y;
	}

	// fill a sub-array of the interpolated output with the given off-earth value
	private void subFill(float[][] y, int j, int k, int m, float offEarth) {
		for (int p = 0; p<m; p++) {
			for (int q = 0; q<m; q++) {
				y[j*m+p][k*m+q] = offEarth;							
			}
		}		
	}
	
	public static void main(String[] args) {
		float[][] x = {{0,1,2,3},{4,5,6,7},{8,9,10,11}};
		
		BilinearInterpolator interp = new BilinearInterpolator(-9999,4);
		float[][] y = interp.interpolate(x);
		
		for (int p=0; p<y.length; p++) {
			System.out.println();
			for (int q=0; q<y[0].length; q++) {
				System.out.print(y[p][q] + "\t");
			}
		}

		
		
	}

	public int getM() {
		return m;
	}
	
}
