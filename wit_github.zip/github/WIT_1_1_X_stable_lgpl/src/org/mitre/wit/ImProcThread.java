/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

package org.mitre.wit;

/**
 * @author Adrian Johnson <abjohnson@mitre.org>
 *
 */

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;

public class ImProcThread implements Runnable {

	int frameStart;
	int frameStop;

	int mode;
	int sca;

	ArrayList paramList = new ArrayList();

	// TivoFrame[] tf;

	int frameCount = 10;
	// WITFrame tf[];// = new TivoFrame[frameCount];
	ArrayList wfl;

	String name;

	static String threadIndentStr = "      OP UPDATE: ";

	static int verbosity = 0;

	int threadStatus = WC.THREAD_STATUS_READY;

	static String formatExtensions[];

	static int exportMode = WC.FORMAT_MP4;
	static int importMode = WC.FORMAT_PNG;

	static float exportQuality = 100.0f;
	static float exportFrameRate = 10.0f;

	static String exportLocation = "C:/javadev/data/WIT_OUTPUT/";
	static String exportName = "tivo1.mpg";
	static String importLocation = "/home/ajohnson/WIT/DEV_DATA/sbirs/seq3/cropped/";// "C:/javadev/data/seq3/cropped/";
	static String importName = "";

	static String scratchStr = "/export/WIT_DEV/ffmpeg_scratch/";// "/home/adrian/CWID_DEV/ffmpeg_scratch/";

	static int scaOffsets[][] = new int[8][2];

	static int stripeBiasCorrections[][][] = new int[2][8][768];
	static float stripeGainCorrections[][][] = new float[2][8][768];

	// specify the algorithms for images - to be executed by various threads

	// this is the class in which integration of native code may occur

	// rasterization
	int maxSensorValue = (int) (Math.pow(2, 13) - 1);// 255 or greater depending
	// on HDR
	int maxRasterValue = 255;

	int seqIndexMask[] = new int[WC.SCAN_SEQ_INDEX_MAX_VAL];

	public ImProcThread(String str, int m, ArrayList wfList, int fstart,
			int fstop, ArrayList pList) {
		this.frameStart = fstart;
		this.frameStop = fstop;// -1;
		// this.tf = tivoFrameRay;
		this.name = str;
		this.mode = m;
		this.paramList = pList;
		this.wfl = wfList;

		for (int i = 0; i < WC.SCAN_SEQ_INDEX_MAX_VAL; i++) {
			seqIndexMask[i] = 1;
		}

		// this.sca=((WITFrame)wfList.get(0)).scaID;

		// super(str);
	}

	public void run() {
		// threadStatus = WC.THREAD_STATUS_WORKING; allow dispatcher to switch
		// to WORKING

		// processFrames(tivoFrameRay, frameStart, frameStop, mode);
		processFrames(mode, wfl, frameStart, frameStop, paramList);

		threadStatus = WC.THREAD_STATUS_COMPLETE;
	}

	public void processFrames(int mode, ArrayList wfl, int a, int b,
			ArrayList paramList) {

		// System.out.println("PROCESSING FRAMES "+a+"-"+b+" ON THREAD "+this.name);

		// threadStatus = WC.THREAD_STATUS_WORKING;
		if (mode == WC.THREAD_LOAD) {
			// .h5rData(tf, a, b, paramList);

			// .rawImage(tf, a, b, paramList);
		} else if (mode == WC.THREAD_CONV) {

			// ie.convImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_FEAT) {

			// ie.watershedImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_THRS) {

			// ie.threshImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_DIFF) {

			diffImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_TEMPORAL) {

			// ie.diffImageDJ(wfl, a, b, paramList);
			// .DWT_CPU_DJ_Filter(tf, a, b, paramList);
			// .DWT_CPU_Filter(tf, a, b, paramList);
		} else if (mode == WC.THREAD_FILT) {

			// ie.filterImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_PREFILTER) {

			preFilterData(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_SEGMENT) {

			// ie.watershedImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_MON) {
			// monitor progress of threads
		} else if (mode == WC.THREAD_EXPORT_VIDEO) {
			exportVideo(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_EXPORT_WEATHER_VIDEO) {
			exportWeatherVideo(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_EXPORT_IMAGES) {
			exportImages2(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_EXPORT_MARKED_IMAGES) {
			exportImages2(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_EXPORT_PROJ_IMAGES) {
			exportImagesMerc(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_DEJITTER) {
			// .dejitterScanlines(tf, a, b, paramList);

			// need to bring paramlist back into CV class
			// ie.dejitterImage2(wfl, a, b, paramList);

		} else if (mode == WC.THREAD_DEJITTER_ADV) {

		} else if (mode == WC.THREAD_CONTRAST) {
			// .manualContrastAdjust(tf, a, b, null);
			// .uiContrastImage(tf, a, b, paramList);
			wrapperContrastImage(wfl, a, b, paramList);
			// .autoContrastImage(tf, a, b, paramList);
			// .contrastImage(tf, a, b, null);
		} else if (mode == WC.THREAD_LOAD_HDF5R) {
			loadHDF5RStitchList(wfl, a, b, paramList); // !! DEV !!
		} else if (mode == WC.THREAD_HISTOGRAM) {
			histogramImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_TIMELAPSE) {
			timelapseImage(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_REGISTRATION) {

			rubberSheetImages(wfl, a, b, paramList);
			//rubberSheetBoundaries(wfl, a, b, paramList);
		} else if (mode == WC.THREAD_STAT_FILTER) {
			statisticalAnalysis(wfl, a, b, paramList);
		}

		// threadStatus = WC.THREAD_STATUS_COMPLETE; // may want to event...or
		// send data over IP
		// threadStatus = WC.THREAD_STATUS_READY;
	}
	
	public void rubberSheetImages(ArrayList wfl, int a, int b, ArrayList paramList) {
		//int thisMode = WC.THREAD_REGISTRATION;
		int inputSrc = (Integer) paramList.get(0);

		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);

		int w = maxX - minX;
		int h = maxY - minY;

		int diffSkip = (Integer) paramList.get(7);
		int scanExportMode = (Integer) paramList.get(8);
		seqIndexMask = (int[]) paramList.get(9);
		

		int searchWindow = 2;
		int searchWindowDiff = 10;
		
		// warp map tiles
		
		// keep same base frame
		int index = getIndexFromTime(minT, 10, wfl, scanExportMode);
		WITFrame wfi = null;
		ScanRegistration scanReg = null;
		
		if (index != -1) {
			wfi = (WITFrame) wfl.get(index);
			 scanReg = new ScanRegistration(wfi.geoLocDataSparse);
			 
			 wfi.layerStatus[mode] = WC.STATUS_COMPLETE;
			 wfl.set(index, wfi);
		}
		
		
		if (wfi != null && scanReg != null){
		for (int i = minT; i < maxT; i++) {


				int nudge = 0;
				int index2 = getIndexFromTime(i + nudge, searchWindowDiff, wfl,
						scanExportMode);

				while (index2 == index) {
					nudge++;
					index2 = getIndexFromTime(i + nudge, searchWindowDiff, wfl,
							scanExportMode);
				}
				//System.out.println("ALIGN FRAMES "+index+" + "+index2);
				if (index2 != -1) {
					WITFrame wfi2 = (WITFrame) wfl.get(index2);

					if (wfi2.layerStatus[mode] != WC.STATUS_COMPLETE
							&& wfi2.layerStatus[inputSrc] == WC.STATUS_COMPLETE && wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE) { // ==
						// WC.STATUS_READY

						System.out.println("EXEC AFFINE ALIGN - FRAMES " + index + " "
								+ index2);


								//wfi.biRay[mode] = scanReg.register(wfi2.biRay[inputSrc], wfi2.geoLocDataSparse);
								wfi2.biRay[mode] = new BufferedImage(wfi2.biRay[inputSrc].getWidth(), wfi2.biRay[inputSrc].getHeight(),BufferedImage.TYPE_INT_ARGB);
								wfi2.biRay[mode] = scanReg.register(wfi2.biRay[inputSrc], wfi2.geoLocDataSparse);
								//Graphics2D g = (Graphics2D)wfi2.biRay[mode].getGraphics();
								//g.setColor(Color.red);
								//g.fillRect(0, 0, w, h);
								
								wfi2.layerOffet[mode][WC.X] = minX;
								wfi2.layerOffet[mode][WC.Y] = minY;
			

						wfi2.layerStatus[mode] = WC.STATUS_COMPLETE;

						//wfi2.layerOffet[mode][WC.X] = wfi2.layerOffet[inputSrc][WC.X];
						//wfi2.layerOffet[mode][WC.Y] = wfi2.layerOffet[inputSrc][WC.Y];

						wfl.set(index2, wfi2);
						System.out.println("REGISTER IMAGE " + index + " UPDATED - TIME " + i);
					}

				}
		}
		}
	}
	
	public void rubberSheetBoundaries(ArrayList wfl, int a, int b, ArrayList paramList) {
		int thisMode = WC.THREAD_REGISTRATION;
		int inputSrc = (Integer) paramList.get(0);

		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);

		int w = maxX - minX;
		int h = maxY - minY;

		int diffSkip = (Integer) paramList.get(7);
		int scanExportMode = (Integer) paramList.get(8);
		seqIndexMask = (int[]) paramList.get(9);
		

		int searchWindow = 2;
		int searchWindowDiff = 10;
		
		// warp map tiles
		
		for (int i = minT; i < maxT; i++) {

			int index = getIndexFromTime(i, searchWindow, wfl, scanExportMode);
			if (index != -1) {
				WITFrame wfi = (WITFrame) wfl.get(index);

				int nudge = 1;
				int index2 = getIndexFromTime(i + nudge, searchWindowDiff, wfl,
						wfi.scanDirection);

				while (index2 == index) {
					nudge++;
					index2 = getIndexFromTime(i + nudge, searchWindowDiff, wfl,
							wfi.scanDirection);
				}
				if (index2 != -1) {
					WITFrame wfi2 = (WITFrame) wfl.get(index2);

					if (wfi.layerStatus[thisMode] != WC.STATUS_COMPLETE
							&& wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE) { // ==
						// WC.STATUS_READY

						System.out.println("EXEC DIFF - FRAMES " + index + " "
								+ index2);
						if (verbosity > 0)
							System.out.println("EXEC DIFF FRAME " + i);

						if (w > 0 && h > 0) {
							wfi.biRay[WC.THREAD_DIFF] = new BufferedImage(w, h,
									BufferedImage.TYPE_INT_RGB);

							wfi.layerOffet[thisMode][WC.X] = minX;
							wfi.layerOffet[thisMode][WC.Y] = minY;

							System.out.println("STATUS INGEST DIFF IMAGE "
									+ wfi.layerStatus[inputSrc] + " "
									+ wfi2.layerStatus[inputSrc]);

							if (wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE
									&& wfi2.layerStatus[inputSrc] == WC.STATUS_COMPLETE) {

								
								
							}
						}

						wfi.layerStatus[WC.THREAD_REGISTRATION] = WC.STATUS_COMPLETE;

						//wfl.remove(index);

						wfi.layerOffet[mode][WC.X] = wfi.layerOffet[inputSrc][WC.X];
						wfi.layerOffet[mode][WC.Y] = wfi.layerOffet[inputSrc][WC.Y];

						//wfl.add(index, wfi);
						wfl.set(index, wfi);
						System.out.println("REGISTER IMAGE " + index + " UPDATED - TIME " + i);
					}

				}
			}
		}
		
	}

	private static String padFrameID(int id, int pad) {
		String paddedID = "" + id;
		if (id < 10) {
			paddedID = "00" + paddedID;
		} else if (id < 100) {
			paddedID = "0" + paddedID;
		}
		return paddedID;
	}

	public static float[] interpolateLonLatFramePointFast(WITFrame t,
			int scaID, int xPoint, int yPoint) {

		// this method only interpolates for small region of the SCA
		float latLonCoords[] = new float[2];

		// NOTE USE 0-5 scaID
		scaOffsets = initSCAoffsets(1);
		// for (int i=0; i<6; i++){

		// todo - extern config
		// int scanYdiff = 0;// 100;
		// int staticFrameW = 768 * 6 + 1;
		// int staticFrameH = 865 + scanYdiff + SCA_Y_OFFSET;

		int scaXoffset = scaOffsets[scaID][WC.X];
		int scaYoffset = scaOffsets[scaID][WC.Y];

		int W = t.numChannels;
		int H = t.numLines;

		int Y_Stepsize_Pixels = t.geoLocYskip;
		int X_Stepsize_Pixels = t.geoLocXskip;

		int sparseXindices = t.geoLocSparseCols;// t.numChannels/X_Stepsize_Pixels;
		int sparseYindices = t.geoLocSparseRows;// t.numLines/Y_Stepsize_Pixels;

		// System.out.println(sparseYindices);

		float lon = 0;
		float lat = 0;

		// int numRows = t.geoLocSparseRows;
		// int numCols = t.geoLocSparseCols;

		float[][] f = new float[4][2];

		// find the notch at which we begin
		int startJ = (int) Math.floor((float) xPoint
				/ (float) X_Stepsize_Pixels);
		int startK = (int) Math.floor((float) yPoint
				/ (float) Y_Stepsize_Pixels);

		// find the fractional portion, ie offset from Stepsize pixels
		int insetJ = (xPoint - (startJ * X_Stepsize_Pixels));
		int insetK = (yPoint - (startK * Y_Stepsize_Pixels));

		int j = startJ;
		int k = startK;

		// System.out.println("   interpFast "+startJ+" "+startK+" : "+insetJ+" "+insetK+" mouse >> "+xPoint+" "+yPoint);

		// FASTMOUSE
		// System.out.println("MOUSE EXEC "+xPoint+" "+yPoint+" : "+insetJ+" "+insetK+" "+startJ+" "+startK);

		if (j < sparseXindices && k < sparseYindices) {
			// corner point to use for interpolation

			int ji1 = j;
			int ji2 = j + 1;

			int ki1 = k;
			int ki2 = k + 1;

			if ((scaID) % 2 == 0) {
				ji1 = sparseXindices - j;
				ji2 = sparseXindices - j - 1;
			}
			if (t.scanDirection == 0) {
				ki1 = sparseYindices - k;
				ki2 = sparseYindices - k - 1;
			}

			if (ji1 >= sparseXindices || ji2 >= sparseXindices || ji1 < 0
					|| ji2 < 0 || ki1 >= sparseYindices
					|| ki2 >= sparseYindices || ki1 < 0 || ki2 < 0) {
				// SCA seam
			} else {

				for (int c = 0; c < 2; c++) {
					f[0][c] = t.geoLocDataSparse[ji1][ki1][c];
					f[1][c] = t.geoLocDataSparse[ji1][ki2][c];
					f[2][c] = t.geoLocDataSparse[ji2][ki1][c];
					f[3][c] = t.geoLocDataSparse[ji2][ki2][c];
				}

				int bypassFlag = 0; // if one portion is off-earth, throw out
				// this whole tile, don't interpoate
				for (int a = 0; a < 4; a++) {
					for (int b = 0; b < 2; b++) {
						if (f[a][b] < -999) {
							bypassFlag = 1;
						}
					}
				}

				// perform the interpolation

				int x = insetJ;
				int y = insetK;

				float ym = (float) y / (float) Y_Stepsize_Pixels;
				float xm = (float) x / (float) X_Stepsize_Pixels;

				// complements
				float xmc = 1.0f - xm;
				float ymc = 1.0f - ym;

				int row = xPoint;// j * Y_Stepsize_Pixels + y;
				int col = yPoint;// k * X_Stepsize_Pixels + x;

				lon = f[0][0] * xmc * ymc + f[2][0] * xm * ymc + f[1][0] * xmc
						* ym + f[3][0] * xm * ym;

				lat = f[0][1] * xmc * ymc + f[2][1] * xm * ymc + f[1][1] * xmc
						* ym + f[3][1] * xm * ym;

				// int scanYoffset = scaOffsets[scaID][Y];

				if (bypassFlag == 0) {
					latLonCoords[WC.GEODATA_LON] = lon;
					latLonCoords[WC.GEODATA_LAT] = lat;
				} else if (bypassFlag == 1) {
					latLonCoords[WC.GEODATA_LON] = -9999;
					latLonCoords[WC.GEODATA_LAT] = -9999;
				}

			}
		}

		return latLonCoords;
	}

	public static WITFrame interpolateLonLatFrame(WITFrame t) {

		// System.out.println("GEN SCA GEOLOCATION");
		WITFrame tempFrame = t;
		int scaID = t.scaID;
		// WITFrame tempFrame= new WITFrame();
		tempFrame.numLines = t.numLines;
		// NOTE USE 0-5 scaID
		scaOffsets = initSCAoffsets(1);
		// for (int i=0; i<6; i++){

		// todo - extern config
		int scanYdiff = 0;// 100;
		int staticFrameW = t.numChannels;// 768 * 6 + 1;
		int staticFrameH = t.numLines;

		tempFrame.geoLocDataFull = new float[staticFrameW][staticFrameH][2];

		int scaXoffset = scaOffsets[scaID][WC.X];
		int scaYoffset = scaOffsets[scaID][WC.Y];

		int W = 768;
		int H = 864;

		int Y_Stepsize_Pixels = t.geoLocYskip;
		int X_Stepsize_Pixels = t.geoLocXskip;

		float lon = 0;
		float lat = 0;

		int numRows = t.geoLocSparseRows;
		int numCols = t.geoLocSparseCols;

		float[][] f = new float[4][2];

		float tLatLon[] = new float[2];

		int destX = 0;
		int destY = 0;

		for (int x = 0; x < t.numChannels; x++) {
			for (int y = 0; y < t.numLines; y++) {

				destX = x;
				destY = y;

				tempFrame.geoLocDataFull[destX][destY][0] = -9999;
				tempFrame.geoLocDataFull[destX][destY][1] = -9999;

				tLatLon = interpolateLonLatFramePointFast(t, scaID, x, y);

				// System.out.println(tLatLon[WC.GEODATA_LON]+" "+tLatLon[WC.GEODATA_LAT]);

				tempFrame.geoLocDataFull[destX][destY][WC.GEODATA_LON] = tLatLon[WC.GEODATA_LON];
				tempFrame.geoLocDataFull[destX][destY][WC.GEODATA_LAT] = tLatLon[WC.GEODATA_LAT];
			}
		}

		// }

		return tempFrame;

	}

	public int[] getLatLonRasterPos(float lat, float lon, WITFrame w, int scaID) {
		scaOffsets = initSCAoffsets(1);

		int[] rasterPos = new int[2];
		rasterPos[WC.X] = WC.INVALID_GEOLOCATION;
		rasterPos[WC.Y] = WC.INVALID_GEOLOCATION;

		// WITFrame tempFrame = .interpolateLonLatFrame(w,scaID);

		float minDist = Float.MAX_VALUE;

		// chunk of sparse array
		int xIndex = -1;
		int yIndex = -1;

		float distThreshold = .5f;

		for (int x = 0; x < w.numChannels; x++) {
			for (int y = 0; y < w.numLines; y++) {

				float thisDist = (w.geoLocDataFull[x][y][WC.GEODATA_LON] - lon)
						* (w.geoLocDataFull[x][y][WC.GEODATA_LON] - lon)
						+ (w.geoLocDataFull[x][y][WC.GEODATA_LAT] - lat)
						* (w.geoLocDataFull[x][y][WC.GEODATA_LAT] - lat);

				if (thisDist < minDist) {

					minDist = thisDist;

					xIndex = x;
					yIndex = y;
				}
			}
		}

		if (xIndex != -1 && yIndex != -1) {
			rasterPos[WC.X] = scaOffsets[scaID][WC.X] + (xIndex);
			rasterPos[WC.Y] = scaOffsets[scaID][WC.Y] + (yIndex);
		}

		return rasterPos;
	}

	// interpolate across sparse grid to find raster locations
	public int[] getLatLonRasterPos_dev(float lat, float lon, WITFrame w,
			int scaID) {
		scaOffsets = initSCAoffsets(1);

		int[] rasterPos = new int[2];
		rasterPos[WC.X] = WC.INVALID_GEOLOCATION;
		rasterPos[WC.Y] = WC.INVALID_GEOLOCATION;

		int Y_Stepsize_Pixels = w.geoLocYskip;
		int X_Stepsize_Pixels = w.geoLocXskip;

		for (int i = 0; i < w.geoLocSparseCols; i++) {
			for (int j = 0; j < w.geoLocSparseRows; j++) {

				if (lon > w.geoLocDataSparse[i][j][WC.GEODATA_LON]
						&& lon <= w.geoLocDataSparse[i + 1][j][WC.GEODATA_LON]
						&& lat > w.geoLocDataSparse[i][j][WC.GEODATA_LAT]
						&& lat <= w.geoLocDataSparse[i][j + 1][WC.GEODATA_LAT]) {

					// base
					rasterPos[WC.X] = scaOffsets[scaID][WC.X];
					rasterPos[WC.Y] = scaOffsets[scaID][WC.Y];

					// add interpolation value
					float xm = (float) i / (float) X_Stepsize_Pixels;
					float ym = (float) j / (float) Y_Stepsize_Pixels;

					// complements
					float xmc = 1.0f - xm;
					float ymc = 1.0f - ym;

				}

			}
		}

		return rasterPos;
	}

	public int[] getLatLonRasterPos_old(float lat, float lon, WITFrame w,
			int scaID) {
		scaOffsets = initSCAoffsets(1);

		int[] rasterPos = new int[2];
		rasterPos[WC.X] = WC.INVALID_GEOLOCATION;
		rasterPos[WC.Y] = WC.INVALID_GEOLOCATION;

		// min vals
		float minDiffX = 999f;
		float minDiffY = 999f;

		float minDist = 999f;

		// min indices
		int minDiffXi = 0;
		int minDiffYi = 0;

		int assignFlag = 0;

		for (int i = 0; i < w.geoLocSparseCols * w.geoLocXskip; i++) {
			for (int j = 0; j < w.geoLocSparseRows * w.geoLocYskip; j++) {
				float dx = Math.abs(w.geoLocDataFull[i][j][WC.GEODATA_LAT]
						- lat);
				float dy = Math.abs(w.geoLocDataFull[i][j][WC.GEODATA_LON]
						- lon);

				float thisDist = (dx * dx) + (dy * dy);

				if (thisDist <= .1f) {
					// if ((dx<.1f) && (dy<.1f)){
					assignFlag = 1; // at least one match

					if (thisDist < minDist) {
						minDiffXi = i;
						// minDiffX=dx;

						minDiffYi = j;
						// minDiffY=dy;

						minDist = thisDist;
					}

					// System.out.println("RASTER AT "+rasterPos[WC.X]+" "+rasterPos[WC.Y]);
				}
			}
		}

		if (assignFlag == 1) {
			// assign the min
			rasterPos[WC.X] = minDiffXi + scaOffsets[scaID][WC.X];
			rasterPos[WC.Y] = minDiffYi + scaOffsets[scaID][WC.Y];
		}

		return rasterPos;
	}

	// from a WIT frame, create the GPU textures
	public void createTexTiles(ArrayList wfl, int a, int b, ArrayList paramList) {

	}

	public void loadHDF5RStitchList(ArrayList wfl, int a, int b,
			ArrayList paramList) {

		int storeHDRvals = 1; // TODO pass param

		int mode = WC.THREAD_LOAD_HDF5R;
		// int mode = WC.THREAD_LOAD_HDF5R_STITCH;

		int tempMax = 0;

		int linesReversed = 0;
		int channelsReversed = 0;

		// int coordSet = WC.COORDINATES_GLOBE;//
		// /WC.COORDINATES_MERCATOR;//WC.COORDINATES_SENSOR;//

		try {
			int arrayOffset = 0;
			int startTimeSecs = a;
			int stopTimeSecs = b;
			int framesToLoad = 0;
			int skipSeconds = 1;
			int errorHandlingCode = 0;
			int autoContrastFromMetadata = 0;
			// int minCalIntensityFile = -1;//0;
			// int maxCalIntensityFile = -1;//4096;
			// String fName = (String) paramList.get(2);
			int scaID = (Integer) paramList.get(0); // must be 0-7, not 1-8
			int satID = -1;
			int reconstructFullScans = 0;
			int snippetSeconds = WC.SNIPPET_SECONDS_LOAD;

			int[][] scanSeqIndexMask = null;

			if (paramList.size() > 1) {
				satID = (Integer) paramList.get(1);
				arrayOffset = (Integer) paramList.get(3);
				startTimeSecs = (Integer) paramList.get(4);
				stopTimeSecs = (Integer) paramList.get(5);
				skipSeconds = (Integer) paramList.get(6);

				snippetSeconds = (Integer) paramList.get(7);
				errorHandlingCode = (Integer) paramList.get(8);
				scanSeqIndexMask = (int[][]) paramList.get(9);
			}

			StringBuilder strBdr = new StringBuilder();
			
			HDF5_R h5 = (HDF5_R) paramList.get(2);

			int contrastMode = WC.CONTRAST_OFF;

			int curF = 0;
			int prevF = 0;
			int nextF = 0;

			FrameMetaData frameMetaData = h5.getFrameMetaData();
			if (frameMetaData != null) {
				FrameMetaData.MetaData theData = frameMetaData.getMetaData();

				int lengthHint = theData.beginLine.length;
				// System.out.println("LENGTH HINT "+lengthHint);

				// int lastLoadSeconds = 0;

				int geolocationExists = 0;

				CalRawData calRawData = null;
				GeoLocationData geolocationData = null;

				calRawData = h5.getCalRawData();

				try {
					geolocationData = h5.getGeolocationData();
					geolocationExists = 1;
				} catch (Exception e) {
					geolocationExists = 0;
				}

				for (int passNo = 0; passNo < 10; passNo++) {

					
						for (int j = 0; j < lengthHint; j++) { // !! examine
							
								if (theData.beginLine[j] == passNo
										* WC.SCA_SCAN_SEGMENT_LINES) {

									double frameIndexSecondsOfDay = theData.secondsOfDay[j];

									if (errorHandlingCode == 1) { 
									}

									if (frameIndexSecondsOfDay >= startTimeSecs
											&& frameIndexSecondsOfDay < stopTimeSecs) {

										// do skip frame logic

										double loadFlagModulo = ((frameIndexSecondsOfDay - startTimeSecs) % skipSeconds);
										if (loadFlagModulo < snippetSeconds) {

											// addFlag=1;
											WITFrame loadFrame = new WITFrame();

											int targetTimestampSecOfDay = (int) theData.secondsOfDay[j];
											int targetTimestampDay = theData.day[j];

											if (errorHandlingCode == 1) { // catch
																			// foobarred
												// timing data
												targetTimestampDay = 0;
												targetTimestampSecOfDay = (int) frameIndexSecondsOfDay;
											}

											loadFrame.scaID = scaID;

											if (errorHandlingCode == 1) {
												loadFrame.missingDataItems[WC.MISSING_ITEM_GEOLOCATION] = 1;
											}

											String secStr = theData.secondsOfDay[j]
													+ "";

											int lapseFlag = 1;

											loadFrame.scanDirection = theData.scanDir[j];
											loadFrame.scanSeqIndex = theData.sosSeqIndex[j];
											loadFrame.numLines = theData.numLines[j];
											loadFrame.numChannels = theData.numChannels[j];
											loadFrame.beginLine = theData.beginLine[j];
											loadFrame.endLine = theData.endLine[j];
											loadFrame.satID = satID;

											loadFrame.hdrValsRaw = new short[loadFrame.numChannels + 1][loadFrame.numLines + 1];

											loadFrame.linesReversed = theData.linesReversed[j];
											loadFrame.chansReversed = theData.chansReversed[j];

											loadFrame.maxCalIntensityFrame = theData.maxCalIntensity[j];
											loadFrame.minCalIntensityFrame = theData.minCalIntensity[j];

											loadFrame.scanBounds[WC.GEODATA_LAT][WC.GEODATA_UL] = theData.UL_lat[j];
											loadFrame.scanBounds[WC.GEODATA_LAT][WC.GEODATA_UR] = theData.UR_lat[j];
											loadFrame.scanBounds[WC.GEODATA_LAT][WC.GEODATA_LR] = theData.LR_lat[j];
											loadFrame.scanBounds[WC.GEODATA_LAT][WC.GEODATA_LL] = theData.LL_lat[j];

											loadFrame.scanBounds[WC.GEODATA_LON][WC.GEODATA_UL] = theData.UL_lon[j];
											loadFrame.scanBounds[WC.GEODATA_LON][WC.GEODATA_UR] = theData.UR_lon[j];
											loadFrame.scanBounds[WC.GEODATA_LON][WC.GEODATA_LR] = theData.LR_lon[j];
											loadFrame.scanBounds[WC.GEODATA_LON][WC.GEODATA_LL] = theData.LL_lon[j];

											loadFrame.offEarthFlag = 0; // good
																		// unless
																		// -9999
											// is
											// found
											for (int gx = 0; gx < 2; gx++) {
												for (int gy = 0; gy < 4; gy++) {
													if (loadFrame.scanBounds[gx][gy] == WC.INVALID_GEOLOCATION) {
														loadFrame.offEarthFlag = 1;
													}
												}
											}

											if (storeHDRvals == 1) { // !! HDR
												// loadFrame.hdrValsRaw = new
												// int[staticFrameW][staticFrameH];

											}

											loadFrame.width = loadFrame.numChannels;
											loadFrame.height = loadFrame.numLines + 1;// staticFrameH;
											// tf[i].totalPixels =
											// tf[i].width*tf[i].height;
											loadFrame.totalPixels = 1
													* loadFrame.numChannels
													* loadFrame.numLines; // need
																			// to
											// exclude blank
											// regions

											loadFrame.layerOffet[mode][WC.X] = 0;
											loadFrame.layerOffet[mode][WC.Y] = 0;

											loadFrame.biRay[mode] = new BufferedImage(
													loadFrame.numChannels,
													loadFrame.numLines,
													BufferedImage.TYPE_INT_RGB);
											loadFrame = createRasterBi(
													loadFrame, mode);
											loadFrame.layerStatus[mode] = WC.STATUS_COMPLETE;

											int hours = (int) ((frameIndexSecondsOfDay / 60) / 60);
											int minutes = (int) (frameIndexSecondsOfDay / 60) % 60;
											int seconds = (int) frameIndexSecondsOfDay
													- (60 * 60 * hours + 60 * minutes);
											// float secFrac = (float)
											// (theData.secondsOfDay[j]-seconds);

											String hStr = hours + "";
											if (hStr.length() == 1)
												hStr = "0" + hStr;
											String mStr = minutes + "";
											if (mStr.length() == 1)
												mStr = "0" + mStr;
											String sStr = seconds + "";
											if (sStr.length() == 1)
												sStr = "0" + sStr;
											// String secFracStr = secFrac+"";

											loadFrame.timeStampHour = hours;
											loadFrame.timeStampMin = minutes;
											loadFrame.timeStampSec = seconds;

											loadFrame.timeStampSecOfDay = (int) frameIndexSecondsOfDay;

											String hmsStr = hStr + ":" + mStr
													+ ":" + sStr;// +"."+secFracStr;
											if (secStr.length() > 8) {
												secStr = (String) secStr
														.subSequence(0, 8);
											}

											String dayStr = theData.day[j] + "";
											if (dayStr.length() == 1) {
												dayStr = "00" + dayStr;
											} else if (dayStr.length() == 2) {
												dayStr = "0" + dayStr;
											}
											strBdr = new StringBuilder();
											strBdr.append(theData.year[j]);
											strBdr.append(":");
											strBdr.append(dayStr);
											strBdr.append(":");
											strBdr.append(hmsStr);
											loadFrame.timeStampStr = strBdr
													.toString();

											// loadFrame.layerStatus[WC.THREAD_LOAD_METADATA]
											// =
											// WC.STATUS_COMPLETE;

											// geolocation copy

											WITFrame tFrame = new WITFrame();

											// !! todo - only need sparse grid
											// for 1 SCA
											if (geolocationExists == 1) {
												tFrame.geoLocDataSparse = geolocationData
														.getGeolocationLonLat(
																j,
																loadFrame.scanDirection,
																scaID);
											}

											if (loadFrame.geoLocDataSparse == null) {
												loadFrame.geoLocDataSparse = new float[tFrame.geoLocDataSparse.length][tFrame.geoLocDataSparse[0].length][2]; // TODO
												// cleanup
											}

											for (int x = 0; x < tFrame.geoLocDataSparse.length; x++) {
												for (int y = 0; y < tFrame.geoLocDataSparse[0].length; y++) {

													int xg = x;
													int yg = tFrame.geoLocDataSparse[0].length
															- 1 - y; // set to
																		// the
																		// max Y
													// extent

													if (tFrame.geoLocDataSparse != null) {
														xg = tFrame.geoLocDataSparse.length
																- 1 - x;

														if (xg < 0) {
															xg = 0;
														}
														loadFrame.geoLocDataSparse[xg][yg][WC.GEODATA_LON] = tFrame.geoLocDataSparse[x][y][WC.GEODATA_LON];
														loadFrame.geoLocDataSparse[xg][yg][WC.GEODATA_LAT] = tFrame.geoLocDataSparse[x][y][WC.GEODATA_LAT];
													}
												}
											}

											try { // catch per frame so we can
													// skip over
												// errors
												WITFrame tempFrame = new WITFrame();

												int H = frameMetaData
														.getMetaData().numLines[j];
												int W = WC.SCA_CHANNELS;// calRawData.getNumCols();

												tempFrame.hdrValsRaw = calRawData
														.getShortFrame(j, 0);

												for (int y = 0; y < H; y++) {
													for (int x = 0; x < W; x++) {
														// priorFillFlag = 0;

														int edgeFlag = 0;

														int destX = x;
														destX = W - 1 - x;

														if (destX < WC.SCA_X_OVERLAP / 2) {
															edgeFlag = 1;
														}
														if (destX > W
																- WC.SCA_X_OVERLAP
																/ 2) {
															edgeFlag = 1;
														}

														int yf = H - 1 - y;

														// if (storeHDRvals ==
														// 1) val =
														// tempFrame.hdrValsRaw[x][y];

														int hdrVal = tempFrame.hdrValsRaw[x][y];

														if (hdrVal > Short.MAX_VALUE)
															hdrVal = Short.MAX_VALUE; // clamp
														if (hdrVal < 0)
															hdrVal = 0;
													

														loadFrame.hdrValsRaw[destX][yf] = (short) hdrVal;

													}
												}

											} catch (Exception e) { // catch for
																	// the
																	// frames
												e.printStackTrace();
											}

											loadFrame.layerSCAstatus[scaID] = WC.STATUS_COMPLETE;
											loadFrame.layerStatus[mode] = WC.STATUS_COMPLETE;
											loadFrame.scaID = scaID;

											loadFrame.biRay[mode] = new BufferedImage(
													loadFrame.numChannels,
													loadFrame.numLines,
													BufferedImage.TYPE_INT_RGB);
											loadFrame = createRasterBi(
													loadFrame, mode);
											loadFrame.layerStatus[mode] = WC.STATUS_COMPLETE;

											// loadFrame =
											// histogramSingleBiIncStats(loadFrame);

											if (passNo == 0
													&& scanSeqIndexMask[satID][loadFrame.scanSeqIndex] == WC.STATUS_ON) {// &&
																															// addFlag
																															// ==
												// 1){

												loadFrame.layerStatus[WC.THREAD_HISTOGRAM] = WC.THREAD_STATUS_READY;
												// loadFrame.layerStatus[WC.THREAD_PREFILTER]
												// = WC.THREAD_STATUS_READY;

												loadFrame.histogram = new int[WC.CONTRAST_UI_HARD_LIMIT];

												wfl.add(loadFrame);

												// System.out.println("frame added");

											} else if (passNo >= 1
													&& scanSeqIndexMask[satID][loadFrame.scanSeqIndex] == WC.STATUS_ON) {// if
																															// (addFlag
																															// ==
																															// 1){
																															// //append
												// System.out.println("frame modified");
												BufferedImage bUpdate = new BufferedImage(
														loadFrame.width,
														loadFrame.endLine,
														BufferedImage.TYPE_INT_ARGB);
												Graphics2D gUpdate = (Graphics2D) bUpdate
														.getGraphics();

												// find the last segment
												int appendedFrame = -1;
												int minTimeDelta = Integer.MAX_VALUE;
												int timeThresh = 5;
												for (int wi = 0; wi < wfl
														.size(); wi++) {
													WITFrame w = (WITFrame) wfl
															.get(wi);
													if (loadFrame.scanDirection == w.scanDirection) {
														if (loadFrame.timeStampSecOfDay >= w.timeStampSecOfDay) {
															int tempDiff = loadFrame.timeStampSecOfDay
																	- w.timeStampSecOfDay;
															if (tempDiff < 5) {
																if (tempDiff < minTimeDelta) {
																	minTimeDelta = tempDiff;
																	appendedFrame = wi;
																}
															}
														}
													}
												}

												if (appendedFrame != -1) { // incoming
													// interrupt
													// placeholder
													WITFrame w = (WITFrame) wfl
															.get(appendedFrame);
													// System.out.println("APPENDING - TIME DELTA "+minTimeDelta+
													// " SCAN STARTS AT "+w.beginLine);

													if (w.scanDirection == loadFrame.scanDirection
															&& w.beginLine < loadFrame.beginLine) {
														if (w.beginLine < loadFrame.beginLine) {

															if (loadFrame.scanDirection == WC.SCAN_DIR_EVEN) {
																// System.out.println("append even");
																w.maxCalIntensityFrame = Math
																		.max(
																				w.maxCalIntensityFrame,
																				loadFrame.maxCalIntensityFrame);
																w.minCalIntensityFrame = Math
																		.min(
																				w.minCalIntensityFrame,
																				loadFrame.minCalIntensityFrame);

																int tempScanLength = loadFrame.endLine;

																// geolocation
																// append
																WITFrame appendFrame = new WITFrame();

																int totalGeolocSparseRows = w.geoLocDataSparse[0].length
																		+ loadFrame.geoLocDataSparse[0].length;
																appendFrame.geoLocDataSparse = new float[w.geoLocSparseCols][totalGeolocSparseRows][2];

																for (int x = 0; x < w.geoLocSparseCols; x++) {
																	for (int y = 0; y < w.geoLocDataSparse[x].length; y++) {
																		for (int k = 0; k < 2; k++) {
																			appendFrame.geoLocDataSparse[x][y][k] = w.geoLocDataSparse[x][y][k];
																		}
																	}

																	for (int y = 0; y < loadFrame.geoLocDataSparse[x].length; y++) {
																		int y2 = w.geoLocDataSparse[x].length
																				+ y;

																		for (int k = 0; k < 2; k++) {
																			appendFrame.geoLocDataSparse[x][y2][k] = loadFrame.geoLocDataSparse[x][y][k];
																		}
																	}
																}

																w.geoLocSparseRows = totalGeolocSparseRows;
																w.geoLocDataSparse = appendFrame.geoLocDataSparse;

																// end
																// geolocation
																// append

																// hdr vals
																// append
																int totalHdrValRows = w.numLines
																		+ loadFrame.numLines;
																appendFrame.hdrValsRaw = new short[loadFrame.numChannels][totalHdrValRows];

																for (int x = 0; x < w.numChannels; x++) {
																	for (int y = 0; y < loadFrame.numLines; y++) {
																		appendFrame.hdrValsRaw[x][y] = loadFrame.hdrValsRaw[x][y]; // 1/11/11
																		// 1
																		// removes
																		// border
																	}
																	for (int y = 0; y < w.numLines; y++) {
																		int y2 = loadFrame.numLines
																				+ y;
																		appendFrame.hdrValsRaw[x][y2] = w.hdrValsRaw[x][y];
																	}
																}
																w.hdrValsRaw = appendFrame.hdrValsRaw;
																w.numLines = totalHdrValRows;
																w.endLine = loadFrame.endLine;
																w.scanSeqIndex = loadFrame.scanSeqIndex;

																// end hdr vals
																// append

																for (int m = 0; m < WC.MODE_COUNT; m++) {
																	if (m != WC.THREAD_LOAD_HDF5R) {
																		w.layerStatus[m] = WC.STATUS_READY;
																	}
																}

																// new bi for
																// appended
																// frame
																w.biRay[mode] = new BufferedImage(
																		w.numChannels,
																		w.numLines,
																		BufferedImage.TYPE_INT_RGB);
																w = createRasterBi(
																		w, mode);
																
																
																for (int m=0; m<WC.MODE_COUNT; m++){
																	w.layerStatus[m] = WC.STATUS_READY;
																}
																w.layerStatus[mode] = WC.STATUS_COMPLETE;

																// System.out.println("APPENDED FRAME "+w.numLines);
																// w.glDrawListID
																// =
																// WC.STATUS_ERROR;
																w.histogram = new int[WC.CONTRAST_UI_HARD_LIMIT];

																wfl
																		.set(
																				appendedFrame,
																				w);
																appendedFrame = 0; // break
																loadFrame = null;

															} else if (loadFrame.scanDirection == WC.SCAN_DIR_ODD) {
																// System.out.println("append odd");
																w.maxCalIntensityFrame = Math
																		.max(
																				w.maxCalIntensityFrame,
																				loadFrame.maxCalIntensityFrame);
																w.minCalIntensityFrame = Math
																		.min(
																				w.minCalIntensityFrame,
																				loadFrame.minCalIntensityFrame);

																int tempScanLength = loadFrame.endLine;

																// geolocation
																// append
																WITFrame appendFrame = new WITFrame();

																int totalGeolocSparseRows = w.geoLocDataSparse[0].length
																		+ loadFrame.geoLocDataSparse[0].length;
																appendFrame.geoLocDataSparse = new float[w.geoLocSparseCols][totalGeolocSparseRows][2];

																for (int x = 0; x < w.geoLocSparseCols; x++) {
																	for (int y = 0; y < w.geoLocDataSparse[x].length; y++) {
																		// for
																		// (int
																		// y=0;
																		// y<loadFrame.geoLocSparseRows;
																		// y++){
																		for (int k = 0; k < 2; k++) {
																			appendFrame.geoLocDataSparse[x][y][k] = w.geoLocDataSparse[x][y][k];
																		}
																	}

																	for (int y = 0; y < loadFrame.geoLocDataSparse[x].length; y++) {
																		int y2 = w.geoLocDataSparse[x].length
																				+ y;
																		for (int k = 0; k < 2; k++) {

																			appendFrame.geoLocDataSparse[x][y2][k] = loadFrame.geoLocDataSparse[x][y][k];

																		}
																	}
																}

																w.geoLocSparseRows = totalGeolocSparseRows;
																w.geoLocDataSparse = appendFrame.geoLocDataSparse;
																// end
																// geolocation
																// append

																// hdr vals
																// append
																int totalHdrValRows = w.numLines
																		+ loadFrame.numLines;
																// int
																// totalHdrValRows
																// =
																// w.hdrValsRaw[0].length
																// +
																// loadFrame.hdrValsRaw[0].length;
																appendFrame.hdrValsRaw = new short[loadFrame.numChannels][totalHdrValRows];

																for (int x = 0; x < w.numChannels; x++) {
																	for (int y = 0; y < loadFrame.numLines; y++) {
																		int y2 = y
																				+ w.numLines;
																		appendFrame.hdrValsRaw[x][y2] = loadFrame.hdrValsRaw[x][y]; // 1/11/11
																		// -1
																		// removes
																		// border
																	}
																	for (int y = 0; y < w.numLines; y++) {
																		appendFrame.hdrValsRaw[x][y] = w.hdrValsRaw[x][y];
																	}
																}
																w.hdrValsRaw = appendFrame.hdrValsRaw;
																w.numLines = totalHdrValRows;
																w.endLine = loadFrame.endLine;
																w.scanSeqIndex = loadFrame.scanSeqIndex;
																// end hdr vals
																// append

																for (int m = 0; m < WC.MODE_COUNT; m++) {
																	if (m != WC.THREAD_LOAD_HDF5R) {
																		w.layerStatus[m] = WC.STATUS_READY;
																	}
																}

																// new bi for
																// appended
																// frame
																w.biRay[mode] = new BufferedImage(
																		w.numChannels,
																		w.numLines,
																		BufferedImage.TYPE_INT_RGB);
																w = createRasterBi(
																		w, mode);
																
																for (int m=0; m<WC.MODE_COUNT; m++){
																	w.layerStatus[m] = WC.STATUS_READY;
																}
																w.layerStatus[mode] = WC.STATUS_COMPLETE;

																// System.out.println("APPENDED FRAME "+w.numLines);
																// w.glDrawListID
																// =
																// WC.STATUS_ERROR;
																w.histogram = new int[WC.CONTRAST_UI_HARD_LIMIT];

																wfl
																		.set(
																				appendedFrame,
																				w);
																appendedFrame = 0; // break
																loadFrame = null;
																
																//System.out.println(w.numLines);

															}

														}
													}
												}
											}
										}

									}// end beginLine check
								}
					
					}

				}
			}

			// }
			// !!!
			h5.finalize();

		} catch (Exception e) { // catch for the file
			e.printStackTrace();
		} catch (Throwable e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		}
	}

	public WITFrame createRasterBi(WITFrame tempFrame, int mode) {

		int H = tempFrame.numLines;
		int W = tempFrame.numChannels;

		short val;
		int rgba;

		for (int y = 0; y < H; y++) {
			for (int x = 0; x < W; x++) {
				// priorFillFlag = 0;

				int edgeFlag = 0;

				int destX = x;
				// destX = W-1 - x;

				if (destX < WC.SCA_X_OVERLAP / 2) {
					edgeFlag = 1;
				}
				if (destX > W - WC.SCA_X_OVERLAP / 2) {
					edgeFlag = 1;
				}

				// int yf = H - 1 - y;
				int yf = y;

				val = tempFrame.hdrValsRaw[x][y];
				// if (storeHDRvals == 1) val
				// =loadFrame.hdrValsRaw[destX][WC.Y];
				int hdrVal = tempFrame.hdrValsRaw[x][y];

				val = tempFrame.hdrValsRaw[x][y];

				if (val > 255)
					val = 255; // clamp
				if (val < 0)
					val = 0;
				rgba = (255 << 24) | (val << 16) | (val << 8) | val;

				if (yf < 0) {

				} else {
					if (val > 0) {
						// System.out.println(" dest y "+yf
						// +" x "+destX+" - "+val);
						try {
							tempFrame.biRay[mode].setRGB(destX, yf, rgba);
						} catch (Exception e) {
							// System.out.println(" dest y "+yf
							// +" "+loadFrame.height);
						}
					}
				}
			}
		}

		return tempFrame;
	}

	public void renderGeoFeatures(WITFrame[] tf, int a, int b,
			ArrayList paramList) {

	}


	public void markReceipt() {

	}

	// need to propagate to tivoframes

	// verified against flight 33 - should check with 34
	public static int[][] initSCAoffsets(int mag) {
		int baseYoffset = mag * WC.SCA_Y_OFFSET;// //*208;//-208;
		int overlapX = WC.SCA_X_OVERLAP;// 4;

		int offsets[][] = new int[8][2];

		offsets[0][WC.X] = 0;
		offsets[0][WC.Y] = 0;

		offsets[1][WC.X] = 768 * 1 - overlapX;
		offsets[1][WC.Y] = baseYoffset;

		offsets[2][WC.X] = 768 * 2 - overlapX * 2;
		offsets[2][WC.Y] = 0;

		offsets[3][WC.X] = 768 * 3 - overlapX * 3;
		offsets[3][WC.Y] = baseYoffset;

		offsets[4][WC.X] = 768 * 4 - overlapX * 4;
		offsets[4][WC.Y] = 0;

		offsets[5][WC.X] = 768 * 5 - overlapX * 5;
		offsets[5][WC.Y] = baseYoffset;

		// bump the non-SWIR SCAs over
		offsets[6][WC.X] = 768 * 6 - overlapX * 6 + 100;
		offsets[6][WC.Y] = baseYoffset;

		offsets[7][WC.X] = 768 * 7 - overlapX * 7 + 200;
		offsets[7][WC.Y] = baseYoffset;

		return offsets;

	}

	public String formatToFileExt(int format) {
		String ext = "";

		if (format == WC.FORMAT_MP4) {
			ext = ".mp4";
		} else if (format == WC.FORMAT_PNG) {
			ext = ".png";
		} else if (format == WC.FORMAT_WMV) {
			ext = ".wmv";
		}

		return ext;
	}


	public void h5rData(WITFrame[] tf, int a, int b, ArrayList paramList) {

		// start filling WIT buffer from tf

	}

	public ArrayList findFrameXYList(ArrayList refCoordsList, WITFrame w) {
		ArrayList frameXYList = new ArrayList();

		for (int j = 0; j < refCoordsList.size(); j++) {
			int[] frameXY = new int[2];
			frameXY[WC.X] = WC.STATUS_ERROR;
			frameXY[WC.Y] = WC.STATUS_ERROR;

			// create full geoloc field

			WITFrame wTemp = interpolateLonLatFrame(w);

			float[] refCoords = (float[]) refCoordsList.get(j);

			// find closest
			float minDist = Float.MAX_VALUE;
			int minX = -1;
			int minY = -1;
			int threshDist = 0;
			for (int x = 0; x < w.numChannels; x++) {
				for (int y = 0; y < w.numLines; y++) {
					float dist = (refCoords[WC.GEODATA_LON] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LON])
							* (refCoords[WC.GEODATA_LON] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LON])
							+ (refCoords[WC.GEODATA_LAT] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LAT])
							* (refCoords[WC.GEODATA_LAT] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LAT]);
					if (dist < minDist) {
						minDist = dist;
						minX = x;
						minY = y;
					}
				}
			}

			frameXY[WC.X] = minX;
			frameXY[WC.Y] = minY;

			frameXYList.add(frameXY);
		}
		return frameXYList;
	}

	public int[] findFrameXY(float refCoords[], WITFrame w) {
		int[] frameXY = new int[2];
		frameXY[WC.X] = WC.STATUS_ERROR;
		frameXY[WC.Y] = WC.STATUS_ERROR;

		// create full geoloc field

		WITFrame wTemp = interpolateLonLatFrame(w);

		// find closest
		float minDist = Float.MAX_VALUE;
		int minX = -1;
		int minY = -1;
		int threshDist = 0;
		for (int x = 0; x < w.numChannels; x++) {
			for (int y = 0; y < w.numLines; y++) {
				float dist = (refCoords[WC.GEODATA_LON] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LON])
						* (refCoords[WC.GEODATA_LON] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LON])
						+ (refCoords[WC.GEODATA_LAT] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LAT])
						* (refCoords[WC.GEODATA_LAT] - wTemp.geoLocDataFull[x][y][WC.GEODATA_LAT]);
				if (dist < minDist) {
					minDist = dist;
					minX = x;
					minY = y;
				}
			}
		}

		frameXY[WC.X] = minX;
		frameXY[WC.Y] = minY;

		return frameXY;
	}

	public void preFilterData(ArrayList wfl, int a, int b, ArrayList paramList) {

		// use loaded HDF5 now, then metadata next version
		int inputSrc = (Integer) paramList.get(0);
		System.out.println("PREFILTERING " + opIDtoName(inputSrc));

		int triggerMagnitude = 400000;
		int triggerDelta = 4000;
		int deltaTimeSecs = 10;
		int searchWindowSecs = 5;

		int mode = WC.THREAD_PREFILTER;

		// for (int sat = 0; sat < 2; sat++) {
		// int sat=userFlight;

		for (int j = 0; j < WC.SEC_IN_DAY; j++) {
			// add start/stop time bounds
			int time1 = j;

			int ix1 = getIndexFromTime(time1, searchWindowSecs, wfl,
					WC.SCAN_DIR_BOTH);

			if (ix1 >= 0) {

				WITFrame wf1 = (WITFrame) wfl.get(ix1);

				if (wf1.layerStatus[inputSrc] == WC.STATUS_COMPLETE
						&& wf1.layerStatus[mode] == WC.STATUS_READY) {
					// wf1.layerSCAstatus[mode] = WC.STATUS_WORKING;
					int time2 = wf1.timeStampSecOfDay - deltaTimeSecs;
					int ix2 = getIndexFromTime(time2, searchWindowSecs, wfl,
							wf1.scanDirection); // match scan dir for deltas
					WITFrame wf2 = null;
					if (ix2 >= 0) {
						wf2 = (WITFrame) wfl.get(ix2);
					}

					int maxIntensity1 = wf1.maxCalIntensityFrame;
					// int minIntensity1=wf1.minCalIntensity;

					BookmarkEvent b1 = new BookmarkEvent();
					int bookmarkTriggers = 0;

					if (maxIntensity1 > triggerMagnitude) {
						b1.eventDetectors[WC.EVENT_DETECTOR_AUTO_METADATA_MAGNITUDE] = true;
						bookmarkTriggers++;
					}

					if (wf2 != null) {

						int maxIntensity2 = wf2.maxCalIntensityFrame;
						// int minIntensity2=wf2.minCalIntensity;
						// System.out.println("SCA "+wf1.scaID+"  MAX "+maxIntensity1+"/"+(maxIntensity2)+" FRAMES: "+ix1+" "+ix2+"   TIMES: "+j+" "+(wf1.timeStampSecOfDay-deltaTimeSecs)+" "+wf1.timeStampSecOfDay+
						// " "+wf2.timeStampSecOfDay);
						if (Math.abs(maxIntensity1 - maxIntensity2) > triggerDelta) {
							b1.eventDetectors[WC.EVENT_DETECTOR_AUTO_METADATA_DELTA] = true;
							bookmarkTriggers++;
						}
					}
					if (bookmarkTriggers > 0) {
						// System.out.println("BOOKMARK CREATED ");
						b1.eventLabel = "INTENSITY CHANGE IN FRAME METADATA";
						b1.scaID = wf1.scaID;
						b1.satID = wf1.satID;
						b1.eventDesc = "max_intensity increased in HDF5 metadata";
						b1.triggerCount = bookmarkTriggers;
						b1.timeStampSecOfDay = wf1.timeStampSecOfDay;
						b1.eventType = WC.EVENT_UNKNOWN;
						b1.statusCheckedByOperator = WC.STATUS_OFF;
						b1.statusCheckedByAuto = WC.STATUS_ON;
						wf1.bookmarkList.add(b1);

					}
					wf1.layerStatus[mode] = WC.STATUS_COMPLETE;
					wfl.set(ix1, wf1);

				}
			}

			// }
		}
	}

	// private static void loadImage(String name, BufferedImage bi){
	private static void loadImage(String name, WITFrame tf) {
		System.out.println("LOAD FILE " + name);
		Image imageRay = Toolkit.getDefaultToolkit().getImage(name);
		MediaTracker mediaTracker = new MediaTracker(new Container());
		mediaTracker.addImage(imageRay, 0);
		try {
			mediaTracker.waitForID(0);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		int width = imageRay.getWidth(null);
		int height = imageRay.getHeight(null);

		tf.biRay[WC.THREAD_LOAD] = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_RGB);
		Graphics2D g = (Graphics2D) tf.biRay[WC.THREAD_LOAD].getGraphics();
		g.drawImage(imageRay, 0, 0, width, height, null);
		imageRay = null;
	}

	private static BufferedImage loadImageBI(String name) {
		System.out.println("LOAD FILE " + name);
		Image imageRay = Toolkit.getDefaultToolkit().getImage(name);
		MediaTracker mediaTracker = new MediaTracker(new Container());
		mediaTracker.addImage(imageRay, 0);
		try {
			mediaTracker.waitForID(0);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		int width = imageRay.getWidth(null);
		int height = imageRay.getHeight(null);

		BufferedImage b = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_ARGB);

		return b;
	}

	public void macroFilter(BufferedImage fi) {

		int tileAreaX = 100;
		int tileAreaY = 200;

		int ww = 1;
		int hh = 1;

		int w = fi.getWidth();
		int h = fi.getHeight();

		int offsetX = tileAreaX / ww;
		int offsetY = tileAreaY / hh;

		BufferedImage ave[][] = new BufferedImage[ww][hh];

		for (int i = 0; i < ww; i++) {
			for (int j = 0; j < hh; j++) {
				ave[i][j] = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
				Graphics gTemp = ave[i][j].getGraphics();
				gTemp.drawImage(fi, 0, 0, null);

				applyRegionEQ(ave[i][j], 10.5f, tileAreaX, tileAreaY, i
						* offsetX, j * offsetY);
			}
		}

		// average
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {

				int sum = 0;// [] = new int[ww*hh];
				for (int i = 0; i < ww; i++) {
					for (int j = 0; j < hh; j++) {

						int rgba = ave[i][j].getRGB(x, y);
						// vals[WC.A] += ((rgba >> 24) & 0xff);
						sum += ((rgba >> 16) & 0xff);
						// vals[WC.G] += ((rgba >> 8) & 0xff);
						// vals[WC.B] += ((rgba ) & 0xff);

					}
				}

				int val = sum / (ww * hh);
				if (val > 255)
					val = 255;
				if (val < 0)
					val = 0;

				int rgba = (val << 24) | (val << 16) | (val << 8) | val;

				fi.setRGB(x, y, rgba);

			}
		}

	}

	public void applyRegionEQ(BufferedImage b, float expansionLimit,
			int channels, int scanlines, int offX, int offY) {

		int w = b.getWidth();
		int h = b.getHeight();

		int data[][] = new int[w][h];

		int pxCount = 0;

		for (int wc = offX; wc < w / channels + offX; wc++) {

			for (int hc = offY; hc < h / scanlines + offY; hc++) {

				pxCount = 0;

				int valDist[] = new int[256];

				for (int x = wc * channels; x < wc * channels + channels; x++) {

					for (int y = hc * scanlines; y < hc * scanlines + scanlines; y++) {

						if (x < w && y < h) {

							int vals[] = new int[4];
							int rgba = b.getRGB(x, y);
							// vals[WC.A] += ((rgba >> 24) & 0xff);
							vals[WC.R] += ((rgba >> 16) & 0xff);
							// vals[WC.G] += ((rgba >> 8) & 0xff);
							// vals[WC.B] += ((rgba ) & 0xff);

							data[x][y] = vals[WC.R];

							valDist[data[x][y]]++;

							pxCount++;
						}
					}

				}

				// statistics
				int accum = 0;

				int q1 = (int) (.1f * (float) pxCount);
				int q2 = (int) (.5f * (float) pxCount);
				int q3 = (int) (.9f * (float) pxCount);

				int q1Val = 0;
				int q2Val = 0;
				int q3Val = 0;

				for (int i = 0; i < 256; i++) {
					accum += valDist[i];

					if (accum < q1) {
						q1Val = i + 1;
					}
					if (accum < q2) {
						q2Val = i + 1;
					}

					if (accum < q3) {
						q3Val = i + 1;
					}

				}
				System.out.println("   q1 " + q1Val + "   q3 " + q3Val
						+ "   MED " + q2Val);

				float span = 255f / (float) (q3Val - q1Val);

				if (span > expansionLimit)
					span = expansionLimit;

				// System.out.println("SPAN "+span);
				// alter values

				int medSpan = 50;
				int medNudge = 128 - q2Val;
				float medNudgeF = .5f - ((float) q2Val / 255f);

				// for (int wc=0; wc<w/channels; wc++){
				for (int x = wc * channels; x < wc * channels + channels; x++) {
					for (int y = hc * scanlines; y < hc * scanlines + scanlines; y++) {

						if (x < w && y < h) {

							int val1 = (int) ((data[x][y] + medNudge) * 1.0);

							int val6 = data[x][y] - q1Val; // translate to
							// origin
							val6 = (int) ((float) val6 * (span));
							val6 += medNudge;

							int val2 = (int) (((float) data[x][y]) * span);
							int val3 = 0;

							int val = val2;

							if (q2Val > 50) {
								val = data[x][y]; // if bright, set to original

							}
							// val = (val+data[WC.X][WC.Y])/2; // average EQ'd
							// val and
							// original
							if (val > 255)
								val = 255;
							if (val < 0)
								val = 0;

							int rgba = (val << 24) | (val << 16) | (val << 8)
									| val;

							b.setRGB(x, y, rgba);

						}
					}
				}
			}
		}

	}

	public void dynContrastImage(ArrayList wfl, int a, int b,
			ArrayList paramList) {

		System.out.println(threadIndentStr + "DYNAMIC CONTRAST " + a + "-" + b);

		int inputSrc = (Integer) paramList.get(0);
		int mode = WC.THREAD_CONTRAST;

		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int w = maxX - minX;
		int h = maxY - minY;

		float expansionLimit = 10.5f;

		for (int i = a; i < b; i++) {
			WITFrame wfi = (WITFrame) wfl.get(i);

			if (wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE
					&& wfi.layerStatus[mode] == WC.STATUS_READY) { // expensive
				// to
				// double-compute

				wfi.layerStatus[mode] = WC.STATUS_WORKING;

				int tileAreaX = 10;
				int tileAreaY = 10;

				wfi.biRay[mode] = new BufferedImage(w, h,
						BufferedImage.TYPE_INT_ARGB);

				wfi.layerOffet[mode][WC.X] = minX;
				wfi.layerOffet[mode][WC.Y] = minY;

				for (int x = 0; x < w / tileAreaX; x++) {
					for (int y = 0; y < h / tileAreaY; y++) {

						int offX = x * tileAreaX;
						int offY = y * tileAreaY;
						int valDist[] = new int[256]; // clamped bins
						short data[][] = new short[tileAreaX][tileAreaY];
						int pxCount = 0;
						for (int wc = 0; wc < tileAreaX; wc++) {
							for (int hc = 0; hc < tileAreaY; hc++) {

								int srcX = offX + wc + minX;
								int srcY = offY + hc + minY;
								data[wc][hc] = wfi.hdrValsRaw[srcX][srcY];// was
								// final

								// TODO - change to raster input option?

								int binID = data[wc][hc];
								binID = validate8bitVal(binID);// clamp
								valDist[binID]++;

								pxCount++;
							}
						}

						// local statistics obtained...

						int accum = 0;
						int q1 = (int) (.1f * (float) pxCount);
						int q2 = (int) (.5f * (float) pxCount);
						int q3 = (int) (.9f * (float) pxCount);

						int q1Val = 0;
						int q2Val = 0;
						int q3Val = 0;

						for (int v = 0; v < 256; v++) {
							accum += valDist[v];

							if (accum < q1) {
								q1Val = v + 1;
							}
							if (accum < q2) {
								q2Val = v + 1;
							}

							if (accum < q3) {
								q3Val = v + 1;
							}

						}
						float span = 255f / (float) (q3Val - q1Val);

						if (span > expansionLimit)
							span = expansionLimit;

						for (int wc = 0; wc < tileAreaX; wc++) {
							for (int hc = 0; hc < tileAreaY; hc++) {

								int dstX = offX + wc;
								int dstY = offY + hc;

								int val = (int) (((float) data[wc][hc] - q1Val) * span);

								val = validate8bitVal(val);

								int rgba = (val << 24) | (val << 16)
										| (val << 8) | val;

								wfi.biRay[mode].setRGB(dstX, dstY, rgba);
							}
						}
						// end tile
					}

				}

				wfi.layerStatus[mode] = WC.STATUS_COMPLETE; // end frame
			}
		}
	}

	// intercept and pass to various contrast methods
	public void wrapperContrastImage(ArrayList wfl, int a, int b,
			ArrayList paramList) {
		int contrastMode = (Integer) paramList.get(7);
		// int scaID = ((WITFrame)wfl.get(a)).scaOriginator;

		if (contrastMode == WC.CONTRAST_AUTO) {
			autoContrastImage(wfl, a, b, paramList);
		} else if (contrastMode == WC.CONTRAST_WINDOW) {

			dynContrastImage(wfl, a, b, paramList);
		} else if (contrastMode == WC.CONTRAST_USER) {

			userContrastImage(wfl, a, b, paramList);
		}
	}

	public static void initStripeBiasCorrections() {

	}

	public void userContrastImage(ArrayList wfl, int a, int b,
			ArrayList paramList) {

		Random r = new Random();
		int procID = r.nextInt();

		int inputSrc = (Integer) paramList.get(0);

		// bounding region
		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);

		int userMinIntensity = (Integer) paramList.get(8);
		int userMaxIntensity = (Integer) paramList.get(9);

		initStripeBiasCorrections();

		ArrayList userControlPoints = (ArrayList) paramList.get(10);

		ArrayList completeCP = new ArrayList();

		UserContrastCP u1 = new UserContrastCP();
		u1.intensity = userMinIntensity;
		u1.rasterIntensity = 0;

		UserContrastCP u2 = new UserContrastCP();
		u2.intensity = userMaxIntensity;
		u2.rasterIntensity = 255;

		completeCP.add(u1);
		for (int i = 0; i < userControlPoints.size(); i++) {
			UserContrastCP ux = (UserContrastCP) userControlPoints.get(i);
			completeCP.add(ux);
		}
		completeCP.add(u2);

		int w = maxX - minX;
		int h = maxY - minY;

		int baseIntensities[] = new int[completeCP.size() + 1];
		int ceilIntensities[] = new int[completeCP.size() + 1];
		int baseRasterIntensities[] = new int[completeCP.size() + 1];
		int ceilRasterIntensities[] = new int[completeCP.size() + 1];
		float scaleIntensities[] = new float[completeCP.size() + 1];
		int binMap[] = new int[WITFrame.histBins];

		int lastBinIndex = completeCP.size() - 1;
		// lower vals
		for (int j = 0; j < userMinIntensity; j++) {
			binMap[j] = 0;
		}
		// upper vals
		for (int j = userMaxIntensity; j < WITFrame.histBins; j++) {
			binMap[j] = lastBinIndex;
		}

		for (int i = 0; i < binMap.length; i++) {
			// binMap[i]=
		}

		UserContrastCP cpf = (UserContrastCP) completeCP.get(lastBinIndex);
		baseIntensities[lastBinIndex] = 0;// cpf.intensity;
		ceilIntensities[lastBinIndex] = 255;// cpf.intensity;
		scaleIntensities[lastBinIndex] = 1.0f;
		for (int j = 0; j < WITFrame.histBins; j++) {
			// for (int j=cpf.intensity; j<WITFrame.histBins; j++){
			binMap[j] = lastBinIndex;
		}

		for (int i = 0; i < completeCP.size() - 1; i++) {
			UserContrastCP cp1 = (UserContrastCP) completeCP.get(i);
			UserContrastCP cp2 = (UserContrastCP) completeCP.get(i + 1);

			baseIntensities[i] = cp1.intensity;
			ceilIntensities[i] = cp2.intensity;
			baseRasterIntensities[i] = cp1.rasterIntensity;
			ceilRasterIntensities[i] = cp2.rasterIntensity;
			float diffInput = (float) (ceilIntensities[i] - baseIntensities[i]);
			float diffOutput = (float) (ceilRasterIntensities[i] - baseRasterIntensities[i]);

			scaleIntensities[i] = (float) (diffOutput / diffInput);

			for (int j = baseIntensities[i]; j <= ceilIntensities[i]; j++) {
				binMap[j] = i;
			}
		}

		int mode = WC.THREAD_CONTRAST;
		for (int i = a; i < b; i++) {

			WITFrame wfi = (WITFrame) wfl.get(i);

			if (wfi.timeStampSecOfDay >= minT && wfi.timeStampSecOfDay <= maxT) {

				int bins = wfi.histBins;

				if (wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE
						&& wfi.layerStatus[mode] == WC.STATUS_READY && w > 0
						&& h > 0) { // expensive
					// to
					// double-compute
					wfi.layerStatus[mode] = WC.STATUS_WORKING;
					wfl.set(i, wfi);

					wfi.biRay[mode] = new BufferedImage(w, h,
							BufferedImage.TYPE_INT_ARGB);

					wfi.layerOffet[mode][WC.X] = minX;
					wfi.layerOffet[mode][WC.Y] = minY;

					if (wfi.layerStatus[WC.THREAD_HISTOGRAM] == WC.STATUS_READY) {
						// do histogram
						ArrayList delegateList = new ArrayList();
						delegateList.add(minT);
						delegateList.add(maxT);
						histogramImage(wfl, a, b, delegateList);
					}

					// set raster
					int val = 0;
					int rgba = 0;

					for (int x = 0; x < w - 1; x++) {
						for (int y = 0; y < h - 1; y++) {

							int srcX = minX + x;
							int srcY = minY + y;

							if (srcX >= 0 && srcY >= 0
									&& srcX < wfi.hdrValsRaw.length
									&& srcY < wfi.hdrValsRaw[srcX].length) {
							

								int valOrig = wfi.hdrValsRaw[srcX][srcY];

								int val2 = 0;

								if (valOrig < userMinIntensity) {
									val2 = 0;
								} else if (valOrig > userMaxIntensity) {
									val2 = 255;
								} else {

									val2 = (int) ((float) (valOrig - baseIntensities[binMap[valOrig]]) * scaleIntensities[binMap[valOrig]]);// +
									// baseRasterIntensities[binMap[valOrig]];

									val2 += baseRasterIntensities[binMap[valOrig]];

									if (val2 < 0)
										val2 = 0;
									if (val2 > 255)
										val2 = 255;
								}

								rgba = (255 << 24) | (val2 << 16) | (val2 << 8)
										| val2;
								if (wfi.biRay[mode] != null) {
									wfi.biRay[mode].setRGB(x, y, rgba);
								}
							}
						}
					}

					wfi.layerStatus[mode] = WC.STATUS_COMPLETE;

				}

				wfl.set(i, wfi);
			}
		}

	}

	public void autoContrastImage(ArrayList wfl, int a, int b,
			ArrayList paramList) {

		System.out.println(threadIndentStr + "AUTO DYNAMIC CONTRAST " + a + "-"
				+ b);

		int inputSrc = (Integer) paramList.get(0);

		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);

		int w = maxX - minX;
		int h = maxY - minY;

		// int userLowerBound = 100;
		// int userUpperBound = 50;
		// int userMidPoint = 0;

		int mode = WC.THREAD_CONTRAST;
		for (int i = a; i < b; i++) {

			WITFrame wfi = (WITFrame) wfl.get(i);

			if (wfi.timeStampSecOfDay >= minT && wfi.timeStampSecOfDay <= maxT) {
				if (wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE
						&& wfi.layerStatus[mode] == WC.STATUS_READY) { // expensive
					// to
					// double-compute
					wfi.layerStatus[mode] = WC.STATUS_WORKING;

					wfi.biRay[mode] = new BufferedImage(w, h,
							BufferedImage.TYPE_INT_ARGB);

					wfi.layerOffet[mode][WC.X] = minX;
					wfi.layerOffet[mode][WC.Y] = minY;

					if (wfi.layerStatus[WC.THREAD_HISTOGRAM] != WC.STATUS_COMPLETE) {
						// do histogram
						histogramImage(wfl, a, b, null);
					}

					int minSpan = 0;
					int maxSpan = 0;

					// set raster
					int val = 0;
					int rgba = 0;

					int tileX = 20;
					int tileY = 20;

					int localMax = 0;
					int localMin = 0;

					int localSearchSize = 7;

					for (int x = 0; x < w - 1; x++) {
						for (int y = 0; y < h - 1; y++) {
							int deltaMedian = 128 - wfi.histStats[WC.STATS_Q2];

							int srcX = minX + x;
							int srcY = minY + y;

							float span = localMax - localMin;

							val = (int) wfi.hdrValsRaw[srcX][srcY] - localMin;

							float multiplier = 255f / span;
							if (multiplier > 80)
								multiplier = 80;
							val *= multiplier;

							if (val < 0)
								val = 0;
							if (val > 255)
								val = 255;

							rgba = (255 << 24) | (val << 16) | (val << 8) | val;
							wfi.biRay[mode].setRGB(x, y, rgba);

						}
					}

					wfi.layerStatus[mode] = WC.STATUS_COMPLETE;
				}
			}
		}

	}

	// use the current raster data, then trigger the use of HDR data
	public void interactiveContrast() {

	}

	public void histogramImage(ArrayList wfl, int a, int b, ArrayList paramList) {

		System.out.println("HISTOGRAM STARTED");
		int inputSrc = WC.THREAD_LOAD_HDF5R;
		int mode = WC.THREAD_HISTOGRAM;

		int minT = (Integer) paramList.get(0);
		int maxT = (Integer) paramList.get(1);

		for (int i = a; i < b; i++) {

			WITFrame wfi = (WITFrame) wfl.get(i);

			if (wfi.timeStampSecOfDay >= minT && wfi.timeStampSecOfDay <= maxT) {

				int w = wfi.width;
				int h = wfi.height;

				if (wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE
						&& wfi.layerStatus[mode] != WC.STATUS_COMPLETE) {
					wfi.layerStatus[mode] = WC.STATUS_WORKING;

					// int bins = (int) Math.pow(2, 11) - 1; // 2047
					int bins = (int) Math.pow(2, 14) - 1; // 65535
					// int bins = (int) Math.pow(2, 8) - 1;

					int[] valDist = new int[bins]; // bins for contrast - clamp
					// dynamic range

					int totalPix = 0;

					// System.out.println("size "+tf[i].hdrValsRaw.length+
					// " "+tf[i].hdrValsRaw[0].length);
					for (int x = 0; x < w - 1; x++) {
						for (int y = 0; y < h - 1; y++) {
							int binID = 0;

							binID = wfi.hdrValsRaw[x][y];
							if (binID >= bins) {
								binID = bins - 1;

							}
							if (binID == WC.INVALID_DATA_MASK || binID < 0) { // don't
								

								binID = 0; // error pix
							} else {

								totalPix++;
								valDist[binID]++;
							}

						}
					}

					wfi.histogram = new int[bins];
					for (int m = 0; m < bins; m++) {
						wfi.histogram[m] = valDist[m];
					}

					// stats
					int accum = 0;

					// int totalPix = tf[i].totalPixels;

					for (int m = 0; m < wfi.histogram.length; m++) {

						// determine which bins correspond to quartiles
						accum += wfi.histogram[m];
						if (accum <= .25 * totalPix) {
							wfi.histStats[WC.STATS_Q1] = m;
						}
						if (accum <= .5 * totalPix) {
							wfi.histStats[WC.STATS_Q2] = m;
						}
						if (accum <= .75 * totalPix) {
							wfi.histStats[WC.STATS_Q3] = m;
						}
					}
					// end stats

					// min/max for rendering

					int maxVal = -1;
					int minVal = Integer.MAX_VALUE;
					for (int m = 0; m < bins; m++) {
						if (wfi.histogram[m] > maxVal) {
							maxVal = wfi.histogram[m];
						}
						if (wfi.histogram[m] < minVal) {
							minVal = wfi.histogram[m];
						}
					}
					wfi.histStats[WC.STATS_MIN_BIN] = minVal;
					wfi.histStats[WC.STATS_MAX_BIN] = maxVal;

					wfi.layerStatus[mode] = WC.STATUS_COMPLETE;

					// new 12.1

					wfl.set(i, wfi);
				}
			}
		}
	}

	public void contrastImage(WITFrame[] tf, int a, int b, ArrayList paramList) {

		int tileX = 100;
		int tileY = 100;

		int pxCount = tileX * tileY;

		int thisMode = WC.THREAD_CONTRAST;

		if (tf[a].layerStatus[WC.THREAD_LOAD] == WC.STATUS_COMPLETE) { // use
		

			int w = tf[a].biRay[WC.THREAD_LOAD].getWidth();
			int h = tf[a].biRay[WC.THREAD_LOAD].getHeight();

			for (int i = a; i < b; i++) {

				int hist[] = new int[256];
				if (tf[i].layerStatus[WC.THREAD_LOAD] == WC.STATUS_COMPLETE) {
					tf[i].layerStatus[thisMode] = WC.STATUS_WORKING;
					tf[i].biRay[WC.THREAD_CONTRAST] = new BufferedImage(w, h,
							BufferedImage.TYPE_INT_RGB);

					Graphics g3 = tf[i].biRay[WC.THREAD_CONTRAST].getGraphics();
					g3.drawImage(tf[i].biRay[WC.THREAD_LOAD], 0, 0, null);

					for (int x = 0; x < w; x++) {
						for (int y = 0; y < h; y++) {
							int rgba1 = tf[i].biRay[WC.THREAD_LOAD]
									.getRGB(x, y);
							// int rgba1 = tf[i].bimageRaw.getRGB(x, y);

							int vals[] = new int[3];
							vals[WC.R] = ((rgba1 >> 16) & 0xff);

							hist[vals[WC.R]]++;
						}
					}

					// adjust via media
					int q2Val = 0;
					int accum = 0;
					for (int f = 0; f < 256; f++) {
						accum += hist[f];
						if (accum < pxCount / 2) {
							q2Val = f + 1;
						}
					}

					for (int x = 0; x < w; x++) {
						for (int y = 0; y < h; y++) {
							int rgba1 = tf[i].biRay[WC.THREAD_LOAD]
									.getRGB(x, y);
							// int rgba1 = tf[i].bimageRaw.getRGB(x, y);

							int vals[] = new int[3];
							vals[WC.R] = ((rgba1 >> 16) & 0xff);

							int val = vals[WC.R] + q2Val;
							if (val > 255)
								val = 255;
							if (val < 0)
								val = 0;

							int col = ((int) (255) << 24) | ((int) (val) << 16)
									| ((int) (val) << 8) | (int) (val);

							tf[i].biRay[WC.THREAD_CONTRAST].setRGB(x, y, col);
						}
					}

					tf[i].layerStatus[thisMode] = WC.STATUS_COMPLETE;

				}
			}
		}
	}

	public void watershedImage(WITFrame[] tf, int a, int b, ArrayList paramList) {

		// threholds
		int threshCount = 9;
		int thresh[] = new int[threshCount];
		thresh[0] = 0;
		thresh[1] = 10;
		thresh[2] = 50;
		thresh[3] = 100;
		thresh[4] = 135;
		thresh[5] = 185;
		thresh[6] = 215;
		thresh[7] = 245;
		thresh[8] = 255;

		if (tf[a].layerStatus[WC.THREAD_LOAD] == WC.STATUS_COMPLETE) { // use
			// blurred
			// input to
			// reduce
			// noise
			// if (tf[a].statusRaw == WC.STATUS_COMPLETE){

			int w = tf[a].biRay[WC.THREAD_LOAD].getWidth();
			int h = tf[a].biRay[WC.THREAD_LOAD].getHeight();

			for (int i = a; i < b; i++) {
				if (tf[i].layerStatus[WC.THREAD_LOAD] == WC.STATUS_COMPLETE
						&& tf[i].layerStatus[WC.THREAD_CONV] == WC.STATUS_COMPLETE) {
					tf[i].layerStatus[WC.THREAD_SEGMENT] = WC.STATUS_WORKING;
					tf[i].biRay[WC.THREAD_SEGMENT] = new BufferedImage(w, h,
							BufferedImage.TYPE_INT_RGB);

					// get the data and bin

					int pxVals[][] = new int[w][h];
					int pxValsThresh[][] = new int[w][h];
					for (int x = 0; x < w; x++) {
						for (int y = 0; y < h; y++) {

							int rgba1 = tf[i].biRay[WC.THREAD_CONV]
									.getRGB(x, y);
							// int rgba1 = tf[i].bimageRaw.getRGB(x, y);

							int vals[] = new int[3];
							vals[WC.R] = ((rgba1 >> 16) & 0xff);
							vals[WC.G] = ((rgba1 >> 8) & 0xff);
							vals[WC.B] = ((rgba1) & 0xff);

							pxVals[x][y] = (vals[WC.R] + vals[WC.G] + vals[WC.B]) / 3;

							// threhold...
							for (int t = 1; t < threshCount; t++) {
								if (pxVals[x][y] > thresh[t - 1]
										&& pxVals[x][y] <= thresh[WC.T]) {
									pxValsThresh[x][y] = thresh[WC.T];
								}
							}

							int colWS = ((int) (1) << 24)
									| ((int) (pxValsThresh[x][y]) << 16)
									| ((int) (pxValsThresh[x][y]) << 8)
									| (int) (pxValsThresh[x][y]);
							// int colWS = ((int)(1) << 24) |
							// ((int)(pxVals[WC.X][WC.Y]) << 16) |
							// ((int)(pxVals[WC.X][WC.Y]) << 8) |
							// (int)(pxVals[WC.X][WC.Y]);

							tf[i].biRay[WC.THREAD_SEGMENT].setRGB(x, y, colWS);
						}
					}

					// sort minima

					int minOffsets[][][] = new int[w][h][2];
					int minSortLevel[][] = new int[w][h];

					for (int x = 0; x < w; x++) {
						for (int y = 0; y < h; y++) {
							minSortLevel[x][y] = -1; // need sorting
						}
					}
					int edgeBuffer = 1;
					for (int x = edgeBuffer; x < w - edgeBuffer; x++) {
						for (int y = edgeBuffer; y < h - edgeBuffer; y++) {

							int minX = x;
							int minY = y;
							int minVal = pxVals[x][y];
							for (int x2 = -1; x2 < 2; x2++) {
								for (int y2 = -1; y2 < 2; y2++) {
									if (pxVals[x + x2][y + y2] < minVal) {
										minVal = pxVals[x + x2][y + y2];
										minX = x + x2;
										minY = y + y2;
									}
								}
							}
							minOffsets[x][y][WC.X] = minX;
							minOffsets[x][y][WC.Y] = minY;

							if (minX == x && minY == y) {
								minSortLevel[x][y] = 0;

								int colWS = ((int) (1) << 24) | ((255) << 16)
										| ((0) << 8) | (0); // mark minima in
								// RED

								// tf[i].bimageSegmented.setRGB(x, y, colWS);

							} else {
								

							}

						}
					}

					// erode - look for stronger features
					for (int x = edgeBuffer; x < w - edgeBuffer; x++) {
						for (int y = edgeBuffer; y < h - edgeBuffer; y++) {
							int nCount = 0;
							if (minSortLevel[x][y] == 0) { // needs sorting
								for (int x2 = -1; x2 < 2; x2++) {
									for (int y2 = -1; y2 < 2; y2++) {
										if (minSortLevel[x + x2][y + y2] == 0) {
											nCount++;
										}

									}
								}
								if (nCount < 2) {
									minSortLevel[x][y] = 1;
								}
							}
						}
					}

					// sort neighbors
					for (int lev = 1; lev < 5; lev++) {
						for (int x = edgeBuffer; x < w - edgeBuffer; x++) {
							for (int y = edgeBuffer; y < h - edgeBuffer; y++) {

								if (minSortLevel[x][y] == -1) { // needs sorting
									for (int x2 = -1; x2 < 2; x2++) {
										for (int y2 = -1; y2 < 2; y2++) {
											if (minSortLevel[x + x2][y + y2] == lev - 1) {
												minSortLevel[x][y] = lev;
											}

										}
									}
								}
							}
						}
					}

					// paint proximity to minima

					for (int x = edgeBuffer; x < w - edgeBuffer; x++) {
						for (int y = edgeBuffer; y < h - edgeBuffer; y++) {

							if (minSortLevel[x][y] < 2
									&& minSortLevel[x][y] >= 0) {
								int val = 255 - minSortLevel[x][y] * 50;
								int val2 = 255 - minSortLevel[x][y] * 25;
								int val3 = 0;// 100 -
								// minSortLevel[WC.X][WC.Y]*10;
								// int val3 =
								// minSortLevel[WC.X][WC.Y]*minSortLevel[WC.X][WC.Y];

								if (val < 0)
									val = 0;
								if (val2 < 0)
									val2 = 0;
								if (val3 < 0)
									val3 = 0;
								// if (val3>255)val3=255;
								int colWS = ((int) (1) << 24) | ((val) << 16)
										| ((val2) << 8) | (val3); // mark minima
								// in RED

								if (minSortLevel[x][y] == 0) {
									colWS = ((int) (1) << 24) | ((255) << 16)
											| ((0) << 8) | (0); // mark minima
									// in RED
								}

								tf[i].biRay[WC.THREAD_SEGMENT].setRGB(x, y,
										colWS);
							}
						}
					}

					// color the segments

					// show features

					tf[i].layerStatus[WC.THREAD_SEGMENT] = WC.STATUS_COMPLETE;
				}
			}
		}
	}

	public void DWT_CPU_Filter(WITFrame[] tf, int a, int b, ArrayList paramList) {

		/*
		 * float[] kernel = new float[40];
		 * 
		 * for (int i=0; i<kernel.length; i++){ kernel[i] = 100f; //kernel[i] =
		 * .95f; }
		 */

		float[] kernel = { -.05f, -.2f, -.3f, -.35f, .1f, .6f, .9f, .6f, .1f,
				-.35f, -.3f, -.2f, -.05f };

		int kWindowSize = kernel.length;

		if (tf[a].layerStatus[WC.THREAD_LOAD] == WC.STATUS_COMPLETE) {

			int w = tf[a].biRay[WC.THREAD_LOAD].getWidth();
			int h = tf[a].biRay[WC.THREAD_LOAD].getHeight();

			// must check that frames a..b are present, plus the padding for the
			// temporal kernel
			int okayToProcess = 1;

			int startFrame = a - kWindowSize / 2;
			if (startFrame < 0)
				startFrame = 0;
			int endFrame = b + kWindowSize / 2;
			if (endFrame > tf.length)
				endFrame = tf.length;

			for (int i = startFrame; i < endFrame; i++) {
				if (tf[i].layerStatus[WC.THREAD_LOAD] == WC.STATUS_COMPLETE) {

				} else {
					okayToProcess = 0;
				}
			}

			if (okayToProcess == 1) {

				int k = -kWindowSize / 2;
				for (int i = a; i < b; i++) {

					if (tf[i].layerStatus[WC.THREAD_TEMPORAL] != WC.STATUS_COMPLETE) { // ==
						// WC.STATUS_READY
						tf[i].biRay[WC.THREAD_TEMPORAL] = new BufferedImage(w,
								h, BufferedImage.TYPE_INT_RGB);
						tf[i].layerStatus[WC.THREAD_TEMPORAL] = WC.STATUS_WORKING;
						for (int x = 0; x < w; x++) {
							for (int y = 0; y < h; y++) {

								int pxRay[] = new int[kWindowSize];

								for (int j = 0; j < kWindowSize; j++) {
									int curFrame = i + j + k;
									if (curFrame >= startFrame
											&& curFrame <= endFrame) {

										int rgba = tf[curFrame].biRay[WC.THREAD_LOAD]
												.getRGB(x, y);

										int v1 = ((rgba >> 16) & 0xff);

										pxRay[j] = v1;

									}
								}

								float val1 = 0;
								for (int j = 0; j < kWindowSize; j++) {

									val1 += ((float) pxRay[j]) * kernel[j];
								}
								if (val1 < 0) {
									val1 = 0;
								} else if (val1 > 255) {
									val1 = 255;
								}
								float val2 = val1 * 2f;
								float val3 = val1 / 2f;
								float val4 = val1 * 1.5f;
								if (val4 > 255)
									val4 = 255;

								float val5 = val1;
								// int colD = ((int)(1) << 24) | ((int)(val3) <<
								// 16) | ((int)(val3) << 8) | (int)(val2);
								// int colD = ((int)(1) << 24) | ((int)(val1) <<
								// 16) | ((int)(val1) << 8) | (int)(val1);

								int colD = ((int) (1) << 24)
										| ((int) (val5) << 16)
										| ((int) (val1) << 8) | (int) (val4);

								tf[i].biRay[WC.THREAD_TEMPORAL].setRGB(x, y,
										colD);

							}
						}
					}

					tf[i].layerStatus[WC.THREAD_TEMPORAL] = WC.STATUS_COMPLETE;

				}
			}
		}
	}

	public void DWT_CPU_DJ_Filter(WITFrame[] tf, int a, int b,
			ArrayList paramList) {

		int modeInputSource = WC.THREAD_LOAD;// WC.THREAD_LOAD; // may switch to
		// convolved to minimize artifact
		// errors
		int modeInputDependent = WC.THREAD_DEJITTER;

		float[] kernel = { -.05f, -.2f, -.3f, -.35f, .1f, .6f, .9f, .6f, .1f,
				-.35f, -.3f, -.2f, -.05f };

		int kWindowSize = kernel.length;

		if (tf[a].layerStatus[modeInputSource] == WC.STATUS_COMPLETE) {

			int w = tf[a].biRay[modeInputSource].getWidth();
			int h = tf[a].biRay[modeInputSource].getHeight();

			// must check that frames a..b are present, plus the padding for the
			// temporal kernel
			int okayToProcess = 1;

			int startFrame = a;// -kWindowSize/2;
			if (startFrame < 0)
				startFrame = 0;
			int endFrame = b + kWindowSize;
			if (endFrame > tf.length)
				endFrame = tf.length;

			for (int i = startFrame; i < endFrame; i++) {
				if (tf[i].layerStatus[modeInputDependent] == WC.STATUS_COMPLETE) {

				} else {
					okayToProcess = 0;
				}
			}

			if (okayToProcess == 1) {

				int k = -kWindowSize / 2;

				int frameSpan = b - a + 1;
				// populate the accumulated jitter - offsets
				int accumJittersX[][] = new int[frameSpan][kWindowSize];
				int accumJittersY[][] = new int[frameSpan][kWindowSize];

				int jitterAtCenterX[] = new int[frameSpan];
				int jitterAtCenterY[] = new int[frameSpan];

				for (int i = a; i < b; i++) {

					int accumX = 0;
					int accumY = 0;

					for (int j = 0; j < kWindowSize; j++) {

						int curFrame = i + j + k;
						if (curFrame >= startFrame && curFrame <= endFrame) {
							accumX += tf[curFrame - a].jitterWholePx[WC.X];
							accumY += tf[curFrame - a].jitterWholePx[WC.Y];

							if (curFrame == i) {
								jitterAtCenterX[i - a] = accumX;
								jitterAtCenterY[i - a] = accumY;
							}
							accumJittersX[i - a][j] = accumX;
							accumJittersY[i - a][j] = accumY;
						}
					}

					// adjust for jitter at kernel center

					for (int j = 0; j < kWindowSize; j++) {
						accumJittersX[i - a][j] -= jitterAtCenterX[i - a];
						accumJittersY[i - a][j] -= jitterAtCenterY[i - a];
					}

				}

				// accumulate the jitters

				// execute DWT
				for (int i = a; i < b; i++) {

					if (tf[i].layerStatus[WC.THREAD_TEMPORAL] != WC.STATUS_COMPLETE) { // ==
						// WC.STATUS_READY
						tf[i].biRay[WC.THREAD_TEMPORAL] = new BufferedImage(w,
								h, BufferedImage.TYPE_INT_RGB);
						tf[i].layerStatus[WC.THREAD_TEMPORAL] = WC.STATUS_WORKING;
						for (int x = 0; x < w; x++) {
							for (int y = 0; y < h; y++) {

								int pxRay[] = new int[kWindowSize];

								for (int j = 0; j < kWindowSize; j++) {
									int curFrame = i + j + k;
									if (curFrame >= startFrame
											&& curFrame <= endFrame) {

										int posX = x + accumJittersX[i - a][j];
										int posY = y + accumJittersY[i - a][j];

										if (posX < 0)
											posX = 0;
										if (posY < 0)
											posY = 0;
										if (posX > w - 1)
											posX = w - 1;
										if (posY > h - 1)
											posY = h - 1;

										int rgba = tf[curFrame].biRay[modeInputSource]
												.getRGB(posX, posY);

										int v1 = ((rgba >> 16) & 0xff);

										pxRay[j] = v1;

									}
								}

								float val1 = 0;
								for (int j = 0; j < kWindowSize; j++) {

									val1 += ((float) pxRay[j]) * kernel[j];
								}
								if (val1 < 0) {
									val1 = 0;
								} else if (val1 > 255) {
									val1 = 255;
								}
								float val2 = val1 * 2f;
								float val3 = val1 / 2f;
								float val4 = val1 * 1.5f;
								if (val4 > 255)
									val4 = 255;

								float val5 = val1;
							
								int colD = ((int) (1) << 24)
										| ((int) (val5) << 16)
										| ((int) (val1) << 8) | (int) (val4);

								tf[i].biRay[WC.THREAD_TEMPORAL].setRGB(x, y,
										colD);

							}
						}
					}
					tf[i].layerStatus[WC.THREAD_TEMPORAL] = WC.STATUS_COMPLETE;

				}
			}
		}
	}

	public void DWT_CPU_DJ_Filter2(WITFrame[] tf, int a, int b,
			ArrayList paramList) {

		int modeInputSource = WC.THREAD_LOAD;// WC.THREAD_LOAD; // may switch to
		// convolved to minimize artifact
		// errors
		int modeInputDependent = WC.THREAD_DEJITTER;

		float[] kernel = { -.05f, -.2f, -.3f, -.35f, .1f, .6f, .9f, .6f, .1f,
				-.35f, -.3f, -.2f, -.05f };

		int kWindowSize = kernel.length;

		if (tf[a].layerStatus[modeInputSource] == WC.STATUS_COMPLETE) {

			int w = tf[a].biRay[modeInputSource].getWidth();
			int h = tf[a].biRay[modeInputSource].getHeight();

			// must check that frames a..b are present, plus the padding for the
			// temporal kernel
			int okayToProcess = 1;

			int startFrame = a - kWindowSize / 2;
			if (startFrame < 0)
				startFrame = 0;
			int endFrame = b + kWindowSize / 2;
			if (endFrame > tf.length)
				endFrame = tf.length;

			for (int i = startFrame; i < endFrame; i++) {
				if (tf[i].layerStatus[modeInputDependent] == WC.STATUS_COMPLETE) {

				} else {
					okayToProcess = 0;
				}
			}

			if (okayToProcess == 1) {

				int k = -kWindowSize / 2;

				// accumulate the jitters

				for (int i = a; i < b; i++) {

					if (tf[i].layerStatus[WC.THREAD_TEMPORAL] != WC.STATUS_COMPLETE) { // ==
						// WC.STATUS_READY
						tf[i].biRay[WC.THREAD_TEMPORAL] = new BufferedImage(w,
								h, BufferedImage.TYPE_INT_RGB);
						tf[i].layerStatus[WC.THREAD_TEMPORAL] = WC.STATUS_WORKING;
						for (int x = 0; x < w; x++) {
							for (int y = 0; y < h; y++) {

								int pxRay[] = new int[kWindowSize];

								for (int j = 0; j < kWindowSize; j++) {
									int curFrame = i + j + k;
									if (curFrame >= startFrame
											&& curFrame <= endFrame) {

										int posX = x;
										int posY = y;

										if (posX < 0)
											posX = 0;
										if (posY < 0)
											posY = 0;
										if (posX > w - 1)
											posX = w - 1;
										if (posY > h - 1)
											posY = h - 1;

										int rgba = tf[curFrame].biRay[modeInputSource]
												.getRGB(posX, posY);

										int v1 = ((rgba >> 16) & 0xff);

										pxRay[j] = v1;

									}
								}

								float val1 = 0;
								for (int j = 0; j < kWindowSize; j++) {

									val1 += ((float) pxRay[j]) * kernel[j];
								}
								if (val1 < 0) {
									val1 = 0;
								} else if (val1 > 255) {
									val1 = 255;
								}
								float val2 = val1 * 2f;
								float val3 = val1 / 2f;
								float val4 = val1 * 1.5f;
								if (val4 > 255)
									val4 = 255;

								float val5 = val1;
					
								int colD = ((int) (1) << 24)
										| ((int) (val5) << 16)
										| ((int) (val1) << 8) | (int) (val4);

								tf[i].biRay[WC.THREAD_TEMPORAL].setRGB(x, y,
										colD);

							}
						}
					}

					tf[i].layerStatus[WC.THREAD_TEMPORAL] = WC.STATUS_COMPLETE;

				}
			}

		}

	}

	public void filterImage(WITFrame[] tf, int a, int b, ArrayList paramList) {

	}

	// PNGs
	public void exportMarkedImages(ArrayList wfl, int a, int b,
			ArrayList paramList) {

		int x1 = (Integer) paramList.get(0);
		int x2 = (Integer) paramList.get(1);
		int y1 = (Integer) paramList.get(2);
		int y2 = (Integer) paramList.get(3);

		int magnification = (Integer) paramList.get(6);

		int selX = Math.min(x1, x2) * magnification;
		int selY = Math.min(y1, y2) * magnification;
		int selW = Math.abs(x1 - x2) * magnification;
		int selH = Math.abs(y1 - y2) * magnification;

		// force even dimensions
		if (selW % 2 == 1) {
			selW -= 1;
		}
		if (selH % 2 == 1) {
			selH -= 1;
		}

		// final destination
		String destStr = (String) paramList.get(4);

		if (destStr.contains(".")) {
			destStr = destStr.substring(0, destStr.indexOf("."));
		}

		File uniqueFile = new File(destStr);
		boolean mk = uniqueFile.mkdir();

		if (mk) {

			// System.out.println(minX+" "+maxX);
			// / create the frames

			int inputSrc = WC.THREAD_LOAD_HDF5R;

			WITFrame wfa = (WITFrame) wfl.get(a);

			int nativeWidth = wfa.biRay[inputSrc].getWidth();
			int nativeHeight = wfa.biRay[inputSrc].getHeight();

			if (selW == 0) {
				selW = nativeWidth;
			}
			if (selH == 0) {
				selH = nativeHeight;
			}
			// force even dimensions
			if (selW % 2 == 1) {
				selW -= 1;
			}
			if (selH % 2 == 1) {
				selH -= 1;
			}

		
			int secBannerH = 20;
			int secBannerTextH = 14;
			int timeBannerH = 20;
			int timeBannerTextH = secBannerTextH;

			int finalW = selW;
			int finalH = selH + 2 * secBannerH + timeBannerH;

			BufferedImage outImage = null;

			System.out.println("   CREATING FRAMES");

			int diffX = 0;
			int diffY = 0;

			int dejitterPlaybackX = 0;
			int dejitterPlaybackY = 0;

			outImage = new BufferedImage(finalW, finalH,
					BufferedImage.TYPE_INT_RGB);

			Graphics2D g = (Graphics2D) outImage.getGraphics();

			int fa = a;
			int fb = b;
			if (fa < 0)
				fa = 0;
			if (fb > wfl.size())
				fb = wfl.size();

			int localFrameCount = 1;

			for (int i = fa; i < fb; i++) {

				WITFrame wfi = (WITFrame) wfl.get(i);
				int fNo = i - fa;

				g.drawImage(wfi.biRay[inputSrc], -selX, -selY + secBannerH
						+ timeBannerH, null);

				// security markings

				g.setColor(Color.RED);
				g.fillRect(0, 0, finalW, secBannerH);
				g.fillRect(0, finalH - secBannerH, finalW, secBannerH);

				// g.setColor(Color.WHITE);
				g.setColor(Color.BLACK);
				String secStr = "SECRET";
				int secStrX = finalW / 2 - (secStr.length() / 2 * 6);
				g.drawString(secStr, secStrX, secBannerTextH);
				g.drawString(secStr, secStrX, finalH - secBannerH
						+ secBannerTextH);

				// timestamps

				if (wfi.timeStampStr.length() > 1) { // only overlay timestamp
					// if we have it
					String timeStr = "SCAN " + localFrameCount + " - "
							+ wfi.timeStampStr;
					// String timeStr = tf[i].timeStampStr;
					int timeStrX = finalW / 2 - (timeStr.length() / 2 * 6);
					g.setColor(Color.LIGHT_GRAY);
					g.fillRect(0, secBannerH, finalW, timeBannerH);

					g.setColor(Color.BLACK);
					g.drawString(timeStr, timeStrX, timeBannerH
							+ timeBannerTextH);

					try {
						File pngFile = new File(destStr + "/" + fNo + ".png");
						pngFile.setReadable(true, false);

						ImageIO.write(outImage, "png", pngFile);
						if (i % 10 == 0 || i > b - 10)
							System.out.println("   FRAME " + i);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					localFrameCount++;
				}
			}
			System.out.println("ANNOTATED PNG EXPORT COMPLETE");
		}

	}

	// different for products versus processing
	public String opIDtoName(int op) {
		String opStr = "[UNKNOWN_OP]";

		if (op == WC.THREAD_LOAD) {
			opStr = "RAW";
		} else if (op == WC.THREAD_LOAD_HDF5R) {

			opStr = "RAW";
		} else if (op == WC.THREAD_HISTOGRAM) {

			opStr = "HISTOGRAM";
		} else if (op == WC.THREAD_CONTRAST) {

			opStr = "CONTRAST";

		} else if (op == WC.THREAD_DIFF) {

			opStr = "DIFFS";
		} else if (op == WC.THREAD_TIMELAPSE) {

			opStr = "TIMELAPSE";
		} else if (op == WC.THREAD_TEMPORAL) {

			opStr = "TEMPORAL1";
		} else if (op == WC.THREAD_REGISTRATION) {

			opStr = "REGISTRATION";
		}

		return opStr;
	}

	public WITFrame prepFrameGPU(WITFrame w, int layer, int sca) {
		
		w = interpolateLonLatFrame((WITFrame) w);

		return w;

	}

	public BufferedImage mercProjAndAverage(int rasterMapW, int rasterMapH,
			float scale, WITFrame w, int layer, int sca,
			ArrayList contrastParamList) {

		int inputSrc = layer;// THREAD_CONTRAST;//layer; //!! HACK
		scaOffsets = initSCAoffsets(1);

		long sumIntensity[][] = new long[rasterMapW][rasterMapH];
		int hitCount[][] = new int[rasterMapW][rasterMapH]; // used for
		// averaging values
		// of the hits

		BufferedImage outputImage = new BufferedImage(rasterMapW, rasterMapH,
				BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = (Graphics2D) outputImage.getGraphics();

		WITFrame tempFrame = null;
		// interpolate geolocation

		tempFrame = interpolateLonLatFrame((WITFrame) w);

		// accumulate the value
		for (int x = 0; x < w.numChannels; x++) {
			for (int y = 0; y < w.numLines; y++) {

				// keep 0 to 360 instead of -180 to 180

				int projX = (int) ((tempFrame.geoLocDataFull[x][y][0] + 180.0f) * scale);
				int projY = rasterMapH
						- (int) ((tempFrame.geoLocDataFull[x][y][1] + 90.0f) * scale);

				int posX = scaOffsets[sca][WC.X];// scaID*768;
				int posY = scaOffsets[sca][WC.Y];// 0;

				int frameYoffset = tempFrame.yAlignGross;

				int finalX = x + posX;
				int finalY = y + posY;// +frameYoffset;

				if (projX >= 0 && projX <= rasterMapW && projY >= 0
						&& projY <= rasterMapH) {

					if (finalX >= 0 && finalX < w.biRay[inputSrc].getWidth()
							&& finalY >= 0
							&& finalY < w.biRay[inputSrc].getHeight()) {

						if (inputSrc == -1) {
							// if (inputSrc == WC.THREAD_CONTRAST){
							int rgba = w.biRay[inputSrc].getRGB(finalX, finalY);

							int vals[] = new int[3];
							vals[WC.B] = w.hdrValsRaw[finalX][finalY];

							if (vals[WC.B] > 0) { // ignore the fringe black
								// bars
								// if (vals[WC.B] >= 5){ // ignore the fringe
								// black bars
								sumIntensity[projX][projY] += vals[WC.B];
								hitCount[projX][projY]++;
							}
						} else {
							int rgba = w.biRay[inputSrc].getRGB(finalX, finalY);

							int vals[] = new int[3];
							vals[WC.R] += ((rgba >> 16) & 0xff);
							vals[WC.G] += ((rgba >> 8) & 0xff);
							vals[WC.B] += ((rgba) & 0xff);

							if (vals[WC.B] > 0) { // ignore the fringe black
								// bars
								// if (vals[WC.B] >= 5){ // ignore the fringe
								// black bars
								sumIntensity[projX][projY] += vals[WC.B];
								hitCount[projX][projY]++;
							}
						}

					} else {
		
					}
				}

			}
		}

		// raster the reprojected items
		for (int x = 0; x < rasterMapW; x++) {
			for (int y = 0; y < rasterMapH; y++) {
				if (hitCount[x][y] > 0) {

					sumIntensity[x][y] = (int) ((float) sumIntensity[x][y] / (float) hitCount[x][y]);

					int val = 0;

					if (contrastParamList == null) {
						val = (int) sumIntensity[x][y];

						if (val > 255)
							val = 255;
						if (val < 0)
							val = 0;

					} else {
						val = adjustContrastCurvePixel(
								(int) sumIntensity[x][y], contrastParamList);
					}

					int rgba = (255 << 24) | (val << 16) | (val << 8) | val;

					outputImage.setRGB(x, y, rgba);

				} else {
					// System.out.println("no hits at "+x+" "+y);
				}

			}
		}

		return outputImage;
	}

	public int adjustContrastCurvePixel(int inputIntensity, ArrayList paramList) {
		int finalIntensity = 0;

		int userMinIntensity = (Integer) paramList.get(0); // 6
		int userMaxIntensity = (Integer) paramList.get(1); // 7

		ArrayList userControlPoints = (ArrayList) paramList.get(2); // 8

		ArrayList completeCP = new ArrayList();

		UserContrastCP u1 = new UserContrastCP();
		u1.intensity = userMinIntensity;
		u1.rasterIntensity = 0;

		UserContrastCP u2 = new UserContrastCP();
		u2.intensity = userMaxIntensity;
		u2.rasterIntensity = 255;

		completeCP.add(u1);
		for (int i = 0; i < userControlPoints.size(); i++) {
			UserContrastCP ux = (UserContrastCP) userControlPoints.get(i);
			completeCP.add(ux);
		}
		completeCP.add(u2);

		int baseIntensities[] = new int[completeCP.size() + 1];
		int ceilIntensities[] = new int[completeCP.size() + 1];
		int baseRasterIntensities[] = new int[completeCP.size() + 1];
		int ceilRasterIntensities[] = new int[completeCP.size() + 1];
		float scaleIntensities[] = new float[completeCP.size() + 1];
		int binMap[] = new int[WITFrame.histBins];

		int lastBinIndex = completeCP.size() - 1;
		// lower vals
		for (int j = 0; j < userMinIntensity; j++) {
			binMap[j] = 0;
		}
		// upper vals
		for (int j = userMaxIntensity; j < WITFrame.histBins; j++) {
			binMap[j] = lastBinIndex;
		}

		UserContrastCP cpf = (UserContrastCP) completeCP.get(lastBinIndex);
		baseIntensities[lastBinIndex] = 0;// cpf.intensity;
		ceilIntensities[lastBinIndex] = 255;// cpf.intensity;
		scaleIntensities[lastBinIndex] = 1.0f;
		for (int j = 0; j < WITFrame.histBins; j++) {
			// for (int j=cpf.intensity; j<WITFrame.histBins; j++){
			binMap[j] = lastBinIndex;
		}

		for (int i = 0; i < completeCP.size() - 1; i++) {
			UserContrastCP cp1 = (UserContrastCP) completeCP.get(i);
			UserContrastCP cp2 = (UserContrastCP) completeCP.get(i + 1);

			baseIntensities[i] = cp1.intensity;
			ceilIntensities[i] = cp2.intensity;
			baseRasterIntensities[i] = cp1.rasterIntensity;
			ceilRasterIntensities[i] = cp2.rasterIntensity;
			// scaleIntensities[i] =
			// (float)(ceilIntensities[i]-baseIntensities[i])/(float)(cp2.rasterIntensity-cp1.rasterIntensity);
			float diffInput = (float) (ceilIntensities[i] - baseIntensities[i]);
			float diffOutput = (float) (ceilRasterIntensities[i] - baseRasterIntensities[i]);
			// if (diffIntensities == 0){
			// diffIntensities = .01f;
			// }

			scaleIntensities[i] = (float) (diffOutput / diffInput);

			// need to map the difference between input intensities to raster
			// range

			for (int j = baseIntensities[i]; j <= ceilIntensities[i]; j++) {
				binMap[j] = i;
			}

			// System.out.println("FILTER CP "+i+" INPUT "+baseIntensities[i]+"-"+ceilIntensities[i]+" OUTPUT "+baseRasterIntensities[i]+"-"+ceilRasterIntensities[i]+" scale "+scaleIntensities[i]);
		}

		int valOrig = inputIntensity;

		int val2 = 0;

		val2 = (int) ((float) (valOrig - baseIntensities[binMap[valOrig]]) * scaleIntensities[binMap[valOrig]]);

		val2 += baseRasterIntensities[binMap[valOrig]];

		if (val2 < 0)
			val2 = 0;
		if (val2 > 255)
			val2 = 255;

		finalIntensity = val2;
		return finalIntensity;
	}

	public void exportImagesMerc(ArrayList wfl, int a, int b,
			ArrayList paramList) {

		scaOffsets = initSCAoffsets(1);

		Color emptyColor = new Color(0, 40, 90);

		int bounds[][] = (int[][]) paramList.get(9);
		int boundsMod[][] = new int[2][2];

		float scale = (Float) paramList.get(10);
		int addUnprojected = (Integer) paramList.get(11);

		// pass contrast params to reprojection

		ArrayList contrastParamList = (ArrayList) paramList.get(12);

		boundsMod[WC.START][WC.GEODATA_LON] = bounds[WC.START][WC.GEODATA_LON] + 180;
		boundsMod[WC.END][WC.GEODATA_LON] = bounds[WC.END][WC.GEODATA_LON] + 180;
		boundsMod[WC.START][WC.GEODATA_LAT] = bounds[WC.START][WC.GEODATA_LAT] + 90;
		boundsMod[WC.END][WC.GEODATA_LAT] = bounds[WC.END][WC.GEODATA_LAT] + 90;

		int lonSpan = 360;
		int latSpan = 180;

		int rasterMapW = (int) (lonSpan * scale);
		int rasterMapH = (int) (latSpan * scale);

		int lonSpanFinal = ((boundsMod[WC.END][WC.GEODATA_LON]) - (boundsMod[WC.START][WC.GEODATA_LON]));
		int latSpanFinal = ((boundsMod[WC.END][WC.GEODATA_LAT]) - (boundsMod[WC.START][WC.GEODATA_LAT]));

		int rasterOutW = (int) (lonSpanFinal * scale);
		int rasterOutH = (int) (latSpanFinal * scale);

		// //
		int[] channelMask = (int[]) paramList.get(6);
		int scanExportMode = (Integer) paramList.get(7);
		int magnification = (Integer) paramList.get(8);

		String productClassificationLabelStr = (String) paramList.get(9);
		// String securityMarkStr = (String)paramList.get(8);
		// String securityMarkStr = "SECRET";

		// final destination
		String destStr = (String) paramList.get(4);
		String extStr = (String) paramList.get(5);

		File uniqueFile = new File(destStr);
		boolean mk = uniqueFile.mkdir();

		for (int c = 0; c < channelMask.length; c++) {

			BufferedImage outImage = new BufferedImage(rasterMapW, rasterMapH,
					BufferedImage.TYPE_INT_ARGB);
			Graphics2D g = (Graphics2D) outImage.getGraphics();

			BufferedImage finalImage = new BufferedImage(rasterOutW,
					rasterOutH, BufferedImage.TYPE_INT_ARGB);
			Graphics2D gFinal = (Graphics2D) finalImage.getGraphics();
			gFinal.setColor(emptyColor);
			gFinal.fillRect(0, 0, rasterOutW, rasterOutH);

			BufferedImage labelImage = new BufferedImage(rasterOutW,
					rasterOutH, BufferedImage.TYPE_INT_ARGB);
			Graphics2D gLabel = (Graphics2D) labelImage.getGraphics();

			g.setColor(emptyColor);
			g.fillRect(0, 0, rasterMapW, rasterMapH);

			if (channelMask[c] == 1) {
				int inputSrc = c;// WC.THREAD_LOAD_HDF5R;

				File layerDir = new File(destStr + "/" + opIDtoName(inputSrc));
				boolean mk2 = layerDir.mkdir();

				// String commandStr = "C:/ffmpeg/bin/ffmpeg";
				// String commandStr = "C:\\Program Files (x86)\\WinFF\\ffmpeg";
				// // win install location
				int seqPad = -1;

				// String scratchStr="C:/javadev/WIT/temp/";

				int VIDEO_EXPORT_SCAN_DIR0 = 1;
				int VIDEO_EXPORT_SCAN_DIR1 = 1;

				int x1 = (Integer) paramList.get(0);
				int x2 = (Integer) paramList.get(1);
				int y1 = (Integer) paramList.get(2);
				int y2 = (Integer) paramList.get(3);

				int selX = Math.min(x1, x2) * magnification;
				int selY = Math.min(y1, y2) * magnification;
				int selW = Math.abs(x1 - x2) * magnification;
				int selH = Math.abs(y1 - y2) * magnification;

				// force even dimensions
				if (selW % 2 == 1) {
					selW -= 1;
				}
				if (selH % 2 == 1) {
					selH -= 1;
				}

				// need to 'cut out' a region from raw data; from other layers
				// we can start at 0,0
				if (inputSrc != WC.THREAD_LOAD_HDF5R) {
					selX = 0;
					selY = 0;
				}

				if (channelMask[inputSrc] == 1) { // if mask is 1, record this
					// channel
					System.out.println("EXPORT LAYER " + inputSrc);
					WITFrame wfa = (WITFrame) wfl.get(a); // some filters like
					// TIMELAPSE have a
					// lead time; look
					// at the end of
					// sequence for
					// validity
					if (wfa.biRay[inputSrc] != null) {
						int nativeWidth = wfa.biRay[inputSrc].getWidth();
						int nativeHeight = wfa.biRay[inputSrc].getHeight();

						if (selW == 0) {
							selW = nativeWidth;
						}

						if (selH == 0) {
							selH = nativeHeight;
						}

						// force even dimensions
						if (selW % 2 == 1) {
							selW -= 1;
						}
						if (selH % 2 == 1) {
							selH -= 1;
						}

						int secBannerH = 20;
						int secBannerTextH = 14;
						int timeBannerH = 20;
						int timeBannerTextH = secBannerTextH;

						// int finalW = (selW);
						// int finalH = (selH) + (2 * secBannerH + timeBannerH);

						if (true) {
							try {

								System.out.println("   CREATING FRAMES");

								int diffX = 0;
								int diffY = 0;

								int dejitterPlaybackX = 0;
								int dejitterPlaybackY = 0;

								// handle temporal bounds checking
								int fa = a;
								int fb = b;
								if (fa < 0)
									fa = 0;
								if (fb > wfl.size())
									fb = wfl.size();

								int startFrame = fa;
								int skipFrame = 1;
								int localFrameCount = 1;

								for (int i = startFrame; i < fb; i += skipFrame) {
									WITFrame wfi = (WITFrame) wfl.get(i);
									int fNo = i - fa;

									// even frames
									if ((scanExportMode == WC.SCAN_DIR_EVEN || scanExportMode == WC.SCAN_DIR_BOTH)
											&& wfi.scanDirection == 0) {

										// overlay undistorted
										// g.drawImage(wfi.biRay[inputSrc],rasterOutW/2
										// -
										// wfi.biRay[inputSrc].getWidth()/2,rasterOutH-wfi.biRay[inputSrc].getHeight(),null);

										if (inputSrc == WC.THREAD_CONTRAST) {

											// tempContrastParamList
											ArrayList tempWFL = new ArrayList();
											wfi.biRay[WC.THREAD_CONTRAST] = null;
											wfi.layerStatus[WC.THREAD_CONTRAST] = WC.STATUS_READY;
											tempWFL.add(wfi);

											// user's filter region

											// for temp full-scene contrast
											ArrayList tempContrastParamList = new ArrayList();
											tempContrastParamList
													.add(WC.THREAD_LOAD_HDF5R); // 0
											tempContrastParamList.add(0); // 1
											tempContrastParamList
													.add(wfi.biRay[WC.THREAD_LOAD_HDF5R]
															.getWidth()); // 2
											tempContrastParamList.add(0); // 3
											tempContrastParamList
													.add(wfi.biRay[WC.THREAD_LOAD_HDF5R]
															.getHeight()); // 4

											tempContrastParamList
													.add(WC.CONTRAST_USER); // 5
											tempContrastParamList
													.add(contrastParamList
															.get(0)); // 6
											tempContrastParamList
													.add(contrastParamList
															.get(1)); // 7
											tempContrastParamList
													.add(contrastParamList
															.get(2)); // 8
											// end user filter

											userContrastImage(tempWFL, 0, 1,
													tempContrastParamList);
											WITFrame tempWFContrast = (WITFrame) tempWFL
													.get(0);

											for (int sca = 0; sca < 6; sca++) {
										
												BufferedImage bProj = mercProjAndAverage(
														rasterMapW, rasterMapH,
														scale, tempWFContrast,
														inputSrc, sca, null);
												gFinal
														.drawImage(
																bProj,
																(int) (-boundsMod[WC.START][WC.GEODATA_LON] * scale),
																(int) (-boundsMod[WC.START][WC.GEODATA_LAT] * scale),
																null);
											}

											if (addUnprojected == 1) {
												gFinal
														.drawImage(
																tempWFContrast.biRay[inputSrc],
																rasterOutW
																		/ 2
																		- tempWFContrast.biRay[inputSrc]
																				.getWidth()
																		/ 2,
																rasterOutH
																		- tempWFContrast.biRay[inputSrc]
																				.getHeight(),
																null);
											}

										} else {

											for (int sca = 0; sca < 6; sca++) {
												BufferedImage bProj = mercProjAndAverage(
														rasterMapW, rasterMapH,
														scale, wfi, inputSrc,
														sca, null);
												gFinal
														.drawImage(
																bProj,
																(int) (-boundsMod[WC.START][WC.GEODATA_LON] * scale),
																(int) (-boundsMod[WC.START][WC.GEODATA_LAT] * scale),
																null);
											}

											if (addUnprojected == 1) {
												gFinal
														.drawImage(
																wfi.biRay[inputSrc],
																rasterOutW
																		/ 2
																		- wfi.biRay[inputSrc]
																				.getWidth()
																		/ 2,
																rasterOutH
																		- wfi.biRay[inputSrc]
																				.getHeight(),
																null);
											}

										}

										// security markings
										gLabel.setColor(Color.RED);
										gLabel.fillRect(0, 0, rasterOutW,
												secBannerH);
										gLabel.fillRect(0, rasterOutH
												- secBannerH, rasterOutW,
												secBannerH);

										// timestamps
										String timeStr = "";
										int timeStrX = 30;
										if (wfi.timeStampStr.length() > 1) {

											timeStr = "SCAN " + localFrameCount
													+ " - " + wfi.timeStampStr;
										}

										gLabel.setColor(Color.WHITE);
										gLabel.drawString(
												productClassificationLabelStr
														+ "           "
														+ timeStr, timeStrX,
												timeBannerTextH);
										gLabel.drawString(
												productClassificationLabelStr
														+ "           "
														+ timeStr,
												timeStrX + 1, timeBannerTextH);

										gLabel.drawString(
												productClassificationLabelStr
														+ "           "
														+ timeStr, timeStrX,
												rasterOutH - secBannerH
														+ timeBannerTextH);
										gLabel.drawString(
												productClassificationLabelStr
														+ "           "
														+ timeStr,
												timeStrX + 1, rasterOutH
														- secBannerH
														+ timeBannerTextH);

										gFinal
												.drawImage(labelImage, 0, 0,
														null);

										String imageFileStr = destStr + "/"
												+ opIDtoName(inputSrc) + "/"
												+ localFrameCount + ".png";
										System.out.println("SAVING IMAGE "
												+ imageFileStr);

										File pngFile = new File(imageFileStr);
										pngFile.setReadable(true, false);
										ImageIO.write(finalImage, "png",
												pngFile);

										localFrameCount++;
									}

									// odd frames
									if ((scanExportMode == WC.SCAN_DIR_ODD || scanExportMode == WC.SCAN_DIR_BOTH)
											&& wfi.scanDirection == 1
											&& wfi.biRay[inputSrc] != null) {

										if (inputSrc == WC.THREAD_CONTRAST) {

											// tempContrastParamList
											ArrayList tempWFL = new ArrayList();
											wfi.biRay[WC.THREAD_CONTRAST] = null;
											wfi.layerStatus[WC.THREAD_CONTRAST] = WC.STATUS_READY;
											tempWFL.add(wfi);

											// user's filter region

											// for temp full-scene contrast
											ArrayList tempContrastParamList = new ArrayList();
											tempContrastParamList
													.add(WC.THREAD_LOAD_HDF5R); // 0
											tempContrastParamList.add(0); // 1
											tempContrastParamList
													.add(wfi.biRay[WC.THREAD_LOAD_HDF5R]
															.getWidth()); // 2
											tempContrastParamList.add(0); // 3
											tempContrastParamList
													.add(wfi.biRay[WC.THREAD_LOAD_HDF5R]
															.getHeight()); // 4

											tempContrastParamList
													.add(WC.CONTRAST_USER); // 5
											tempContrastParamList
													.add(contrastParamList
															.get(0)); // 6
											tempContrastParamList
													.add(contrastParamList
															.get(1)); // 7
											tempContrastParamList
													.add(contrastParamList
															.get(2)); // 8
											// end user filter

											userContrastImage(tempWFL, 0, 1,
													tempContrastParamList);
											WITFrame tempWFContrast = (WITFrame) tempWFL
													.get(0);

											for (int sca = 0; sca < 6; sca++) {
											
												BufferedImage bProj = mercProjAndAverage(
														rasterMapW, rasterMapH,
														scale, tempWFContrast,
														inputSrc, sca, null);
												gFinal
														.drawImage(
																bProj,
																(int) (-boundsMod[WC.START][WC.GEODATA_LON] * scale),
																(int) (-boundsMod[WC.START][WC.GEODATA_LAT] * scale),
																null);
											}

											if (addUnprojected == 1) {
												gFinal
														.drawImage(
																tempWFContrast.biRay[inputSrc],
																rasterOutW
																		/ 2
																		- tempWFContrast.biRay[inputSrc]
																				.getWidth()
																		/ 2,
																rasterOutH
																		- tempWFContrast.biRay[inputSrc]
																				.getHeight(),
																null);
											}

										} else {

											for (int sca = 0; sca < 6; sca++) {
												BufferedImage bProj = mercProjAndAverage(
														rasterMapW, rasterMapH,
														scale, wfi, inputSrc,
														sca, null);
												gFinal
														.drawImage(
																bProj,
																(int) (-boundsMod[WC.START][WC.GEODATA_LON] * scale),
																(int) (-boundsMod[WC.START][WC.GEODATA_LAT] * scale),
																null);
											}

											if (addUnprojected == 1) {
												gFinal
														.drawImage(
																wfi.biRay[inputSrc],
																rasterOutW
																		/ 2
																		- wfi.biRay[inputSrc]
																				.getWidth()
																		/ 2,
																rasterOutH
																		- wfi.biRay[inputSrc]
																				.getHeight(),
																null);
											}

										}

										// security markings
										gLabel.setColor(Color.RED);
										gLabel.fillRect(0, 0, rasterOutW,
												secBannerH);
										gLabel.fillRect(0, rasterOutH
												- secBannerH, rasterOutW,
												secBannerH);

										// timestamps
										String timeStr = "";
										int timeStrX = 30;
										if (wfi.timeStampStr.length() > 1) {

											timeStr = "SCAN " + localFrameCount
													+ " - " + wfi.timeStampStr;
										}

										gLabel.setColor(Color.WHITE);
										gLabel.drawString(
												productClassificationLabelStr
														+ "           "
														+ timeStr, timeStrX,
												timeBannerTextH);
										gLabel.drawString(
												productClassificationLabelStr
														+ "           "
														+ timeStr,
												timeStrX + 1, timeBannerTextH);

										gLabel.drawString(
												productClassificationLabelStr
														+ "           "
														+ timeStr, timeStrX,
												rasterOutH - secBannerH
														+ timeBannerTextH);
										gLabel.drawString(
												productClassificationLabelStr
														+ "           "
														+ timeStr,
												timeStrX + 1, rasterOutH
														- secBannerH
														+ timeBannerTextH);

										gFinal
												.drawImage(labelImage, 0, 0,
														null);

										String imageFileStr = destStr + "/"
												+ opIDtoName(inputSrc) + "/"
												+ localFrameCount + ".png";
										System.out.println("SAVING IMAGE "
												+ imageFileStr);

										File pngFile = new File(imageFileStr);
										pngFile.setReadable(true, false);
										ImageIO.write(finalImage, "png",
												pngFile);

										localFrameCount++;
									}
								}

							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

						}
					}
				}

			}
		}
		System.out.println("IMAGE EXPORT COMPLETE");
	}

	public void exportImages2(ArrayList wfl, int a, int b, ArrayList paramList) {

		int[] channelMask = (int[]) paramList.get(6);
		int scanExportMode = (Integer) paramList.get(7);
		int magnification = (Integer) paramList.get(8);
		// String securityMarkStr = (String)paramList.get(8);
		String securityMarkStr = "SECRET";

		// final destination
		String destStr = (String) paramList.get(4);
		String extStr = (String) paramList.get(5);

		File uniqueFile = new File(destStr);
		boolean mk = uniqueFile.mkdir();

		for (int c = 0; c < channelMask.length; c++) {

			if (channelMask[c] == 1) {
				int inputSrc = c;// WC.THREAD_LOAD_HDF5R;

				File layerDir = new File(destStr + "/" + opIDtoName(inputSrc));
				boolean mk2 = layerDir.mkdir();

				// String commandStr = "C:/ffmpeg/bin/ffmpeg";
				// String commandStr = "C:\\Program Files (x86)\\WinFF\\ffmpeg";
				// // win install location
				int seqPad = -1;

				// String scratchStr="C:/javadev/WIT/temp/";

				int VIDEO_EXPORT_SCAN_DIR0 = 1;
				int VIDEO_EXPORT_SCAN_DIR1 = 1;

				int x1 = (Integer) paramList.get(0);
				int x2 = (Integer) paramList.get(1);
				int y1 = (Integer) paramList.get(2);
				int y2 = (Integer) paramList.get(3);

				int selX = Math.min(x1, x2) * magnification;
				int selY = Math.min(y1, y2) * magnification;
				int selW = Math.abs(x1 - x2) * magnification;
				int selH = Math.abs(y1 - y2) * magnification;

				// force even dimensions
				if (selW % 2 == 1) {
					selW -= 1;
				}
				if (selH % 2 == 1) {
					selH -= 1;
				}

				// need to 'cut out' a region from raw data; from other layers
				// we can start at 0,0
				if (inputSrc != WC.THREAD_LOAD_HDF5R) {
					selX = 0;
					selY = 0;
				}

				if (channelMask[inputSrc] == 1) { // if mask is 1, record this
					// channel
					System.out.println("EXPORT LAYER " + inputSrc);
					WITFrame wfa = (WITFrame) wfl.get(b - 1); // some filters
	
					if (wfa.biRay[inputSrc] != null) {
						int nativeWidth = wfa.biRay[inputSrc].getWidth();
						int nativeHeight = wfa.biRay[inputSrc].getHeight();

						if (selW == 0) {
							selW = nativeWidth;
						}

						if (selH == 0) {
							selH = nativeHeight;
						}

						// force even dimensions
						if (selW % 2 == 1) {
							selW -= 1;
						}
						if (selH % 2 == 1) {
							selH -= 1;
						}

						int secBannerH = 20;
						int secBannerTextH = 14;
						int timeBannerH = 20;
						int timeBannerTextH = secBannerTextH;

						int finalW = (selW);
						int finalH = (selH) + (2 * secBannerH + timeBannerH);

						if (true) {
							try {
								BufferedImage outImage = null;

								BufferedImage outImageA = new BufferedImage(
										finalW, finalH,
										BufferedImage.TYPE_INT_RGB);

								Graphics2D gA = (Graphics2D) outImageA
										.getGraphics();

								System.out.println("   CREATING FRAMES");

								int diffX = 0;
								int diffY = 0;

								int dejitterPlaybackX = 0;
								int dejitterPlaybackY = 0;

								outImage = new BufferedImage(finalW, finalH,
										BufferedImage.TYPE_INT_RGB);

								Graphics2D g = (Graphics2D) outImage
										.getGraphics();

								// handle temporal bounds checking
								int fa = a;
								int fb = b;
								if (fa < 0)
									fa = 0;
								if (fb > wfl.size())
									fb = wfl.size();

								int startFrame = fa;
								int skipFrame = 1;
								int localFrameCount = 1;

								for (int i = startFrame; i < fb; i += skipFrame) {
									WITFrame wfi = (WITFrame) wfl.get(i);
									int fNo = i - fa;

									g.setColor(Color.BLACK);
									g.fillRect(0, 0, finalW, finalH);

									// even frames
									if ((scanExportMode == WC.SCAN_DIR_EVEN || scanExportMode == WC.SCAN_DIR_BOTH)
											&& wfi.scanDirection == 0) {

										if (inputSrc == WC.THREAD_LOAD_HDF5R) {
											g.drawImage(wfi.biRay[inputSrc],
													-selX, -selY + secBannerH
															+ timeBannerH,
													wfi.biRay[inputSrc]
															.getWidth()
															* magnification,
													wfi.biRay[inputSrc]
															.getHeight()
															* magnification,
													null);
										} else {
											g.drawImage(wfi.biRay[inputSrc],
													-selX, -selY + secBannerH
															+ timeBannerH,
													finalW, finalH, null);
										}

										// security markings
										g.setColor(Color.RED);
										g.fillRect(0, 0, finalW, secBannerH);
										g.fillRect(0, finalH - secBannerH,
												finalW, secBannerH);

										// g.setColor(Color.WHITE);
										g.setColor(Color.BLACK);
										int secStrX = finalW
												/ 2
												- (securityMarkStr.length() / 2 * 6);
										g.drawString(securityMarkStr, secStrX,
												secBannerTextH);
										g.drawString(securityMarkStr, secStrX,
												finalH - secBannerH
														+ secBannerTextH);

										// timestamps
										if (wfi.timeStampStr.length() > 1) {

											String timeStr = "SCAN "
													+ localFrameCount + " - "
													+ wfi.timeStampStr;
											// String timeStr =
											// tf[i].timeStampStr;
											int timeStrX = finalW
													/ 2
													- (timeStr.length() / 2 * 6);
											g.setColor(Color.LIGHT_GRAY);
											g.fillRect(0, secBannerH, finalW,
													timeBannerH);

											g.setColor(Color.BLACK);
											g.drawString(timeStr, timeStrX,
													timeBannerH
															+ timeBannerTextH);
										}

										String imageFileStr = destStr + "/"
												+ opIDtoName(inputSrc) + "/"
												+ localFrameCount + ".png";
										System.out.println("SAVING IMAGE "
												+ imageFileStr);

										File pngFile = new File(imageFileStr);
										pngFile.setReadable(true, false);
										ImageIO.write(outImage, "png", pngFile);

										localFrameCount++;
									}

									// odd frames
									if ((scanExportMode == WC.SCAN_DIR_ODD || scanExportMode == WC.SCAN_DIR_BOTH)
											&& wfi.scanDirection == 1
											&& wfi.biRay[inputSrc] != null) {

										if (inputSrc == WC.THREAD_LOAD_HDF5R) {
											g.drawImage(wfi.biRay[inputSrc],
													-selX, -selY + secBannerH
															+ timeBannerH,
													wfi.biRay[inputSrc]
															.getWidth()
															* magnification,
													wfi.biRay[inputSrc]
															.getHeight()
															* magnification,
													null);
										} else {
											g.drawImage(wfi.biRay[inputSrc],
													-selX, -selY + secBannerH
															+ timeBannerH,
													finalW, finalH, null);
										}

										// security markings

										g.setColor(Color.RED);
										g.fillRect(0, 0, finalW, secBannerH);
										g.fillRect(0, finalH - secBannerH,
												finalW, secBannerH);

										// g.setColor(Color.WHITE);
										g.setColor(Color.BLACK);
										int secStrX = finalW
												/ 2
												- (securityMarkStr.length() / 2 * 6);
										g.drawString(securityMarkStr, secStrX,
												secBannerTextH);
										g.drawString(securityMarkStr, secStrX,
												finalH - secBannerH
														+ secBannerTextH);

										// timestamps
										if (wfi.timeStampStr.length() > 1) {

											String timeStr = "SCAN "
													+ localFrameCount + " - "
													+ wfi.timeStampStr;

											int timeStrX = finalW
													/ 2
													- (timeStr.length() / 2 * 6);
											g.setColor(Color.LIGHT_GRAY);
											g.fillRect(0, secBannerH, finalW,
													timeBannerH);

											g.setColor(Color.BLACK);
											g.drawString(timeStr, timeStrX,
													timeBannerH
															+ timeBannerTextH);
										}

										String imageFileStr = destStr + "/"
												+ opIDtoName(inputSrc) + "/"
												+ localFrameCount + ".png";
										System.out.println("SAVING IMAGE "
												+ imageFileStr);

										File pngFile = new File(imageFileStr);
										pngFile.setReadable(true, false);
										ImageIO.write(outImage, "png", pngFile);

										localFrameCount++;
									}
								}

							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

						}
					}
				}

			}
		}
		System.out.println("IMAGE EXPORT COMPLETE");
	}

	public void applyEQ(BufferedImage b, float expansionLimit) {

		int w = b.getWidth();
		int h = b.getHeight();

		int data[][] = new int[w][h];

		int valDist[] = new int[256];

		int pxCount = 0;

		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int vals[] = new int[4];
				int rgba = b.getRGB(x, y);
				// vals[WC.A] += ((rgba >> 24) & 0xff);
				vals[WC.R] += ((rgba >> 16) & 0xff);
				// vals[WC.G] += ((rgba >> 8) & 0xff);
				// vals[WC.B] += ((rgba ) & 0xff);

				data[x][y] = vals[WC.R];

				valDist[data[x][y]]++;

				pxCount++;
			}
		}

		// statistics
		int accum = 0;

		int q1 = (int) (.1f * pxCount);
		int q3 = (int) (.9f * pxCount);

		//
		// int q1 = (int)(.25f*pxCount);
		// int q3 = (int)(.75f*pxCount);

		int q1Val = 0;
		int q3Val = 0;

		for (int i = 0; i < 256; i++) {
			accum += valDist[i];
			if (accum < q1) {
				q1Val = i;
			}
			if (accum < q3) {
				q3Val = i;
			}
		}
		System.out.println("   q1 " + q1Val + "   q3 " + q3Val);

		float span = 255f / (float) (q3Val - q1Val);

		if (span > expansionLimit)
			span = expansionLimit;

		System.out.println("SPAN " + span);
		// alter values

		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {

				int val = (int) (((float) data[x][y] - q1Val) * span);

				// val = (val+data[WC.X][WC.Y])/2; // average EQ'd val and
				// original
				if (val > 255)
					val = 255;
				if (val < 0)
					val = 0;

				int rgba = (val << 24) | (val << 16) | (val << 8) | val;

				b.setRGB(x, y, rgba);
			}
		}

	}

	public void exportKMLIntensities(ArrayList wfl, int a, int b,
			ArrayList paramList) {

	}

	// public void exportKMLRaster() // todo

	// todo add status/return logic
	public void createKMLSCABounds(WITFrame w) {

		for (int scaID = 0; scaID < 8; scaID++) {
			w.SCAcoordBounds[scaID] = new ArrayList();

			int geoLocW = w.geoLocSparseCols;
			int geoLocH = w.geoLocSparseRows;

			// find bounds for up, down, left, right
			int scaU[] = new int[geoLocW];
			int scaD[] = new int[geoLocW];

			int scaL[] = new int[geoLocH];
			int scaR[] = new int[geoLocH];
		}

	}

	public void initFormatExt() {
		// formatExtensions
	}

	// find the index of the most recent frame
	public int getIndexFromTime(int secs, int searchSecs, ArrayList wl,
			int scanDir) {
		int index = -1;
		int threshDelta = searchSecs;// 5;
		int minDelta = threshDelta;

		int timeResult = 0;
		for (int i = 0; i < wl.size(); i++) {

			WITFrame w = (WITFrame) wl.get(i);
			int tDelta = Math.abs(w.timeStampSecOfDay - secs);
			// System.out.println(scaID+ " TIME SECS "+w.timeStampSecOfDay+
			// " "+secs+ " "+tDelta);
			if (tDelta < threshDelta) {

				if (tDelta <= minDelta) {
					/*
					 * minDelta = tDelta; index=i; timeResult =
					 * w.timeStampSecOfDay;
					 */

					if (scanDir == WC.SCAN_SELECT_ALL
							&& seqIndexMask[w.scanSeqIndex] == WC.STATUS_ON) {
						minDelta = tDelta;
						index = i;
						timeResult = w.timeStampSecOfDay;
						// System.out.println("UPDATE");
					} else if (scanDir == WC.SCAN_SELECT_EVEN
							&& seqIndexMask[w.scanSeqIndex] == WC.STATUS_ON) {
						if (w.scanDirection == WC.SCAN_SELECT_EVEN) {
							minDelta = tDelta;
							index = i;
							timeResult = w.timeStampSecOfDay;
						}
					} else if (scanDir == WC.SCAN_SELECT_ODD
							&& seqIndexMask[w.scanSeqIndex] == WC.STATUS_ON) {
						if (w.scanDirection == WC.SCAN_SELECT_ODD) {
							minDelta = tDelta;
							index = i;
							timeResult = w.timeStampSecOfDay;
						}
					}

				}
			}
		}

		return index;
	}

	public String secondsOfDayToReadable(int seconds) {

		int tPos = seconds;
		int hour = tPos / (WC.SEC_IN_HOUR);
		String hourStr = hour + "";
		if (hour < 10) {
			hourStr = "0" + hour;
		}
		int min = (tPos - hour * WC.SEC_IN_HOUR) / (60);
		String minStr = "" + min;
		if (min < 10)
			minStr = "0" + minStr;

		int sec = (tPos - hour * WC.SEC_IN_HOUR - min * 60);
		String secStr = "" + sec;
		if (sec < 10)
			secStr = "0" + secStr;

		hourStr += ":" + minStr + ":" + secStr;

		return hourStr;
	}

	public void exportVideo(ArrayList wfll, int a, int b, ArrayList paramList) {

		ArrayList wflr[] = new ArrayList[wfll.size()];

		// int numSCAsIncluded = wfll.size();

		for (int k = 0; k < WC.TOTAL_SCAS; k++) {

			wflr[k] = (ArrayList) wfll.get(k);
			// System.out.println("FRAMES "+wflr[k].size());
		}

		scaOffsets = initSCAoffsets(1);

		int searchWindow = 1;

		if (wfll.size() > 0) {
			boolean[] formatMask = (boolean[]) paramList.get(2);
			boolean[] channelMask = (boolean[]) paramList.get(3);
			int scanExportMode = (Integer) paramList.get(4);
			float magnification = (Float) paramList.get(5);
			int[] scaExportMask = (int[]) paramList.get(6);
			float videoPlaybackSpeed = (Float) paramList.get(7);

			int minT = (Integer) paramList.get(8);
			int maxT = (Integer) paramList.get(9);

			String productClassificationLabelStr = (String) paramList.get(10);
			String productTitleLabelStr = (String) paramList.get(11);

			seqIndexMask = (int[]) paramList.get(12);

			System.out.print("EXPORT SCA MASK ");
			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				// if (scaExportMask[k]==1){
				System.out.print(scaExportMask[k]);
				// }
			}
			System.out.println("  VID SPEED " + videoPlaybackSpeed);

			// System.out.println("RANGE "+a+"-"+b+
			// " SCAN MODE "+scanExportMode);

			int indexA[] = new int[WC.TOTAL_SCAS];
			int indexB[] = new int[WC.TOTAL_SCAS];


			int leftSca = 0;
			int rightSca = 0;

			for (int k = 0; k < WC.TOTAL_SCAS; k++) {
				if (scaExportMask[k] == 1) {
					leftSca = k;
					k = WC.TOTAL_SCAS;
				}
			}
			for (int k = WC.TOTAL_SCAS - 1; k >= 0; k--) {
				if (scaExportMask[k] == 1) {
					rightSca = k;
					k = -1;
				}
			}

			int formatCount = 0;
			for (int f = 0; f < formatMask.length; f++) {
				if (formatMask[f] == true) {
					formatCount++;
				}
			}

			for (int c = 0; c < channelMask.length; c++) {

				if (channelMask[c] == true && formatCount > 0) {

					System.out.println("VIDEO ITEM  " + c + " "
							+ channelMask[c]);
					;
					int inputSrc = c;

					int seqPad = -1;

					// temp dir for PNGs
					String uniqueDir = scratchStr + System.currentTimeMillis()
							+ "_EXPORT" + inputSrc;
					File uniqueFile = new File(uniqueDir);

					boolean mk = uniqueFile.mkdir();


					String inputStr = " -i " + uniqueDir + "/%d.png";

					int[][][] bounds = (int[][][]) paramList.get(0);
					int x1[] = new int[WC.TOTAL_SCAS];
					int x2[] = new int[WC.TOTAL_SCAS];
					int y1[] = new int[WC.TOTAL_SCAS];
					int y2[] = new int[WC.TOTAL_SCAS];

					int selX[] = new int[WC.TOTAL_SCAS];
					int selY[] = new int[WC.TOTAL_SCAS];
					int selW[] = new int[WC.TOTAL_SCAS];
					int selH[] = new int[WC.TOTAL_SCAS];

					int selTotalW = 0;
					int selTotalH = 0;

					for (int k = 0; k < WC.TOTAL_SCAS; k++) {

						x1[k] = bounds[k][WC.START][WC.X];
						x2[k] = bounds[k][WC.END][WC.X];
						y1[k] = bounds[k][WC.START][WC.Y];
						y2[k] = bounds[k][WC.END][WC.Y];

						selW[k] = (int) ((float) Math.abs(x1[k] - x2[k]) * magnification);
						selH[k] = (int) ((float) Math.abs(y1[k] - y2[k]) * magnification);

						if (inputSrc != WC.THREAD_LOAD_HDF5R) {

						}

						selX[k] = (int) ((float) Math.min(x1[k], x2[k]) * magnification);
						selY[k] = (int) ((float) Math.min(y1[k], y2[k]) * magnification);

						if (selTotalW > 0 && selW[k] > 0) {
							selTotalW -= WC.SCA_X_OVERLAP;
						}
						selTotalW += selW[k];

						if (selH[k] > 0) {
							selTotalH = selH[k];
						}

					}

					System.out.println("DIMS " + selTotalW + " " + selTotalH);

					// force even dimensions
					if (selTotalW % 2 == 1) {
						selTotalW -= 1;
					}
					if (selTotalH % 2 == 1) {
						selTotalH -= 1;
					}

					if (channelMask[inputSrc] == true) { // if mask is 1, record
						// this
						// channel
						System.out.println("EXPORT LAYER " + inputSrc);

						if (true) {
							int secBannerH = 20;
							int secBannerTextH = 14;

							int titleBannerH = 20;
							int titleBannerTextH = 14;

							int timeBannerH = 20;
							int timeBannerTextH = secBannerTextH;

							int finalW = (selTotalW);
							int finalH = (selTotalH) + (2 * secBannerH)
									+ timeBannerH;

							if (productTitleLabelStr.length() > 0) {
								finalH = finalH + titleBannerH;
								System.out.println("TITLE "
										+ productTitleLabelStr);
							}

							if (mk) {

								try {
									BufferedImage outImage = null;

									BufferedImage outImageA = new BufferedImage(
											finalW, finalH,
											BufferedImage.TYPE_INT_RGB);

									System.out.println("OUTPUT IMAGE DIMS "
											+ finalW + " " + finalH);

									Graphics2D gA = (Graphics2D) outImageA
											.getGraphics();

									System.out.println("   CREATING FRAMES");

									int diffX = 0;
									int diffY = 0;

									int dejitterPlaybackX = 0;
									int dejitterPlaybackY = 0;

									outImage = new BufferedImage(finalW,
											finalH, BufferedImage.TYPE_INT_RGB);

									Graphics2D g = (Graphics2D) outImage
											.getGraphics();

									// handle temporal bounds checking

									// handle even/odd/all frame output
									int frameIndex = 0;

									int localFrameCount = 1;

									int forcedFrameReps = 1;// 10;

									for (int i = minT; i < maxT; i++) {
										// for (int i = a; i < b; i += 1) {
										int validTimeForExport = 0;
										// System.out.println("BEGIN seeking time "+i);

										WITFrame wfir[] = new WITFrame[wfll
												.size()];

										for (int k = 0; k < WC.TOTAL_SCAS; k++) {
											int index = getIndexFromTime(i,
													searchWindow, wflr[k],
													scanExportMode);
											if (index != -1) {
												wfir[k] = (WITFrame) wflr[k]
														.get(index);
												validTimeForExport = 1;
											
											}
										}

										// int fNo = i - a;

										g.setColor(Color.BLACK);
										g.fillRect(0, 0, finalW, finalH);

										int xOffAccum = 0;

										for (int k = 0; k < WC.TOTAL_SCAS; k++) {
											if (wfir[k] != null) {

												if (((scanExportMode == WC.SCAN_DIR_EVEN && wfir[k].scanDirection == 0)
														|| (scanExportMode == WC.SCAN_DIR_ODD && wfir[k].scanDirection == 1) || scanExportMode == WC.SCAN_DIR_BOTH)
														&& wfir[k].biRay[inputSrc] != null) {

													if (scaExportMask[k] == 1) {

														int yOffFromText = secBannerH
																+ timeBannerH;
														if (productTitleLabelStr
																.length() > 0) {
															yOffFromText += titleBannerH;
														}

														if (inputSrc == WC.THREAD_LOAD_HDF5R) {

															int xOff = -bounds[leftSca][WC.START][WC.X]
																	+ scaOffsets[k][WC.X]
																	- scaOffsets[leftSca][WC.X];
															int yOff = -bounds[k][WC.START][WC.Y];

															xOff = (int) ((float) xOff * magnification);
															yOff = (int) ((float) yOff * magnification);
															g
																	.drawImage(
																			wfir[k].biRay[inputSrc],
																			xOff,
																			yOff
																					+ yOffFromText,
																			(int) ((float) wfir[k].biRay[inputSrc]
																					.getWidth() * magnification),
																			(int) ((float) wfir[k].biRay[inputSrc]
																					.getHeight() * magnification),
																			null);
														} else {

															int xOff = -bounds[leftSca][WC.START][WC.X]
																	+ scaOffsets[k][WC.X]
																	- scaOffsets[leftSca][WC.X];
															if (k == leftSca)
																xOff = 0;
															xOff = (int) ((float) xOff * magnification);
															g
																	.drawImage(
																			wfir[k].biRay[inputSrc],
																			xOff,
																			yOffFromText,
																			(int) ((float) wfir[k].biRay[inputSrc]
																					.getWidth() * magnification),
																			(int) ((float) wfir[k].biRay[inputSrc]
																					.getHeight() * magnification),
																			null);
														}

														// xOffAccum+=(bounds[k][WC.END][WC.X]-bounds[k][WC.START][WC.X]);

														// security markings

														g.setColor(Color.RED);
														g.fillRect(0, 0,
																finalW,
																secBannerH);
														g.fillRect(0, finalH
																- secBannerH,
																finalW,
																secBannerH);

														int fontSizePx = 7;
														// g.setColor(Color.WHITE);
														g.setColor(Color.BLACK);
														int secStrX = finalW
																/ 2
																- (productClassificationLabelStr
																		.length() / 2 * fontSizePx);
														g.drawString(
																		productClassificationLabelStr,
																		secStrX,
																		secBannerTextH);
														g.drawString(
																		productClassificationLabelStr,
																		secStrX - 1,
																		secBannerTextH);

														g.drawString(
																		productClassificationLabelStr,
																		secStrX,
																		finalH
																				- secBannerH
																				+ secBannerTextH);
														g.drawString(
																		productClassificationLabelStr,
																		secStrX - 1,
																		finalH
																				- secBannerH
																				+ secBannerTextH);

														if (productTitleLabelStr
																.length() > 0) {

															g
																	.setColor(Color.BLACK);
															g
																	.fillRect(
																			0,
																			secBannerH,
																			finalW,
																			secBannerH
																					+ titleBannerH);

															g
																	.setColor(Color.YELLOW);
															int titleStrX = finalW
																	/ 2
																	- (productTitleLabelStr
																			.length() / 2 * fontSizePx);
															g
																	.drawString(
																			productTitleLabelStr,
																			titleStrX,
																			secBannerH
																					+ titleBannerTextH);
															g
																	.drawString(
																			productTitleLabelStr,
																			titleStrX - 1,
																			secBannerH
																					+ titleBannerTextH);
														}

														// timestamps
														if (wfir[k].timeStampStr
																.length() > 1) {

															String timeStr = wfir[k].timeStampStr;
														
															int timeStrX = finalW
																	/ 2
																	- (timeStr
																			.length() / 2 * fontSizePx);
															g
																	.setColor(Color.BLACK);

															int titleBannerOffsetY = 0;

															// nudge if we have
															// a title
															if (productTitleLabelStr
																	.length() == 0) {

																titleBannerOffsetY = timeBannerH
																		+ timeBannerTextH;
																g
																		.fillRect(
																				0,
																				secBannerH,
																				finalW,
																				timeBannerH);
															} else {
																titleBannerOffsetY = titleBannerH
																		+ timeBannerH
																		+ timeBannerTextH;
																g
																		.fillRect(
																				0,
																				secBannerH
																						+ titleBannerH,
																				finalW,
																				timeBannerH);
															}
															g.setColor(Color.red);
															g.drawString(
																			timeStr,
																			timeStrX,
																			titleBannerOffsetY);
															g.drawString(
																			timeStr,
																			timeStrX - 1,
																			titleBannerOffsetY);
														}
													}

												}

											}
										}
										if (validTimeForExport == 1) {
											// System.out.println("saving time "+secondsOfDayToReadable(i));

											// if (validTimeForExport == 1){
											File pngFile = new File(uniqueDir
													+ "/" + frameIndex + ".png");
											// pngFile.setReadable(true, false);
											ImageIO.write(outImage, "png",
													pngFile);

											System.out.println("FRAME: "
													+ frameIndex
													+ " - WRITING IMAGE "
													+ pngFile);
											frameIndex++;

										}

									}

									for (int f = 0; f < formatMask.length; f++) {

										if (formatMask[f] == true) {

											// final destination
											String destStr = (String) paramList
													.get(1);

											String commandStr = "ffmpeg";
											String ffmpegStr = "";

											if (inputSrc != WC.THREAD_LOAD_HDF5R) {
												if (inputSrc == WC.THREAD_DIFF) {
													destStr = destStr
															+ "_DIFFS";
												} else if (inputSrc == WC.THREAD_TIMELAPSE) {
													destStr = destStr
															+ "_TIMELAPSE";
												} else if (inputSrc == WC.THREAD_CONTRAST) {
													destStr = destStr
															+ "_CONTRAST";
												} else {
													destStr = destStr + "_MODE"
															+ inputSrc;
												}
											}

											destStr = destStr.replaceAll(
													"\\\\", "/");

											String extStr = "";
											String paramStr = " ";

											if (f == WC.FORMAT_MP4) {
												paramStr = " -vcodec mpeg4  ";
												extStr = ".mp4";
											} else if (f == WC.FORMAT_MP4_H264) {
												paramStr = " -vcodec libx264 ";
												// intercept extension
												extStr = "(h264).mp4";
											} else if (f == WC.FORMAT_WMV) {
												paramStr = " -vcodec wmv2 ";
												extStr = ".wmv";
											} else if (f == WC.FORMAT_MPG) {
												extStr = ".mpg";
											}
											if (!destStr.endsWith(extStr)) {
												destStr = destStr + extStr;

											}

											float scaledPlaybackSpeed = (1.25f * videoPlaybackSpeed);
											paramStr += " -sameq ";
											// String fpsStr =
											// " -r 1.25 ";//" -r 2 ";//
											// " -r 15";
											String fpsStr = " -r "
													+ scaledPlaybackSpeed;// " -r 2 ";//
											// " -r 15";
											String fpsOutStr = " -r 24 ";
											String fps1Str = " -r 1 ";
											String fps30Str = " -r 30 ";
											String fps60Str = " -r 60 ";

											if (extStr.equalsIgnoreCase(".mpg")) {
												
												ffmpegStr = commandStr + fpsStr
														+ inputStr + fpsOutStr
														+ paramStr + destStr;
											} else {
												// ffmpegStr = commandStr +
												// fpsStr + inputStr + paramStr
												// + destStr;
												ffmpegStr = commandStr + fpsStr
														+ inputStr + fpsStr
														+ paramStr + destStr;
											}

											Runtime rt = Runtime.getRuntime();
											Process p = null;

											// InputStream is = new
											// InputStream();
											p = rt.exec(ffmpegStr);

											InputHandler errorHandler = new InputHandler(
													p.getErrorStream(),
													"Error Stream");
											errorHandler.start();
											InputHandler outputHandler = new InputHandler(
													p.getInputStream(),
													"Output Stream");
											outputHandler.start();

											System.out.println("   FFMPEG: "
													+ ffmpegStr);
											int pVal = p.waitFor();
											System.out
													.println("   FFMPEG EXIT VALUE "
															+ pVal);

											String commandChmod = "chmod 777 "
													+ destStr;
											System.out.println(commandChmod);
											Runtime rtChmod = Runtime
													.getRuntime();
											Process pChmod = null;
											pChmod = rtChmod.exec(commandChmod);

											InputHandler errorHandler2 = new InputHandler(
													pChmod.getErrorStream(),
													"Error Stream");
											errorHandler2.start();
											InputHandler outputHandler2 = new InputHandler(
													pChmod.getInputStream(),
													"Output Stream");
											outputHandler2.start();

											int pVal2 = pChmod.waitFor();
											System.out
													.println("   CHMOD EXIT VALUE "
															+ pVal2);
											
											if (f == WC.FORMAT_PNG) {

												System.out.println("   MOVING PNGs");
												String destPngStr = destStr;//videoExportFileStr;
												destPngStr = destPngStr.replaceAll("\\\\", "/");
												destPngStr = destPngStr + "_PNGs";
												File pngDir = new File(destPngStr);
												pngDir.mkdir();
												
												File batchScratchFile = new File(uniqueDir);
												
												File[] pngFiles = batchScratchFile.listFiles();

												for (int i = 0; i < pngFiles.length; i++) {
													// File copyPng = new
													// File(pngDir+pngFiles[i].getName());
													// copyPng.
													pngFiles[i].renameTo(new File(pngDir + "/"
															+ pngFiles[i].getName()));
												}

											}

										}

									}

									// delete temp images used for video
									// creation

									boolean dk = deleteDir(uniqueFile);
									if (dk) {
										System.out
												.println("   DELETED SCRATCH FRAMES ");
									}

									System.out.println("ENCODING COMPLETE");

									// int exitVal = p.exitValue();
									// System.out.println("exited with value "+exitVal);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

								// delete the frames
							}
						}
					}

				}
			}
		}
	}

	public void exportWeatherVideo(ArrayList wfl, int a, int b,
			ArrayList paramList) {

		scaOffsets = initSCAoffsets(1);

		String warningStr = "";// // SECRET // OT&E PRODUCT - NOT TO BE USED FOR
		// TARGETING OR DECISION SUPPORT //";

		float mosaicFade = .00f;
		// float mosaicFade = .01f;

		Color emptyColor = new Color(0, 40, 90);

		// export for a bounded region
		int minLat = (Integer) paramList.get(9);
		int maxLat = (Integer) paramList.get(10);
		int minLon = (Integer) paramList.get(11);
		int maxLon = (Integer) paramList.get(12);
		float scale = (Float) paramList.get(13);
		int vidW = (Integer) paramList.get(14);
		int vidH = (Integer) paramList.get(15);
		float downSample = (Float) paramList.get(16);
		float strokeWidth = (Float) paramList.get(17);

		int embedScale = (Integer) paramList.get(18);
		int embedPosY = (Integer) paramList.get(19);

		int yPadding = (Integer) paramList.get(20);

		int embedNudgeX = (Integer) paramList.get(21);

		// pass contrast params to reprojection
		ArrayList contrastParamList = (ArrayList) paramList.get(22);

		warningStr = (String) paramList.get(23);

		int adjMinLat = minLat + 90;
		int adjMaxLat = maxLat + 90;
		int adjMinLon = minLon + 180;
		int adjMaxLon = maxLon + 180;
		int adjDeltaLat = adjMaxLat - adjMinLat;
		int adjDeltaLon = adjMaxLon - adjMinLon;

		int offsetCropX = -(int) ((float) (adjMinLon) * scale);
		int offsetCropY = -(int) ((float) adjMinLat * scale) / 2;

		System.out.println("AOI " + adjMinLat + "-" + adjMaxLat + " "
				+ adjMinLon + "-" + adjMaxLon + " ... " + adjDeltaLat + "x"
				+ adjDeltaLon + " ... " + (int) ((float) adjDeltaLon * scale)
				+ " " + (int) ((float) adjDeltaLat * scale));

		// start creating map
		int rasterMapW = (int) ((360) * scale);
		int rasterMapH = (int) ((180) * scale);// + rawHeight;
	

		int frameH = (int) (adjDeltaLat * scale) + (yPadding); // room for the
		// map + SCAs
		int forcedFrameReps = 1;// 10;

		int frameIndex = 0;

		// /
		int[] channelMask = (int[]) paramList.get(6);
		int scanExportMode = (Integer) paramList.get(7);
		int magnification = (Integer) paramList.get(8);

		for (int c = 0; c < channelMask.length; c++) {

			BufferedImage outImage = new BufferedImage((int) ((360) * scale),
					Math.max(frameH, rasterMapH), BufferedImage.TYPE_INT_ARGB);
			Graphics2D g = (Graphics2D) outImage.getGraphics();
			g.setColor(emptyColor);
			g.fillRect(0, 0, rasterMapW, frameH * 2);

			if (channelMask[c] == 1) {
				int inputSrc = c;// THREAD_CONTRAST;// HACK !! //c;//
				// WC.THREAD_LOAD_HDF5R;

				// String commandStr = "C:/ffmpeg/bin/ffmpeg";
				// String commandStr = "C:\\Program Files (x86)\\WinFF\\ffmpeg";
				// // win install location
				String commandStr = "ffmpeg";

				int seqPad = -1;

				String ffmpegStr = "";

				// String scratchStr="C:/javadev/WIT/temp/";

				// final destination
				String destStr = (String) paramList.get(4);
				String extStr = (String) paramList.get(5);

				// File dest = new File(destStr);

				// temp dir for PNGs
				String uniqueDir = scratchStr + System.currentTimeMillis()
						+ "_EXPORT" + inputSrc;
				File uniqueFile = new File(uniqueDir);
				boolean mk = uniqueFile.mkdir();

				// set as FFmpeg input
				// String inputStr =
				// " -i C:/DEV_DATA/input_seq_1/uav1_%03d.png";//

				String inputStr = " -i " + uniqueDir + "/%d.png";
				// String inputStr = " -i "+uniqueDir+"/*.png";

				String paramStr = " ";

				if (extStr.equalsIgnoreCase(".mp4")) {
					paramStr = " -vcodec mpeg4  ";
				}
				if (extStr.equalsIgnoreCase(".h264")) {
					paramStr = " -vcodec libx264 ";
					// intercept extension
					extStr = "(h264).mp4";
				}
				if (extStr.equalsIgnoreCase(".swf")) {
					// paramStr = " -vcodec libx264 -flags +4mv -cmp 256 ";
				}
				if (extStr.equalsIgnoreCase(".flv")) {
					// paramStr = " -vcodec libx264 ";
				}
				if (extStr.equalsIgnoreCase(".wmv")) {
					paramStr = " -vcodec wmv2 ";
				}
				if (extStr.equalsIgnoreCase(".avi")) {
					// paramStr = " -vcodec libx264 ";
				}
				if (extStr.equalsIgnoreCase(".flv")) {
					// paramStr = " -vcodec libx264 ";
				}
				if (extStr.equalsIgnoreCase(".mpg")) {
					// paramStr = " -vcodec libx264 ";
				}

				if (inputSrc != WC.THREAD_LOAD_HDF5R) {
					if (inputSrc == WC.THREAD_DIFF) {
						destStr = destStr + "_DIFFS";
					} else if (inputSrc == WC.THREAD_TIMELAPSE) {
						destStr = destStr + "_TIMELAPSE";
					} else if (inputSrc == WC.THREAD_CONTRAST) {
						destStr = destStr + "_CONTRAST";
					} else {
						destStr = destStr + "_MODE" + inputSrc;
					}
				}

				if (!destStr.endsWith(extStr)) {
					destStr = destStr + extStr;
					// destStr = destStr + "_LAYER" + inputSrc + extStr;
					// destStr = destStr += extStr;
				}

				destStr = destStr.replaceAll("\\\\", "/");

				paramStr += " -sameq ";
				// String fpsStr = " -r 1.25 "; // default
				String fpsStr = " -r 15.0 ";
				String fpsOutStr = " -r 24 ";

				if (extStr.equalsIgnoreCase(".mpg")) {
					ffmpegStr = commandStr + fpsStr + inputStr + fpsOutStr
							+ paramStr + destStr;
				} else {
					ffmpegStr = commandStr + fpsStr + inputStr + paramStr
							+ destStr;
				}

				int x1 = (Integer) paramList.get(0);
				int x2 = (Integer) paramList.get(1);
				int y1 = (Integer) paramList.get(2);
				int y2 = (Integer) paramList.get(3);

				int selX = Math.min(x1, x2) * magnification;
				int selY = Math.min(y1, y2) * magnification;
				int selW = Math.abs(x1 - x2) * magnification;
				int selH = Math.abs(y1 - y2) * magnification;

				// force even dimensions
				if (selW % 2 == 1) {
					selW -= 1;
				}
				if (selH % 2 == 1) {
					selH -= 1;
				}

				// need to 'cut out' a region from raw data; from other layers
				// we can start at 0,0
				if (inputSrc != WC.THREAD_LOAD_HDF5R) {
					selX = 0;
					selY = 0;
				}

				if (channelMask[inputSrc] == 1) { // if mask is 1, record this
					// channel
					System.out.println("EXPORT LAYER " + inputSrc);
					WITFrame wfa = (WITFrame) wfl.get(b - 1); // some filters
					// like
					// TIMELAPSE
					// have a lead
					// time; look at
					// the end of
					// sequence for
					// validity
					if (wfa.biRay[inputSrc] != null) {
						int nativeWidth = wfa.biRay[inputSrc].getWidth();
						int nativeHeight = wfa.biRay[inputSrc].getHeight();

						if (selW == 0) {
							selW = nativeWidth;
						}

						if (selH == 0) {
							selH = nativeHeight;
						}

						// force even dimensions
						if (selW % 2 == 1) {
							selW -= 1;
						}
						if (selH % 2 == 1) {
							selH -= 1;
						}

						int secBannerH = 20;
						int secBannerTextH = 14;
						int timeBannerH = 20;
						int timeBannerTextH = secBannerTextH;

						// int finalW = (selW);
						// int finalH = (selH) + (2 * secBannerH + timeBannerH);

						if (true) {
							try {

								System.out.println("   CREATING FRAMES");

								int diffX = 0;
								int diffY = 0;

								int dejitterPlaybackX = 0;
								int dejitterPlaybackY = 0;

								// handle temporal bounds checking
								int fa = a;
								int fb = b;
								if (fa < 0)
									fa = 0;
								if (fb > wfl.size())
									fb = wfl.size();

								int startFrame = fa;
								int skipFrame = 1;
								int localFrameCount = 1;

								for (int i = startFrame; i < fb; i += skipFrame) {
									System.out.println("FRAME GENERATED... ");
									WITFrame wfi = (WITFrame) wfl.get(i);
									int fNo = i - fa;

									// even frames
									if ((scanExportMode == WC.SCAN_DIR_EVEN || scanExportMode == WC.SCAN_DIR_BOTH)
											&& wfi.scanDirection == 0
											&& wfi.biRay[inputSrc] != null) {

									
										g.setColor(emptyColor);
										g.setComposite(makeComposite(mosaicFade));

										g.fillRect(0, 0, rasterMapW,
														rasterMapH);
										g.setComposite(makeComposite(1.0f));

										for (int sca = 0; sca < 6; sca++) {
											BufferedImage bProj = mercProjAndAverage(
													rasterMapW, rasterMapH,
													scale, wfi, inputSrc, sca,
													null);

											g.drawImage(bProj, 0, 0, null);
										}

										g.drawImage(
														wfi.biRay[inputSrc],
														embedNudgeX
																+ ((int) ((adjMinLon + adjMaxLon) * scale) / 2 - wfi.biRay[inputSrc]
																		.getWidth()
																		/ 2
																		/ embedScale),
														embedPosY,
														wfi.biRay[inputSrc]
																.getWidth()
																/ embedScale,
														wfi.biRay[inputSrc]
																.getHeight()
																/ embedScale,
														null);

										localFrameCount++;

										// start crop
										BufferedImage cropImage = new BufferedImage(
												(int) ((float) adjDeltaLon * scale),
												frameH,
												BufferedImage.TYPE_INT_ARGB);

										Graphics2D cropGraphics = (Graphics2D) cropImage
												.getGraphics();

										cropGraphics.drawImage(outImage,
												offsetCropX, offsetCropY,
												outImage.getWidth(), outImage
														.getHeight(), null);

										BufferedImage scaleImage = new BufferedImage(
												(int) ((float) cropImage
														.getWidth() / downSample),
												(int) ((float) cropImage
														.getHeight() / downSample),
												BufferedImage.TYPE_INT_ARGB);

										Graphics2D gscale = (Graphics2D) scaleImage
												.getGraphics();
										gscale
												.setRenderingHint(
														RenderingHints.KEY_INTERPOLATION,
														RenderingHints.VALUE_INTERPOLATION_BICUBIC);

										gscale.drawImage(cropImage, 0, 0,
												scaleImage.getWidth(),
												scaleImage.getHeight(), null);
										// end crop

										// timestamps
										if (wfi.timeStampStr.length() > 1) {

											String timeStr = "SCAN "
													+ localFrameCount + " - "
													+ wfi.timeStampStr + " ";
											timeStr = warningStr
													+ "           " + timeStr;
										
											int timeStrX = 30;
											
											gscale.setColor(Color.red);
											gscale.fillRect(0, 0, rasterMapW,
													timeBannerH);
											gscale.fillRect(0, scaleImage
													.getHeight()
													- secBannerH, rasterMapW,
													timeBannerH);

											gscale.setColor(Color.WHITE);
											gscale.drawString(timeStr,
													timeStrX, timeBannerTextH);
											gscale.drawString(timeStr,
													timeStrX + 1,
													timeBannerTextH);

											gscale.drawString(timeStr,
													timeStrX, scaleImage
															.getHeight()
															- secBannerH
															+ timeBannerTextH);
											gscale.drawString(timeStr,
													timeStrX + 1, scaleImage
															.getHeight()
															- secBannerH
															+ timeBannerTextH);

										}

										for (int ff = 0; ff < forcedFrameReps; ff++) {

											File pngFile = new File(uniqueDir
													+ "/" + frameIndex + ".png");
											pngFile.setReadable(true, false);
											ImageIO.write(outImage, "png",
													pngFile);

											frameIndex++;
										}
									}

									// odd frames
									if ((scanExportMode == WC.SCAN_DIR_ODD || scanExportMode == WC.SCAN_DIR_BOTH)
											&& wfi.scanDirection == 1
											&& wfi.biRay[inputSrc] != null) {

								
										g.setColor(emptyColor);
										g.setComposite(makeComposite(mosaicFade));

										g.fillRect(0, 0, rasterMapW, frameH);
										g.setComposite(makeComposite(1.0f));

										for (int sca = 0; sca < 6; sca++) {
											BufferedImage bProj = mercProjAndAverage(
													rasterMapW, rasterMapH,
													scale, wfi, inputSrc, sca,
													null);

											g.drawImage(bProj, 0, 0, null);
										}

										g
												.drawImage(
														wfi.biRay[inputSrc],
														embedNudgeX
																+ ((int) ((adjMinLon + adjMaxLon) * scale) / 2 - wfi.biRay[inputSrc]
																		.getWidth()
																		/ 2
																		/ embedScale),
														embedPosY,
														wfi.biRay[inputSrc]
																.getWidth()
																/ embedScale,
														wfi.biRay[inputSrc]
																.getHeight()
																/ embedScale,
														null);

										// security markings

										localFrameCount++;

										// start crop

										BufferedImage cropImage = new BufferedImage(
												(int) ((float) adjDeltaLon * scale),
												frameH,
												BufferedImage.TYPE_INT_ARGB);
										// System.out.println("NEW CROPPED "+cropImage.getWidth()+
										// " "+cropImage.getHeight());
										Graphics2D cropGraphics = (Graphics2D) cropImage
												.getGraphics();

										// System.out.println("CROPPING AT "+offsetCropX+" "+offsetCropY);
										cropGraphics.drawImage(outImage,
												offsetCropX, offsetCropY,
												outImage.getWidth(), outImage
														.getHeight(), null);

										BufferedImage scaleImage = new BufferedImage(
												(int) ((float) cropImage
														.getWidth() / downSample),
												(int) ((float) cropImage
														.getHeight() / downSample),
												BufferedImage.TYPE_INT_ARGB);
										

										Graphics2D gscale = (Graphics2D) scaleImage
												.getGraphics();
										gscale
												.setRenderingHint(
														RenderingHints.KEY_INTERPOLATION,
														RenderingHints.VALUE_INTERPOLATION_BICUBIC);

										gscale.drawImage(cropImage, 0, 0,
												scaleImage.getWidth(),
												scaleImage.getHeight(), null);
										// end crop

										// timestamps
										if (wfi.timeStampStr.length() > 1) {

											String timeStr = "SCAN "
													+ localFrameCount + " - "
													+ wfi.timeStampStr + " ";
											timeStr = warningStr
													+ "           " + timeStr;
											
											int timeStrX = 30;

											gscale.setColor(Color.red);
											gscale.fillRect(0, 0, rasterMapW,
													timeBannerH);
											gscale.fillRect(0, scaleImage
													.getHeight()
													- secBannerH, rasterMapW,
													timeBannerH);

											gscale.setColor(Color.WHITE);
											gscale.drawString(timeStr,
													timeStrX, timeBannerTextH);
											gscale.drawString(timeStr,
													timeStrX + 1,
													timeBannerTextH);

											gscale.drawString(timeStr,
													timeStrX, scaleImage
															.getHeight()
															- secBannerH
															+ timeBannerTextH);
											gscale.drawString(timeStr,
													timeStrX + 1, scaleImage
															.getHeight()
															- secBannerH
															+ timeBannerTextH);

										}

										for (int ff = 0; ff < forcedFrameReps; ff++) {

											File pngFile = new File(uniqueDir
													+ "/" + frameIndex + ".png");
											pngFile.setReadable(true, false);
											ImageIO.write(outImage, "png",
													pngFile);

											frameIndex++;

										}
									}
								}

								Runtime rt = Runtime.getRuntime();
								Process p = null;

								// InputStream is = new InputStream();
								p = rt.exec(ffmpegStr);

								InputHandler errorHandler = new InputHandler(p
										.getErrorStream(), "Error Stream");
								errorHandler.start();
								InputHandler outputHandler = new InputHandler(p
										.getInputStream(), "Output Stream");
								outputHandler.start();

								System.out.println("   FFMPEG: " + ffmpegStr);
								int pVal = p.waitFor();
								System.out.println("   FFMPEG EXIT VALUE "
										+ pVal);

								// change permissions// change permissions
								String chmodStr = "chmod ug+rw /export/WIT_PRODUCTS/*";
								p = rt.exec(chmodStr);

								errorHandler = new InputHandler(p
										.getErrorStream(), "Error Stream");
								errorHandler.start();
								outputHandler = new InputHandler(p
										.getInputStream(), "Output Stream");
								outputHandler.start();

								pVal = p.waitFor();
								System.out.println("   CHMOD EXIT VALUE "
										+ pVal);

								System.out.println("ENCODING COMPLETE");


							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

						}
					}
				}
			}
		}
	}

	public boolean deleteDir(File dir) {
		if (dir.isDirectory()) {
			String children[] = dir.list();
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteDir(new File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}

		return dir.delete();
	}

	public int validate8bitVal(int vIn) {
		int vOut = vIn;
		if (vOut > 255)
			vOut = 255;
		if (vOut < 0)
			vOut = 0;
		return vOut;
	}

	public void statisticalAnalysis(ArrayList wfl, int a, int b,
			ArrayList paramList) {
		int thisMode = WC.THREAD_STAT_FILTER;

		int inputSrc = (Integer) paramList.get(0);

		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);

		int w = maxX - minX;
		int h = maxY - minY;

		int diffSkip = (Integer) paramList.get(7);
		int scanExportMode = (Integer) paramList.get(7);
		// WITFrame wfa = (WITFrame)wfl.get(a);

		int searchWindow = 2;
		int searchWindowDiff = 10;
		// int scanExportMode = WC.SCAN_DIR_BOTH;

		int indexMain = -1;

		// mark as received

		for (int i = minT; i < maxT; i++) {

			int index = getIndexFromTime(i, searchWindow, wfl, scanExportMode);
			if (index != -1) {
				WITFrame wfi = (WITFrame) wfl.get(index);

				int nudge = 1;
				int index2 = getIndexFromTime(i + nudge, searchWindowDiff, wfl,
						wfi.scanDirection);

				while (index2 == index) {
					nudge++;
					index2 = getIndexFromTime(i + nudge, searchWindowDiff, wfl,
							wfi.scanDirection);
				}
				if (index2 != -1) {
					WITFrame wfi2 = (WITFrame) wfl.get(index2);

					if (wfi.layerStatus[thisMode] != WC.STATUS_COMPLETE
							&& wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE) { // ==
						// WC.STATUS_READY

						System.out.println("EXEC DIFF - FRAMES " + index + " "
								+ index2);
						if (verbosity > 0)
							System.out.println("EXEC DIFF FRAME " + i);

						if (w > 0 && h > 0) {
							wfi.biRay[WC.THREAD_DIFF] = new BufferedImage(w, h,
									BufferedImage.TYPE_INT_RGB);

							wfi.layerOffet[thisMode][WC.X] = minX;
							wfi.layerOffet[thisMode][WC.Y] = minY;

							System.out.println("STATUS INGEST DIFF IMAGE "
									+ wfi.layerStatus[inputSrc] + " "
									+ wfi2.layerStatus[inputSrc]);

							if (wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE
									&& wfi2.layerStatus[inputSrc] == WC.STATUS_COMPLETE) {

								for (int x = 0; x < w; x++) {
									for (int y = 0; y < h; y++) {

										int srcX = minX + x;
										int srcY = minY + y;

										if (srcX < wfi.biRay[inputSrc]
												.getWidth()
												&& srcY < wfi.biRay[inputSrc]
														.getHeight()
												&& srcX < wfi2.biRay[inputSrc]
														.getWidth()
												&& srcY < wfi2.biRay[inputSrc]
														.getHeight()
												&& srcX >= 0 && srcY >= 0) {

											int rgba1 = wfi2.biRay[inputSrc]
													.getRGB(srcX, srcY);

											int rgba2 = wfi.biRay[inputSrc]
													.getRGB(srcX, srcY);

											int v1 = ((rgba1 >> 16) & 0xff);
											int v2 = ((rgba2 >> 16) & 0xff);

											int diffVal = Math.abs(v2 - v1);

											if (diffVal > 255)
												diffVal = 255; // limiter
											if (diffVal < 0)
												diffVal = 0;

											int diffVal2 = diffVal * 2;
											int diffVal3 = diffVal * diffVal;

											if (diffVal2 > 255)
												diffVal2 = 255;
											if (diffVal3 > 255)
												diffVal3 = 255;

											int colD = ((int) (255) << 24)
													| ((int) (diffVal) << 16)
													| ((int) (diffVal2) << 8)
													| (int) (diffVal3);

											if (x < wfi.biRay[inputSrc]
													.getWidth()
													&& y < wfi.biRay[inputSrc]
															.getHeight()) {
												wfi.biRay[WC.THREAD_DIFF]
														.setRGB(x, y, colD);
											}
										}
									}
								}

								System.out.println("COMPLETE DIFF IMAGE " + i);
							}
						}

						wfi.layerStatus[WC.THREAD_DIFF] = WC.STATUS_COMPLETE;

						//wfl.remove(index);

						wfi.layerOffet[mode][WC.X] = wfi.layerOffet[inputSrc][WC.X];
						wfi.layerOffet[mode][WC.Y] = wfi.layerOffet[inputSrc][WC.Y];

						wfl.set(index, wfi);
						System.out.println("DIFF IMAGE " + index
								+ " UPDATED - TIME " + i);
					}

				}
			}
		}
	}

	public void timelapseImage(ArrayList wfl, int a, int b, ArrayList paramList) {
		int inputSrc = (Integer) paramList.get(0);

		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);

		int w = maxX - minX;
		int h = maxY - minY;

		int histSkip = (Integer) paramList.get(8);

		seqIndexMask = (int[]) paramList.get(10);

		int mode = WC.THREAD_TIMELAPSE;
		int history = (Integer) paramList.get(7);

		int scanExportMode = (Integer) paramList.get(9);
		int searchWindowDiff = 5;

		int searchWindow = 2;

		for (int i = minT; i < maxT; i++) {

			int index = getIndexFromTime(i, searchWindow, wfl, scanExportMode);
			if (index != -1) {
				WITFrame wfi = (WITFrame) wfl.get(index);

				if (wfi.layerStatus[mode] != WC.STATUS_COMPLETE) {

					wfi.layerStatus[mode] = WC.STATUS_WORKING;

					wfi.layerOffet[mode][WC.X] = wfi.layerOffet[inputSrc][WC.X];
					wfi.layerOffet[mode][WC.Y] = wfi.layerOffet[inputSrc][WC.Y];

					wfi.biRay[mode] = new BufferedImage(w, h,
							BufferedImage.TYPE_INT_ARGB);

					int nudge = 1;
					// int index2 = getIndexFromTime(i+nudge,searchWindowDiff,
					// wfl,scanExportMode);//wfi.scanDirection);

					int maxVals[][][] = new int[w][h][3];

					for (int hh = 0; hh < history; hh++) { // 
						int index2 = getIndexFromTime(i + nudge + hh,
								searchWindowDiff, wfl, wfi.scanDirection);

						while (index2 == index) {
							nudge++;
							index2 = getIndexFromTime(i + nudge,
									searchWindowDiff, wfl, wfi.scanDirection);
						}
						// if (true){
						if (index2 != -1) {

							WITFrame wfi2 = (WITFrame) wfl.get(index2);

							// additive - TODO

							// max method
							for (int x = 0; x < w; x++) {
								for (int y = 0; y < h; y++) {

									int vals[] = new int[3];

									if (wfi2.biRay[inputSrc] != null) { // skip
										// overscans
										// if (wfj.overscanSegment == 0 &&
										// wfj.biRay[inputSrc]!= null) { // skip
										// overscans
										if (x < wfi2.biRay[inputSrc].getWidth()
												&& y < wfi2.biRay[inputSrc]
														.getHeight()) {
											int rgba1 = wfi2.biRay[inputSrc]
													.getRGB(x, y);
											vals[0] = ((rgba1 >> 16) & 0xff);
											vals[1] = ((rgba1 >> 8) & 0xff);
											vals[2] = ((rgba1) & 0xff);
											for (int k = 0; k < 3; k++) {

												if (vals[k] > maxVals[x][y][k])
													maxVals[x][y][k] = vals[k];
											}
										}
									}

									for (int k = 0; k < 3; k++) {
										validate8bitVal(maxVals[x][y][k]);
									}
								}
							}
						}
					}

					// int rgba = ((int)(255) << 24) | ((int)(maxVal) << 16)
					// | ((int)(maxVal) << 8) | (int)(maxVal);
					// tint to its clear what layer is on top

					for (int x = 0; x < w; x++) {
						for (int y = 0; y < h; y++) {
							int rgba = ((int) (255) << 24)
									| ((int) (maxVals[x][y][0]) << 16)
									| ((int) (maxVals[x][y][1]) << 8)
									| (int) (maxVals[x][y][2]);
							wfi.biRay[mode].setRGB(x, y, rgba);

						}
					}

					wfi.layerStatus[mode] = WC.STATUS_COMPLETE;
					//wfl.remove(index);
					wfl.set(index, wfi);
				}
			}

		}

	}

	public void diffImage(ArrayList wfl, int a, int b, ArrayList paramList) {

		int thisMode = WC.THREAD_DIFF;
		int inputSrc = (Integer) paramList.get(0);

		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int minT = (Integer) paramList.get(5);
		int maxT = (Integer) paramList.get(6);

		int w = maxX - minX;
		int h = maxY - minY;

		int diffSkip = (Integer) paramList.get(7);
		int scanExportMode = (Integer) paramList.get(8);
		seqIndexMask = (int[]) paramList.get(9);
		// WITFrame wfa = (WITFrame)wfl.get(a);

		int searchWindow = 2;
		int searchWindowDiff = 10;
		// int scanExportMode = WC.SCAN_DIR_BOTH;

		int indexMain = -1;
		// if (wfa.layerStatus[inputSrc] == WC.STATUS_COMPLETE) {

		// System.out.println("WC.START DIFF IMAGE "+a+" - "+b);
		// int w = tf[a].width;
		// int h = tf[a].height;

		// mark as received

		for (int i = minT; i < maxT; i++) {

			int index = getIndexFromTime(i, searchWindow, wfl, scanExportMode);
			if (index != -1) {
				WITFrame wfi = (WITFrame) wfl.get(index);

				int nudge = 1;
				int index2 = getIndexFromTime(i + nudge, searchWindowDiff, wfl,
						wfi.scanDirection);

				while (index2 == index) {
					nudge++;
					index2 = getIndexFromTime(i + nudge, searchWindowDiff, wfl,
							wfi.scanDirection);
				}
				if (index2 != -1) {
					WITFrame wfi2 = (WITFrame) wfl.get(index2);

					if (wfi.layerStatus[thisMode] != WC.STATUS_COMPLETE
							&& wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE) { // ==
						// WC.STATUS_READY

						System.out.println("EXEC DIFF - FRAMES " + index + " "
								+ index2);
						if (verbosity > 0)
							System.out.println("EXEC DIFF FRAME " + i);

						if (w > 0 && h > 0) {
							wfi.biRay[WC.THREAD_DIFF] = new BufferedImage(w, h,
									BufferedImage.TYPE_INT_RGB);

							wfi.layerOffet[thisMode][WC.X] = minX;
							wfi.layerOffet[thisMode][WC.Y] = minY;

							System.out.println("STATUS INGEST DIFF IMAGE "
									+ wfi.layerStatus[inputSrc] + " "
									+ wfi2.layerStatus[inputSrc]);

							if (wfi.layerStatus[inputSrc] == WC.STATUS_COMPLETE
									&& wfi2.layerStatus[inputSrc] == WC.STATUS_COMPLETE) {

								for (int x = 0; x < w; x++) {
									for (int y = 0; y < h; y++) {

										int srcX = minX + x;
										int srcY = minY + y;

										if (srcX < wfi.biRay[inputSrc]
												.getWidth()
												&& srcY < wfi.biRay[inputSrc]
														.getHeight()
												&& srcX < wfi2.biRay[inputSrc]
														.getWidth()
												&& srcY < wfi2.biRay[inputSrc]
														.getHeight()
												&& srcX >= 0 && srcY >= 0) {

											int rgba1 = wfi2.biRay[inputSrc]
													.getRGB(srcX, srcY);

											int rgba2 = wfi.biRay[inputSrc]
													.getRGB(srcX, srcY);

											int v1 = ((rgba1 >> 16) & 0xff);
											int v2 = ((rgba2 >> 16) & 0xff);

											int diffVal = Math.abs(v2 - v1);

											if (diffVal > 255)
												diffVal = 255; // limiter
											if (diffVal < 0)
												diffVal = 0;

											int diffVal2 = diffVal * 2;
											int diffVal3 = diffVal * diffVal;

											if (diffVal2 > 255)
												diffVal2 = 255;
											if (diffVal3 > 255)
												diffVal3 = 255;

											int colD = ((int) (255) << 24)
													| ((int) (diffVal) << 16)
													| ((int) (diffVal2) << 8)
													| (int) (diffVal3);

											if (x < wfi.biRay[inputSrc]
													.getWidth()
													&& y < wfi.biRay[inputSrc]
															.getHeight()) {
												wfi.biRay[WC.THREAD_DIFF]
														.setRGB(x, y, colD);
											}
										}
									}
								}

								System.out.println("COMPLETE DIFF IMAGE " + i);
							}
						}

						wfi.layerStatus[WC.THREAD_DIFF] = WC.STATUS_COMPLETE;

						//wfl.remove(index);

						wfi.layerOffet[mode][WC.X] = wfi.layerOffet[inputSrc][WC.X];
						wfi.layerOffet[mode][WC.Y] = wfi.layerOffet[inputSrc][WC.Y];

						wfl.set(index, wfi);
						System.out.println("DIFF IMAGE " + index
								+ " UPDATED - TIME " + i);
					}

				}
			}
		}
	}

	// Hugh's ninja code
	public void georegAffine(WITFrame[] tf, int a, int b, ArrayList paramList) {

	}

	public void diffImageDJ(WITFrame[] tf, int a, int b, ArrayList paramList) {

		if (tf[a].layerStatus[WC.THREAD_DEJITTER] == WC.STATUS_COMPLETE) {

			int w = tf[a].biRay[WC.THREAD_LOAD].getWidth();
			int h = tf[a].biRay[WC.THREAD_LOAD].getHeight();

			// mark as received
			for (int i = a + 1; i < b; i++) {
				if (tf[i].layerStatus[WC.THREAD_TEMPORAL] != WC.STATUS_COMPLETE) {
					if (tf[i].layerStatus[WC.THREAD_DEJITTER] == WC.STATUS_COMPLETE
							&& tf[i - 1].layerStatus[WC.THREAD_DEJITTER] == WC.STATUS_COMPLETE) {
						tf[i].layerStatus[WC.THREAD_TEMPORAL] = WC.STATUS_WORKING;
					}
				}
			}

			for (int i = a + 1; i < b; i++) {
				if (tf[i].layerStatus[WC.THREAD_TEMPORAL] != WC.STATUS_COMPLETE) { // ==
					// WC.STATUS_READY
					if (verbosity > 0)
						System.out.println("EXEC DIFF FRAME " + i);
					tf[i].biRay[WC.THREAD_TEMPORAL] = new BufferedImage(w, h,
							BufferedImage.TYPE_INT_RGB);

					if (tf[i].layerStatus[WC.THREAD_DEJITTER] == WC.STATUS_COMPLETE
							&& tf[i - 1].layerStatus[WC.THREAD_DEJITTER] == WC.STATUS_COMPLETE) {
						// tf[i].layerStatus[WC.THREAD_DIFF] =
						// WC.STATUS_WORKING;
						for (int x = 0; x < w; x++) {
							for (int y = 0; y < h; y++) {

								int offsetX = tf[i].jitterWholePx[WC.X];
								int offsetY = tf[i].jitterWholePx[WC.Y];

								int pxX = x + offsetX;
								int pxY = y + offsetY;

								if (pxX >= 0 && pxX < w && pxY >= 0 && pxY < h) {
									int rgba1 = tf[i - 1].biRay[WC.THREAD_LOAD]
											.getRGB(x, y);
									int rgba2 = tf[i].biRay[WC.THREAD_LOAD]
											.getRGB(pxX, pxY);

									int v1 = ((rgba1 >> 16) & 0xff);
									int v2 = ((rgba2 >> 16) & 0xff);

									int diffVal = Math.abs(v1 - v2);
									// add gain
									// diffVal = diffVal*diffVal;
									// diffVal = (int) Math.pow((float)diffVal,
									// .5f);
									if (diffVal > 255)
										diffVal = 255; // limiter

									int diffVal2 = diffVal * 2;
									int diffVal3 = diffVal * diffVal;

									if (diffVal2 > 255)
										diffVal2 = 255;
									if (diffVal3 > 255)
										diffVal3 = 255;

									int colD = ((int) (1) << 24)
											| ((int) (diffVal) << 16)
											| ((int) (diffVal2) << 8)
											| (int) (diffVal3);

									tf[i].biRay[WC.THREAD_TEMPORAL].setRGB(x,
											y, colD);
								}
							}
						}

						tf[i].layerStatus[WC.THREAD_TEMPORAL] = WC.STATUS_COMPLETE;
					}
				}
			}
		}
	}

	public void convImage(WITFrame[] tf, int a, int b, ArrayList paramList) {

		if (tf[a].layerStatus[WC.THREAD_LOAD] == WC.STATUS_COMPLETE) {

			int w = tf[a].biRay[WC.THREAD_LOAD].getWidth();
			int h = tf[a].biRay[WC.THREAD_LOAD].getHeight();

			float kerData[] = new float[9];
			float blurCoeff = 1f / 9f;
			for (int i = 0; i < 9; i++) {
				kerData[i] = blurCoeff;
			}

			Kernel k = new Kernel(3, 3, kerData);

			ConvolveOp co = new ConvolveOp(k);
			BufferedImage tempIm = new BufferedImage(w, h,
					BufferedImage.TYPE_INT_RGB);

			int kerPasses = 20;
			for (int i = a; i < b; i++) {

				if (tf[i].layerStatus[WC.THREAD_CONV] == WC.STATUS_READY) { // ==
					// WC.STATUS_READY

					tf[i].layerStatus[WC.THREAD_CONV] = WC.STATUS_WORKING;
					if (verbosity > 0)
						System.out.println("EXEC CONVOLVE FRAME " + i);

					tf[i].biRay[WC.THREAD_CONV] = new BufferedImage(w, h,
							BufferedImage.TYPE_INT_RGB);

					if (tf[i].layerStatus[WC.THREAD_LOAD] == WC.STATUS_COMPLETE) {
						for (int p = 0; p < kerPasses; p++) {
							if (p == 0) {

								tempIm.createGraphics()
										.drawImage(tf[i].biRay[WC.THREAD_LOAD],
												0, 0, null);// seed
								// with
								// raw
								// data
							} else {

								tempIm.createGraphics()
										.drawImage(tf[i].biRay[WC.THREAD_CONV],
												0, 0, null);// update
								// latest
								// convolved
								// input
							}
							co.filter(tempIm, tf[i].biRay[WC.THREAD_CONV]);
						}

						tf[i].layerStatus[WC.THREAD_CONV] = WC.STATUS_COMPLETE;
					}
				}
			}

		}
	}

	public void dejitterImage(WITFrame[] tf, int a, int b, ArrayList paramList) {

		int modeInputSource = WC.THREAD_LOAD; // may switch to convolved to
		// minimize artifact errors

		if (tf[a].layerStatus[modeInputSource] == WC.STATUS_COMPLETE
				&& tf[a - 1].layerStatus[modeInputSource] == WC.STATUS_COMPLETE
				&& a > 0) {

			int w = tf[a].biRay[WC.THREAD_LOAD].getWidth();
			int h = tf[a].biRay[WC.THREAD_LOAD].getHeight();

			// sparse sampling method

			int samplingDensity = 6; // sample every n pixels
			int jitterNeighborhoodX = 15;
			int jitterNeighborhoodY = 15;

			int jitterNeighborhoodXhalf = jitterNeighborhoodX / 2 - 1;
			int jitterNeighborhoodYhalf = jitterNeighborhoodY / 2 - 1;

			int allowedSamplesX = 20;// 100;
			int allowedSamplesY = 20;// 100;

			int edgeMargin = 10 + jitterNeighborhoodX;

			int jitterDiffs[][] = new int[jitterNeighborhoodX][jitterNeighborhoodY];

			for (int i = a; i < b; i++) {
				if (tf[i].layerStatus[modeInputSource] == WC.STATUS_COMPLETE
						&& tf[i - 1].layerStatus[modeInputSource] == WC.STATUS_COMPLETE) {
					// System.out.println("DEJITTER "+i);

					tf[i].layerStatus[WC.THREAD_DEJITTER] = WC.STATUS_WORKING;

					int jitterResults[][][] = new int[allowedSamplesX][allowedSamplesY][3]; // X/Y
					// offsets
					// +
					// diff

					for (int x = 0; x < allowedSamplesX; x++) {
						for (int y = 0; y < allowedSamplesY; y++) {

							jitterResults[x][y][WC.Z] = Integer.MAX_VALUE; // mark
							// as
							// unused

						}
					}

					// each sample point
					for (int x = 0; x < allowedSamplesX; x++) {
						for (int y = 0; y < allowedSamplesY; y++) {

							int xCoord = edgeMargin + x * samplingDensity;
							int yCoord = edgeMargin + y * samplingDensity;

							if (xCoord > w - edgeMargin
									|| yCoord > h - edgeMargin) {
								// System.out.println("INVALID SAMPLE POINT");
							} else {

								int px = tf[i].biRay[modeInputSource].getRGB(
										xCoord, yCoord);
								int val = ((px >> 16) & 0xff);

								// each neighborhood per sample point
								for (int x2 = 0; x2 < jitterNeighborhoodX; x2++) {
									for (int y2 = 0; y2 < jitterNeighborhoodY; y2++) {

										int offsetX = xCoord + x2
												- jitterNeighborhoodXhalf;
										int offsetY = yCoord + y2
												- jitterNeighborhoodYhalf;

										// target frame (previous)
										int px2 = tf[i - 1].biRay[WC.THREAD_LOAD]
												.getRGB(offsetX, offsetY);
										// int px2 =
										// tf[i-1].biRay[WC.THREAD_LOAD].getRGB(x+offsetX,
										// y+offsetY);
										int val2 = ((px2 >> 16) & 0xff);

										jitterDiffs[x2][y2] = Math.abs(val2
												- val);
									}
								}

								// find min
								int minXindex = 0;
								int minYindex = 0;
								int minVal = Integer.MAX_VALUE;
								for (int x2 = 0; x2 < jitterNeighborhoodX; x2++) {
									for (int y2 = 0; y2 < jitterNeighborhoodY; y2++) {

										if (jitterDiffs[x2][y2] < minVal) {
											minXindex = x2;
											minYindex = y2;
											minVal = jitterDiffs[x2][y2];
										}
									}
								}

								// sample point results
								jitterResults[x][y][WC.X] = minXindex;
								jitterResults[x][y][WC.Y] = minYindex;
								jitterResults[x][y][WC.Z] = minVal;

							}

						}
					}

					int totalSamplePoints = allowedSamplesX * allowedSamplesY; // decrement
					// for
					// invalid
					// samples
					int candidateSamplePoints = totalSamplePoints;

					int jitterXaccum = 0;
					int jitterYaccum = 0;

					// rejection threshold
					int rejectionThreshold = 10;

					for (int x3 = 0; x3 < allowedSamplesX; x3++) {
						for (int y3 = 0; y3 < allowedSamplesY; y3++) {

							if (jitterResults[x3][y3][WC.Z] > rejectionThreshold) {
								totalSamplePoints -= 1; // disregard this
								// sample, we're too
								// wide a difference
							} else {
								// System.out.println("ACCEPT "+x3+" "+y3+" "+jitterResults[x3][y3][WC.Z]);
								jitterXaccum += jitterResults[x3][y3][WC.X];
								jitterYaccum += jitterResults[x3][y3][WC.Y];
							}

							// jitterXaccum +=jitterResults[WC.X][WC.Y][WC.X];
							// jitterYaccum +=jitterResults[WC.X][WC.Y][WC.Y];
						}
					}

					float jitterXfinal = (float) jitterXaccum
							/ (float) totalSamplePoints;
					float jitterYfinal = (float) jitterYaccum
							/ (float) totalSamplePoints;

					tf[i].jitterWholePx[WC.X] = (int) jitterXfinal
							- jitterNeighborhoodXhalf;
					tf[i].jitterWholePx[WC.Y] = (int) jitterYfinal
							- jitterNeighborhoodYhalf;

					// tf[i].jitterWholePx[WC.X] = (int)jitterXfinal;
					// tf[i].jitterWholePx[WC.Y] = (int)jitterYfinal;

					// System.out.println(jitterNeighborhoodXhalf);

					tf[i].layerStatus[WC.THREAD_DEJITTER] = WC.STATUS_COMPLETE;

					// System.out.println("JITTER floats "+jitterXfinal+" "+jitterYfinal);
					// System.out.println("JITTER "+tf[i].jitterWholePx[WC.X]+" "+tf[i].jitterWholePx[WC.Y]);

					// System.out.println("accepted "+totalSamplePoints+" of "+candidateSamplePoints+" alignment samples");

				}
			}
		}

		// full image subtraction method

	}

	public void dejitterSR(WITFrame[] tf, int a, int b, ArrayList paramList) {
		int modeInputSource = WC.THREAD_LOAD; // may switch to convolved to
		// minimize artifact errors

		int scaleFactor = 4;

		if (tf[a].layerStatus[modeInputSource] == WC.STATUS_COMPLETE
				&& tf[a - 1].layerStatus[modeInputSource] == WC.STATUS_COMPLETE
				&& a > 0) {

			int w = tf[a].biRay[WC.THREAD_LOAD].getWidth();
			int h = tf[a].biRay[WC.THREAD_LOAD].getHeight();

			int ws = w * scaleFactor;
			int hs = h * scaleFactor;

			int diffMargin = 100;
			int diffRangeX = w - diffMargin * 2;
			int diffRangeY = h - diffMargin * 2;

			// mark as received
			for (int i = a; i < b; i++) {

				tf[i].layerStatus[WC.THREAD_DEJITTER] = WC.STATUS_WORKING;
			}

			for (int i = a; i < b; i++) {
				if (tf[i].layerStatus[modeInputSource] == WC.STATUS_COMPLETE
						&& tf[i - 1].layerStatus[modeInputSource] == WC.STATUS_COMPLETE) {
					// System.out.println("DEJITTER "+i);

					int neighborhood = 11;
					int kOffset = 5;// neighborhood/2;

					float jitterResults[][] = new float[neighborhood][neighborhood]; // X/Y
					// offsets
					// +
					// diff

					float diffCoeff = 1f / (float) (diffRangeX * diffRangeY);

					for (int x = 0; x < neighborhood; x++) {
						for (int y = 0; y < neighborhood; y++) {
							int offsetX = x - kOffset;
							int offsetY = y - kOffset;

							// int jitterDiffs[][] = new
							// int[diffRangeX][diffRangeY];
							float diffAve = 0;

							// all pixels within the offset margin - current
							// image
							for (int x2 = diffMargin; x2 < diffRangeX; x2++) {
								for (int y2 = diffMargin; y2 < diffRangeY; y2++) {

									// all pixels within the offset margin -
									// prev image

									int px1 = tf[i].biRay[modeInputSource]
											.getRGB(x2, y2);
									int val1 = ((px1 >> 16) & 0xff);
									int px2 = tf[i - 1].biRay[modeInputSource]
											.getRGB(x2 + offsetX, y2 + offsetY);
									int val2 = ((px2 >> 16) & 0xff);

									// jitterDiffs[x2-diffMargin][y2-diffMargin]
									// = Math.abs(val1-val2);

									float diff = (float) Math.abs(val1 - val2)
											* diffCoeff;
									diffAve += diff;
								}
							}

							jitterResults[x][y] = diffAve;

						}
					}
					// end comparisons

					// find min diff
					float minDiff = Float.MAX_VALUE;
					int minJitX = kOffset;
					int minJitY = kOffset;
					for (int x = 0; x < neighborhood; x++) {
						for (int y = 0; y < neighborhood; y++) {
							if (jitterResults[x][y] < minDiff) {
								minDiff = jitterResults[x][y];
								minJitY = y;
								minJitX = x;
							}
						}
					}

					// store result
					tf[i].jitterWholePx[WC.X] = -(minJitX - kOffset);
					tf[i].jitterWholePx[WC.Y] = -(minJitY - kOffset);
					tf[i].layerStatus[WC.THREAD_DEJITTER] = WC.STATUS_COMPLETE;

					// System.out.println("FRAME "+i+" jitX "+tf[i].jitterWholePx[WC.X]
					// +" jitY "+tf[i].jitterWholePx[WC.Y]);
				}
			}

		}

	}

	public void dejitterScanlines(WITFrame[] tf, int a, int b,
			ArrayList paramList) {
		// align subregions of pseudoframe
		int subtileSizeX = 4;
		int subtileSizeY = 8;

		int modeInputSource = WC.THREAD_LOAD; // may switch to convolved to
		// minimize artifact errors

		if (tf[a].layerStatus[modeInputSource] == WC.STATUS_COMPLETE) {

			for (int i = a; i < b; i++) {
				if (tf[i].layerStatus[WC.THREAD_DEJITTER_ADV] == WC.STATUS_READY) {
					tf[i].layerStatus[WC.THREAD_DEJITTER_ADV] = WC.STATUS_WORKING;

					tf[i].layerStatus[WC.THREAD_DEJITTER_ADV] = WC.STATUS_COMPLETE;
				}
			}
		}

	}

	public void dejitterImage2(WITFrame[] tf, int a, int b, ArrayList paramList) {

		int thisMode = WC.THREAD_DEJITTER;
		int modeInputSource = WC.THREAD_LOAD; // may switch to convolved to
		// minimize artifact errors

		if (tf[a].layerStatus[modeInputSource] == WC.STATUS_COMPLETE
				&& tf[a - 1].layerStatus[modeInputSource] == WC.STATUS_COMPLETE
				&& a > 0) {

			int w = tf[a].biRay[WC.THREAD_LOAD].getWidth();
			int h = tf[a].biRay[WC.THREAD_LOAD].getHeight();

			int diffMargin = 100;
			int diffRangeX = w - diffMargin * 2;
			int diffRangeY = h - diffMargin * 2;

			// mark as received
			for (int i = a; i < b; i++) {

				if (tf[i].layerStatus[thisMode] == WC.STATUS_READY) {
					tf[i].layerStatus[thisMode] = WC.STATUS_WORKING;
				}
			}

			for (int i = a; i < b; i++) {

				if (tf[i].layerStatus[modeInputSource] == WC.STATUS_COMPLETE
						&& tf[i - 1].layerStatus[modeInputSource] == WC.STATUS_COMPLETE) {
					// System.out.println("DEJITTER "+i);

					int neighborhood = 11;
					int kOffset = 5;// neighborhood/2;

					float jitterResults[][] = new float[neighborhood][neighborhood]; // X/Y
					// offsets
					// +
					// diff

					float diffCoeff = 1f / (float) (diffRangeX * diffRangeY);

					for (int x = 0; x < neighborhood; x++) {
						for (int y = 0; y < neighborhood; y++) {
							int offsetX = x - kOffset;
							int offsetY = y - kOffset;

							float diffAve = 0;

							// all pixels within the offset margin - current
							// image
							for (int x2 = diffMargin; x2 < diffRangeX; x2++) {
								for (int y2 = diffMargin; y2 < diffRangeY; y2++) {

									// all pixels within the offset margin -
									// prev image

									int px1 = tf[i].biRay[modeInputSource]
											.getRGB(x2, y2);
									int val1 = ((px1 >> 16) & 0xff);
									int px2 = tf[i - 1].biRay[modeInputSource]
											.getRGB(x2 + offsetX, y2 + offsetY);
									int val2 = ((px2 >> 16) & 0xff);

									// jitterDiffs[x2-diffMargin][y2-diffMargin]
									// = Math.abs(val1-val2);

									float diff = (float) Math.abs(val1 - val2)
											* diffCoeff;
									diffAve += diff;
								}
							}

							jitterResults[x][y] = diffAve;

						}
					}
					// end comparisons

					// find min diff
					float minDiff = Float.MAX_VALUE;
					int minJitX = kOffset;
					int minJitY = kOffset;
					for (int x = 0; x < neighborhood; x++) {
						for (int y = 0; y < neighborhood; y++) {
							if (jitterResults[x][y] < minDiff) {
								minDiff = jitterResults[x][y];
								minJitY = y;
								minJitX = x;
							}
						}
					}

					// store result
					tf[i].jitterWholePx[WC.X] = -(minJitX - kOffset);
					tf[i].jitterWholePx[WC.Y] = -(minJitY - kOffset);
					tf[i].layerStatus[thisMode] = WC.STATUS_COMPLETE;

					// System.out.println("FRAME "+i+" jitX "+tf[i].jitterWholePx[WC.X]
					// +" jitY "+tf[i].jitterWholePx[WC.Y]);
				}
			}

		}
	}

	public void dejitterImageTiles(WITFrame[] tf, int a, int b,
			ArrayList paramList) {

		int tileX = (Integer) paramList.get(0);
		int tileY = (Integer) paramList.get(1);

		int modeInputSource = WC.THREAD_LOAD; // may switch to convolved to
		// minimize artifact errors

		if (tf[a].layerStatus[modeInputSource] == WC.STATUS_COMPLETE
				&& tf[a - 1].layerStatus[modeInputSource] == WC.STATUS_COMPLETE
				&& a > 0) {

			int w = tf[a].biRay[WC.THREAD_LOAD].getWidth();
			int h = tf[a].biRay[WC.THREAD_LOAD].getHeight();

			int tileXCount = w / tileX;
			int tileYCount = w / tileY;

			int diffMargin = 100;
			int diffRangeX = w - diffMargin * 2;
			int diffRangeY = h - diffMargin * 2;

			// mark as received
			for (int i = a; i < b; i++) {

				tf[i].layerStatus[WC.THREAD_DEJITTER] = WC.STATUS_WORKING;
			}

			for (int i = a; i < b; i++) {

				// initialize jitter storage

				tf[i].jitterWholePxTiles = new int[tileXCount][tileYCount];

				if (tf[i].layerStatus[modeInputSource] == WC.STATUS_COMPLETE
						&& tf[i - 1].layerStatus[modeInputSource] == WC.STATUS_COMPLETE) {
					// System.out.println("DEJITTER "+i);

					int neighborhood = 11;
					int kOffset = 5;// neighborhood/2;

					float jitterResults[][] = new float[neighborhood][neighborhood]; // X/Y
					// offsets
					// +
					// diff

					float diffCoeff = 1f / (float) (diffRangeX * diffRangeY);

					for (int x = 0; x < neighborhood; x++) {
						for (int y = 0; y < neighborhood; y++) {
							int offsetX = x - kOffset;
							int offsetY = y - kOffset;

							// int jitterDiffs[][] = new
							// int[diffRangeX][diffRangeY];
							float diffAve = 0;

							// all pixels within the offset margin - current
							// image
							for (int x2 = diffMargin; x2 < diffRangeX; x2++) {
								for (int y2 = diffMargin; y2 < diffRangeY; y2++) {

									// all pixels within the offset margin -
									// prev image

									int px1 = tf[i].biRay[modeInputSource]
											.getRGB(x2, y2);
									int val1 = ((px1 >> 16) & 0xff);
									int px2 = tf[i - 1].biRay[modeInputSource]
											.getRGB(x2 + offsetX, y2 + offsetY);
									int val2 = ((px2 >> 16) & 0xff);

									// jitterDiffs[x2-diffMargin][y2-diffMargin]
									// = Math.abs(val1-val2);

									float diff = (float) Math.abs(val1 - val2)
											* diffCoeff;
									diffAve += diff;
								}
							}

							jitterResults[x][y] = diffAve;

						}
					}
					// end comparisons

					// find min diff
					float minDiff = Float.MAX_VALUE;
					int minJitX = kOffset;
					int minJitY = kOffset;
					for (int x = 0; x < neighborhood; x++) {
						for (int y = 0; y < neighborhood; y++) {
							if (jitterResults[x][y] < minDiff) {
								minDiff = jitterResults[x][y];
								minJitY = y;
								minJitX = x;
							}
						}
					}

					// store result
					tf[i].jitterWholePx[WC.X] = -(minJitX - kOffset);
					tf[i].jitterWholePx[WC.Y] = -(minJitY - kOffset);
					tf[i].layerStatus[WC.THREAD_DEJITTER] = WC.STATUS_COMPLETE;

					// System.out.println("FRAME "+i+" jitX "+tf[i].jitterWholePx[WC.X]
					// +" jitY "+tf[i].jitterWholePx[WC.Y]);
				}
			}

		}
	}

	public void manualContrastAdjust(WITFrame[] tf, int a, int b,
			ArrayList paramList) {

		// float brightness

		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int w = maxX - minX;
		int h = maxY - minY;

		int rgba = 0;
		int val = 0;
		for (int i = a; i < b; i++) {

			for (int x = 0; x < tf[i].width; x++) {
				for (int y = 0; y < tf[i].height; y++) {

					val = tf[i].hdrValsRaw[x][y];

					if (val > 255) {
						// System.out.println("OVER-SATURATED "+val);
						val = 255;
					}
					if (val < 0)
						val = 0;

					// add raw data to the WIT Frame

					rgba = (255 << 24) | (val << 16) | (val << 8) | val;
				}
			}

		}

		// for(int i=0 )
	}

	public void autoContrastAdjust(WITFrame[] tf, int a, int b,
			ArrayList paramList) {

		int minX = (Integer) paramList.get(1);
		int maxX = (Integer) paramList.get(2);
		int minY = (Integer) paramList.get(3);
		int maxY = (Integer) paramList.get(4);

		int w = maxX - minX;
		int h = maxY - minY;

		System.out.println(" CONTRAST DIMS " + w + " " + h);

		int rgba = 0;
		int val = 0;
		for (int i = a; i < b; i++) {

			for (int x = 0; x < tf[i].width; x++) {
				for (int y = 0; y < tf[i].height; y++) {

					val = tf[i].hdrValsRaw[x][y];

					if (val > 255) {
						// System.out.println("OVER-SATURATED "+val);
						val = 255;
					}
					if (val < 0)
						val = 0;

					// add raw data to the WIT Frame

					rgba = (255 << 24) | (val << 16) | (val << 8) | val;
				}
			}

		}

		// for(int i=0 )
	}

	public void registerSubFrame(WITFrame[] tf, int a, int b,
			ArrayList paramList) {

	}

	public void dwtCpuSubFrame(WITFrame[] tf, int a, int b, ArrayList paramList) {

	}

	public void dwtGpuSubFrame(WITFrame[] tf, int a, int b, ArrayList paramList) {

	}

	private static String getRecentH5R(String dir, int sca, int scid) {
		// TODO Auto-generated method stub
		String notFoundStr = "FILE_NOT_FOUND";

		String name = notFoundStr;

		File h5Dir = new File(dir);

		File[] fileRay = h5Dir.listFiles();

		// for (int i=0; i<hNames.length; i++){
		String scidStr = "SCID" + scid;
		String scaStr = "SCA" + (sca + 1);// (i+1);

		long modDate = Long.MAX_VALUE;
		int recentID = -1;
		int recentIDprev = -1;

		for (int j = 0; j < fileRay.length; j++) {

			if (fileRay[j].getName().contains(scaStr)
					&& fileRay[j].getName().contains(scidStr)) {

				// System.out.println(scaStr +" "+fileRay[j].getName());
				long date = fileRay[j].lastModified();
				if (date < modDate) {
					// if (fileRay[j].canRead() == true ){ // make sure there's
					// not a lock on the file; 2222 appears to be a bug
					if (fileRay[j].canRead() == true
							&& !fileRay[j].getName().contains("_2222_")) { // make
						// sure
						// there's
						// not
						// a
						// lock
						// on
						// the
						// file;
						// 2222
						// appears
						// to
						// be
						// a
						// bug
						modDate = date;
						recentIDprev = recentID;
						recentID = j;
					}
				}
			}

		}

		if (recentID == -1) {
			name = notFoundStr;
		} else {

			name = fileRay[recentID].getAbsolutePath();
			System.out.println(scaStr + " " + fileRay[recentID].getName());
		}

		return name;

	}

	public Composite makeComposite(float a) {
		Composite c = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, a);

		return c;

	}

	public void threshImage(WITFrame[] tf, int a, int b, ArrayList paramList) {

		int w = tf[a].biRay[WC.THREAD_LOAD].getWidth();
		int h = tf[a].biRay[WC.THREAD_LOAD].getHeight();

		int pxRay1[][] = new int[w][h];
		int pxRay2[][] = new int[w][h];

		for (int i = a; i < b; i++) {

			if (tf[i].layerStatus[WC.THREAD_THRS] == WC.STATUS_READY) {
				tf[i].layerStatus[WC.THREAD_THRS] = WC.STATUS_WORKING;
				tf[i].biRay[WC.THREAD_THRS] = new BufferedImage(w, h,
						BufferedImage.TYPE_INT_RGB);
				if (verbosity > 0)
					System.out.println("EXEC THRESHOLD FRAME " + i);
				tf[i].layerStatus[WC.THREAD_THRS] = WC.STATUS_COMPLETE;
			}
		}
	}

}
