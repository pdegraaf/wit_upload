#ifndef H5R_CALRAWDATA
#define H5R_CALRAWDATA

//#pragma once
#include "hdf5.h"

#include "H5Classes.h"
using namespace H5;

class H5R_File{};

class H5R_CalRawData
{
public:
	H5R_CalRawData(DataSet *dataset, H5R_File *h);
	H5R_CalRawData();
	~H5R_CalRawData(void);

	H5R_File h5;
	int numFrames;
	DataSet dataset();
	double h5LibVersion;

	int** getFrame(int frameNum);
	short** getShortFrame(int frameNum, int shift);

	int* getPackedIntFrame(int frameNum);
	short* getPackedFrame(int frameNum, int shift);


};

#endif