#ifndef PLAYBACKPANE_H
#define PLAYBACKPANE_H

#include <QWidget>
#include <QObject>
#include <QtGui>

class PlaybackPane : public QWidget
{
	Q_OBJECT

public:
	PlaybackPane();
	~PlaybackPane();

	void setupItems();

	QHBoxLayout *hboxPlayback1;
	QVBoxLayout *vboxPlayback1;
	
	QLabel *labelPlaybackSpeed; 
	QLineEdit *textPlaybackSpeed;
	QCheckBox *cbPause;
	QCheckBox *cbReverse;
	
public slots:
	void toggleReverseButton();
	void togglePauseButton();

private:
	
};

#endif // PLAYBACKPANE_H
