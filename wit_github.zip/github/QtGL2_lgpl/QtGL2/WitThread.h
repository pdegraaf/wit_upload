#pragma once

#include "StdAfx.h"
#include "WitFile.h"
#include "WitFrame.h"

#include <QThread>
#include <QProcess>
#include <QDebug>

class WitThread
 {

public:

	WitThread(void);
	~WitThread();

	QObject* parent;
	
	void run(void);

	boost::thread *bt;
	
	void load(void);
	void loadH5Test(void);
	void loadH5R(void);
	void loadH5RMeta(void);
	void invokeFFmpegExport(void);
	void prepThread(void);
	int threadStatus;
	long threadStartTime;

	int threadId;

	int mode;

	WitFrame *wframe;
	WitFile *wfile;
	string *params;
	
	int startTime;		// performance tracking
	int queuedTime;
	int endTime;

	float secsOfDay;	// timestamp of data operated on by thread

	public slots:
		
	void runSlot(void);
};

