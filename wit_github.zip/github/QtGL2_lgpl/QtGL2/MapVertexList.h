#pragma once
#include "MapVertex.h"
#include <string>

class MapVertexList
{
public:
	MapVertexList(void);
	~MapVertexList(void);
		
	int type;
	int numVertices;
	MapVertex *vertexList;
};

