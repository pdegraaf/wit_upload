#include "H5R_CalRawData.h"
//#include "H5R_File.h"
//#include "H5R_Combined.h"

H5R_CalRawData::H5R_CalRawData(DataSet *dataset, H5R_File *h)
{
	//this.h5 = h5;
	//this. dataset = dataset;
	//this.dataset.init(); // Retrieve Dataset information from file
		//h5LibVersion = h->getH5LibVersion();


		// Read the number of frames from the file meta data
		//H5R_FileMetaData fileMetaData = h->getFileMetaData();
		//numFrames = fileMetaData.numberOfFrames;//.getNumberOfFrames();

}

H5R_CalRawData::H5R_CalRawData(){

}


H5R_CalRawData::~H5R_CalRawData(void)
{
}
