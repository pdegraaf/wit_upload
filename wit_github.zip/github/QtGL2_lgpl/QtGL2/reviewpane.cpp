/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

#include "reviewpane.h"
#include "EventDetection.h"

ReviewPane::ReviewPane()
	: QWidget()
{

}

ReviewPane::~ReviewPane()
{

}

void ReviewPane::updateTable(EventDetection *e){
	
	QTableWidgetItem* itemStatus=new QTableWidgetItem("?");

	QString strX = QString::number(e->pxX, 'f', 0);
	QString strY = QString::number(e->pxY, 'f', 0);
		
	QString strLat = QString::number(e->lat, 'f', 5);
	QString strLon = QString::number(e->lon, 'f', 5);
		
	QString strRawVal = QString::number(e->valRaw, 'f', 5);
	QString strFilterVal = QString::number(e->valFilter, 'f', 5);
	QString strSigmaVal = QString::number(e->valSigma, 'f', 5);
	if (e->valSigma == 0){
		strSigmaVal = QString("OMIT");
	}
	QString strType = QString("UNK");

	QString strTime = QString::number(e->timeSecOfDay, 'f', 5);
	QString strFrameId = QString::number(e->frameId, 'f', 0);
	QString strEventId = QString::number(e->eventDetectId, 'f', 0);

	QString strComment = QString("AUTO");
	
	QTableWidgetItem* itemX=new QTableWidgetItem(strX);
	QTableWidgetItem* itemY=new QTableWidgetItem(strY);

	QTableWidgetItem* itemLon=new QTableWidgetItem(strLon);
	QTableWidgetItem* itemLat=new QTableWidgetItem(strLat);

	QTableWidgetItem* itemTime=new QTableWidgetItem(strTime);
	QTableWidgetItem* itemRawVal=new QTableWidgetItem(strRawVal);
	QTableWidgetItem* itemFilterVal=new QTableWidgetItem(strFilterVal);
	QTableWidgetItem* itemSigmaVal=new QTableWidgetItem(strSigmaVal);
	QTableWidgetItem* itemType=new QTableWidgetItem(strType);

	QTableWidgetItem* itemEventId=new QTableWidgetItem(strEventId);
	QTableWidgetItem* itemFrameId=new QTableWidgetItem(strFrameId);
	QTableWidgetItem* itemComment=new QTableWidgetItem(strComment);

	itemStatus->setBackgroundColor(*colorUnknown);

	itemX->setBackgroundColor(*rowColorUnknown);
	itemY->setBackgroundColor(*rowColorUnknown);
	itemLon->setBackgroundColor(*rowColorUnknown);
	itemLat->setBackgroundColor(*rowColorUnknown);

	itemTime->setBackgroundColor(*rowColorUnknown);
	itemRawVal->setBackgroundColor(*rowColorUnknown);
	itemFilterVal->setBackgroundColor(*rowColorUnknown);
	itemSigmaVal->setBackgroundColor(*rowColorUnknown);
	itemType->setBackgroundColor(*rowColorUnknown);
	itemEventId->setBackgroundColor(*rowColorUnknown);
	itemFrameId->setBackgroundColor(*rowColorUnknown);
	itemComment->setBackgroundColor(*rowColorUnknown);

	itemX->setFlags(itemX->flags() ^ Qt::ItemIsEditable); 
	itemY->setFlags(itemY->flags() ^ Qt::ItemIsEditable); 
	itemLon->setFlags(itemLon->flags() ^ Qt::ItemIsEditable); 
	itemLat->setFlags(itemLat->flags() ^ Qt::ItemIsEditable); 
	itemTime->setFlags(itemTime->flags() ^ Qt::ItemIsEditable); 
	itemRawVal->setFlags(itemRawVal->flags() ^ Qt::ItemIsEditable); 
	itemFilterVal->setFlags(itemFilterVal->flags() ^ Qt::ItemIsEditable); 
	itemSigmaVal->setFlags(itemSigmaVal->flags() ^ Qt::ItemIsEditable); 
	itemType->setFlags(itemType->flags() ^ Qt::ItemIsEditable); 
	itemEventId->setFlags(itemEventId->flags() ^ Qt::ItemIsEditable); 
	itemFrameId->setFlags(itemFrameId->flags() ^ Qt::ItemIsEditable); 
		
	int rowCount = this->reviewTable->rowCount();
	if (rowCount <= witItemCount){
		this->reviewTable->setRowCount(rowCount+1);
	}

	this->reviewTable->setItem(witItemCount,0,itemStatus); //r,c
	this->reviewTable->setItem(witItemCount,1,itemTime);
	
	this->reviewTable->setItem(witItemCount,2,itemRawVal);
	this->reviewTable->setItem(witItemCount,3,itemFilterVal);
	this->reviewTable->setItem(witItemCount,4,itemSigmaVal);
	this->reviewTable->setItem(witItemCount,5,itemType);
	
	this->reviewTable->setItem(witItemCount,6,itemLon);
	this->reviewTable->setItem(witItemCount,7,itemLat); 

	this->reviewTable->setItem(witItemCount,8,itemX);
	this->reviewTable->setItem(witItemCount,9,itemY); 
	
	this->reviewTable->setItem(witItemCount,10,itemEventId);
	this->reviewTable->setItem(witItemCount,11,itemFrameId); 
	this->reviewTable->setItem(witItemCount,12,itemComment); 

	witItemCount++;
}

void ReviewPane::setRowAccept(){
	QList<QTableWidgetItem *> list = this->reviewTable->selectedItems();
	for (int i=0; i<list.size(); i++){
		for (int c=1; c< cols; c++){
			this->reviewTable->item(list.at(i)->row(), c)->setBackgroundColor(*rowColorAccept);
		}
		this->reviewTable->item(list.at(i)->row(), 0)->setBackgroundColor(*colorAccept);
		this->reviewTable->item(list.at(i)->row(), 0)->setText("A");
	}
}

void ReviewPane::setRowReject(){
	QList<QTableWidgetItem *> list = this->reviewTable->selectedItems();
	for (int i=0; i<list.size(); i++){
		for (int c=1; c< cols; c++){
			this->reviewTable->item(list.at(i)->row(), c)->setBackgroundColor(*rowColorReject);
		}
		this->reviewTable->item(list.at(i)->row(), 0)->setBackgroundColor(*colorReject);
		this->reviewTable->item(list.at(i)->row(), 0)->setText("R");
	}
}

void ReviewPane::setRowUnknown(){
	QList<QTableWidgetItem *> list = this->reviewTable->selectedItems();
	for (int i=0; i<list.size(); i++){
		for (int c=1; c< cols; c++){
			this->reviewTable->item(list.at(i)->row(), c)->setBackgroundColor(*rowColorUnknown);
		}
		this->reviewTable->item(list.at(i)->row(), 0)->setBackgroundColor(*colorUnknown);
		this->reviewTable->item(list.at(i)->row(), 0)->setText("U");
	}
}

void ReviewPane::setRowShow(){
	QList<QTableWidgetItem *> list = this->reviewTable->selectedItems();
	int rowCount = this->reviewTable->rowCount();
	for (int i=0; i<rowCount; i++){
		this->reviewTable->setRowHidden(i, false);
	}
}

void ReviewPane::setRowDelete(){
	QList<QTableWidgetItem *> list = this->reviewTable->selectedItems();
	for (int i=0; i<list.size(); i++){
		this->reviewTable->hideRow(list.at(i)->row());
	}
}

void ReviewPane::detectTableClear(){
	this->reviewTable->setRowCount(0);
	witItemCount=0;
	qDebug("DETECTION TABLE PURGED");
}

void ReviewPane::setupItems(){

	cols = 13;
	witItemCount = 0;

	// colors
	rowColorUnknown = new QColor(255, 255, 200);
	rowColorAccept = new QColor(200, 255, 200);
	rowColorReject = new QColor(255, 200, 200);
	
	colorUnknown = new QColor(255, 255, 0);
	colorAccept = new QColor(0, 255, 0);
	colorReject = new QColor(255, 0, 0);

	// detection review
	QHBoxLayout *hboxReview1 = new QHBoxLayout();
	QHBoxLayout *hboxReview2 = new QHBoxLayout();
	QHBoxLayout *hboxReview3 = new QHBoxLayout();
	QHBoxLayout *hboxReview4 = new QHBoxLayout();
	QVBoxLayout *vboxReview1 = new QVBoxLayout();

	reviewTable = new QTableWidget();
	reviewTable->setFixedHeight(100);

	reviewTable->setAlternatingRowColors(true);
	reviewTable->setColumnCount(cols);
	reviewTable->setRowCount(0);
	reviewTable->setSortingEnabled(true);
	reviewTable->setWordWrap(true);
	QStringList headers;
	headers << "?" << "TIME"<< "R-VAL"<< "F-VAL" << "Z-VAL" << "TYPE" << "LON" << "LAT" << "PIX X" << "PIX Y" << "EVENT ID" << "FRAME ID" << "COMMENT";
	reviewTable->setHorizontalHeaderLabels(headers);
	reviewTable->setColumnWidth(0,20);
	reviewTable->setColumnWidth(1,80);
	reviewTable->setColumnWidth(2,60);
	reviewTable->setColumnWidth(3,60);
	reviewTable->setColumnWidth(4,60);
	reviewTable->setColumnWidth(5,40);
	reviewTable->setColumnWidth(6,65);
	reviewTable->setColumnWidth(7,65);
	reviewTable->setColumnWidth(8,65);
	reviewTable->setColumnWidth(9,65);
	reviewTable->setColumnWidth(10,65);
	reviewTable->setColumnWidth(11,65);
	reviewTable->setColumnWidth(12,300);

	QTableWidgetItem* item=new QTableWidgetItem("");
	item->setBackgroundColor(QColor(255, 255, 0));
	reviewTable->setItem(0,1,item);

	hboxReview1->addWidget(reviewTable);
	vboxReview1->addLayout(hboxReview1);
	vboxReview1->addLayout(hboxReview2);
	vboxReview1->addLayout(hboxReview3);
	vboxReview1->addLayout(hboxReview4);
	vboxReview1->addStretch(1);

	this->setLayout(vboxReview1);
	qbReject = new QPushButton();
	qbReject->setText("REJECT");
	qbReject->setFocusPolicy(Qt::NoFocus);
	qbAccept = new QPushButton();
	qbAccept->setText("ACCEPT");
	qbAccept->setFocusPolicy(Qt::NoFocus);
	qbClear = new QPushButton();
	qbClear->setText("CLEAR ALL");
	qbClear->setFocusPolicy(Qt::NoFocus);
	qbDelete = new QPushButton();
	qbDelete->setText("HIDE");
	qbDelete->setFocusPolicy(Qt::NoFocus);
	qbShow = new QPushButton();
	qbShow->setText("SHOW ALL");
	qbShow->setFocusPolicy(Qt::NoFocus);
	qbUnknown = new QPushButton();
	qbUnknown->setText("UNKNOWN");
	qbUnknown->setFocusPolicy(Qt::NoFocus);

	qbSaveXml = new QPushButton();
	qbSaveXml->setText("SAVE AS XML");
	qbSaveXml->setEnabled(false);
	qbSaveDb = new QPushButton();
	qbSaveDb->setText("SAVE TO DB");
	qbSaveDb->setEnabled(false);

	hboxReview2->addWidget(qbAccept);
	hboxReview2->addWidget(qbReject);
	hboxReview2->addWidget(qbUnknown);
	hboxReview2->addStretch(1);
	
	hboxReview3->addWidget(qbUnknown);
	hboxReview3->addWidget(qbDelete);
	hboxReview3->addStretch(1);
	
	hboxReview4->addWidget(qbShow);
	hboxReview4->addWidget(qbClear);
	hboxReview4->addStretch(1);
	hboxReview4->addWidget(qbSaveXml);
	hboxReview4->addWidget(qbSaveDb);
}