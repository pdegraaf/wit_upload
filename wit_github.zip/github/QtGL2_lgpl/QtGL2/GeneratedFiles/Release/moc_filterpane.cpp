/****************************************************************************
** Meta object code from reading C++ file 'filterpane.h'
**
** Created: Wed Jan 30 08:03:17 2013
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../filterpane.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'filterpane.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_FilterPane[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      16,   12,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
      50,   46,   11,   11, 0x0a,
      81,   77,   11,   11, 0x0a,
     113,   11,   11,   11, 0x0a,
     129,   11,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_FilterPane[] = {
    "FilterPane\0\0k,n\0applyTapEdits(QLineEdit*,int)\0"
    "n,t\0updateKernelTap(int,float)\0n,s\0"
    "updateKernelTapStr(int,QString)\0"
    "relayTapEdits()\0toggleFilterButton()\0"
};

const QMetaObject FilterPane::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_FilterPane,
      qt_meta_data_FilterPane, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &FilterPane::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *FilterPane::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *FilterPane::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_FilterPane))
        return static_cast<void*>(const_cast< FilterPane*>(this));
    return QWidget::qt_metacast(_clname);
}

int FilterPane::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: applyTapEdits((*reinterpret_cast< QLineEdit*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 1: updateKernelTap((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2]))); break;
        case 2: updateKernelTapStr((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 3: relayTapEdits(); break;
        case 4: toggleFilterButton(); break;
        default: ;
        }
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void FilterPane::applyTapEdits(QLineEdit * _t1, int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
