/****************************************************************************
** Meta object code from reading C++ file 'contrastpane.h'
**
** Created: Wed Jan 30 09:52:38 2013
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../contrastpane.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'contrastpane.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ContrastPane[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x0a,
      37,   13,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_ContrastPane[] = {
    "ContrastPane\0\0toggleContrastButton()\0"
    "toggleHistogramButton()\0"
};

const QMetaObject ContrastPane::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_ContrastPane,
      qt_meta_data_ContrastPane, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ContrastPane::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ContrastPane::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ContrastPane::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ContrastPane))
        return static_cast<void*>(const_cast< ContrastPane*>(this));
    return QWidget::qt_metacast(_clname);
}

int ContrastPane::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: toggleContrastButton(); break;
        case 1: toggleHistogramButton(); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
