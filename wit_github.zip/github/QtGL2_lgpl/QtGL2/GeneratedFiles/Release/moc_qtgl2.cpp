/****************************************************************************
** Meta object code from reading C++ file 'qtgl2.h'
**
** Created: Wed Jan 30 09:52:37 2013
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../qtgl2.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qtgl2.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_QtGL2[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      56,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      16,       // signalCount

 // signals: signature, parameters, type, tag, flags
       9,    7,    6,    6, 0x05,
      48,   44,    6,    6, 0x05,
      77,   73,    6,    6, 0x05,
     109,  107,    6,    6, 0x05,
     131,  107,    6,    6, 0x05,
     158,  107,    6,    6, 0x05,
     186,    6,    6,    6, 0x05,
     208,    6,    6,    6, 0x05,
     232,    6,    6,    6, 0x05,
     257,    6,    6,    6, 0x05,
     283,    6,    6,    6, 0x05,
     306,    6,    6,    6, 0x05,
     332,    6,    6,    6, 0x05,
     359,    6,    6,    6, 0x05,
     390,    6,    6,    6, 0x05,
     424,  418,    6,    6, 0x05,

 // slots: signature, parameters, type, tag, flags
     460,    6,    6,    6, 0x0a,
     479,    6,    6,    6, 0x0a,
     502,    6,    6,    6, 0x0a,
     528,    6,    6,    6, 0x0a,
     551,    6,    6,    6, 0x0a,
     573,    6,    6,    6, 0x0a,
     596,    6,    6,    6, 0x0a,
     620,    6,    6,    6, 0x0a,
     645,    6,    6,    6, 0x0a,
     670,    6,    6,    6, 0x0a,
     695,    6,    6,    6, 0x0a,
     721,    6,    6,    6, 0x0a,
     752,    6,    6,    6, 0x0a,
     784,    6,    6,    6, 0x0a,
     809,    6,    6,    6, 0x0a,
     838,  834,    6,    6, 0x0a,
     867,  834,    6,    6, 0x0a,
     894,  834,    6,    6, 0x0a,
     921,  418,    6,    6, 0x0a,
     950,  834,    6,    6, 0x0a,
     983,  834,    6,    6, 0x0a,
    1023, 1017,    6,    6, 0x0a,
    1051, 1047,    6,    6, 0x0a,
    1079,    6,    6,    6, 0x0a,
    1097,    6,    6,    6, 0x0a,
    1115,  834,    6,    6, 0x0a,
    1158,    6,    6,    6, 0x0a,
    1186,    6,    6,    6, 0x0a,
    1214,    6,    6,    6, 0x0a,
    1241,  834,    6,    6, 0x0a,
    1275, 1272,    6,    6, 0x0a,
    1296,    6,    6,    6, 0x0a,
    1319,    6,    6,    6, 0x0a,
    1339,    6,    6,    6, 0x0a,
    1357, 1272,    6,    6, 0x0a,
    1380,    6,    6,    6, 0x0a,
    1413, 1403,    6,    6, 0x0a,
    1453, 1449,    6,    6, 0x0a,
    1485,    6,    6,    6, 0x0a,
    1504,    6,    6,    6, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_QtGL2[] = {
    "QtGL2\0\0e\0thresholdDetected(EventDetection*)\0"
    "i,t\0pushKernelTap(int,float)\0i,s\0"
    "pushKernelTapStr(int,QString)\0t\0"
    "updateThreshUi(float)\0updateWatchRadiusUi(float)\0"
    "updateRejectRadiusUi(float)\0"
    "updateUiTogglePause()\0updateUiToggleReverse()\0"
    "updateUiToggleContrast()\0"
    "updateUiToggleHistogram()\0"
    "updateUiToggleFilter()\0updateUiToggleThreshold()\0"
    "updateUiToggleAutoOrient()\0"
    "updateUiToggleAutoOrientSnap()\0"
    "updateUiToggleExportVideo()\0state\0"
    "updateUiToggleExportButtonText(int)\0"
    "toggleAutoOrient()\0toggleAutoOrientSnap()\0"
    "togglePlaybackDirection()\0"
    "togglePlaybackPaused()\0toggleContrastOnOff()\0"
    "toggleHistogramOnOff()\0toggleCudaFilterOnOff()\0"
    "toggleThreshConstOnOff()\0"
    "toggleThreshSigmaOnOff()\0"
    "toggleRegionWatchOnOff()\0"
    "toggleRegionRejectOnOff()\0"
    "toggleRegionWatchRadiusOnOff()\0"
    "toggleRegionRejectRadiusOnOff()\0"
    "toggleVideoStreamOnOff()\0"
    "toggleVideoExportOnOff()\0str\0"
    "changePlaybackSpeed(QString)\0"
    "changeThreshConst(QString)\0"
    "changeThreshSigma(QString)\0"
    "changeThreshConstPreset(int)\0"
    "changeRegionWatchRadius(QString)\0"
    "changeRegionRejectRadius(QString)\0"
    "i,str\0changeKTap(int,QString)\0k,n\0"
    "changeKTaps(QLineEdit*,int)\0"
    "detectListClear()\0resetDetections()\0"
    "changeIncomingDataArchiveLocation(QString)\0"
    "changeIncomingDataArchive()\0"
    "changeIncomingDataMonitor()\0"
    "changeIncomingDataStream()\0"
    "changeVideoExportName(QString)\0id\0"
    "setKernelPreset(int)\0setKernelPassthrough()\0"
    "restoreUserKernel()\0undoKernelEdits()\0"
    "setContrastPreset(int)\0resetContrastResults()\0"
    "r,c,rp,cp\0highlightDetection(int,int,int,int)\0"
    "r,c\0highlightDetectionNone(int,int)\0"
    "videoStreamStart()\0videoExportStart()\0"
};

const QMetaObject QtGL2::staticMetaObject = {
    { &QGLWidget::staticMetaObject, qt_meta_stringdata_QtGL2,
      qt_meta_data_QtGL2, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QtGL2::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QtGL2::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QtGL2::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QtGL2))
        return static_cast<void*>(const_cast< QtGL2*>(this));
    return QGLWidget::qt_metacast(_clname);
}

int QtGL2::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGLWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: thresholdDetected((*reinterpret_cast< EventDetection*(*)>(_a[1]))); break;
        case 1: pushKernelTap((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2]))); break;
        case 2: pushKernelTapStr((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 3: updateThreshUi((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 4: updateWatchRadiusUi((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 5: updateRejectRadiusUi((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 6: updateUiTogglePause(); break;
        case 7: updateUiToggleReverse(); break;
        case 8: updateUiToggleContrast(); break;
        case 9: updateUiToggleHistogram(); break;
        case 10: updateUiToggleFilter(); break;
        case 11: updateUiToggleThreshold(); break;
        case 12: updateUiToggleAutoOrient(); break;
        case 13: updateUiToggleAutoOrientSnap(); break;
        case 14: updateUiToggleExportVideo(); break;
        case 15: updateUiToggleExportButtonText((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: toggleAutoOrient(); break;
        case 17: toggleAutoOrientSnap(); break;
        case 18: togglePlaybackDirection(); break;
        case 19: togglePlaybackPaused(); break;
        case 20: toggleContrastOnOff(); break;
        case 21: toggleHistogramOnOff(); break;
        case 22: toggleCudaFilterOnOff(); break;
        case 23: toggleThreshConstOnOff(); break;
        case 24: toggleThreshSigmaOnOff(); break;
        case 25: toggleRegionWatchOnOff(); break;
        case 26: toggleRegionRejectOnOff(); break;
        case 27: toggleRegionWatchRadiusOnOff(); break;
        case 28: toggleRegionRejectRadiusOnOff(); break;
        case 29: toggleVideoStreamOnOff(); break;
        case 30: toggleVideoExportOnOff(); break;
        case 31: changePlaybackSpeed((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 32: changeThreshConst((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 33: changeThreshSigma((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 34: changeThreshConstPreset((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 35: changeRegionWatchRadius((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 36: changeRegionRejectRadius((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 37: changeKTap((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 38: changeKTaps((*reinterpret_cast< QLineEdit*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 39: detectListClear(); break;
        case 40: resetDetections(); break;
        case 41: changeIncomingDataArchiveLocation((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 42: changeIncomingDataArchive(); break;
        case 43: changeIncomingDataMonitor(); break;
        case 44: changeIncomingDataStream(); break;
        case 45: changeVideoExportName((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 46: setKernelPreset((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 47: setKernelPassthrough(); break;
        case 48: restoreUserKernel(); break;
        case 49: undoKernelEdits(); break;
        case 50: setContrastPreset((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 51: resetContrastResults(); break;
        case 52: highlightDetection((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 53: highlightDetectionNone((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 54: videoStreamStart(); break;
        case 55: videoExportStart(); break;
        default: ;
        }
        _id -= 56;
    }
    return _id;
}

// SIGNAL 0
void QtGL2::thresholdDetected(EventDetection * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QtGL2::pushKernelTap(int _t1, float _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QtGL2::pushKernelTapStr(int _t1, QString _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QtGL2::updateThreshUi(float _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void QtGL2::updateWatchRadiusUi(float _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void QtGL2::updateRejectRadiusUi(float _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void QtGL2::updateUiTogglePause()
{
    QMetaObject::activate(this, &staticMetaObject, 6, 0);
}

// SIGNAL 7
void QtGL2::updateUiToggleReverse()
{
    QMetaObject::activate(this, &staticMetaObject, 7, 0);
}

// SIGNAL 8
void QtGL2::updateUiToggleContrast()
{
    QMetaObject::activate(this, &staticMetaObject, 8, 0);
}

// SIGNAL 9
void QtGL2::updateUiToggleHistogram()
{
    QMetaObject::activate(this, &staticMetaObject, 9, 0);
}

// SIGNAL 10
void QtGL2::updateUiToggleFilter()
{
    QMetaObject::activate(this, &staticMetaObject, 10, 0);
}

// SIGNAL 11
void QtGL2::updateUiToggleThreshold()
{
    QMetaObject::activate(this, &staticMetaObject, 11, 0);
}

// SIGNAL 12
void QtGL2::updateUiToggleAutoOrient()
{
    QMetaObject::activate(this, &staticMetaObject, 12, 0);
}

// SIGNAL 13
void QtGL2::updateUiToggleAutoOrientSnap()
{
    QMetaObject::activate(this, &staticMetaObject, 13, 0);
}

// SIGNAL 14
void QtGL2::updateUiToggleExportVideo()
{
    QMetaObject::activate(this, &staticMetaObject, 14, 0);
}

// SIGNAL 15
void QtGL2::updateUiToggleExportButtonText(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 15, _a);
}
QT_END_MOC_NAMESPACE
