/****************************************************************************
** Meta object code from reading C++ file 'threshpane.h'
**
** Created: Wed Jan 30 08:03:21 2013
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../threshpane.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'threshpane.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ThreshPane[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      14,   12,   11,   11, 0x0a,
      39,   12,   11,   11, 0x0a,
      70,   12,   11,   11, 0x0a,
     102,   11,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_ThreshPane[] = {
    "ThreshPane\0\0t\0updateThreshConst(float)\0"
    "updateRegionWatchRadius(float)\0"
    "updateRegionRejectRadius(float)\0"
    "toggleThresholdButton()\0"
};

const QMetaObject ThreshPane::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_ThreshPane,
      qt_meta_data_ThreshPane, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ThreshPane::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ThreshPane::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ThreshPane::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ThreshPane))
        return static_cast<void*>(const_cast< ThreshPane*>(this));
    return QWidget::qt_metacast(_clname);
}

int ThreshPane::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: updateThreshConst((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 1: updateRegionWatchRadius((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 2: updateRegionRejectRadius((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 3: toggleThresholdButton(); break;
        default: ;
        }
        _id -= 4;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
