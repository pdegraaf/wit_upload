/********************************************************************************
** Form generated from reading UI file 'qtgl2.ui'
**
** Created: Wed Jan 30 08:03:16 2013
**      by: Qt User Interface Compiler version 4.7.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QTGL2_H
#define UI_QTGL2_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>
#include <QtOpenGL/QGLWidget>

QT_BEGIN_NAMESPACE

class Ui_QtGL2Class
{
public:
    QMenuBar *menuBar;
    QGLWidget *glWidget;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *QtGL2Class)
    {
        if (QtGL2Class->objectName().isEmpty())
            QtGL2Class->setObjectName(QString::fromUtf8("QtGL2Class"));
        QtGL2Class->resize(1200, 800);
        menuBar = new QMenuBar(QtGL2Class);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        QtGL2Class->setMenuBar(menuBar);
        glWidget = new QGLWidget(QtGL2Class);
        glWidget->setObjectName(QString::fromUtf8("glWidget"));
        QtGL2Class->setCentralWidget(glWidget);
        mainToolBar = new QToolBar(QtGL2Class);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        QtGL2Class->addToolBar(mainToolBar);
        centralWidget = new QWidget(QtGL2Class);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        QtGL2Class->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(QtGL2Class);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        QtGL2Class->setStatusBar(statusBar);

        retranslateUi(QtGL2Class);

        QMetaObject::connectSlotsByName(QtGL2Class);
    } // setupUi

    void retranslateUi(QMainWindow *QtGL2Class)
    {
        QtGL2Class->setWindowTitle(QApplication::translate("QtGL2Class", "QtGL2", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class QtGL2Class: public Ui_QtGL2Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QTGL2_H
