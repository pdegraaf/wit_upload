#pragma once
#include <string>
using namespace std;

#include <QImage>
#include <QColor>
#include "hdf5.h"
#include <stdio.h>

#include "StdAfx.h"
#include "WitFrame.h"

class WitFile
{
public:
	WitFile(void);
	~WitFile(void);

	int frameCount;
	string fileName;
	int sensorId;
	int chipId;
	int *fileStatus;
	int dataFileType;

	int secsStart;
	int secsStop;
	
	void setModeStatus(int mode, int status);
	int numReservedFrames;
	typedef WitFrame* WitFramePtr;

	WitFramePtr *wframeSeq;
	int getFrameCount(const char *);

	long fileTimeMin;
	long fileTimeMax;
	
};

