/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

#include "contrastpane.h"
s
ContrastPane::ContrastPane()
	: QWidget()
{

}

ContrastPane::~ContrastPane()
{

}

void ContrastPane::setupItems(){
	
	hboxContrast1 = new QHBoxLayout();
	hboxContrast2 = new QHBoxLayout();
	vboxContrast1 = new QVBoxLayout();
		
	cbContrast = new QCheckBox();
	cbContrast->setText("ENABLED");
	
	cbHistogram = new QCheckBox();
	cbHistogram->setText("SHOW HISTOGRAM");

	labelContrastPreset = new QLabel; 
	labelContrastPreset->setTextFormat(Qt::RichText); 
	labelContrastPreset->setText("PRESET");

	contrastList = new QComboBox();
	contrastList->addItem("WIT CLASSIC");
	contrastList->addItem("GRAY");
	contrastList->addItem("MARS");
	contrastList->setToolTip("Select color scheme for contrast enhancement.");

	hboxContrast2->addWidget(cbHistogram);
	hboxContrast2->addStretch(1);

	hboxContrast1->addWidget(cbContrast);
	hboxContrast1->addStretch(1);
	hboxContrast1->addWidget(labelContrastPreset);
	hboxContrast1->addWidget(contrastList);
	vboxContrast1->addLayout(hboxContrast1);
	vboxContrast1->addLayout(hboxContrast2);
	vboxContrast1->addStretch(1);

	this->setLayout(vboxContrast1);
}


void ContrastPane::toggleContrastButton(){
	cbContrast->toggle();
}

void ContrastPane::toggleHistogramButton(){
	cbHistogram->toggle();
}