#include "H5R_File.h"
//#include "H5R_Combined.h"

H5R_File::H5R_File(string fileName)
{

	hid_t h = H5Fopen (fileName.c_str(), H5F_ACC_RDONLY, H5P_DEFAULT);
}


H5R_File::~H5R_File(void)
{
}

H5R_CalRawData *H5R_File::findCalRawData(Group *g){

	H5R_CalRawData r =  H5R_CalRawData(); // H5R_CalRawData(hhid);

	return &r;
}

H5R_GeoLocationData H5R_File::findGeolocationData(Group *g){

	H5R_GeoLocationData hgd;

	return hgd;
}

H5R_FrameMetaData H5R_File::findFrameMetaData(Group *g){

	H5R_FrameMetaData hfmd;

	return hfmd;
}

H5R_CalRawData H5R_File::getCalRawData(){

	H5R_CalRawData hcrd;

	return hcrd;
}

H5R_GeoLocationData H5R_File::getGeolocationData(){
	H5R_GeoLocationData hgd;

	return hgd;
}

H5R_FrameMetaData H5R_File::getFrameMetaData(){
	H5R_FrameMetaData hfmd;

	return hfmd;
}

H5R_FileMetaData H5R_File::getFileMetaData(){
	H5R_FileMetaData hfmd;

	return hfmd;
}

int H5R_File::getNumFrames(){
	int n=0;

	return n;
}

H5R_SummaryMetaData H5R_File::getSummaryMetaData(){
	H5R_SummaryMetaData hsmd;

	return hsmd;
}

double H5R_File::getH5LibVersion(){

	double v =0;

	return v;
}