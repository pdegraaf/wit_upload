#ifndef FILTERPANE_H
#define FILTERPANE_H

#include <QObject>
#include <QtGui>

class FilterPane : public QWidget
{
	Q_OBJECT

public:
	FilterPane();
	~FilterPane();

	void setupItems();

	QHBoxLayout *hboxTemporal1;
	QHBoxLayout *hboxTemporal2;
	QHBoxLayout *hboxTemporal3;
	QVBoxLayout *vboxTemporal1;

	QPushButton *qbApplyTapEdits;
	QPushButton *qbUndoTapEdits;

	QCheckBox *cbTemporal;
	QLabel *labelTemporalPreset; 
	QComboBox *filterList;

	int numKTaps;
	QLineEdit *kTap;
	
public slots: 
	void updateKernelTap(int n, float t);
	void updateKernelTapStr(int n, QString s);
	void relayTapEdits();
	void toggleFilterButton();

signals:
	void applyTapEdits(QLineEdit *k, int n);
	
};

#endif
