#ifndef OUTPUTPANE_H
#define OUTPUTPANE_H

#include <QWidget>
#include <QObject>
#include <QtGui>

class OutputPane : public QWidget
{
	Q_OBJECT

public:
	OutputPane();
	~OutputPane();

	void setupItems();

	QPushButton *cbVideoExport;

	QCheckBox *cbVideoStream;
	
	QLabel *labelVideoStream;
	QLabel *labelVideoExport;

	QLineEdit *textVideoStream;
	QLineEdit *textVideoExport;

	QHBoxLayout *hboxOutput1;
	QHBoxLayout *hboxOutput2;
	QVBoxLayout *vboxOutput1;

public slots:
	void toggleExportButtonText(int state);
	void toggleVideoExportButton();

private:
	
};

#endif // OUTPUTPANE_H
