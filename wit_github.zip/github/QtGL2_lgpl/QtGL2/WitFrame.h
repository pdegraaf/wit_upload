#pragma once

#include <QImage>
#include <QColor>
#include "hdf5.h"
#include <stdio.h>
#include "H5R_FullFile.h"

class WitFrame
{
public:
	WitFrame(void);
	~WitFrame(void);
	
	int load(const char *, int x, int y, float secs);
	int getFrameId();
	void setModData();

	float variance;
	float stdDev;

	float *histValZ;
	float *histValRaw;
	float *histValFilter;
	
	int frameId;
	int frameOfFileNo;
	int sensorId;
	int chipId;
	int dataFileType;
	
	int segBeginLine;
	int segEndLine;
	int segNumLines;
	int segSecs;
	int segScanDir;

	int valMin;
	int valQ1;
	int valQ2;
	int valQ3;
	int valMax;
	
	float getLatLonX(float radius, float lat, float lon);
	float getLatLonY(float radius, float lat, float lon);
	float getLatLonZ(float radius, float lat, float lon);

	void setModeStatus(int mode, int status);

	float **dataSrc;
	float *dataRes;
	float *dataResContrast;

	int gridX;
	int gridY;

	int gridNumX;
	int gridNumY; 

	float **coordsX;
	float **coordsY;
	float **coordsZ;
	float **coordsLat;
	float **coordsLon;

	float secsOfDay;

	string fileName;

	int *frameStatus;
	int w;
	int h; 
	int pxCount;

	QImage *frameData;
	GLuint drawListIndex;
	GLuint *textures;

	GLuint drawListContrastIndex;
	GLuint *texturesContrast;

	// from FullFile - schema R

	typedef struct {
		float x;
		float y;
		float z;
		float lat;
		float lon;

	} geoloc_t;

	typedef struct {
		int frameNumber;
		long imageStatus;
		int beginChannel;
		int endChannel;
		int numChannels;
		int beginLine;
		int endLine;
		int numLines;
		int scanDir;
		int numGeoPoints;
		int year;
		int day;
		double secondsOfDay;
		int calNoCalFlag;
		int imageId;
		float satPosECF[3];
		float satVelECF[3];
		double lineDeltaTimeSecs;
		double absoluteCalCoeff_kws;
		double absoluteCalCoeff_wcmsq;
		double sosCTCsecs;
		int sosSeqIndex;
		int sosStepIndex;
		int sosDirection;
		char sosScaSelectStr[24];
		char sosParentAimPtStr[32];
		double sosScanRateMradUsecs;
		double sosFrameTimeUsecs;
		double sosBlankTimeUsecs;
		double sosLongIntUsecs;
		double sosShortIntUsecs;
		char sosIntegMode[16];
		int minCalIntensity;
		int maxCalIntensity;
		int linesReversed;
		int chansReversed;
		float UL_lat;
		float UL_lon;
		float UR_lat;
		float UR_lon;
		float LL_lat;
		float LL_lon;
		float LR_lat;
		float LR_lon;
		
	} meta_t;

	geoloc_t* gdata;
	meta_t* mdata;
	int* rdata;

	int* beginLine;
	int* endLine;
	int* numLines;

	double* secondsOfDay;

	int* sosSeqIndex;
	int* sosStepIndex;
};

