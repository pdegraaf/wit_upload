#pragma once
#include "hdf5.h"

#include "H5Classes.h"
using namespace H5;


#include <iostream>
using namespace std;


class H5R_CalRawData
{
public:
	H5R_CalRawData(DataSet *dataset, H5R_File *h);
	H5R_CalRawData();
	~H5R_CalRawData(void);

	H5R_File h5;
	int numFrames;
	DataSet dataset();
	double h5LibVersion;

	int** getFrame(int frameNum);
	short** getShortFrame(int frameNum, int shift);

	int* getPackedIntFrame(int frameNum);
	short* getPackedFrame(int frameNum, int shift);

};


class H5R_ErrorInfoTableEntry 
{
public:
	string errorTag;
	int affectedFrameCount;
	float percentOfFramesAffected;
};


class H5R_ErrorInfoTable
{
public:
	H5R_ErrorInfoTable(CompType *ds);
	H5R_ErrorInfoTable();
	//H5R_ErrorInfoTable(CompoundDS ds);
	~H5R_ErrorInfoTable(void);

	H5R_ErrorInfoTableEntry* errorInfoTableEntry;
	int NUM_COLS;
	int numRows;

	int getNumRows();
	H5R_ErrorInfoTableEntry* getErrorInfoTableEntry();
};


class H5R_File
{
public:
	H5R_File(string fileName);
	~H5R_File(void);

	hid_t h;

	H5R_CalRawData findCalRawData(Group *g);
	H5R_GeoLocationData findGeolocationData(Group *g);
	H5R_FrameMetaData findFrameMetaData(Group *g);

	H5R_CalRawData getCalRawData();
	H5R_GeoLocationData getGeolocationData();
	H5R_FrameMetaData getFrameMetaData();
	H5R_FileMetaData getFileMetaData();
	int getNumFrames();
	H5R_SummaryMetaData getSummaryMetaData();
	double getH5LibVersion();

	H5R_CalRawData calRawData;
	H5R_GeoLocationData geolocationData;
	H5R_FrameMetaData frameMetaData;
//	FileFormat h5File;
	H5R_FileMetaData fileMetaData;
	H5R_SummaryMetaData summaryMetaData;
	int numFrames;
	double h5LibVersion;
};


class H5R_FileMetaData
{
public:
	H5R_FileMetaData(Group *root);
	~H5R_FileMetaData(void);

	int scid;
	int sca;
	string minTimeStamp;
	int minYear;
	int minDay;
	double minSeconds;
	string maxTimeStamp;
	int maxYear;
	int maxDay;
	double maxSeconds;
	int numberOfFrames;
	double minLatitude;
	double maxLatitude;
	double minLongitude;
	double maxLongitude;

	int minCalIntensity;
	int maxCalIntensity;

};


class MetaData
{
public:
		int* frameNumber;
		int* beginChannel;
		int* endChannel;
		int* numChannels;
		int* beginLine;
		int* endLine;
		int* numLines;
		int* scanDir;
		int* numGeoPoints;
		int* year;
		int* day;
		double* secondsOfDay;
		int* calNoCalFlag;
		int* ImageId;
		double** satPosECF;
		double** satVelECF;
		double* lineDeltaTimeSecs;
		double* AbsoluteCalCoeff_kws;
		double* AbsoluteCalCoeff_wcmsq;
		double* sosCTCsecs;
		int* sosSeqIndex;
		int* sosStepIndex;
		int* sosDirection;
		string* sosScaSelectStr;
		string* sosParentAimPtStr;
		double* sosScanRateMradUsecs;
		double* sosFrameTimeUsecs;
		double* sosBlankTimeUsecs;
		double* sosLongIntUsecs;
		double* sosShortIntUsecs;
		string* sosIntegMode;

		// new items 11/2010
		float* UL_lat;
		float* UR_lat;
		float* LL_lat;
		float* LR_lat;
		float* UL_lon;
		float* UR_lon;
		float* LL_lon;
		float* LR_lon;

		int* minCalIntensity;
		int* maxCalIntensity;

		int* linesReversed;
		int* chansReversed;
};


class H5R_FrameMetaData
{
public:
	H5R_FrameMetaData(CompType *compound_ds);
	//H5R_FrameMetaData(CompoundDS compound_ds);
	~H5R_FrameMetaData(void);

	string* memberNames;
	long numFrames;
	CompType *compoundDS;
	//CompoundDS compoundDS;
	MetaData metaData;

	string* getMemberNames();
	MetaData getMetaData();

};


class H5R_Coords
{
public:
		int numAttr;// = 5;
		// X,Y,Z line of sight unit vectors in ECEF frame with origin
		// at spacecraft
		int xECEFUnit;// = 0;
		int yECEFUnit;// = 1;
		int zECEFUnit;// = 2;
		// line of sight mapped to ellipsoid lat/lon
		int latDeg;// = 3;
		int lonDeg;// = 4;
		float* attr;// = new float[numAttr];

		H5R_Coords(float x, float y, float z, float lat, float lon) {
			attr[xECEFUnit] = x;
			attr[yECEFUnit] = y;
			attr[zECEFUnit] = z;
			attr[latDeg] = lat;
			attr[lonDeg] = lon;
		}

		H5R_Coords() {
			attr[xECEFUnit] = 0;
			attr[yECEFUnit] = 0;
			attr[zECEFUnit] = 0;
			attr[latDeg] = 0;
			attr[lonDeg] = 0;
		}

};


class H5R_GeoLocationData
{
public:
	H5R_GeoLocationData(CompType *compound_ds, H5R_File * h5);
	//H5R_GeoLocationData(CompoundDS compound_ds, H5R_File h5); 
	~H5R_GeoLocationData(void);

	void getGeoLocationAttributes();
	H5R_Coords** getGeolocationData(int frameNum);
	float*** getGeolocationLonLat(int frameNum, int scanDir, int sca);
	H5R_Coords** getInterpolatedGeolocationData(int frameNum);
	float*** getInterpolatedLonLatData(int frameNum);
	
	string* getMemberNames();
	int getX_Stepsize_Pixels();
	int getY_Stepsize_Pixels();
	string getXY_coord_system();
	string getGeodetic_ellipsoid();
	double getEquatorial_radius_km();
	double getFlattening();

	int numFrames;
	int* numRows;
	int* numCols;
	string* memberNames;
	//CompoundDS compoundDS;
	CompType* compoundDS;
	int X_Stepsize_Pixels;
	int Y_Stepsize_Pixels;
	float offEarth;
	string XY_coord_system;
	string geodetic_ellipsoid;
	double equatorial_radius_km;
	double flattening;
};


class SeqInfoTableEntry 
{
public:
	int seqIndex;
	float minLat;
	float maxLat;
	float minLon;
	float maxLon;
	int minCalIntensity;
	int maxCalIntensity;
	int maxLineNumber;
	int numFrames;
};


class H5R_SeqInfoTable
{
public:
	//H5R_SeqInfoTable(CompoundDS ds);
	H5R_SeqInfoTable(CompType *ds);
	H5R_SeqInfoTable();
	~H5R_SeqInfoTable(void);

	SeqInfoTableEntry* seqInfoTableEntry;
	int numRows;

	int getNumRows();
	SeqInfoTableEntry* getSeqInfoTableEntry();
};

class H5R_SummaryMetaData
{
public:
	H5R_SummaryMetaData(Group *root);
	H5R_SummaryMetaData();
	~H5R_SummaryMetaData(void);

	void findTables(Group *g);
	H5R_ErrorInfoTable getErrorInfoTable();
	H5R_SeqInfoTable getSeqInfoTable();

	H5R_ErrorInfoTable errorInfoTable;
	H5R_SeqInfoTable seqInfoTable;
};

