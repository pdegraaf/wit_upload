//#pragma once

#ifndef H5R_FILEMETADATA
#define H5R_FILEMETADATA

#include <iostream>
using namespace std;

#include "hdf5.h"
#include "H5Classes.h"
using namespace H5;


class H5R_FileMetaData
{
public:
	H5R_FileMetaData(Group *root);
	~H5R_FileMetaData(void);

	int scid;
	int sca;
	string minTimeStamp;
	int minYear;
	int minDay;
	double minSeconds;
	string maxTimeStamp;
	int maxYear;
	int maxDay;
	double maxSeconds;
	int numberOfFrames;
	double minLatitude;
	double maxLatitude;
	double minLongitude;
	double maxLongitude;

	int minCalIntensity;
	int maxCalIntensity;

};

#endif