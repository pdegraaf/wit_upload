#include "StdAfx.h"
#include "H5R_Exec.h"

using namespace std;


H5R_Exec::H5R_Exec(void)
{
}


H5R_Exec::~H5R_Exec(void)
{
}

/*
int main(int argc, char *argv[])
{

	try{
		Exception::dontPrint();
	 
	cout << "Exec HDF5_R Ingest" << endl;
	string confFile = "";
	
	string inputFile = "C:/dev/test_hdf5/H5R.h5";
	
	string p1 = argv[1];
	if (std::strcmp(p1.c_str(), "-conf") == 0){
		confFile = argv[2];
	} else {
		//qDebug("usage: -conf <config_file>");
		exit(0);
	}
	//QApplication a(argc, argv);

	//H5R_File h = H5R_File(inputFile);
	H5R_FullFile h = H5R_FullFile(inputFile);

	//Wit::WitApp* wit = new Wit::WitApp();    

	//wit->initWit(confFile);

	while (true){}

	} catch (Exception e){
		e.printError();
	}

	return 0;
}
*/