#pragma once

#include "H5R_FullFile.h"
#include "H5R_File.h"

class H5R_Exec
{
public:
	H5R_Exec(void);
	~H5R_Exec(void);
};

 