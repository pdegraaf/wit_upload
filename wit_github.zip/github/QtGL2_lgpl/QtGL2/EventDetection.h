#pragma once

#include <string>
using namespace std;

#include <QWidget>
#include <QMap>
 
#include <QMetaType>

#include <GL/glew.h> 

#include <QtOpenGL/QGLWidget>

class EventDetection
{

public:
	EventDetection(void);
	~EventDetection(void);
	
	int frameId;
	int eventDetectId;

	int highlighted;

	float valRaw;
	float valFilter;
	float valSigma;

	float timeSecOfDay;
	
	int pxX;
	int pxY;

	float lat;
	float lon;

	float ecfX;
	float ecfY;
	float ecfZ;

	GLfloat* renderPoint1;
	GLfloat* renderPoint2;

	float renderY1;
	float renderZ1;
	float renderX2;
	float renderY2;
	float renderZ2;

	float stdd;
	float certainty;

	int eventReviewStatus;
	int eventType;

	int sensorId;
	int scaId;

	int displayStatus;
};

Q_DECLARE_METATYPE(EventDetection);

