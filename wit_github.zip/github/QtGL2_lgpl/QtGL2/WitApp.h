#pragma once

#include "qtgl2.h"
#include <QtGui/QApplication>
#include <QWidget>
#include <QMap>
#include <QtGui>
#include "Globals.h"
#include "reviewpane.h"
#include "threshpane.h"
#include "filterpane.h"
#include "playbackpane.h"
#include "projectionpane.h"
#include "inputpane.h"
#include "outputpane.h"
#include "contrastpane.h"

#include <boost/bind.hpp>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/posix_time_types.hpp>
#include <boost/date_time/local_time/local_time.hpp>  
#include <boost/date_time/gregorian/gregorian.hpp>
using namespace boost::gregorian; 
using namespace boost::local_time;
using namespace boost::posix_time;
#include <boost/filesystem.hpp>

namespace Wit{
	   
class WitApp
{

public:
	__declspec(dllexport) WitApp(void);
	~WitApp(void);

	__declspec(dllexport) QMainWindow* __cdecl initWit(string config);
	__declspec(dllexport) void loadConfig(string config);

	__declspec(dllexport) QMainWindow* getQMainWindow();
	__declspec(dllexport) QApplication* getQApplication();

	void setupUi();

	QApplication* app;

	QtGL2* glw;
	QMainWindow *window;    
	QDockWidget *dockWindowGlobe;  

	QDockWidget *dockWindowInput;
	QDockWidget *dockWindowOutput;

	QDockWidget *dockWindowProjection;
	QDockWidget *dockWindowPlayback;
	QDockWidget *dockWindowFilterTemporal;
	QDockWidget *dockWindowFilterContrast;  
	QDockWidget *dockWindowFilterThreshold; 
	QDockWidget *dockWindowFilterReview; 

	InputPane *windowInput;
	OutputPane *windowOutput;

	PlaybackPane *windowPlayback;
	ProjectionPane *windowProjection;
	FilterPane *windowFilterTemporal;
	ContrastPane *windowFilterContrast;  
	ThreshPane *windowFilterThreshold; 
	ReviewPane *windowFilterReview; 
	
	QLabel *statusLabel;

	int getValidatedIntFromQString(QString str);
	float getValidatedFloatFromQString(QString str);

    int displayW;
	int displayH;
	
};

}