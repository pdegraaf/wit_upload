#pragma once
#include <iostream>
using namespace std;

namespace Wit{

class WitApp
{

public:
	__declspec(dllexport) WitApp(void);
	~WitApp(void);

	__declspec(dllexport) int __cdecl initWit(string config);
	__declspec(dllexport) void loadConfig(string config);
	void setupUi();
	
};

}