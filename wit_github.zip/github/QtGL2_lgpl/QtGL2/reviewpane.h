#ifndef REVIEWPANE_H
#define REVIEWPANE_H

#include <QObject>
#include <QtGui>

#include "EventDetection.h"
#include "detection.h"

class ReviewPane : public QWidget
{
	Q_OBJECT

public:
	ReviewPane();
	~ReviewPane();

	int witItemCount;
	int cols;

	void setupItems();
	
	QTableWidget *reviewTable;

	QPushButton *qbClear;
	QPushButton *qbReject;
	QPushButton *qbAccept;
	QPushButton *qbDelete;
	QPushButton *qbUnknown;
	QPushButton *qbShow;
	
	QPushButton *qbSaveXml;
	QPushButton *qbSaveDb;

	QColor *rowColorUnknown;
	QColor *rowColorAccept;
	QColor *rowColorReject;
	
	QColor *colorUnknown;
	QColor *colorAccept;
	QColor *colorReject;
	
public slots: 
	void updateTable(EventDetection *e);
	void detectTableClear();

	void setRowAccept();
	void setRowReject();
	void setRowUnknown();
	void setRowDelete();
	void setRowShow();

private:
	
};

#endif // REVIEWPANE_H
