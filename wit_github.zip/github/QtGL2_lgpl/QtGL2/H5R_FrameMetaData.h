//#pragma once


#ifndef H5R_FRAMEMETADATA
#define H5R_FRAMEMETADATA

#include <iostream>
using namespace std;


#include "hdf5.h"
#include "H5Classes.h"
using namespace H5;


class MetaData
{
public:
		int* frameNumber;
		int* beginChannel;
		int* endChannel;
		int* numChannels;
		int* beginLine;
		int* endLine;
		int* numLines;
		int* scanDir;
		int* numGeoPoints;
		int* year;
		int* day;
		double* secondsOfDay;
		int* calNoCalFlag;
		int* ImageId;
		double** satPosECF;
		double** satVelECF;
		double* lineDeltaTimeSecs;
		double* AbsoluteCalCoeff_kws;
		double* AbsoluteCalCoeff_wcmsq;
		double* sosCTCsecs;
		int* sosSeqIndex;
		int* sosStepIndex;
		int* sosDirection;
		string* sosScaSelectStr;
		string* sosParentAimPtStr;
		double* sosScanRateMradUsecs;
		double* sosFrameTimeUsecs;
		double* sosBlankTimeUsecs;
		double* sosLongIntUsecs;
		double* sosShortIntUsecs;
		string* sosIntegMode;

		// new items 11/2010
		float* UL_lat;
		float* UR_lat;
		float* LL_lat;
		float* LR_lat;
		float* UL_lon;
		float* UR_lon;
		float* LL_lon;
		float* LR_lon;

		int* minCalIntensity;
		int* maxCalIntensity;

		int* linesReversed;
		int* chansReversed;
};


class H5R_FrameMetaData
{
public:
	H5R_FrameMetaData(CompType *compound_ds);
	//H5R_FrameMetaData(CompoundDS compound_ds);
	~H5R_FrameMetaData(void);

	string* memberNames;
	long numFrames;
	CompType *compoundDS;
	//CompoundDS compoundDS;
	MetaData metaData;

	string* getMemberNames();
	MetaData getMetaData();

};

#endif