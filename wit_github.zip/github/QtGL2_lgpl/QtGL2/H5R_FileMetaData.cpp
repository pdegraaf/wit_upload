#include "H5R_FileMetaData.h"
//#include "H5R_Combined.h"

H5R_FileMetaData::H5R_FileMetaData(Group *root)
{
}

H5R_FileMetaData::~H5R_FileMetaData(void)
{
}
