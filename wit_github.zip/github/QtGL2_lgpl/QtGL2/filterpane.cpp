/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

#include "filterpane.h"

FilterPane::FilterPane()
	: QWidget()
{

}

FilterPane::~FilterPane()
{

}

void FilterPane::updateKernelTap(int n, float t){
	QString tStr = QString::number(t, 'f', 3);
	kTap[n].setText(tStr);
}

void FilterPane::updateKernelTapStr(int n, QString s){
	kTap[n].setText(s);
}

void FilterPane::relayTapEdits(){
	applyTapEdits(kTap, numKTaps);
}

void FilterPane::setupItems(){

	hboxTemporal1 = new QHBoxLayout();
	hboxTemporal2 = new QHBoxLayout();
	hboxTemporal3 = new QHBoxLayout();
	vboxTemporal1 = new QVBoxLayout();
	
	vboxTemporal1->addLayout(hboxTemporal1);
	vboxTemporal1->addLayout(hboxTemporal2);
	vboxTemporal1->addLayout(hboxTemporal3);
	vboxTemporal1->addStretch(1);
	
	cbTemporal = new QCheckBox();
	cbTemporal->setText("ENABLED");

	qbApplyTapEdits = new QPushButton();
	qbApplyTapEdits->setText("APPLY EDITS");

	qbUndoTapEdits = new QPushButton();
	qbUndoTapEdits->setText("UNDO EDITS");
	
	hboxTemporal3->addWidget(qbApplyTapEdits);
	hboxTemporal3->addWidget(qbUndoTapEdits);
	hboxTemporal3->addStretch(1);

	labelTemporalPreset = new QLabel; 
	labelTemporalPreset->setTextFormat(Qt::RichText); 
	labelTemporalPreset->setText("PRESET");

	filterList = new QComboBox();
	filterList->addItem("SUBTRACT AVERAGE");
	filterList->addItem("SUBTRACT PREVIOUS");
	filterList->addItem("WAVELET");
	filterList->addItem("BRIGHTEST");
	filterList->setToolTip("Select filter used to visually suppress clutter or generate detections.");

	numKTaps =9;
	kTap = new QLineEdit[numKTaps]();
	
	for (int k=0; k<numKTaps;k++){
		hboxTemporal2->addWidget(&kTap[k]);
	}

	hboxTemporal1->addWidget(cbTemporal);
	hboxTemporal1->addStretch(1);
	hboxTemporal1->addWidget(labelTemporalPreset);
	hboxTemporal1->addWidget(filterList);

	this->setLayout(vboxTemporal1);
}

void FilterPane::toggleFilterButton(){
	cbTemporal->toggle();
}