#include <string>
#include <iostream>
using namespace std;

#define cimg_use_png
#include "CImg.h"
using namespace cimg_library;

#include "Globals.h"

#include <GL/glew.h> 
#include <gl/GL.h> 
#include <gl/GLU.h> 

#pragma comment(lib, "opengl32.lib") 
#pragma comment(lib, "glu32.lib") 
#pragma comment(lib, "glew32.lib") 

#include <boost/bind.hpp>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/posix_time_types.hpp>
#include "boost/date_time/local_time/local_time.hpp"  
#include "boost/date_time/gregorian/gregorian.hpp"
using namespace boost::gregorian; 
using namespace boost::local_time;
using namespace boost::posix_time;
#include <boost/filesystem.hpp>

#include "hdf5.h"
#include "H5Classes.h"
using namespace H5;

#define pi 3.14159265359

#include "cuda_runtime.h"
#include "device_launch_parameters.h"

cudaError_t addWithCuda(int *c, int *a, float *k, int *dev_c, int *dev_a, float *dev_k, size_t size, size_t num_kc, int timeIndex);
cudaError_t addWithCudaN(int *c, int *a, float *k, int *dev_c, int *dev_a, float *dev_k, size_t px, size_t py, size_t num_kc, int timeIndex, int tpb, int kcContrast);
cudaError_t addWithCudaO(float *c, float *a, float *k, float *dev_c, float *dev_a, float *dev_k, size_t px, size_t py, size_t num_kc, int timeIndex, int tpb, int kcContrast);

int* allocCuda(int *n, size_t size);
float* allocCudaF(float *n, size_t size);
int** allocCudaM(int **n, size_t size);
cudaError_t initDevicesCuda();