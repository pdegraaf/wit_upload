#ifndef DETECTION_H
#define DETECTION_H

#include <QObject>

class Detection : public QObject
{
	Q_OBJECT

public:
	Detection(QObject *parent);
	Detection();
	~Detection();

	
	int pxX;
	int pxY;

	int frameId;
	int eventDetectId;

	
	float intensity;

	float timeSecOfDay;


	float lat;
	float lon;

	float ecfX;
	float ecfY;
	float ecfZ;

	float stdd;
	float certainty;

	int eventReviewStatus;
	int eventType;

private:
	
};

#endif // DETECTION_H
