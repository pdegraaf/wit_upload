#include "H5R_GeoLocationData.h"
//#include "H5R_Combined.h"

H5R_GeoLocationData::H5R_GeoLocationData(CompType *compound_ds, H5R_File *h5)
{
}

H5R_GeoLocationData::H5R_GeoLocationData()
{
}

H5R_GeoLocationData::~H5R_GeoLocationData(void)
{
}


void H5R_GeoLocationData::getGeoLocationAttributes(){
}

H5R_Coords** H5R_GeoLocationData::getGeolocationData(int frameNum){
	H5R_Coords** c;

	return c;
}

float*** H5R_GeoLocationData::getGeolocationLonLat(int frameNum, int scanDir, int sca){
	float*** f;

	return f;
}

H5R_Coords** H5R_GeoLocationData::getInterpolatedGeolocationData(int frameNum){
	H5R_Coords** c;

	return c;
}

float*** H5R_GeoLocationData::getInterpolatedLonLatData(int frameNum){
	float*** f;

	return f;
}

string* H5R_GeoLocationData::getMemberNames(){
	return memberNames;
}
int H5R_GeoLocationData::getX_Stepsize_Pixels(){
	return X_Stepsize_Pixels;
}
int H5R_GeoLocationData::getY_Stepsize_Pixels(){
	return Y_Stepsize_Pixels;
}
string H5R_GeoLocationData::getXY_coord_system(){
	return XY_coord_system;
}
string H5R_GeoLocationData::getGeodetic_ellipsoid(){
	return geodetic_ellipsoid;
}
double H5R_GeoLocationData::getEquatorial_radius_km(){
	return equatorial_radius_km;
}
double H5R_GeoLocationData::getFlattening(){
	return flattening;
}