/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

#include "threshpane.h"

ThreshPane::ThreshPane()
	: QWidget()
{

}

ThreshPane::~ThreshPane()
{

}


void ThreshPane::setupItems(){
	hboxThresh1 = new QHBoxLayout();
	hboxThresh2 = new QHBoxLayout();
	hboxThresh3 = new QHBoxLayout();
	hboxThresh4 = new QHBoxLayout();
	hboxThresh5 = new QHBoxLayout();
	hboxThresh6 = new QHBoxLayout();
	hboxThresh7 = new QHBoxLayout();
	vboxThresh1 = new QVBoxLayout();

	cbDetectConst = new QCheckBox();
	cbDetectConst->setText("ENABLED");

	cbDetectSigma = new QCheckBox();
	cbDetectSigma->setText("STATISTICS");

	labelThreshConstPreset = new QLabel; 
	labelThreshConstPreset->setTextFormat(Qt::RichText); 
	labelThreshConstPreset->setText("PRESET");

	threshConstList = new QComboBox();
	threshConstList->addItem("HIGH");
	threshConstList->addItem("MEDIUM");
	threshConstList->addItem("LOW");

	textThreshLevelConst = new QLineEdit();
	textThreshLevelConst->setText(".95");
	textThreshLevelConst->setFixedWidth(40);

	hboxThresh1->addWidget(cbDetectConst);
	hboxThresh1->addStretch(1);
	hboxThresh1->addWidget(labelThreshConstPreset);
	hboxThresh1->addWidget(threshConstList);
	hboxThresh1->addWidget(textThreshLevelConst);

	labelThreshSigmaPreset = new QLabel; 
	labelThreshSigmaPreset->setTextFormat(Qt::RichText); 
	labelThreshSigmaPreset->setText("PRESET");

	textThreshLevelSigma = new QLineEdit();
	textThreshLevelSigma->setText("3.0");
	textThreshLevelSigma->setFixedWidth(40);

	threshSigmaList = new QComboBox();
	threshSigmaList->addItem("LOW");
	threshSigmaList->addItem("MEDIUM");
	threshSigmaList->addItem("HIGH");

	hboxThresh2->addWidget(cbDetectSigma);
	hboxThresh2->addStretch(1);

	cbAlert = new QCheckBox();
	cbAlert->setText("AUDIO ALERTS");
	cbAlert->setEnabled(false);

	hboxThresh3->addWidget(cbAlert);
	hboxThresh3->addStretch(1);

	cbRegionWatch = new QCheckBox();
	cbRegionWatch->setText("WATCH AREA");

	labelRegionWatchFile = new QLabel; 
	labelRegionWatchFile->setTextFormat(Qt::RichText); 
	labelRegionWatchFile->setText("REGION(S)");

	textRegionWatchFile = new QLineEdit();
	textRegionWatchFile->setText("/export/WIT_DEPLOY/watch.kml");
	textRegionWatchFile->setFixedWidth(200);

	cbRegionReject = new QCheckBox();
	cbRegionReject->setText("REJECT AREA");

	labelRegionRejectFile = new QLabel; 
	labelRegionRejectFile->setTextFormat(Qt::RichText); 
	labelRegionRejectFile->setText("REGION(S)");

	textRegionRejectFile = new QLineEdit();
	textRegionRejectFile->setText("/export/WIT_DEPLOY/known.kml");
	textRegionRejectFile->setFixedWidth(200);

	hboxThresh4->addWidget(cbRegionWatch);
	hboxThresh4->addStretch(1);
	hboxThresh4->addWidget(labelRegionWatchFile);
	hboxThresh4->addWidget(textRegionWatchFile);
	hboxThresh4->addStretch(1);

	hboxThresh5->addWidget(cbRegionReject);
	hboxThresh5->addStretch(1);
	hboxThresh5->addWidget(labelRegionRejectFile);
	hboxThresh5->addWidget(textRegionRejectFile);
	hboxThresh5->addStretch(1);


	cbRegionWatchRadius = new QCheckBox();
	cbRegionWatchRadius->setText("EXPAND RADIUS");

	textRegionWatchRadius = new QLineEdit();
	textRegionWatchRadius->setText("");
	textRegionWatchRadius->setFixedWidth(40);

	hboxThresh6->addWidget(cbRegionWatchRadius);
	hboxThresh6->addWidget(textRegionWatchRadius);
	hboxThresh6->addStretch(1);

	cbRegionRejectRadius = new QCheckBox();
	cbRegionRejectRadius->setText("EXPAND RADIUS");

	textRegionRejectRadius = new QLineEdit();
	textRegionRejectRadius->setText("");
	textRegionRejectRadius->setFixedWidth(40);

	hboxThresh7->addWidget(cbRegionRejectRadius);
	hboxThresh7->addWidget(textRegionRejectRadius);
	hboxThresh7->addStretch(1);

	vboxThresh1->addLayout(hboxThresh1);
	vboxThresh1->addLayout(hboxThresh3);
	vboxThresh1->addLayout(hboxThresh4);
	vboxThresh1->addLayout(hboxThresh6);
	vboxThresh1->addLayout(hboxThresh5);
	vboxThresh1->addLayout(hboxThresh7);
	vboxThresh1->addStretch(1);

	this->setLayout(vboxThresh1);
}

void ThreshPane::updateThreshConst(float t){
	QString tStr = QString::number(t, 'f', 3);
	textThreshLevelConst->setText(tStr);
}

void ThreshPane::updateRegionWatchRadius(float t){
	QString tStr = QString::number(t, 'f', 3);
	textRegionWatchRadius->setText(tStr);
}

void ThreshPane::updateRegionRejectRadius(float t){
	QString tStr = QString::number(t, 'f', 3);
	textRegionRejectRadius->setText(tStr);
}

void ThreshPane::toggleThresholdButton(){
	cbDetectConst->toggle();
}