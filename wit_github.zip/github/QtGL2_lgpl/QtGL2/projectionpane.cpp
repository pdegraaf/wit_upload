/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

#include "projectionpane.h"

ProjectionPane::ProjectionPane()
	: QWidget()
{

}

ProjectionPane::~ProjectionPane()
{

}

void ProjectionPane::setupItems(){

	hboxProj1 = new QHBoxLayout();
	vboxProj1 = new QVBoxLayout();
	
	projList = new QComboBox();
	projList->addItem("3D GLOBE");
	//projList->addItem("SENSOR SPACE");

	cbAutoZoom = new QCheckBox();
	cbAutoZoom->setText("AUTO-ORIENT");
	cbAutoZoom->setToolTip("Lock globe rotation to the re-projected data.");
	
	cbAutoZoomSnap = new QCheckBox();
	cbAutoZoomSnap->setText("INSTANT");
	cbAutoZoomSnap->setToolTip("Do not animate transition to orientation.");

	hboxProj1->addWidget(cbAutoZoom);
	hboxProj1->addWidget(cbAutoZoomSnap);
	hboxProj1->addStretch(1);
	hboxProj1->addWidget(projList);

	vboxProj1->addLayout(hboxProj1);
	vboxProj1->addStretch(1);

	this->setLayout(vboxProj1);
}

void ProjectionPane::toggleAutoOrientButton(){
	cbAutoZoom->toggle();
}