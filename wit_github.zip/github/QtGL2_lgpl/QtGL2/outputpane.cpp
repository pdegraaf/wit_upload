/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

#include "outputpane.h"
#include "Globals.h"

OutputPane::OutputPane()
	: QWidget()
{

}

OutputPane::~OutputPane()
{

}

void OutputPane::toggleExportButtonText(int state){
	if (state == OFF){
		cbVideoExport->setText("BEGIN EXPORT");
	} else {
		cbVideoExport->setText("STOP EXPORT");
	}
}

void OutputPane::setupItems(){
	
	cbVideoExport = new QPushButton();
	cbVideoExport->setText("BEGIN EXPORT");

	cbVideoStream = new QCheckBox();
	cbVideoStream->setText("STREAMING VIZ");
	cbVideoStream->setEnabled(false);
	
	labelVideoStream = new QLabel; 
	labelVideoStream->setTextFormat(Qt::RichText); 
	labelVideoStream->setText("LOCATION");
	labelVideoStream->setEnabled(false);

	textVideoStream = new QLineEdit();
	textVideoStream->setText("192.42.42.12:4242");
	textVideoStream->setFixedWidth(200);
	textVideoStream->setEnabled(false);
	
	textVideoExport = new QLineEdit();
	textVideoExport->setText("");
	textVideoExport->setFixedWidth(200);

	labelVideoExport = new QLabel; 
	labelVideoExport->setTextFormat(Qt::RichText); 
	labelVideoExport->setText("FILE");

	hboxOutput1 = new QHBoxLayout();
	hboxOutput2 = new QHBoxLayout();
	vboxOutput1 = new QVBoxLayout();

	hboxOutput1->addWidget(cbVideoStream);
	hboxOutput1->addStretch(1);
	hboxOutput1->addWidget(labelVideoStream);
	hboxOutput1->addWidget(textVideoStream);
	vboxOutput1->addLayout(hboxOutput1);

	hboxOutput2->addWidget(cbVideoExport);
	hboxOutput2->addStretch(1);
	hboxOutput2->addWidget(labelVideoExport);
	hboxOutput2->addWidget(textVideoExport);
	vboxOutput1->addLayout(hboxOutput2);
	vboxOutput1->addStretch(1);

	this->setLayout(vboxOutput1);
}

void OutputPane::toggleVideoExportButton(){
	cbVideoExport->toggle();
}