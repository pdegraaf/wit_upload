#include "H5R_SummaryMetaData.h"
//#include "H5R_Combined.h"

H5R_SummaryMetaData::H5R_SummaryMetaData(Group *root)
{

}

H5R_SummaryMetaData::H5R_SummaryMetaData()
{

}


H5R_SummaryMetaData::~H5R_SummaryMetaData(void)
{
}



void H5R_SummaryMetaData::findTables(Group *g){
	
	/*if (g == NULL) return;
	
		java.util.List members = g.getMemberList();
		int n = members.size();
		HObject obj = null;

		for (int i = 0; i < n; i++) {
			obj = (HObject) members.get(i);
			if (obj instanceof Group) {
				findTables((Group) obj);
			} else if (obj instanceof CompoundDS) {
				if (obj.getName().equalsIgnoreCase("ErrorInfoTable")) {
					errorInfoTable = new H5R_ErrorInfoTable((CompoundDS) obj);
				} else if (obj.getName().equalsIgnoreCase("SeqInfoTable")) {
					seqInfoTable = new H5R_SeqInfoTable((CompoundDS) obj);
				}
			}
		}

		return;
	}*/



}

H5R_ErrorInfoTable H5R_SummaryMetaData::getErrorInfoTable(){
	return errorInfoTable;
}

H5R_SeqInfoTable H5R_SummaryMetaData::getSeqInfoTable(){
	return seqInfoTable;
}