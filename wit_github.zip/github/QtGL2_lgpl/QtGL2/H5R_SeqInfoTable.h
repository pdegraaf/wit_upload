//#pragma once

#ifndef H5R_SEQINFOTABLE
#define H5R_SEQINFOTABLE

#include "hdf5.h"
#include "H5Classes.h"
using namespace H5;

class SeqInfoTableEntry 
{
public:
	int seqIndex;
	float minLat;
	float maxLat;
	float minLon;
	float maxLon;
	int minCalIntensity;
	int maxCalIntensity;
	int maxLineNumber;
	int numFrames;
};


class H5R_SeqInfoTable
{
public:
	//H5R_SeqInfoTable(CompoundDS ds);
	H5R_SeqInfoTable(CompType *ds);
	H5R_SeqInfoTable();
	~H5R_SeqInfoTable(void);

	SeqInfoTableEntry* seqInfoTableEntry;
	int numRows;

	int getNumRows();
	SeqInfoTableEntry* getSeqInfoTableEntry();
};

#endif