/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

#include "StdAfx.h"
#include "WitFrame.h"

#include <algorithm>


WitFrame::WitFrame(void)
{
	frameStatus = new int[MODES];
	frameStatus[MODE_LOAD] = STATUS_READY;
}

WitFrame::~WitFrame(void)
{
}

void WitFrame::setModData(){
	for (int y=0; y<h; y++){
		for (int x=0; x<w; x++){
			int val = dataRes[x +(y*w)];

			if (val<PX_INT_MIN) val=PX_INT_MIN;
			if (val>PX_INT_MAX) val=PX_INT_MAX;

			// QImage version
			frameData->setPixel(x,y,val);

			/*	/// CImg version
			frameData(x,y,0,DIM_R) = val;
			frameData(x,y,0,DIM_G) = val;
			frameData(x,y,0,DIM_B) = val;
			*/
		}
	}
}

float WitFrame::getLatLonX(float radius, float lat, float lon){
	
	float latRad = (float)(lat* pi  / 180.0f);
	float lonRad = (float)(lon* pi  / 180.0f);
	float x= (float)(-radius* cos(latRad) * cos(lonRad));
	return x;
}

float WitFrame::getLatLonY(float radius, float lat, float lon){
	
	float latRad = (float)(lat* pi  / 180.0f);
	float y= (float)(radius* sin(latRad));

	return y;
}

float WitFrame::getLatLonZ(float radius, float lat, float lon){
	
	float latRad = (float)(lat* pi  / 180.0f);
	float lonRad = (float)(lon* pi  / 180.0f);
	float z= (float)(radius* cos(latRad) * sin(lonRad));
	
	return z;
}


int WitFrame::load(const char *fileName, int x, int y, float secs){

	qDebug("      LOADED FROM PNG %s", fileName);

	QString fStr = QString(fileName); // QImage version
	frameData = new QImage(fStr);
	
	int status = STATUS_ERROR;

	// convert to internal representation
	w = x;
	h = y;
	
	for (int i=0; i<PX_VAL_MAX; i++){
		histValRaw[i]=0;
	}
	valMax = -1;
	valMin = PX_VAL_MAX+1;
	
	int errorFlag = OFF;

		for (int x=0; x<w; x++){
		
		for (int y=0; y<h; y++){
			if (x<frameData->width() && y<frameData->height()){
		
			QRgb tempColorRgb =  frameData->pixel(x,y);
			QColor tempColor(tempColorRgb);

			dataSrc[x][y] = tempColor.valueF();
			
			int intVal = tempColor.value();

			if (intVal<valMin){
				valMin = intVal;
			}
			if (intVal>valMax){
				valMax = intVal;
			}

			histValRaw[intVal]++;

			} else {
				errorFlag = ON;	// size mismatch
			}
		}
	}

		pxCount =  min(frameData->width(),w)*min(frameData->height(),h);

		int pxQ1 = pxCount/4;
		int pxQ2 = pxQ1*2;
		int pxQ3 = pxQ1*3;

		valQ1 = STATUS_ERROR;
		valQ2 = STATUS_ERROR;
		valQ3 = STATUS_ERROR;

		//determine quartiles
		int accum = 0;
		for (int j=0; j<PX_VAL_MAX; j++){
			accum += histValRaw[j];
			if (accum >= pxQ3 && valQ3 == STATUS_ERROR){
				valQ3 = j;
			}
			if (accum >= pxQ2 && valQ2 == STATUS_ERROR){
				valQ2 = j;
			}
			if (accum >= pxQ1 && valQ1 == STATUS_ERROR){
				valQ1 = j;
			}  
		}

	gridX = TILE_SIZE_X;
	gridY = TILE_SIZE_Y;

	gridNumX = w/gridX;
	gridNumY = h/gridY;


	if (secs != STATUS_ERROR){
		secsOfDay = secs;
	}

	float globeRadius = 1.0f;

	float driftLat = 0;
	float driftLon = 0;

	for (int x=0; x<gridNumX; x++){

		for (int y=0; y<gridNumY; y++){
			coordsLat[x][y] = 40 -y*0.02f*(float)TILE_SIZE_Y + driftLat;
			coordsLon[x][y] = -65 + x*0.02f*(float)TILE_SIZE_X + driftLon;
			coordsX[x][y] = getLatLonX(globeRadius, coordsLat[x][y], coordsLon[x][y]);
			coordsY[x][y] = getLatLonY(globeRadius, coordsLat[x][y], coordsLon[x][y]);
			coordsZ[x][y] = getLatLonZ(globeRadius, coordsLat[x][y], coordsLon[x][y]);
		}
	}

	frameStatus[MODE_CUDA_FILTER_T] = STATUS_READY;
	frameStatus[MODE_RASTER] = STATUS_READY;
	status = STATUS_COMPLETE_IO;

	delete frameData;
	frameData = NULL;

	qDebug("      LOADED IMAGE %s - Q1:%i Q2:%i Q3:%i - ERRORS %i",fileName, valQ1, valQ2, valQ3, errorFlag);
	return status;
}

void WitFrame::setModeStatus(int mode, int status){
	frameStatus[mode] = status;
}

int WitFrame::getFrameId(){
	return frameId;
}
