/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

#include "WitThread.h"


WitThread::WitThread(void)
	//:QObject()

{
}


WitThread::~WitThread(void)
{
}

void WitThread::run(void)
{
	load();
}

void WitThread::runSlot(void)
{

}

void WitThread::prepThread(void){

	qDebug("      BIND THREAD %i",threadId);

	if (mode == MODE_LOAD){
		
		if (wfile->dataFileType == FILE_INPUT_PNG){
			bt = new boost::thread(boost::bind( &WitThread::load, this)); 
		} else if (wfile->dataFileType == FILE_INPUT_H5){

		}
	}
	if (mode == MODE_FFMPEG_EXPORT){
		qDebug("      START FFMPEG EXPORT %i",threadId);
		bt = new boost::thread(boost::bind( &WitThread::invokeFFmpegExport, this)); 
	}
		
}


void WitThread::load(void)
{
	qDebug("      THREAD ID: %i - THREAD TASK: LOAD PNG %i",threadId);
	wframe->frameStatus[MODE_LOAD] = wframe->load(wframe->fileName.c_str(), wframe->w, wframe->h, wframe->secsOfDay);
	qDebug("      FINISH LOAD PNG %i",threadId);
	threadStatus = STATUS_COMPLETE_THREAD;
}

void WitThread::invokeFFmpegExport(void)
{
	string ffmpegCmdStr = "ffmpeg ";
	
	string vcodecStr;
	string paramStr = " -sameq -y "; // same quality, and force overwrite

	float encodingFps = 12.0f;//30.0f;
	string fpsStr = " -r "+ boost::lexical_cast<std::string>(encodingFps)+" ";
	
	string inputStr = " -i "+params[0];//vid_scratch_dir;
	inputStr+= "\%d.png";

	//!! hardcode for now...add logic to check user's outfile
	//vid_export_format = VID_FORMAT_WMV;
	int vid_export_format = VID_FORMAT_WMV;

	string destStr = params[1];//vid_path_export;
	int extSubIndex = destStr.find_last_of(".");
	string userExtStr =  "";
	if (extSubIndex != -1){
		userExtStr = destStr.substr(extSubIndex);
	}
	
	if (vid_export_format == VID_FORMAT_WMV){
		vcodecStr = " -vcodec wmv2 ";
		if (userExtStr.length() == 0){
			userExtStr = ".wmv";
			destStr += userExtStr;
		}
	}

	if (vid_export_format == VID_FORMAT_MPG){
		vcodecStr = " ";
		if (userExtStr.length() == 0){
			userExtStr = ".mpg";
			destStr += userExtStr;
		}
	}

	//string fpsOutStr = " -r 24 ";
	string fpsOutStr = " -r 12 ";
	
	ffmpegCmdStr += fpsStr;
	ffmpegCmdStr += inputStr;
	ffmpegCmdStr += fpsOutStr;
	ffmpegCmdStr += vcodecStr;
	ffmpegCmdStr += paramStr;
	ffmpegCmdStr += destStr;

	qDebug("INVOKING FFMPEG... %s",ffmpegCmdStr.c_str());
	QString qCmdStr(ffmpegCmdStr.c_str());
	
	QProcess *encodeProcess = new QProcess(parent);
	//	QProcess *encodeProcess = new QProcess(this);
	encodeProcess->start(qCmdStr);

	encodeProcess->waitForFinished();
	//encodeProcess->setReadChannel(QProcess.ProcessChannel.StandardOutput);
	
	//QString strOut = encodeProcess->readAllStandardOutput();
	QString strErr = encodeProcess->readAllStandardError();
	QString strOut = encodeProcess->readAllStandardOutput();

	if (strErr.length()>0){
		qDebug() << strErr;
	}

	if (strOut.length()>0){
		qDebug() << strOut;
	}

	qDebug("      FINISH FFMPEG EXPORT %i",threadId);
	threadStatus = STATUS_COMPLETE_THREAD;
}
