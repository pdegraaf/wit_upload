#include "StdAfx.h"
#include "H5R_FullFile.h"


H5R_FullFile::H5R_FullFile(string fileName)
{

	cout << "open file " << fileName.c_str() << endl;
	//hid_t h = H5Fopen (fileName.c_str(), H5F_ACC_RDONLY, H5P_DEFAULT);
	herr_t status;

	H5std_string rName = "CalRawData";
	H5std_string gName = "GeoLocationData"; 
	H5std_string mName = "frameMetaData";
	H5std_string fName = fileName;

	string gStdName = "GeoLocationData";
	string mStdName = "frameMetaData";
		
	H5File file(fName, H5F_ACC_RDONLY);
	DataSet dsr = file.openDataSet(rName);
	DataSet dsg = file.openDataSet(gName);
	DataSet dsm = file.openDataSet(mName);

	DataSpace dataspaceRaster = dsr.getSpace();
	DataSpace dataspaceGeo = dsg.getSpace();

	const int rankRaster = dataspaceRaster.getSimpleExtentNdims();
	const int rankGeo = dataspaceGeo.getSimpleExtentNdims();
	
	hsize_t hdr[3];
	dataspaceRaster.getSimpleExtentDims(hdr, NULL);
	
	const int xr = hdr[2];
	const int yr = hdr[1];
	const int zr = hdr[0];

	hsize_t hdg[3];
	dataspaceGeo.getSimpleExtentDims(hdg, NULL);
	
	const int xg = hdg[2];
	const int yg = hdg[1];
	const int zg = hdg[0];
	
	/*
	for (int i=0; i<rankRaster; i++){
		cout << " dim R " << hdr[i] << endl;
	}
	cout << endl;

	for (int i=0; i<rankGeo; i++){
		cout << " dim G " << hdg[i] << endl;
	}	
	cout << endl;*/

	hsize_t dimsRaster[1] = {1};
	rdata = (int *) malloc (dimsRaster[0] * sizeof(int) *xr*yr*zr);
	
	hid_t f = H5Fopen(fileName.c_str(), H5F_ACC_RDONLY, H5P_DEFAULT);
	
	// read raster data
	dsr.read(rdata, PredType::NATIVE_INT, dataspaceRaster, dataspaceRaster);
	
	/*
	for (int j=0; j<5; j++){
		for (int i=0; i<20; i++){
			cout << rdata[0 + j + (i*xr)] << " ";
		}
		cout << endl;
	}cout << endl;*/


	hid_t gType;

	gType = H5Tcreate(H5T_COMPOUND, sizeof(geoloc_t));
	status  = H5Tinsert(gType, "x", HOFFSET(geoloc_t, x), H5T_NATIVE_FLOAT);
	status  = H5Tinsert(gType, "y", HOFFSET(geoloc_t, y), H5T_NATIVE_FLOAT);
	status  = H5Tinsert(gType, "z", HOFFSET(geoloc_t, z), H5T_NATIVE_FLOAT);
	status  = H5Tinsert(gType, "lat", HOFFSET(geoloc_t, lat), H5T_NATIVE_FLOAT);
	status  = H5Tinsert(gType, "lon", HOFFSET(geoloc_t, lon), H5T_NATIVE_FLOAT);

	hid_t dsetGeo = H5Dopen(f, gStdName.c_str(), H5P_DEFAULT);

	hsize_t dimsGeo[1] = {5};
	hid_t space = H5Dget_space(dsetGeo);
	hid_t ndims = H5Sget_simple_extent_dims(space, dimsGeo, NULL);

	gdata = (geoloc_t *) malloc (dimsGeo[0] * sizeof(geoloc_t) *xg*yg*zg);

	// read geo data
	status = H5Dread(dsetGeo, gType, H5S_ALL, H5S_ALL, H5P_DEFAULT, gdata);
	
	/*
	for (int j=0; j<3; j++){
		for (int i=0; i<3; i++){
			cout << gdata[i+j*64].lat << "," << gdata[i+j*64].lon << " ";
		}
		cout << endl;
	}
	*/

	// read other metadata
		
	/*
	beginLine = (int *) malloc (sizeof(int) * zr);
	endLine = (int *) malloc (sizeof(int) * zr);
	numLines = (int *) malloc (sizeof(int) * zr);

	secondsOfDay  = (double *) malloc (sizeof(double) * zr);

	sosSeqIndex = (int *) malloc (sizeof(int) * zr);
	sosStepIndex = (int *) malloc (sizeof(int) * zr);
	*/

	hid_t mType;

	mType = H5Tcreate(H5T_COMPOUND, sizeof(meta_t));
	status  = H5Tinsert(mType, "beginLine", HOFFSET(meta_t, beginLine), H5T_NATIVE_INT);
	status  = H5Tinsert(mType, "endLine", HOFFSET(meta_t, endLine), H5T_NATIVE_INT);
	status  = H5Tinsert(mType, "numLines", HOFFSET(meta_t, numLines), H5T_NATIVE_INT);

	status  = H5Tinsert(mType, "sosStepIndex", HOFFSET(meta_t, sosStepIndex), H5T_NATIVE_INT);
	status  = H5Tinsert(mType, "sosSeqIndex", HOFFSET(meta_t, sosSeqIndex), H5T_NATIVE_INT);

	status  = H5Tinsert(mType, "scanDir", HOFFSET(meta_t, scanDir), H5T_NATIVE_INT);

	status  = H5Tinsert(mType, "secondsOfDay", HOFFSET(meta_t, secondsOfDay), H5T_NATIVE_DOUBLE);

	hid_t dsetMeta = H5Dopen(f, mStdName.c_str(), H5P_DEFAULT);

	mdata = (meta_t *) malloc (sizeof(meta_t)*zr);

	status = H5Dread(dsetMeta, mType, H5S_ALL, H5S_ALL, H5P_DEFAULT, mdata);

	for (int i=0; i<zr; i++){
		cout << mdata[i].beginLine << " " << mdata[i].endLine << " " << mdata[i].numLines << " " << mdata[i].scanDir << " " << endl;
	}
}



void H5R_FullFile::H5R_FullFile_LoadFrame(string fileName, int frameNo)
{
	cout << "open file " << fileName.c_str() << endl;
	//hid_t h = H5Fopen (fileName.c_str(), H5F_ACC_RDONLY, H5P_DEFAULT);
	herr_t status;

	H5std_string rName = "CalRawData";
	H5std_string gName = "GeoLocationData"; 
	H5std_string mName = "frameMetaData";
	H5std_string fName = fileName;

	string gStdName = "GeoLocationData";
	string mStdName = "frameMetaData";
		
	H5File file(fName, H5F_ACC_RDONLY);
	DataSet dsr = file.openDataSet(rName);
	DataSet dsg = file.openDataSet(gName);
	DataSet dsm = file.openDataSet(mName);

	DataSpace dataspaceRaster = dsr.getSpace();
	DataSpace dataspaceGeo = dsg.getSpace();

	const int rankRaster = dataspaceRaster.getSimpleExtentNdims();
	const int rankGeo = dataspaceGeo.getSimpleExtentNdims();
	
	hsize_t hdr[3];
	dataspaceRaster.getSimpleExtentDims(hdr, NULL);
	
	const int xr = hdr[2];
	const int yr = hdr[1];
	const int zr = hdr[0];

	hsize_t hdg[3];
	dataspaceGeo.getSimpleExtentDims(hdg, NULL);
	
	const int xg = hdg[2];
	const int yg = hdg[1];
	const int zg = hdg[0];

	hsize_t dimsRaster[1] = {1};
	rdata = (int *) malloc (dimsRaster[0] * sizeof(int) *xr*yr*zr); // !! need to handle single frames
		
	hid_t f = H5Fopen(fileName.c_str(), H5F_ACC_RDONLY, H5P_DEFAULT);
	
	// read raster data
	dsr.read(rdata, PredType::NATIVE_INT, dataspaceRaster, dataspaceRaster);
	

	/*
	for (int j=0; j<5; j++){
		for (int i=0; i<20; i++){
			cout << rdata[0 + j + (i*xr)] << " ";
		}
		cout << endl;
	}cout << endl;*/


	hid_t gType;

	gType = H5Tcreate(H5T_COMPOUND, sizeof(geoloc_t));
	status  = H5Tinsert(gType, "x", HOFFSET(geoloc_t, x), H5T_NATIVE_FLOAT);
	status  = H5Tinsert(gType, "y", HOFFSET(geoloc_t, y), H5T_NATIVE_FLOAT);
	status  = H5Tinsert(gType, "z", HOFFSET(geoloc_t, z), H5T_NATIVE_FLOAT);
	status  = H5Tinsert(gType, "lat", HOFFSET(geoloc_t, lat), H5T_NATIVE_FLOAT);
	status  = H5Tinsert(gType, "lon", HOFFSET(geoloc_t, lon), H5T_NATIVE_FLOAT);

	hid_t dsetGeo = H5Dopen(f, gStdName.c_str(), H5P_DEFAULT);

	hsize_t dimsGeo[1] = {5};
	hid_t space = H5Dget_space(dsetGeo);
	hid_t ndims = H5Sget_simple_extent_dims(space, dimsGeo, NULL);

	gdata = (geoloc_t *) malloc (dimsGeo[0] * sizeof(geoloc_t) *xg*yg*zg);

	// read geo data
	status = H5Dread(dsetGeo, gType, H5S_ALL, H5S_ALL, H5P_DEFAULT, gdata);
	
	/*
	for (int j=0; j<3; j++){
		for (int i=0; i<3; i++){
			cout << gdata[i+j*64].lat << "," << gdata[i+j*64].lon << " ";
		}
		cout << endl;
	}
	*/

	// read other metadata
		
	/*
	beginLine = (int *) malloc (sizeof(int) * zr);
	endLine = (int *) malloc (sizeof(int) * zr);
	numLines = (int *) malloc (sizeof(int) * zr);

	secondsOfDay  = (double *) malloc (sizeof(double) * zr);

	sosSeqIndex = (int *) malloc (sizeof(int) * zr);
	sosStepIndex = (int *) malloc (sizeof(int) * zr);
	*/

	hid_t mType;

	mType = H5Tcreate(H5T_COMPOUND, sizeof(meta_t));
	status  = H5Tinsert(mType, "beginLine", HOFFSET(meta_t, beginLine), H5T_NATIVE_INT);
	status  = H5Tinsert(mType, "endLine", HOFFSET(meta_t, endLine), H5T_NATIVE_INT);
	status  = H5Tinsert(mType, "numLines", HOFFSET(meta_t, numLines), H5T_NATIVE_INT);

	status  = H5Tinsert(mType, "sosStepIndex", HOFFSET(meta_t, sosStepIndex), H5T_NATIVE_INT);
	status  = H5Tinsert(mType, "sosSeqIndex", HOFFSET(meta_t, sosSeqIndex), H5T_NATIVE_INT);

	status  = H5Tinsert(mType, "scanDir", HOFFSET(meta_t, scanDir), H5T_NATIVE_INT);

	status  = H5Tinsert(mType, "secondsOfDay", HOFFSET(meta_t, secondsOfDay), H5T_NATIVE_DOUBLE);

	hid_t dsetMeta = H5Dopen(f, mStdName.c_str(), H5P_DEFAULT);

	mdata = (meta_t *) malloc (sizeof(meta_t)*zr);

	status = H5Dread(dsetMeta, mType, H5S_ALL, H5S_ALL, H5P_DEFAULT, mdata);

	int i=frameNo;
		cout << mdata[i].beginLine << " " << mdata[i].endLine << " " << mdata[i].numLines << " " << mdata[i].scanDir << " " << endl;
	
}

H5R_FullFile::~H5R_FullFile(void)
{
}
