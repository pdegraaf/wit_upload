/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

#include "inputpane.h"

InputPane::InputPane()
	: QWidget()
{

}

InputPane::~InputPane()
{

}

void InputPane::setupItems(){

	hboxInput1 = new QHBoxLayout();
	hboxInput2 = new QHBoxLayout();
	hboxInput3 = new QHBoxLayout();
	vboxInput1 = new QVBoxLayout();

	cbInput = new QCheckBox();
	cbInput->setText("STREAMING");
	cbInput->setEnabled(false);

	labelInputStream = new QLabel; 
	labelInputStream->setTextFormat(Qt::RichText); 
	labelInputStream->setText("LOCATION");
	labelInputStream->setEnabled(false);

	textInputStream = new QLineEdit();
	textInputStream->setText("192.42.42.12:4242");
	textInputStream->setFixedWidth(200);
	textInputStream->setToolTip("IP:PORT of incoming stream data.");
	textInputStream->setEnabled(false);
	
	cbArchive = new QCheckBox();
	cbArchive->setText("MONITORING");
	cbArchive->setEnabled(false);
	
	labelInputArchive = new QLabel; 
	labelInputArchive->setTextFormat(Qt::RichText); 
	labelInputArchive->setText("ARCHIVE");

	textInputArchive = new QLineEdit();
	textInputArchive->setText("/export/data/hdf5/r/");
	textInputArchive->setFixedWidth(200);
	textInputArchive->setToolTip("Directory of HDF5-R files.");

	labelInputMonitorFreq = new QLabel; 
	labelInputMonitorFreq->setTextFormat(Qt::RichText); 
	labelInputMonitorFreq->setText("FREQ");
	labelInputMonitorFreq->setEnabled(false);

	labelInputMonitorSpan = new QLabel; 
	labelInputMonitorSpan->setTextFormat(Qt::RichText); 
	labelInputMonitorSpan->setText("SPAN");
	labelInputMonitorSpan->setEnabled(false);

	labelInputMonitorAdvance = new QLabel; 
	labelInputMonitorAdvance->setTextFormat(Qt::RichText); 
	labelInputMonitorAdvance->setText("ADV");
	labelInputMonitorAdvance->setEnabled(false);

	textInputMonitorFreq = new QLineEdit();
	textInputMonitorFreq->setText("30");
	textInputMonitorFreq->setFixedWidth(40);
	textInputMonitorFreq->setToolTip("How often to poll for files (secs).");
	textInputMonitorFreq->setEnabled(false);
	
	textInputMonitorSpan = new QLineEdit();
	textInputMonitorSpan->setText("120");
	textInputMonitorSpan->setFixedWidth(40);
	textInputMonitorSpan->setToolTip("Duration of data to query for (secs).");
	textInputMonitorSpan->setEnabled(false);
	
	textInputMonitorAdvance = new QLineEdit();
	textInputMonitorAdvance->setText("30");
	textInputMonitorAdvance->setFixedWidth(40);
	textInputMonitorAdvance->setToolTip("How far to advance the query window per update (secs).");
	textInputMonitorAdvance->setEnabled(false);

	hboxInput1->addWidget(cbInput);
	hboxInput1->addStretch(1);
	hboxInput1->addWidget(labelInputStream);
	hboxInput1->addWidget(textInputStream);

	qbLoadFromArchive = new QPushButton();
	qbLoadFromArchive->setText("LOAD FILES");

	hboxInput2->addWidget(qbLoadFromArchive);
	hboxInput2->addStretch(1);
	hboxInput2->addWidget(labelInputArchive);
	hboxInput2->addWidget(textInputArchive);

	hboxInput3->addWidget(cbArchive);
	hboxInput3->addStretch(1);
	hboxInput3->addWidget(labelInputMonitorFreq);
	hboxInput3->addWidget(textInputMonitorFreq);
	hboxInput3->addWidget(labelInputMonitorSpan);
	hboxInput3->addWidget(textInputMonitorSpan);
	hboxInput3->addWidget(labelInputMonitorAdvance);
	hboxInput3->addWidget(textInputMonitorAdvance);

	vboxInput1->addLayout(hboxInput1);
	vboxInput1->addLayout(hboxInput2);
	vboxInput1->addLayout(hboxInput3);
	vboxInput1->addStretch(1);

	this->setLayout(vboxInput1);
}