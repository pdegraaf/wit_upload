#pragma once

#include <iostream>
using namespace std;

#include "hdf5.h"
#include "H5Classes.h"
using namespace H5;

class H5Test
{
public:
	H5Test(void);
	~H5Test(void);

	void loadFile(string fName);
};

