
#ifndef H5R_SUMMARYMETADATA
#define H5R_SUMMARYMETADATA

//#pragma once
#include "H5R_ErrorInfoTable.h"
#include "H5R_SeqInfoTable.h"

#include "hdf5.h"
#include "H5Classes.h"
using namespace H5;

class H5R_SummaryMetaData
{
public:
	H5R_SummaryMetaData(Group *root);
	H5R_SummaryMetaData();
	~H5R_SummaryMetaData(void);

	void findTables(Group *g);
	H5R_ErrorInfoTable getErrorInfoTable();
	H5R_SeqInfoTable getSeqInfoTable();

	H5R_ErrorInfoTable errorInfoTable;
	H5R_SeqInfoTable seqInfoTable;
};

#endif