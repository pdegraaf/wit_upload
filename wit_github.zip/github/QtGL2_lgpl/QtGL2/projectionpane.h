#ifndef PROJECTIONPANE_H
#define PROJECTIONPANE_H

#include <QWidget>
#include <QObject>
#include <QtGui>

class ProjectionPane : public QWidget
{
	Q_OBJECT

public:
	ProjectionPane();
	~ProjectionPane();

	QHBoxLayout *hboxProj1;
	QVBoxLayout *vboxProj1;
	
	QComboBox *projList;
	QCheckBox *cbAutoZoom;
	QCheckBox *cbAutoZoomSnap;

	void setupItems();

	public slots:
	void toggleAutoOrientButton();

private:
	
};

#endif // PROJECTIONPANE_H
