
#ifndef H5R_GEOLOCATIONDATA
#define H5R_GEOLOCATIONDATA

//#pragma once


#include <iostream>
using namespace std;

#include "hdf5.h"
#include "H5Classes.h"
using namespace H5;

class H5R_File;

class H5R_Coords
{
public:
	int numAttr;// = 5;
	// X,Y,Z line of sight unit vectors in ECEF frame with origin
	// at spacecraft
	int xECEFUnit;// = 0;
	int yECEFUnit;// = 1;
	int zECEFUnit;// = 2;
	// line of sight mapped to ellipsoid lat/lon
	int latDeg;// = 3;
	int lonDeg;// = 4;
	float* attr;// = new float[numAttr];
	
	H5R_Coords(float x, float y, float z, float lat, float lon) {
		attr[xECEFUnit] = x;
		attr[yECEFUnit] = y;
		attr[zECEFUnit] = z;
		attr[latDeg] = lat;
		attr[lonDeg] = lon;
	}
	H5R_Coords() {
		attr[xECEFUnit] = 0;
		attr[yECEFUnit] = 0;
		attr[zECEFUnit] = 0;
		attr[latDeg] = 0;
		attr[lonDeg] = 0;
	}
};


class H5R_GeoLocationData
{
public:
	H5R_GeoLocationData(CompType *compound_ds, H5R_File *h5);
	H5R_GeoLocationData();
	//H5R_GeoLocationData(CompoundDS compound_ds, H5R_File h5);
	~H5R_GeoLocationData(void);

	void getGeoLocationAttributes();
	H5R_Coords** getGeolocationData(int frameNum);
	float*** getGeolocationLonLat(int frameNum, int scanDir, int sca);
	H5R_Coords** getInterpolatedGeolocationData(int frameNum);
	float*** getInterpolatedLonLatData(int frameNum);
	
	string* getMemberNames();
	int getX_Stepsize_Pixels();
	int getY_Stepsize_Pixels();
	string getXY_coord_system();
	string getGeodetic_ellipsoid();
	double getEquatorial_radius_km();
	double getFlattening();

	int numFrames;
	int* numRows;
	int* numCols;
	string* memberNames;
	//CompoundDS compoundDS;
	CompType* compoundDS;
	int X_Stepsize_Pixels;
	int Y_Stepsize_Pixels;
	float offEarth;
	string XY_coord_system;
	string geodetic_ellipsoid;
	double equatorial_radius_km;
	double flattening;
};

#endif