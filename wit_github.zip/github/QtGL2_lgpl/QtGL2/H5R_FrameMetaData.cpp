#include "H5R_FrameMetaData.h"
//#include "H5R_Combined.h"

H5R_FrameMetaData::H5R_FrameMetaData(CompType *compound_d)
{
}


H5R_FrameMetaData::~H5R_FrameMetaData(void)
{
}

string* H5R_FrameMetaData::getMemberNames(void)
{
	return memberNames;
}

MetaData H5R_FrameMetaData::getMetaData(void)
{
	return metaData;
}
