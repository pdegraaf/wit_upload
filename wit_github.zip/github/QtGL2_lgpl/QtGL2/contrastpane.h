#ifndef CONTRASTPANE_H
#define CONTRASTPANE_H

#include <QWidget>
#include <QObject>
#include <QtGui>


class ContrastPane : public QWidget
{
	Q_OBJECT

public:
	ContrastPane();
	~ContrastPane();

	void setupItems();
	
	QHBoxLayout *hboxContrast1;
	QHBoxLayout *hboxContrast2;
	QVBoxLayout *vboxContrast1;
		
	QCheckBox *cbContrast;
	QCheckBox *cbHistogram;
	QLabel *labelContrastPreset; 
	QComboBox *contrastList;
	
public slots:
	void toggleContrastButton();
	void toggleHistogramButton();

private:
	
};

#endif // CONTRASTPANE_H
