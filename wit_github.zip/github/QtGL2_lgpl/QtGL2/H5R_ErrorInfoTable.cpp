#include "H5R_ErrorInfoTable.h"
//#include "H5R_Combined.h"

H5R_ErrorInfoTable::H5R_ErrorInfoTable(CompType *ds)
{
}

H5R_ErrorInfoTable::H5R_ErrorInfoTable()
{
}

H5R_ErrorInfoTable::~H5R_ErrorInfoTable(void)
{
}

	

int H5R_ErrorInfoTable::getNumRows(){

	int i=0;

	return i;
}
H5R_ErrorInfoTableEntry* H5R_ErrorInfoTable::getErrorInfoTableEntry(){
	return errorInfoTableEntry;
}