#pragma once


#include <iostream>
using namespace std;

#include "H5cpp.h"

#include "hdf5.h"
#include "H5Classes.h"
using namespace H5;

class H5R_FullFile
{
public:
	H5R_FullFile(string);
	~H5R_FullFile(void);
	void H5R_FullFile_LoadFrame(string, int);
		
	typedef struct {
		float x;
		float y;
		float z;
		float lat;
		float lon;

	} geoloc_t;

	typedef struct {
		int frameNumber;
		long imageStatus;
		int beginChannel;
		int endChannel;
		int numChannels;
		int beginLine;
		int endLine;
		int numLines;
		int scanDir;
		int numGeoPoints;
		int year;
		int day;
		double secondsOfDay;
		int calNoCalFlag;
		int imageId;
		float satPosECF[3];
		float satVelECF[3];
		double lineDeltaTimeSecs;
		double absoluteCalCoeff_kws;
		double absoluteCalCoeff_wcmsq;
		double sosCTCsecs;
		int sosSeqIndex;
		int sosStepIndex;
		int sosDirection;
		char sosScaSelectStr[24];
		char sosParentAimPtStr[32];
		double sosScanRateMradUsecs;
		double sosFrameTimeUsecs;
		double sosBlankTimeUsecs;
		double sosLongIntUsecs;
		double sosShortIntUsecs;
		char sosIntegMode[16];
		int minCalIntensity;
		int maxCalIntensity;
		int linesReversed;
		int chansReversed;
		float UL_lat;
		float UL_lon;
		float UR_lat;
		float UR_lon;
		float LL_lat;
		float LL_lon;
		float LR_lat;
		float LR_lon;
		
	} meta_t;

	
	geoloc_t* gdata;
	meta_t* mdata;
	int* rdata;

	int* beginLine;
	int* endLine;
	int* numLines;

	double* secondsOfDay;

	int* sosSeqIndex;
	int* sosStepIndex;
};

