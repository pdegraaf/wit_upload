#ifndef QTGL2_H
#define QTGL2_H

#include <GL/glew.h> 
#include <QtOpenGL/QGLWidget> 
#include <QtGui/QMainWindow>
#include <QDebug>
#include <QTableWidgetItem>
#include "WitThread.h"
#include "WitFrame.h"
#include "EventDetection.h"
#include "H5R_FullFile.h"
#include "detection.h"
#include <boost/filesystem/operations.hpp>
#include <boost/filesystem/fstream.hpp>
using namespace boost::filesystem; 

#include "MapVertexList.h"
#include <stdio.h>
#include <iostream>
#include <algorithm>
using namespace std;

class QtGL2 : public QGLWidget
{
	Q_OBJECT

public:
	QtGL2(QWidget *parent);
	~QtGL2();

	void mouseMoveEvent(QMouseEvent *e);
	void mouseClickEvent(QMouseEvent *e);
	void mousePressEvent(QMouseEvent *e);
	void mouseReleaseEvent(QMouseEvent *e);
	void wheelEvent(QWheelEvent *e);
	void keyPressEvent(QKeyEvent *e);
	void enterEvent(QEvent *e);
	void leaveEvent(QEvent *e);

	int viewW;
	int viewH;
	
	float histRenderX;
	float histRenderY;
	float histRenderW;
	float histRenderH;

	string mapDataDir;
	int mapSparseness;
	
	int scanDir[2];

	int videoExportFrameNo;
	string vid_path_export;
	string vid_scratch_dir;
	int vid_export_format;
	int vid_stream_format;
	QGLFramebufferObject *catchFbo;
	QImage catchImage;
	QImage catchImageCrop;
	float videoExportScaleFactor;
	float videoStreamScaleFactor;
	string labelClassification;
	string labelTitle;

	 void initializeGL();
	 void resizeGL(int w, int h);
	 void paintGL();
	 void runSystem();
	 void setupItems();
	 void loadMap(string dir, int sparseness);
	 void loadRegion(string dir, MapVertexList& mv, int& flag, int& segCount);
	 void genRegionRadius(MapVertexList& mv, MapVertexList& mvr, float radius);
	 void drawGlobe();
	 void mainLoop();
	 void setKernelTap(int loc, float val);
	 int drawGLScene();

	 void createLoadDataTasks();
	 void createLoadMetaTasks();
	 void updateLoadStatus();
	 void createListenerTasks();
	 void createFFmpegExportTask();
	 int getFrameAtTime(float secs, int scid, int sca, int dir, int beginLine);

	 void updateEventTable();

	 void prepFrames();
	 void resetFramesAndFiles();
	 void prepEventList();
	 void allocFrameData();
	 void resetThreads();
	 void prepGpuResources();
	 void prepProcessing();
	 
	void advanceFrame(int dir);
	void scrollTimeline(int dir, int speed);
	float checkTimeBounds(float p);
	void findFallbackFrames();
	void resetCudaResults();

	int getNextThread(int state);
	int getCountThread(int state);
	void getCompletedThreads();
	void manageThreads();

	int getNextFrame(int mode, int state);

	float getLatLonX(float radius, float lat, float lon);
	float getLatLonY(float radius, float lat, float lon);
	float getLatLonZ(float radius, float lat, float lon);

	float* interpolateLoc(int x, int y, WitFrame w);
	
	typedef WitFrame* WitFramePtr;

	float *dataResContrastBuffer;
	float *getContrastFromVal(float v);
	float *crossProd(float *v1, float *v2);
	float dotProd(float *v1, float *v2);
	void setContrastCpRastPos();
	int getNearestContrastCp(int x, int y);

	void invokeFfmpeg();
	void deleteFfmpegScratchFiles();

public slots: 
	void toggleAutoOrient();
	void toggleAutoOrientSnap();
	void togglePlaybackDirection();
	void togglePlaybackPaused();
	void toggleContrastOnOff();
	void toggleHistogramOnOff();
	void toggleCudaFilterOnOff();
	void toggleThreshConstOnOff();
	void toggleThreshSigmaOnOff();
	void toggleRegionWatchOnOff();
	void toggleRegionRejectOnOff();
	void toggleRegionWatchRadiusOnOff();
	void toggleRegionRejectRadiusOnOff();

	void toggleVideoStreamOnOff();
	void toggleVideoExportOnOff();
	
	void changePlaybackSpeed(QString str);
	
	void changeThreshConst(QString str);
	void changeThreshSigma(QString str);
	
	void changeThreshConstPreset(int state);
		
	void changeRegionWatchRadius(QString str);
	void changeRegionRejectRadius(QString str);

	void changeKTap(int i, QString str);
	void changeKTaps(QLineEdit *k, int n);

	void detectListClear();
	void resetDetections();
	
	void changeIncomingDataArchiveLocation(QString str);

	void changeIncomingDataArchive();
	void changeIncomingDataMonitor();
	void changeIncomingDataStream();

	void changeVideoExportName(QString str);

	void setKernelPreset(int id);
	void setKernelPassthrough();
	void restoreUserKernel();
	void undoKernelEdits();
	
	void setContrastPreset(int id);
	void resetContrastResults();
	
	void highlightDetection(int r, int c, int rp, int cp);
	void highlightDetectionNone(int r, int c);

	void videoStreamStart();
	void videoExportStart();
	
signals:
	void thresholdDetected(EventDetection *e);
	void pushKernelTap(int i, float t);
	void pushKernelTapStr(int i, QString s);
	void updateThreshUi(float t);
	void updateWatchRadiusUi(float t);
	void updateRejectRadiusUi(float t);
	void updateUiTogglePause();
	void updateUiToggleReverse();
	void updateUiToggleContrast();
	void updateUiToggleHistogram();
	void updateUiToggleFilter();
	void updateUiToggleThreshold();
	void updateUiToggleAutoOrient();
	void updateUiToggleAutoOrientSnap();
	void updateUiToggleExportVideo();
	void updateUiToggleExportButtonText(int state);

private:
	int elapsed;
 
};

Q_DECLARE_METATYPE(QList<QTableWidgetItem *>);

#endif // QTGL2_H
