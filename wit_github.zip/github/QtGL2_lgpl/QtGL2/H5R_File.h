//#pragma once

#ifndef H5R_FILE
#define H5R_FILE

#include <iostream>
using namespace std;

#include "hdf5.h"
#include "H5Classes.h"
using namespace H5;


//#include "H5R_CalRawData.h"
//#include "H5R_ErrorInfoTable.h"
//#include "H5R_File.h"
//#include "H5R_FileMetaData.h"
//#include "H5R_FrameMetaData.h"
//#include "H5R_GeoLocationData.h"
//#include "H5R_SeqInfoTable.h"
///#include "H5R_SummaryMetaData.h"

class H5R_CalRawData{};
class H5R_GeoLocationData{};
class H5R_FrameMetaData{};
class H5R_FileMetaData{};
class H5R_SummaryMetaData{};

class H5R_File
{
public:
	H5R_File(string fileName);
	~H5R_File(void);

	hid_t h;

	H5R_CalRawData * findCalRawData(Group *g);
	H5R_GeoLocationData findGeolocationData(Group *g);
	H5R_FrameMetaData findFrameMetaData(Group *g);

	H5R_CalRawData getCalRawData();
	H5R_GeoLocationData getGeolocationData();
	H5R_FrameMetaData getFrameMetaData();
	H5R_FileMetaData getFileMetaData();
	int getNumFrames();
	H5R_SummaryMetaData getSummaryMetaData();
	double getH5LibVersion();

	H5R_CalRawData calRawData;
	H5R_GeoLocationData geolocationData;
	H5R_FrameMetaData frameMetaData;
//	FileFormat h5File;
	H5R_FileMetaData fileMetaData;
	H5R_SummaryMetaData summaryMetaData;
	int numFrames;
	double h5LibVersion;
};

#endif