#ifndef THRESHPANE_H
#define THRESHPANE_H

#include <QObject>
#include <QtGui>

class ThreshPane : public QWidget
{
	Q_OBJECT

public:
	ThreshPane();
	~ThreshPane();
	
	void setupItems();

	QHBoxLayout *hboxThresh1;
	QHBoxLayout *hboxThresh2;
	QHBoxLayout *hboxThresh3;
	QHBoxLayout *hboxThresh4;
	QHBoxLayout *hboxThresh5;
	QHBoxLayout *hboxThresh6;
	QHBoxLayout *hboxThresh7;
	QVBoxLayout *vboxThresh1;

	QCheckBox *cbDetectConst;
	QCheckBox *cbDetectSigma;

	QLabel *labelThreshConstPreset;
	QComboBox *threshConstList;
	QLineEdit *textThreshLevelConst;

	QLabel *labelThreshSigmaPreset;
	QLineEdit *textThreshLevelSigma;
	QComboBox *threshSigmaList;

	QCheckBox *cbAlert;
	QCheckBox *cbRegionWatch;

	QLabel *labelRegionWatchFile;
	QLineEdit *textRegionWatchFile;	
	QCheckBox *cbRegionReject;
	
	QLabel *labelRegionRejectFile;
	QLineEdit *textRegionRejectFile;
	QCheckBox *cbRegionWawtch;

	QCheckBox *cbRegionWatchRadius;
	QLineEdit *textRegionWatchRadius;
		
	QCheckBox *cbRegionRejectRadius;
	QLineEdit *textRegionRejectRadius;

	public slots:
		void updateThreshConst(float t);
		void updateRegionWatchRadius(float t);
		void updateRegionRejectRadius(float t);
		void toggleThresholdButton();

private:
	
};

#endif // THRESHPANE_H
