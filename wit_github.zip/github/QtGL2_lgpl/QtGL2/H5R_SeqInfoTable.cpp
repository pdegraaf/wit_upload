#include "H5R_SeqInfoTable.h"
//#include "H5R_Combined.h"

H5R_SeqInfoTable::H5R_SeqInfoTable(CompType *ds)
{
}

H5R_SeqInfoTable::H5R_SeqInfoTable()
{
}


H5R_SeqInfoTable::~H5R_SeqInfoTable(void)
{
}

SeqInfoTableEntry* H5R_SeqInfoTable::getSeqInfoTableEntry(){
	return seqInfoTableEntry;
}

int H5R_SeqInfoTable::getNumRows(){
	return numRows;
}