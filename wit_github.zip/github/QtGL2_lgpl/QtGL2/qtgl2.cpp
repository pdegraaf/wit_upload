/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

#include <GL/glew.h> 

#include <QtGui/QMouseEvent>
#include <QTimer>
#include <QLineEdit>
#include <QProcess>
#include <QPainter>
#include <QDir>
#include <QTableWidgetItem>
#include <QGLFramebufferObject>
#include "qtgl2.h"

#include "StdAfx.h"
#include "MapVertexList.h"
#include "detection.h"

const int numFrames  = 60;
const int numFiles  = 2000;

int frameStart = 305;
int frameNo = frameStart;
int frameSkip = 1;
int frameMax = 1300;

int wfIndexRay[TOTAL_SENSORS][TOTAL_SCAS];

int drawDelayMs = DRAW_DELAY_STANDARD;//16;//32;
int drawDelayMsMax = 3000;
int drawDelayMsMin = 2;

int animDelayMs = drawDelayMs;//32;
int animDelayMsMax = 3000;
int animDelayMsMin = 2;

int backendDelayMs = 100;//100;

const int numPx = 768;//1920;//720;//900;
const int numPy = 864;//1080;//900;//
const int numT = 9;// temporal slices

const int numTx = 2;
const int numTy = 2;

static int timeBufferIndex = 0;

int chan = DIM_R;

int playback = ON;

int testMode = OFF; // to iterate through many settings
int testStep = 0;
int testStepInit = 100;

// thread pool management
const int threadPoolSize = 200;//32;
int threadsMaxActive = 1;//12;
int threadsActive = 0;

int threadsQueued = 0;
int threadsReady = 0;

// thread pool
WitThread witThreadRay[threadPoolSize];

// data storage
WitFrame witFrameRay[numFrames];
WitFile witFileRay[numFiles];

int fileType = FILE_INPUT_PNG;
int fileScanStatus = STATUS_READY;
int framesUsed = 0;

QStringList listPng;
QStringList listH5;
QStringList listAll;

// event storage
const int numEvents = 1000;
const int numEventsQtPush = 100;
EventDetection witEventRay[numEvents];
int eventHighlight = 0;
int eventCount = 0;
int eventUid = 0; 
int eventTableNeedsUpdateFlag = OFF;

float regionRejectRadius = .05f;
float regionWatchRadius = .05f;

float defaultThreshLow = .3f;
float defaultThreshMed = .6f;
float defaultThreshHi = .8f;

float defaultWatchRadius = .2f;
float defaultRejectRadius = .1f;

float detectThreshConst = defaultThreshHi;
float detectThreshSigma = 3.0f;

float detectConstCurrMin = 0;
float detectConstCurrMax = 0;
float detectConstCurrSpan = 0;
float normConstScale = 255.0f;

float detectSigmaCurrMin = 0;
float detectSigmaCurrMax = 0;
float detectSigmaCurrSpan = 0;
float normSigmaScale = 255.0f;

// toggle via UI
int threshConstActivated = OFF;
int threshSigmaActivated = OFF;
int regionWatchActivated = OFF;
int regionWatchRadiusActivated = OFF;
int regionRejectActivated = OFF;
int regionRejectRadiusActivated = OFF;
int filterActivated = OFF;
int contrastActivated = OFF;
int histogramActivated = OFF;

int videoExportActivated = OFF;
int videoStreamActivated = OFF;
int videoNeedsEncoding = OFF;
int videoExportSaveImagesActivated = OFF;

// video export
int videoExportCounter = 0;
int videoExportCounterStartVal = 1; // export every nth openGL render

QImage screenBuffer;
int videoFrameCounter=0;

// mouse and other input devices
int mouseState = MOUSE_STATE_READY;
int mouseItem = STATUS_ERROR; // index of item per mouse state

// histogram and contrast
int histMaxBinCount =0;

// kernels for GPU functions
float kc_a[numT] = {0};
float kc_b[numT] = {0};
float kc_c[numT] = {0};
float kc_d[numT] = {0};
float kc_e[numT] = {0};

float kc_user[numT] = {0};
float kc_user_prev[numT] = {0};

int kcSelected = 0;
int kcSelectMax = 5;

int kcWaveletScale = 0;
int kcWaveletScaleMax = 4;

int kcContrast = 0;
int kcContrastMax = 3;

int kcErode =0;
int kcErodeMax = 10;

int kcDilate =0;
int kcDilateMax = 10;

int kcOrder[KC_MODES] = {0};

// false color contrast modes
int fcSelected = 0;
int fcSelectMax = 2;

const int fcRampNum = 3;
const int fcRampColors = 5;
float fcRamps[fcRampNum][fcRampColors][3] = {0};
int fcRampSlots[fcRampNum] = {0};

const int contrastNumCp = 20;
float contrastCpVal[contrastNumCp] = {0};
float contrastCpOut[contrastNumCp] = {0};
float contrastCpRastX[contrastNumCp] = {0};
float contrastCpRastY[contrastNumCp] = {0};
float contrastCpActive[contrastNumCp] = {OFF};

// widgets
int winAlertLocX = 0;
int winAlertLocY = 0;

int winGraphLocX = 0;
int winGraphLocY = 0;

int winInfoLocX = 0;
int winInfoLocY = 0;

// timers
ptime timeProcGlobalStart;
ptime timeProcGlobalStop;
ptime timeProcGlobalStopPrev;
int outputResultFlag = 1;

ptime timeDraw1;
ptime timeDraw2;

ptime timeAnim1;
ptime timeAnim2;

ptime timeBackend1;
ptime timeBackend2;

string frameType = ".png";
string vid_path("C:\\dev\\test_videos\\fireworks_hd1\\");

float renderLatencyAve;
int renderLatencyOutputCount = 0;
int renderLatencyOutputStartVal = 20;
float renderLatencyWeight = 1.0f/(float)renderLatencyOutputStartVal;

// GPU processing params
int tpb = 256;

string frameStr;
string finalFramePath;
char *fileName;
const int numPc = numPx*numPy;
const int numPct = numT*numPc;
int timeSlots[numT] = {0};

float aPxy[numPct] = {0};
float resPxy[numPc] = {0};
float sigmaPxy[numPc] = {0};
int maskPxy[numPc] = {0};

static float *ptr_a;
static float *ptr_res;
static float *ptr_kc;

GLuint buffId;

// sensor specifics
int sensorStates[TOTAL_SENSORS][TOTAL_SCAS] = {{0}};
int sensorToggleLoad[TOTAL_SENSORS][TOTAL_SCAS] = {{0}};
int sensorRenderStart = 0;
int numSensorsRender = TOTAL_SENSORS;

// timeline items
float timeStep = 1.0f;	// in s
float timeStepMin = .01f;
float timeStepMax = 1000.0f*60.0f*120.0f;
float timeStepMulStep = 1.2f;
int playbackDirection = 1;

int userTimelinePos[2] = {0};
int userTimelinePosMin = 0;
int userTimelinePosMax = 60000;
int fastScrollSpeed =100;
int slowScrollSpeed =10;

int incomingDataStateArchive = OFF;
int incomingDataStateStream = OFF;
int playbackPaused = OFF;
int archiveLoadState = STATUS_READY;

float playheadSecsOfDay = 0.0f;
float timeMin[TOTAL_SENSORS] = {0};	// based on loaded data
float timeMax[TOTAL_SENSORS] = {0};

float timeUserMin = SECS_IN_DAY*2;
float timeUserMax = 0.0f;

float timeUserScroll = 0.0f;
float timeUserScrollGoal = 0.0f;
float timeUserScrollInc = 30.0f;
float timeUserScrollMin = -timeStepMax;  
float timeUserScrollMax = 0;

float timeZoom = 2.0f;
float timeZoomMin = 1.0f;
float timeZoomMax = 1000.0f;

float ptPrev1;
int wfIndexP1Ray[TOTAL_SENSORS][TOTAL_SCAS];
float ptPrev2;
int wfIndexP2Ray[TOTAL_SENSORS][TOTAL_SCAS];

// animation speeds
float animRateUs = 0.3f;

// window params
int winLocX = 200;
int winLocY = 100;
int winSizeW = 2000;
int winSizeH = 1400;

// map items
MapVertexList *globeVertexLists;
int numGlobeLists = 10;
float globeRadius = 1.0;

float globeZoom = 2.0f;
float globeZoomGoal = 2.0f;
float globeZoomMin = 1.0f;
float globeZoomMax = 6.82f;
float globeZoomSpeed = 1.02f;
float globeZoomAnimRate = .50f;

float globeRotGoal[3] = {45.0f,90.0f,0.0f};
float globeRot[3] = {0.0f,0.0f,0.0f};
float globeRotDataLast[3] = {0.0f,0.0f,0.0f};
float globeRotAnimRate = .250f;
float globeRotSpeedKb = .2f;
float globeRotSpeedKbFast = 10*globeRotSpeedKb;

int windowIsLive = 0;
int autoOrient = OFF;
int autoOrientSnap = OFF;

GLuint globeIndex;
int globeDrawStatus = STATUS_ERROR;
int regionRejectDrawStatus = STATUS_ERROR;
int regionWatchDrawStatus = STATUS_ERROR;

string regionWatchDir = "c:\\dev\\KML_CSV\\WATCH";
MapVertexList watchVertexLists;
int numRegionWatchLists = 10;
MapVertexList watchRadiusVertexLists;

int regionRadiusPoints = 100; // how smooth to make the circle

string regionRejectDir = "c:\\dev\\KML_CSV\\REJECT";
MapVertexList rejectVertexLists;
int numRegionRejectLists = 10;
MapVertexList rejectRadiusVertexLists;

int counter=0;

// rendering options
int textureInterpolation = OFF;


QtGL2::QtGL2(QWidget *parent)
	:QGLWidget(QGLFormat(QGL::SampleBuffers), parent)
{
	setMouseTracking(true);
}

QtGL2::~QtGL2()
{

}

void QtGL2::restoreUserKernel() {
	for (int i=0; i<numT; i++){
		kc_user[i] = kc_user_prev[i];
	}
}

void QtGL2::setKernelPassthrough() {

	for (int i=0; i<numT; i++){
		kc_user_prev[i] = kc_user[i];
		kc_user[i] = kc_e[i];
	}
}

void QtGL2::undoKernelEdits(){
	setKernelPreset(kcSelected);
}

void QtGL2::resetDetections(){

	if (filterActivated == ON){
		detectListClear();
		resetCudaResults();

		detectConstCurrMax = 0.0f;
		detectConstCurrMin = 1.0f;

		detectSigmaCurrMax = 0.0f;
		detectSigmaCurrMin = 1.0f;
	}

	qDebug("RESET DETECTIONS");
}

void QtGL2::setKernelPreset(int id) 
{
	int lastKern =kcSelected;
	kcSelected = id;

	if (id ==0){
		for (int i=0; i<numT; i++){
			kc_user[i] = kc_a[i];
		}
	} else if (id ==1){
		for (int i=0; i<numT; i++){
			kc_user[i] = kc_b[i];
		}
	} else if (id ==2){
		for (int i=0; i<numT; i++){
			kc_user[i] = kc_c[i];
		}
	} else if (id ==3){
		for (int i=0; i<numT; i++){
			kc_user[i] = kc_d[i];
		}
	}

	if (id == 3){
		for (int i=0; i<numT; i++){
			pushKernelTapStr(i, QString("THRU"));
		}
		qDebug("KERNEL [0] %f",kc_user[0]);
	} else {
		for (int i=0; i<numT; i++){
			pushKernelTap(i, kc_user[i]);
		}
	}

	if (filterActivated == OFF){
		for (int i=0; i<numT; i++){
			kc_user_prev[i] = kc_user[i];
		}
	}

	qDebug("KERNEL SELECTED: %i",id);
}

void QtGL2::setKernelTap(int loc, float val) 
{
	kc_user[loc] = val;
}


void QtGL2::setContrastPreset(int id) 
{
	fcSelected = id;

	qDebug("CONTRAST SELECTED: %i",id);
}

void QtGL2::highlightDetectionNone(int r, int c) 
{
	for (int i=0; i<eventCount; i++){
		witEventRay[i].highlighted = OFF;
	}
	if (r>=0 && r<eventCount){

		witEventRay[r].highlighted = ON;
		eventHighlight = r;
	}
}

void QtGL2::highlightDetection(int r, int c, int rp, int cp) 
{
	if (r>=0 && r<eventCount){
		witEventRay[r].highlighted = ON;
		eventHighlight = r;
	}
}

void QtGL2::togglePlaybackDirection() 
{
	if (playbackDirection == 1){
		playbackDirection = -1;
	} else {
		playbackDirection = 1;
	}

	qDebug("PLAYBACK DIRECTION %i",playbackPaused);
}

void QtGL2::togglePlaybackPaused() 
{
	if (playbackPaused == ON){
		playbackPaused = OFF;
	} else {
		playbackPaused = ON;
	}

	qDebug("PAUSE TOGGLED %i",playbackPaused);
}


void QtGL2::changePlaybackSpeed(QString str) 
{
	str.simplified();
	str.remove(QRegExp("[a-zA-Z]"));
	int perCount = str.count(".");
	while (perCount > 1){
		str.remove(str.lastIndexOf("."), 1);
		perCount = str.count(".");
	}
	str.remove(QRegExp(QString::fromUtf8("[-`~!@#$%^&*()_�+=|:;<>��,?/{}\'\"\\\[\\\]\\\\]")));

	float newStep = ((float)boost::lexical_cast<int>(str.toStdString()))/1000.0f;

	if (newStep >= timeStepMin && newStep <= timeStepMax){
		timeStep = newStep;

		qDebug("PLAYBACK SPEED MS %s",str.toStdString());
	}
}

void QtGL2::toggleRegionWatchRadiusOnOff(){
	if (regionWatchRadiusActivated == ON){
		regionWatchRadiusActivated = OFF;
	} else {
		regionWatchRadiusActivated = ON;
	}
	qDebug("REGION WATCH RADIUS TOGGLED %i",regionWatchRadiusActivated);
}

void QtGL2::toggleRegionRejectRadiusOnOff(){
	if (regionRejectRadiusActivated == ON){
		regionRejectRadiusActivated = OFF;
	} else {
		regionRejectRadiusActivated = ON;
	}
	qDebug("REGION REJECT RADIUS TOGGLED %i",regionRejectRadiusActivated);
}

void QtGL2::toggleRegionWatchOnOff(){
	if (regionWatchActivated == ON){
		regionWatchActivated = OFF;
	} else {
		regionWatchActivated = ON;

		if (regionWatchDrawStatus != STATUS_READY){
			loadRegion(regionWatchDir, watchVertexLists, regionWatchDrawStatus, numRegionWatchLists);
			genRegionRadius(watchVertexLists, watchRadiusVertexLists, globeRadius);
			qDebug("LOADED SEGMENTS %i",numRegionWatchLists);

			qDebug("   SEG VERTICES %i",watchVertexLists.numVertices);
		}
	}
	qDebug("REGION WATCH TOGGLED %i",regionWatchActivated);
}

void QtGL2::toggleRegionRejectOnOff(){
	if (regionRejectActivated == ON){
		regionRejectActivated = OFF;
	} else {
		regionRejectActivated = ON;

		if (regionRejectDrawStatus != STATUS_READY){
			loadRegion(regionRejectDir, rejectVertexLists, regionRejectDrawStatus, numRegionRejectLists);
			genRegionRadius(rejectVertexLists, rejectRadiusVertexLists, globeRadius);
		}
	}
	qDebug("REGION REJECT TOGGLED %i",regionRejectActivated);
}


void QtGL2::changeThreshConstPreset(int state) 
{
	if (state == 2){
		detectThreshConst = defaultThreshLow;
	} else if (state == 1){
		detectThreshConst = defaultThreshMed; 
	} else if (state == 0){
		detectThreshConst = defaultThreshHi;
	}  

	updateThreshUi(detectThreshConst);

	if (filterActivated == OFF){
		resetCudaResults();
	} else {
		resetDetections();
	}

	qDebug("DETECTION CONST THRESHOLD %f",detectThreshConst);
}


void QtGL2::changeRegionWatchRadius(QString str) 
{
	str.simplified();
	str.remove(QRegExp("[a-zA-Z]"));
	int perCount = str.count(".");
	while (perCount > 1){
		str.remove(str.lastIndexOf("."), 1);
		perCount = str.count(".");
	}
	str.remove(QRegExp(QString::fromUtf8("[-`~!@#$%^&*()_�+=|:;<>��,?/{}\'\"\\\[\\\]\\\\]")));

	float newThresh = ((float)boost::lexical_cast<float>(str.toStdString()));

	if (newThresh < 0){
		newThresh = 0.0f;
	} else if (newThresh > 1){
		newThresh = 1.0f;
	}  

	regionWatchRadius = newThresh;

	qDebug("DETECTION WATCH RADIUS %s",str.toStdString());

}

void QtGL2::changeRegionRejectRadius(QString str) 
{
	str.simplified();
	str.remove(QRegExp("[a-zA-Z]"));
	int perCount = str.count(".");
	while (perCount > 1){
		str.remove(str.lastIndexOf("."), 1);
		perCount = str.count(".");
	}
	str.remove(QRegExp(QString::fromUtf8("[-`~!@#$%^&*()_�+=|:;<>��,?/{}\'\"\\\[\\\]\\\\]")));

	float newThresh = ((float)boost::lexical_cast<float>(str.toStdString()));

	if (newThresh < 0){
		newThresh = 0.0f;
	} else if (newThresh > 1){
		newThresh = 1.0f;
	}  

	regionRejectRadius = newThresh;

	qDebug("DETECTION REJECT RADIUS %s",str.toStdString());
}


void QtGL2::changeKTap(int i, QString str) 
{
	str.simplified();
	str.remove(QRegExp("[a-zA-Z]"));
	int perCount = str.count(".");
	while (perCount > 1){
		str.remove(str.lastIndexOf("."), 1);
		perCount = str.count(".");
	}
	str.remove(QRegExp(QString::fromUtf8("[-`~!@#$%^&*()_�+=|:;<>��,?/{}\'\"\\\[\\\]\\\\]")));

	float newTap = ((float)boost::lexical_cast<float>(str.toStdString()));

	kc_user[i] = newTap;

	qDebug("TAP %i UPDATED %s",i,str.toStdString());

}



void QtGL2::changeKTaps(QLineEdit *k, int n) 
{
	for (int i=0; i<n; i++){

		QString str = QString(k[i].text());

		str.simplified();
		str.remove(QRegExp("[a-zA-Z]"));
		int perCount = str.count(".");
		while (perCount > 1){
			str.remove(str.lastIndexOf("."), 1);
			perCount = str.count(".");
		}
		str.remove(QRegExp(QString::fromUtf8("[-`~!@#$%^&*()_�+=|:;<>��,?/{}\'\"\\\[\\\]\\\\]")));

		float newTap = ((float)boost::lexical_cast<float>(str.toStdString()));

		kc_user[i] = newTap;

		qDebug("TAP %i UPDATED %s",i,str.toStdString());

	}

	resetDetections();

	if (filterActivated == OFF){
		for (int i=0; i<numT; i++){
			kc_user_prev[i] = kc_user[i];
		}
	}

}

void QtGL2::changeThreshConst(QString str) 
{
	str.simplified();
	str.remove(QRegExp("[a-zA-Z]"));
	int perCount = str.count(".");
	while (perCount > 1){
		str.remove(str.lastIndexOf("."), 1);
		perCount = str.count(".");
	}
	str.remove(QRegExp(QString::fromUtf8("[-`~!@#$%^&*()_�+=|:;<>��,?/{}\'\"\\\[\\\]\\\\]")));

	float newThresh = ((float)boost::lexical_cast<float>(str.toStdString()));

	if (newThresh < 0){
		newThresh = 0.0f;
	} else if (newThresh > 1){
		newThresh = 1.0f;
	}  

	detectThreshConst = newThresh;

	qDebug("DETECTION CONST THRESHOLD %s",str.toStdString());

}

void QtGL2::changeThreshSigma(QString str) 
{
	str.simplified();
	str.remove(QRegExp("[a-zA-Z]"));
	int perCount = str.count(".");
	while (perCount > 1){
		str.remove(str.lastIndexOf("."), 1);
		perCount = str.count(".");
	}
	str.remove(QRegExp(QString::fromUtf8("[-`~!@#$%^&*()_�+=|:;<>��,?/{}\'\"\\\[\\\]\\\\]")));

	float newThresh = ((float)boost::lexical_cast<float>(str.toStdString()));

	if (newThresh < 0){
		newThresh = 0.0f;
	}

	detectThreshSigma = newThresh;

	qDebug("DETECTION SIGMA THRESHOLD %s",str.toStdString());

}


void QtGL2::videoExportStart(){

}

void QtGL2::videoStreamStart(){
	videoStreamActivated = ON;
}


void QtGL2::invokeFfmpeg(){


	string ffmpegCmdStr = "ffmpeg ";


	string vcodecStr;
	string paramStr = " -sameq -y "; // same quality, and force overwrite

	float encodingFps = 12.0f;//30.0f;
	string fpsStr = " -r "+ boost::lexical_cast<std::string>(encodingFps)+" ";

	string inputStr = " -i "+vid_scratch_dir;
	inputStr+= "\%d.png";

	//!! hardcode for now...add logic to check user's outfile
	vid_export_format = VID_FORMAT_WMV;

	string destStr = vid_path_export;
	int extSubIndex = destStr.find_last_of(".");
	string userExtStr =  "";
	if (extSubIndex != -1){
		userExtStr = destStr.substr(extSubIndex);
	}

	if (vid_export_format == VID_FORMAT_WMV){
		vcodecStr = " -vcodec wmv2 ";

		if (userExtStr.length() == 0){
			userExtStr = ".wmv";
			destStr += userExtStr;
		}
	}

	if (vid_export_format == VID_FORMAT_MPG){
		vcodecStr = " ";

		if (userExtStr.length() == 0){
			userExtStr = ".mpg";
			destStr += userExtStr;
		}
	}

	//string fpsOutStr = " -r 24 ";
	string fpsOutStr = " -r 12 ";

	ffmpegCmdStr += fpsStr;
	ffmpegCmdStr += inputStr;
	ffmpegCmdStr += fpsOutStr;
	ffmpegCmdStr += vcodecStr;
	ffmpegCmdStr += paramStr;
	ffmpegCmdStr += destStr;

	qDebug("INVOKING FFMPEG... %s",ffmpegCmdStr.c_str());
	QString qCmdStr(ffmpegCmdStr.c_str());

	QProcess *encodeProcess = new QProcess(this);
	encodeProcess->start(qCmdStr);

	encodeProcess->waitForFinished();

	QString strErr = encodeProcess->readAllStandardError();
	QString strOut = encodeProcess->readAllStandardOutput();

	if (strErr.length()>0){
		qDebug() << strErr;
	}
	if (strOut.length()>0){
		qDebug() << strOut;
	}

	//deleteFfmpegScratchFiles();
}


void QtGL2::toggleVideoStreamOnOff(){
	if (videoStreamActivated == OFF){
		videoStreamActivated = ON;
	} else {
		videoStreamActivated = OFF;
	}

	qDebug("VIDEO STREAM TOGGLED %i",videoStreamActivated);
}

void QtGL2::toggleVideoExportOnOff(){

	if (videoExportActivated == OFF){
		videoExportActivated = ON; 

		videoNeedsEncoding = ON;
		videoExportFrameNo = 0;


		drawDelayMs = DRAW_DELAY_IO_BOUND;
		animDelayMs = drawDelayMs;

	} else {

		videoExportActivated = OFF;


		drawDelayMs = DRAW_DELAY_STANDARD;
		animDelayMs = drawDelayMs;

		if (videoNeedsEncoding == ON){
			createFFmpegExportTask();
		}

		if (videoExportSaveImagesActivated == ON){
			// xfer to new dir

			// delete content in FFMPEG_SCRATCH
			//deleteFfmpegScratchFiles();
		} else {
			// delete content in FFMPEG_SCRATCH
			//deleteFfmpegScratchFiles();
		}
	}


	updateUiToggleExportButtonText(videoExportActivated);
	qDebug("VIDEO EXPORT TOGGLED %i",videoExportActivated);
}

void QtGL2::deleteFfmpegScratchFiles(){

	qDebug("DELETING SCRATCH FILES ");

	namespace fs = boost::filesystem;
	fs::path someDir(vid_scratch_dir);
	fs::directory_iterator end_iter;

	if(exists(someDir)){
		directory_iterator end;
		for(directory_iterator iter(someDir); iter != end; ++iter){
			if (is_directory(*iter)){

			} else {
				remove(iter->path().c_str());
			}
		}
	}
}

void QtGL2::detectListClear() 
{
	for (int i=0; i< eventCount; i++){
		witEventRay[i].displayStatus = STATUS_ERROR;
		witEventRay[i].highlighted = OFF;
		witEventRay[i].valFilter=0;
		witEventRay[i].valRaw=0;
		witEventRay[i].valSigma=0;
	}
	eventCount = 0;

	qDebug("DETECTIONS PURGED");
}

void QtGL2::changeIncomingDataMonitor(){

	if (incomingDataStateArchive == ON){
		incomingDataStateArchive = OFF;

		archiveLoadState = STATUS_READY;
		prepFrames();
		prepProcessing();

	} else {
		incomingDataStateArchive = ON;
	}

	qDebug("MONITORING TOGGLED %i",incomingDataStateArchive);
}

void QtGL2::changeIncomingDataArchive() 
{
		incomingDataStateArchive = OFF;

		archiveLoadState = STATUS_READY;
		
		resetFramesAndFiles();

		for (int i=0; i<TOTAL_SENSORS; i++){
			for (int j=0; j<TOTAL_SCAS; j++){
				sensorToggleLoad[i][j] = OFF;
			}
		}	

	fileScanStatus = STATUS_READY;
	incomingDataStateArchive = ON;
	qDebug("LOAD %i",incomingDataStateArchive);
}

void QtGL2::changeIncomingDataArchiveLocation(QString str) 
{
	
	str.simplified();

	vid_path = str.toStdString();

	qDebug("VIDEO IMPORT DIR %s", vid_path.c_str());
	
}

void QtGL2::changeVideoExportName(QString str) 
{
	str.simplified();

	vid_path_export = str.toStdString();

	qDebug("VIDEO EXPORT FILE %s", vid_path_export.c_str());

}

void QtGL2::changeIncomingDataStream() 
{
	if (incomingDataStateStream == OFF){
		incomingDataStateStream = ON;
	} else {
		incomingDataStateStream = OFF;
	}

	qDebug("	MONITORING STREAM %i",incomingDataStateStream);
}


void QtGL2::toggleContrastOnOff() 
{
	if (contrastActivated == OFF){
		contrastActivated = ON;
	} else {
		contrastActivated = OFF;
	}

	resetContrastResults();

	qDebug("	CONTRAST ACTIVATION %i",contrastActivated);
}

void QtGL2::toggleHistogramOnOff() 
{
	if (histogramActivated == OFF){
		histogramActivated = ON;
	} else {
		histogramActivated = OFF;
	}
	qDebug("	HISTOGRAM ACTIVATION %i",histogramActivated);
}

void QtGL2::toggleCudaFilterOnOff() 
{

	if (filterActivated == OFF){
		filterActivated = ON;
	} else {
		filterActivated = OFF;
	}
	qDebug("	FILTER ACTIVATION %i",filterActivated);

	if (filterActivated == OFF){
		setKernelPassthrough();
		resetCudaResults();
	} else {
		restoreUserKernel();
		resetDetections();
	}
}

void QtGL2::toggleThreshConstOnOff() 
{
	if (threshConstActivated == OFF){
		threshConstActivated = ON;
	} else {
		threshConstActivated = OFF;
	}
	qDebug("	THRESHOLD CONST ACTIVATION %i",threshConstActivated);
}

void QtGL2::toggleThreshSigmaOnOff() 
{
	if (threshSigmaActivated == OFF){
		threshSigmaActivated = ON;
	} else {
		threshSigmaActivated = OFF;
	}
	qDebug("	THRESHOLD SIGMA ACTIVATION %i",threshSigmaActivated);
}

void QtGL2::toggleAutoOrient() 
{
	autoOrient++;
	autoOrient = autoOrient%2;
}

void QtGL2::toggleAutoOrientSnap() 
{
	autoOrientSnap++;
	autoOrientSnap = autoOrientSnap%2;
}

void QtGL2::updateEventTable(){

	if (eventTableNeedsUpdateFlag == ON){

		int detectsPushed = 0;

		for (int i=0; i< eventCount; i++){
			if (detectsPushed < numEventsQtPush){
				if (witEventRay[i].displayStatus == OFF){
					witEventRay[i].displayStatus = ON;

					thresholdDetected(&witEventRay[i]);
					detectsPushed++;
				}
			}
		}

		if (detectsPushed == 0){
			eventTableNeedsUpdateFlag = OFF;
		}
	}
}

float* QtGL2::interpolateLoc(int x, int y, WitFrame w){
	float latlon[2] = {0};

	int gx = x/w.gridX;
	int gy = y/w.gridY;

	int diffX = x-(gx*w.gridX);
	int diffY = y-(gy*w.gridY);

	float cornerRay[4][2];

	int gxi1 = gx;
	int gxi2 = gx+1;

	int gyi1 = gy;
	int gyi2 = gy+1;

	if (gxi2 < w.gridNumX && gyi2 < w.gridNumY){

		cornerRay[0][DIM_LON] = w.coordsLon[gxi1][gyi1];
		cornerRay[1][DIM_LON] = w.coordsLon[gxi1][gyi2];
		cornerRay[2][DIM_LON] = w.coordsLon[gxi2][gyi1];
		cornerRay[3][DIM_LON] = w.coordsLon[gxi2][gyi2];

		cornerRay[0][DIM_LAT] = w.coordsLat[gxi1][gyi1];
		cornerRay[1][DIM_LAT] = w.coordsLat[gxi1][gyi2];
		cornerRay[2][DIM_LAT] = w.coordsLat[gxi2][gyi1];
		cornerRay[3][DIM_LAT] = w.coordsLat[gxi2][gyi2];

		float xm = (float)diffX/(float)(w.gridX);
		float ym = (float)diffY/(float)(w.gridY);

		float xmc = 1.0 - xm;
		float ymc = 1.0 - ym;

		latlon[DIM_LON] = cornerRay[0][DIM_LON] *xmc *ymc + cornerRay[2][DIM_LON] *xm *ymc + cornerRay[1][DIM_LON] *xmc * ym + cornerRay[3][DIM_LON] * xm * ym;
		latlon[DIM_LAT] = cornerRay[0][DIM_LAT] *xmc *ymc + cornerRay[2][DIM_LAT] *xm *ymc + cornerRay[1][DIM_LAT] *xmc * ym + cornerRay[3][DIM_LAT] * xm * ym;
	}

	return latlon;
}



void QtGL2::keyPressEvent( QKeyEvent *e ){

	if (e->key() == Qt::Key_W){
		if (e->modifiers() == Qt::ShiftModifier){
			globeRotGoal[DIM_X] += globeRotSpeedKbFast;
		} else {
			globeRotGoal[DIM_X] += globeRotSpeedKb;
		}
	} else if (e->key() == Qt::Key_S){
		if (e->modifiers() == Qt::ShiftModifier){
			globeRotGoal[DIM_X] -= globeRotSpeedKbFast;
		} else {
			globeRotGoal[DIM_X] -= globeRotSpeedKb;
		}
	}  else if (e->key() == Qt::Key_A){
		if (e->modifiers() == Qt::ShiftModifier){
			globeRotGoal[DIM_Y] += globeRotSpeedKbFast;
		} else {
			globeRotGoal[DIM_Y] += globeRotSpeedKb;
		}
	} else if (e->key() == Qt::Key_D){
		if (e->modifiers() == Qt::ShiftModifier){
			globeRotGoal[DIM_Y] -= globeRotSpeedKbFast;
		} else {
			globeRotGoal[DIM_Y] -= globeRotSpeedKb;
		}
	} else if (e->key() == Qt::Key_Left){
		if (e->modifiers() == Qt::ShiftModifier){

		} else {
			advanceFrame(-1);
		}
	} else if (e->key() == Qt::Key_Right){
		if (e->modifiers() == Qt::ShiftModifier){

		} else {
			advanceFrame(1);
		}
	} else if (e->key() == Qt::Key_Space){
		if (e->modifiers() == Qt::ShiftModifier){

		} else {
			updateUiTogglePause();
		}		
	}  else if (e->key() == Qt::Key_R){
		if (e->modifiers() == Qt::ShiftModifier){

		} else {
			updateUiToggleReverse();
		}		
	} else if (e->key() == Qt::Key_H){
		if (e->modifiers() == Qt::ShiftModifier){

		} else {
			updateUiToggleHistogram();
		}		
	} else if (e->key() == Qt::Key_C){
		if (e->modifiers() == Qt::ShiftModifier){

		} else {
			updateUiToggleContrast();
		}		
	} else if (e->key() == Qt::Key_F){
		if (e->modifiers() == Qt::ShiftModifier){

		} else {
			updateUiToggleFilter();
		}		
	}  else if (e->key() == Qt::Key_T){
		if (e->modifiers() == Qt::ShiftModifier){

		} else {
			updateUiToggleThreshold();
		}		
	} else if (e->key() == Qt::Key_O){
		if (e->modifiers() == Qt::ShiftModifier){

		} else {
			updateUiToggleAutoOrient();
		}		
	} else if (e->key() == Qt::Key_V){
		if (e->modifiers() == Qt::ShiftModifier){

		} else {
			updateUiToggleExportVideo();
		}		
	} else if (e->key() == Qt::Key_Comma){
		if (e->modifiers() == Qt::AltModifier){
			
			scrollTimeline(1, fastScrollSpeed);
		} else {
			scrollTimeline(1, slowScrollSpeed);
		}		
	} else if (e->key() == Qt::Key_Period){
		if (e->modifiers() == Qt::AltModifier){
			scrollTimeline(-1, fastScrollSpeed);
		} else {
			scrollTimeline(-1, slowScrollSpeed);
		}		
	}

}


void QtGL2::mouseClickEvent(QMouseEvent *event) {
	qDebug("CLICK");

	int x = event->pos().x();
	int y = event->pos().y();

	if (histogramActivated == ON){
		if (x>histRenderX && x<histRenderX+histRenderW){
			if (y>histRenderY && y<histRenderY+histRenderH){
				qDebug("CLICK HIST");
			}
		}
	}
}

void QtGL2::mouseReleaseEvent(QMouseEvent *event) {

	mouseState = MOUSE_STATE_READY;
	mouseItem = STATUS_ERROR;
}

void QtGL2::mousePressEvent(QMouseEvent *event) {

	int x = event->pos().x();
	int y = viewH-event->pos().y();

	if (histogramActivated == ON){

		if (x>histRenderX && x<histRenderX+histRenderW){
			if (y>histRenderY && y<histRenderY+histRenderH){
				mouseState = MOUSE_STATE_DRAG_HIST;
				mouseItem = getNearestContrastCp(x, y);
			}
		}
	}
}

void QtGL2::mouseMoveEvent(QMouseEvent *event) {

	int x = event->pos().x();
	int y = viewH-event->pos().y();

	if (mouseState == MOUSE_STATE_DRAG_HIST){

		int xh = x-histRenderX;
		int yh = y-histRenderY;

		if (mouseItem != STATUS_ERROR){

			contrastCpVal[mouseItem] = (float)xh/(float)histRenderW;
			contrastCpOut[mouseItem] = (float)yh/(float)histRenderH;

			setContrastCpRastPos();
			resetContrastResults();
		}
	}
}

void QtGL2::enterEvent(QEvent *e){
	setFocus();
	grabKeyboard();
}

void QtGL2::leaveEvent(QEvent *e){

	releaseKeyboard();
}

void QtGL2::wheelEvent(QWheelEvent *event){

	float delta =  event->delta();

	float spDelta = 1.0f;

	if (abs(delta) > 200){
		spDelta = 1.1f;
	}
	if (abs(delta) > 400){
		spDelta = 1.2f;
	}
	if (abs(delta) > 500){
		spDelta = 1.7f;
	}

	if (delta < 0){
		globeZoomGoal /= (globeZoomSpeed*spDelta);
	} else if (delta > 0){
		globeZoomGoal *= (globeZoomSpeed*spDelta);
	}

	if (globeZoomGoal < globeZoomMin){
		globeZoomGoal = globeZoomMin;
	}
	if (globeZoomGoal > globeZoomMax){
		globeZoomGoal = globeZoomMax;
	}
}


void QtGL2::mainLoop(){

	while (true){

		int64_t timeDeltaBackend(backendDelayMs); // !! todo make timers for draw vs anim

		timeBackend1 = microsec_clock::local_time();
		time_duration diffBackend = timeBackend1 - timeBackend2;

		if (diffBackend.total_milliseconds()>timeDeltaBackend){

			timeBackend2=timeBackend1;

			int tCheck = threadsReady = getCountThread(STATUS_READY);

			if (tCheck > 0){
				if (incomingDataStateArchive == ON){
					//createLoadMetaTasks();
					createLoadDataTasks();
					updateLoadStatus();
				} else if (incomingDataStateStream == ON){
					createListenerTasks();
				} 
			}

			manageThreads();

			// update event table
			updateEventTable();
			update(); 
		}

		// end backend

		int64_t timeDeltaDraw(drawDelayMs);

		timeDraw1 = microsec_clock::local_time();
		time_duration diffDraw = timeDraw1 - timeDraw2;

		if (diffDraw.total_milliseconds()>timeDeltaDraw){
			
			renderLatencyOutputCount--;
			renderLatencyAve += renderLatencyWeight*diffDraw.total_milliseconds();

			if (renderLatencyOutputCount<=0){
				renderLatencyOutputCount = renderLatencyOutputStartVal;

				string diffRenderTimeStr = boost::lexical_cast<std::string>(renderLatencyAve);
				renderLatencyAve =0;
			}

			if (autoOrient == ON){
				globeRotGoal[DIM_Y]+=1.2;
				globeRotGoal[DIM_X] = globeRotDataLast[DIM_X];
				globeRotGoal[DIM_Y] = globeRotDataLast[DIM_Y];
			}

			globeZoom = globeZoomAnimRate*globeZoomGoal+ (1.0f-globeZoomAnimRate)*globeZoom;

			if (autoOrientSnap == ON){
				for (int k=0; k<3; k++){
					globeRot[k] = globeRotGoal[k];
				}
			} else {// animate goal-to-current globe rotation
				for (int k=0; k<3; k++){
					globeRot[k] = globeRotAnimRate*globeRotGoal[k]+ (1.0f-globeRotAnimRate)*globeRot[k];
				}
			}

			for (int k=0; k<3; k++){
				if (globeRot[k]>360.0){
					globeRot[k]-=360.0;
				}
			}
			update(); // trigger paintGL

			string pbfStr;
			
			//if (testMode == ON){ // iterate for regression testing and benchmarking
			//	if (testStep <= 0){

			//		kcSelected++;
			//		if (kcSelected >= kcSelectMax){
			//		kcSelected = 0;
			//		}
			//		resetCudaResults();
			//		testStep = testStepInit;
			//	}
			//	testStep--;
			//}

			string diffStr = boost::lexical_cast<std::string>(diffDraw.total_milliseconds());
			
			timeDraw2=timeDraw1;

			// animate the user interface widgets

			if (abs(timeUserScrollGoal-timeUserScroll) > .1f){
				timeUserScroll = (1.0f-animRateUs)*timeUserScroll + (animRateUs)*timeUserScrollGoal;
			}
			// end animation user elements 

			const unsigned char color[] = {255,0,0};

			for (int i=0; i<TOTAL_SENSORS; i++){
				for (int j=0; j<TOTAL_SCAS; j++){
					if (wfIndexRay[i][j] != STATUS_ERROR){
			if (witFrameRay[wfIndexRay[i][j]].frameStatus[MODE_LOAD] == STATUS_COMPLETE_IO && witFrameRay[wfIndexRay[i][j]].frameStatus[MODE_CUDA_FILTER_T] == STATUS_READY){
				witFrameRay[wfIndexRay[i][j]].setModeStatus(MODE_CUDA_FILTER_T, STATUS_WORKING);

				const int w = witFrameRay[0].w;
				const int h = witFrameRay[0].h;

				ptime timeProc1 = microsec_clock::local_time();

				outputResultFlag = 1;
			
				int * rgb = new int[3];
				int * rgbPrev = new int[3];

				int offsetRes = timeBufferIndex*numPc;

				for (int y=0; y<numPy; y++){
					for (int x=0; x<numPx; x++){

						int loc = (offsetRes)+(y*numPx)+x;
						// copy for upload to the device
						aPxy[loc] = witFrameRay[wfIndexRay[i][j]].dataSrc[x][y];

					}
				}

				qDebug("PROCESSING FRAME %i",wfIndexRay[i][j]);
				cudaError_t cudaStatus = addWithCudaO(resPxy, aPxy, kc_user, ptr_res, ptr_a, ptr_kc, numPx, numPy, numT, timeBufferIndex, tpb, kcContrast);

				qDebug("CUDA COMPLETED %i",wfIndexRay[i][j]);
				// copy back to the host frames

				// determine frame stats
				
				double stdDev = 0;
				double variance = 0;
				double mean = 0;
				double mad = 0;
				double median = 0;
				double q1 = 0;
				double q3 = 0;
				int validPxCount = 0;
				if (threshSigmaActivated == ON){
					float ml =0;
					for (int y=0; y<numPy; y++){
						for (int x=0; x<numPx; x++){
							int loc = (y*numPx)+x;
							float valNorm = resPxy[loc];

							sigmaPxy[validPxCount] = valNorm;
							if (valNorm != 0){ // only use varying pixels to generate statistics
								validPxCount++;
							}

							if (valNorm > 1) valNorm = 1;

							if (valNorm < 0) valNorm = 0;

							mean += (valNorm);

						}
					}
					mean /= validPxCount;
					mean *= normConstScale;

					float varAccum = 0;

					for (int y=0; y<numPy; y++){
						for (int x=0; x<numPx; x++){
							int loc = (y*numPx)+x;
							float valNorm = resPxy[loc];
							float val = valNorm*normConstScale;
							varAccum += (val-mean)*(val-mean);
						}
					}

					variance = varAccum/validPxCount;
					stdDev = pow(variance,.5);


					for (int y=0; y<numPy; y++){
						for (int x=0; x<numPx; x++){
							int loc = (y*numPx)+x;
							float valNorm = resPxy[loc];

							sigmaPxy[loc] = abs((double)(resPxy[loc])-mean)/stdDev;
						}
					}
				}
				witFrameRay[wfIndexRay[i][j]].stdDev = stdDev;
				witFrameRay[wfIndexRay[i][j]].variance = variance;

				// end frame stats
				

				float radius1 = globeRadius;
				float radius2 = 0;

				bool andFlag = OFF;
				if (threshConstActivated == ON && threshSigmaActivated == ON){
					andFlag = ON;
				}

				for (int y=0; y<numPy; y++){
					for (int x=0; x<numPx; x++){
						int loc = (y*numPx)+x;
						float valNorm = (float)resPxy[loc];
						float val = (valNorm*normConstScale);
						witFrameRay[wfIndexRay[i][j]].dataRes[loc] = valNorm;

						float valSig = sigmaPxy[loc];

						if (eventCount<numEvents && filterActivated == ON){

							if ((valNorm >= detectThreshConst && threshConstActivated == ON)){ // only show stats, don't trigger on stats
							
								float *latlon = interpolateLoc(x,y, witFrameRay[wfIndexRay[i][j]]);
								witEventRay[eventCount].lon = latlon[DIM_LON];
								witEventRay[eventCount].lat = latlon[DIM_LAT];

								witEventRay[eventCount].renderPoint1[DIM_X] = getLatLonX(radius1, witEventRay[eventCount].lat, witEventRay[eventCount].lon);
								witEventRay[eventCount].renderPoint1[DIM_Y] = getLatLonY(radius1, witEventRay[eventCount].lat, witEventRay[eventCount].lon);
								witEventRay[eventCount].renderPoint1[DIM_Z] = getLatLonZ(radius1, witEventRay[eventCount].lat, witEventRay[eventCount].lon);

								int watchFlag = ON; // by default watch all, reject none
								int rejectFlag = OFF;

								if (regionRejectActivated == ON){
									for (int i=0; i<rejectVertexLists.numVertices; i++){
										float dx = rejectVertexLists.vertexList[i].coordX-witEventRay[eventCount].renderPoint1[DIM_X];
										float dy = rejectVertexLists.vertexList[i].coordY-witEventRay[eventCount].renderPoint1[DIM_Y];
										float dz = rejectVertexLists.vertexList[i].coordZ-witEventRay[eventCount].renderPoint1[DIM_Z];
										float dist = dx*dx + dy*dy + dz*dz;

										if (dist <=	 regionRejectRadius*regionRejectRadius){
											rejectFlag = ON;
										}
									}
								}

								if (regionWatchActivated == ON){
									for (int i=0; i<watchVertexLists.numVertices; i++){
										float dx = watchVertexLists.vertexList[i].coordX-witEventRay[eventCount].renderPoint1[DIM_X];
										float dy = watchVertexLists.vertexList[i].coordY-witEventRay[eventCount].renderPoint1[DIM_Y];
										float dz = watchVertexLists.vertexList[i].coordZ-witEventRay[eventCount].renderPoint1[DIM_Z];
										float dist = dx*dx + dy*dy + dz*dz;

										if (dist > regionWatchRadius*regionWatchRadius){
											watchFlag = OFF;
										}
									}
								}

								if (watchFlag == ON && rejectFlag == OFF){

									if (valNorm > detectConstCurrMax){
										detectConstCurrMax = valNorm;
									}
									if (valNorm < detectConstCurrMin){
										detectConstCurrMin = valNorm;
									}

									if (valSig > detectSigmaCurrMax){
										detectSigmaCurrMax = valSig;
									}
									if (valSig < detectSigmaCurrMin){
										detectSigmaCurrMin = valSig;
									}

									witEventRay[eventCount].pxX = x;
									witEventRay[eventCount].pxY = y;
									witEventRay[eventCount].timeSecOfDay = witFrameRay[wfIndexRay[i][j]].secsOfDay;
									witEventRay[eventCount].valFilter = valNorm;
									witEventRay[eventCount].valRaw = val;

									if (threshSigmaActivated == ON){
										witEventRay[eventCount].valSigma = valSig;
									} else {
										witEventRay[eventCount].valSigma = 0;
									}

									witEventRay[eventCount].frameId = wfIndexRay[i][j];
									witEventRay[eventCount].eventDetectId = eventUid;

									witEventRay[eventCount].displayStatus = OFF; 

									if (threshConstActivated){
										radius2 = globeRadius*1.001f + (witEventRay[eventCount].valFilter*.05f);
									} else if (threshSigmaActivated){
										radius2 = globeRadius*1.001f + (witEventRay[eventCount].valSigma*.05f* (1.0f/(float)detectSigmaCurrMax)); // normalize to 6 sigma
									}							

									witEventRay[eventCount].renderPoint2[DIM_X] = getLatLonX(radius2, witEventRay[eventCount].lat, witEventRay[eventCount].lon);
									witEventRay[eventCount].renderPoint2[DIM_Y] = getLatLonY(radius2, witEventRay[eventCount].lat, witEventRay[eventCount].lon);
									witEventRay[eventCount].renderPoint2[DIM_Z] = getLatLonZ(radius2, witEventRay[eventCount].lat, witEventRay[eventCount].lon);

									witEventRay[eventCount].eventReviewStatus = EVENT_REVIEW_STATUS_UNKNOWN;

									eventCount++;
									eventUid++;

									eventTableNeedsUpdateFlag = ON;

								}
							}
						}
				}
				}
				
				
					if (threshSigmaActivated == ON){
						qDebug("   FRAME STATS: STDDEV %f VAR %f MEAN %f SIG-MAX %f", stdDev, variance, mean, detectSigmaCurrMax );
					}
				
				

				ptime timeProc2 = microsec_clock::local_time();

				timeProcGlobalStopPrev = timeProcGlobalStop;
				timeProcGlobalStop = timeProc2;

				time_duration diffProc = timeProc2 - timeProc1;

				string diffProcStr = boost::lexical_cast<std::string>(diffProc.total_milliseconds());
				
				string timeslotStr = boost::lexical_cast<std::string>(timeBufferIndex);
				string numTStr = boost::lexical_cast<std::string>(numT);
				

						witFrameRay[wfIndexRay[i][j]].setModeStatus(MODE_CUDA_FILTER_T, STATUS_COMPLETE_CUDA_T);
					
				timeBufferIndex++;

				if (timeBufferIndex>=numT){
					timeBufferIndex=0;
				}
			}
			}
			}
			}

			time_duration diffProcGlobal = timeProcGlobalStop - timeProcGlobalStart;
			time_duration diffProcStop = timeProcGlobalStop - timeProcGlobalStopPrev;
			string diffProcGlobalStr = boost::lexical_cast<std::string>(diffProcGlobal.total_milliseconds());
			
			if (diffProcStop.total_milliseconds() != 0 && outputResultFlag == 1){
				outputResultFlag = 0;
				diffProcStop = diffProcGlobal; 

				qDebug("CUMULATIVE PROCESSING TIME: %s", diffProcGlobalStr);
			}
		}

		// timeline logic

		int64_t timeDeltaAnim(animDelayMs); // !! todo make timers for draw vs anim

		timeAnim1 = microsec_clock::local_time();
		time_duration diffAnim = timeAnim1 - timeAnim2;

		if (diffAnim.total_milliseconds()>timeDeltaAnim && playback == ON){
			if (playback == ON && playbackPaused == OFF){

				advanceFrame(playbackDirection);

				string timeStr = boost::lexical_cast<std::string>(playheadSecsOfDay);
				
				// fallback frames
				for (int a=0; a<TOTAL_SENSORS; a++){
					for (int b=0; b<TOTAL_SCAS; b++){
						if (wfIndexRay[a][b] != STATUS_ERROR){

					if (witFrameRay[wfIndexRay[a][b]].frameStatus[MODE_LOAD] == STATUS_COMPLETE_IO){
						int sparseX = witFrameRay[wfIndexRay[a][b]].gridNumX/2;
						int sparseY = witFrameRay[wfIndexRay[a][b]].gridNumY/2;
						globeRotDataLast[DIM_Y] = 90-witFrameRay[wfIndexRay[a][b]].coordsLon[sparseX][sparseY] +2;
						globeRotDataLast[DIM_X] = witFrameRay[wfIndexRay[a][b]].coordsLat[sparseX][sparseY] +5 ;
					}

					}
					}
				}

				timeAnim2=timeAnim1;
			}
		}
	} // end infinite while
}

// advance in direction by numSeconds indicated by speed
void QtGL2::scrollTimeline(int dir, int speed){
	timeUserScrollGoal += speed*dir;
	
	if (timeUserScrollGoal> timeUserScrollMax){
		timeUserScrollGoal = timeUserScrollMax;
	}
	if (timeUserScrollGoal< timeUserScrollMin){
		timeUserScrollGoal = timeUserScrollMin;
	}
	qDebug("SCROLL POS: %f", timeUserScrollGoal);
	
}

void QtGL2::advanceFrame(int dir){
	playheadSecsOfDay += (timeStep*dir);
	playheadSecsOfDay = checkTimeBounds(playheadSecsOfDay);

	for (int i=0; i<TOTAL_SENSORS; i++){
		for (int j=0; j<TOTAL_SCAS; j++){
			wfIndexRay[i][j] = getFrameAtTime(playheadSecsOfDay, i,j, scanDir[i], 0);
		}
	}

	
	findFallbackFrames();
}

void QtGL2::runSystem() 
{

	qDebug("STARTING SYSTEM");

	
	prepEventList();
	prepFrames();
	allocFrameData();
	prepGpuResources();
	prepProcessing();
	setKernelPreset(kcSelected);
	setKernelPassthrough();
	
	loadMap(mapDataDir, mapSparseness);
		
	boost::thread *GUIThread;
	GUIThread = new boost::thread(&QtGL2::mainLoop, this);
	
}

void QtGL2::resetThreads(void){ 

	for (int i=0; i<threadPoolSize; i++){
		witThreadRay[i].threadStatus = STATUS_READY;
		witThreadRay[i].threadId = i;
	}
}

void QtGL2::manageThreads(void){
	//qDebug("MANAGE THREADS");
	getCompletedThreads();

	threadsActive = getCountThread(STATUS_WORKING);
	threadsQueued = getCountThread(STATUS_QUEUED);
	threadsReady = getCountThread(STATUS_READY);
	string activeStr = boost::lexical_cast<std::string>(threadsActive);

	if (threadsActive == threadsMaxActive){
		//cout<<"MAX THREADS ACTIVE"<<endl;
	}

	// return complete to ready (return to pool)
	while (getCountThread(STATUS_COMPLETE_THREAD) > 0){

		int tid = getNextThread(STATUS_COMPLETE_THREAD);
		qDebug("   RECLAIM THREAD %i", tid);
		witThreadRay[tid].threadStatus = STATUS_READY;

		// only purge scratch items after encoding is complete
		if (witThreadRay[tid].mode == MODE_FFMPEG_EXPORT){
			deleteFfmpegScratchFiles();
		}
	}

	// dispatch queued threads
	while (getCountThread(STATUS_QUEUED) > 0 && threadsActive< threadsMaxActive){
		int tid = getNextThread(STATUS_QUEUED);
		qDebug("   STARTED THREAD %i",tid);

		
		witThreadRay[tid].threadStatus = STATUS_WORKING;
		witThreadRay[tid].prepThread();//bt = new boost::thread(&WitThread::load, witThreadRay[tid]);

		threadsActive++;// = getCountThread(STATUS_WORKING);

		string itemStr = boost::lexical_cast<std::string>(tid);
		//cout<<"STARTED THREAD "+itemStr<<endl;
	}
}

void QtGL2::getCompletedThreads(){

	int count = 0;
	boost::posix_time::time_duration timeout = boost::posix_time::milliseconds(1); 

	// qDebug("CHECK STATUS THREAD");
	for (int i=0; i<threadPoolSize;i++){
		if (witThreadRay[i].threadStatus == STATUS_WORKING){
			if (witThreadRay[i].bt->timed_join(timeout) == true){
				qDebug("	RETURN THREAD %i",i);
				witThreadRay[i].threadStatus = STATUS_COMPLETE_THREAD;
			}
		}
	}
}

int QtGL2::getCountThread(int state){
	int count = 0;

	for (int i=0; i<threadPoolSize;i++){
		if (witThreadRay[i].threadStatus == state){
			count++;
		}
	}
	return count;
}

int QtGL2::getNextThread(int state){
	int threadId = STATUS_ERROR; //in case no threads are free

	float timestampMin = SECS_IN_DAY;

	// look for next thread to dispatch in desired STATE, find thread associated with earlier time to preserve proper queue order
	for (int i=0; i<threadPoolSize;i++){
		if (witThreadRay[i].threadStatus == state){// && threadId == STATUS_ERROR){
			if (witThreadRay[i].secsOfDay < timestampMin){
				threadId = i;
				timestampMin = witThreadRay[i].secsOfDay;
			}
		}
	}
	return threadId; 
} 

int QtGL2::getNextFrame(int mode, int state){
	int frameId = STATUS_ERROR;				// in case no threads are free
	
	for (int i=0; i<numFrames; i++){
		if (witFrameRay[i].frameStatus[mode] == state){// && threadId == STATUS_ERROR){
			frameId = i;
			i=numFrames;
		}
	}
	return frameId;
}

void QtGL2::createListenerTasks(void){

}

void QtGL2::createFFmpegExportTask(void){

	int tid = getNextThread(STATUS_READY);

	if (tid != STATUS_ERROR){
		witThreadRay[tid].params = new string[2];
		witThreadRay[tid].params[0] = vid_scratch_dir;
		witThreadRay[tid].params[1] = vid_path_export;
		witThreadRay[tid].mode = MODE_FFMPEG_EXPORT;
		witThreadRay[tid].threadStatus = STATUS_QUEUED;
	}
}

void QtGL2::updateLoadStatus(void){
	for (int k=0; k<framesUsed; k++){
		if (witFrameRay[k].frameStatus[MODE_LOAD] == STATUS_COMPLETE_IO){
	
		if (witFrameRay[k].segSecs > timeUserMax){
			timeUserMax = witFrameRay[k].segSecs;
		}
		if (witFrameRay[k].segSecs < timeUserMin){
			timeUserMin = witFrameRay[k].segSecs;
		}
	
		timeUserScrollGoal = -timeUserMax+300;
		}
	}					
}

void QtGL2::createLoadMetaTasks(void){
	// if data monitor is on, append timeline with add'l file extents

	// 
}

void QtGL2::createLoadDataTasks(void){
	
	// This function first surveys the directory and creates a list of files
	// Secondly tasks are configured to load each file

	if (fileScanStatus == STATUS_READY){
	
	QDir myDirPng(vid_path.c_str());
	QDir myDirH5(vid_path.c_str());
	QDir myDirAll(vid_path.c_str());
	
	QStringList filterH5;
	QStringList filterPng;
    filterH5 << "*.h5";
    filterPng << "*.png";

    myDirPng.setNameFilters(filterPng);
    myDirH5.setNameFilters(filterH5);

	myDirH5.setSorting(QDir::LocaleAware | QDir::Name);
	myDirPng.setSorting(QDir::LocaleAware | QDir::Name);
	
	listPng = myDirPng.entryList (QDir::Files);
	listH5 = myDirH5.entryList (QDir::Files);
	listAll = myDirAll.entryList (QDir::Files);

	qDebug("Scanning dir %s ... H5 file count: %i  ... PNG file count: %i ... total files: %i",vid_path.c_str(), listH5.size(),listPng.size(),listAll.size());

	if (listH5.size() > listPng.size()){
		fileType = FILE_INPUT_H5;
	}

	if (fileType == FILE_INPUT_PNG){
		frameType = ".png";
	} else if (fileType == FILE_INPUT_H5){
		frameType = ".h5";
	} 

	int framesPlanned = 0;
	int loc = -1;

	int sensor = 0;
	int chip = 0;
	
	for (int i=0; i<listAll.size(); i++){

			if (framesPlanned < numFrames){

				string fileStr = "";
				if (fileType == FILE_INPUT_PNG){

					string fnHint = ("_"+boost::lexical_cast<std::string>(framesPlanned+1)+".png");//"_"+framesPlanned;
					QString qfnHint(fnHint.c_str());
					
					loc=-1;

					for (int a=0; a<listPng.size(); a++){
						if (listPng.at(a).contains(qfnHint)){
							loc = a;
						}
					}

					if (loc != -1){ 
						fileStr = listPng.at(loc).toStdString();
					}

				} else if (fileType == FILE_INPUT_H5){
					
				}

				if (loc != -1){
					if (witFileRay[i].fileStatus[MODE_LOAD] == STATUS_READY){
						witFileRay[i].fileStatus[MODE_LOAD] = STATUS_QUEUED;
					
						finalFramePath = vid_path+fileStr;

					witFileRay[i].sensorId = sensor;
					witFileRay[i].chipId = chip;

					witFileRay[i].secsStart = 0;
					witFileRay[i].secsStop = 200;
				
					witFileRay[i].fileName = finalFramePath;
					witFileRay[i].setModeStatus(MODE_LOAD, STATUS_QUEUED);
					witFileRay[i].dataFileType = fileType;

					if (fileType == FILE_INPUT_H5){

					} else if (fileType == FILE_INPUT_PNG){
						witFileRay[i].frameCount = 1;
					}
					witFileRay[i].wframeSeq = new WitFramePtr[witFileRay[i].frameCount];
					
					qDebug("     FRAMES/FILE: %i SENSOR/SCA: %i/%i", witFileRay[i].frameCount, sensor,chip);

					framesPlanned+=witFileRay[i].frameCount;

					qDebug("     QUEUED ITEM %s", witFileRay[i].fileName.c_str());

					}
				}
			}
	}

	fileScanStatus = STATUS_COMPLETE_IO;

	}
	
	// reserve frames
	for (int i=0; i<numFiles; i++){
		if (witFileRay[i].fileStatus[MODE_LOAD] == STATUS_QUEUED){
		qDebug("     RESERVE FRAMES FOR FILE %i - %s ", i, witFileRay[i].fileName.c_str());
		for (int j=witFileRay[i].numReservedFrames; j<witFileRay[i].frameCount; j++){
			
			int k = getNextFrame(MODE_LOAD, STATUS_READY);
			
				if (k != STATUS_ERROR){
					if (framesUsed < numFrames){
						
						witFrameRay[k].setModeStatus(MODE_LOAD, STATUS_QUEUED);
						witFileRay[i].wframeSeq[j] = &witFrameRay[k]; // !!
						witFileRay[i].numReservedFrames = j+1;
						framesUsed++;
					}
				}
		}
		}
	}
	// end reserve frames

	// load specific frames
	for (int i=0; i<numFiles; i++){

		int tid = STATUS_ERROR;

		if (witFileRay[i].fileStatus[MODE_LOAD] == STATUS_QUEUED){
			witFileRay[i].fileStatus[MODE_LOAD] = STATUS_WORKING;

			tid = getNextThread(STATUS_READY);

			if (tid != STATUS_ERROR){

				qDebug("     CREATE TASK TO LOAD FILE %i FRAMES %i THREAD %i - %s",i,witFileRay[i].numReservedFrames, tid, finalFramePath.c_str());
				
				witThreadRay[tid].wfile = &witFileRay[i];

				float timeStamp=0;

				if (fileType == FILE_INPUT_PNG){
					float timeStamp = (float)(i)*PNG_DEFAULT_FRAME_RATE; // fake timestamps until meta/filename is used
					string timeStampStr = boost::lexical_cast<std::string>(timeStamp);
					for (int a =0; a<witFileRay[i].numReservedFrames; a++){
						witFileRay[i].wframeSeq[a]->setModeStatus(MODE_LOAD, STATUS_WORKING);
						witFileRay[i].wframeSeq[a]->fileName = witFileRay[i].fileName;
						witFileRay[i].wframeSeq[a]->dataFileType = fileType;
						witFileRay[i].wframeSeq[a]->secsOfDay = timeStamp;
						witFileRay[i].wframeSeq[a]->sensorId = 2;
						witFileRay[i].wframeSeq[a]->w = numPx;
						witFileRay[i].wframeSeq[a]->h = numPy;
					}

					if (timeStamp > timeUserMax){
						timeUserMax = timeStamp;
					}
				} else if (fileType == FILE_INPUT_H5){
					
				}
				
				qDebug("        QUEUED FILE %i",i);
				
			}
			}	

		// HDF threads
		if (tid != STATUS_ERROR && witFileRay[i].fileStatus[MODE_LOAD] == STATUS_WORKING){
			witThreadRay[tid].mode = MODE_LOAD;
			witThreadRay[tid].threadStatus = STATUS_QUEUED;
			qDebug("     QUEUED THREAD %i",tid);
		}
		// end HDF threads
	}

		
}

void QtGL2::setupItems(){

	histRenderX = 20;
	histRenderY = 140;

	histRenderW = viewW -2*histRenderX -QT_DOCK_WIDGET_W;
	histRenderH = viewH/6;

	winSizeW = viewW -QT_DOCK_WIDGET_W;
	winSizeH = viewH;

}

void QtGL2::initializeGL() {

	glShadeModel(GL_SMOOTH);							// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations

}

void QtGL2::resizeGL(int w, int h) {

	if (h==0)										// Prevent A Divide By Zero By
	{
		h=1;										// Making Height Equal One
	}

	glViewport(0,0,w,h);							// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0f,(float)w/(float)h,0.1f,100.0f);

	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();	
}

float QtGL2::getLatLonX(float radius, float lat, float lon){

	float latRad = (float)(lat* pi  / 180.0f);
	float lonRad = (float)(lon* pi  / 180.0f);
	float x= (float)(-radius* cos(latRad) * cos(lonRad));

	return x;
}

float QtGL2::getLatLonY(float radius, float lat, float lon){

	float latRad = (float)(lat* pi  / 180.0f);
	float y= (float)(radius* sin(latRad));

	return y;
}

float QtGL2::getLatLonZ(float radius, float lat, float lon){

	float latRad = (float)(lat* pi  / 180.0f);
	float lonRad = (float)(lon* pi  / 180.0f);
	float z= (float)(radius* cos(latRad) * sin(lonRad));

	return z;
}

float* QtGL2::getContrastFromVal(float v){
	float contrast[] = {0.0f,0.0f,1.0f};

	float mix1;
	float mix2;

	int col1;
	int col2;

	int maxFcSlot = fcRampSlots[fcSelected]-1;

	for (int i=0; i< fcRampSlots[fcSelected]; i++){
		if (contrastCpActive[i] == ON){
			if (v >= contrastCpVal[i]){
				col1 = i;
				col2 = i+1;
			} else {
				i = contrastNumCp;
			}
		}
	}

	// saturation case
	if (col2 == maxFcSlot){
		col2 = col1;
	}

	if (col1 < 0) col1 = 0;
	if (col2 < 0) col2 = 0;
	if (col1 > maxFcSlot) col1 = maxFcSlot;
	if (col2 > maxFcSlot) col2 = maxFcSlot;

	float delta1 = abs(v-contrastCpVal[col1]);
	float delta2 = abs(contrastCpVal[col2]-v);

	mix1 = delta2/contrastCpVal[col2];
	mix2 = 1.0-mix1;

	float weightedOut = mix1*contrastCpOut[col1]+mix2*contrastCpOut[col2];

	float slotW = 1.0f/(float)fcRampSlots[fcSelected];
	
	float fcol1Weight = abs(weightedOut-(col1*slotW));
	float fcol2Weight = abs(weightedOut-(col2*slotW));

	float fdeltaSum = fcol1Weight+fcol2Weight;

	float fmix1 = fcol2Weight/fdeltaSum;
	float fmix2 = 1.0 - fmix1;

	for (int k=0; k<3; k++){
		contrast[k] = fmix1*fcRamps[fcSelected][col1][k]+fmix2*fcRamps[fcSelected][col2][k];
	}
	
	return contrast;
}

float* QtGL2::crossProd(float *vec1, float *vec2){
	float res[3] = {0,0,0};

	res[DIM_X] = vec1[DIM_Y]*vec2[DIM_Z]-vec1[DIM_Z]*vec2[DIM_Y];
	res[DIM_Y] = vec1[DIM_Z]*vec2[DIM_X]-vec1[DIM_X]*vec2[DIM_Z]; 
	res[DIM_Z] = vec1[DIM_X]*vec2[DIM_Y]-vec1[DIM_Y]*vec2[DIM_X]; 

	return res;
}


float QtGL2::dotProd(float *vec1, float *vec2){
	float res = 0;

	for (int i=0; i<3; i++){
		res += vec1[i]*vec2[i];
	}

	return res;
}

int  QtGL2::drawGLScene(GLvoid)									// Here's Where We Do All The Drawing
{
	
	float colorUiBlue[] = {0.0f,0.0f,1.0f};
	float colorUiDarkBlue[] = {0.0f,0.0f,.5f};
	float colorUiGreen[] = {0.0f,1.0f,0.0f};
	float colorUiBrightBlue[] = {0.0f,.40f,1.0f};
	float colorUiBrightestBlue[] = {0.0f,.8f,1.0f};
	float colorUiGray[] = {0.35f,0.420f,0.40f};
	float colorUiMedGray[] = {0.2f,0.250f,0.22f};
	float colorUiDarkGray[] = {0.15f,0.15f,0.15f};
	float colorUiWhite[] = {1.0f,1.0f,1.0f};
	float colorUiBlack[] = {0.0f,0.0f,0.0f};
	float colorUiOrange[] = {1.0f,0.5f,0.0f};
	float colorUiRed[] = {0.6f,0.0f,0.0f};
	float colorUiRedBright[] = {1.0f,0.0f,0.0f};
	float colorUiBlackOverlay[] = {0.0f,0.0f,0.0f,0.7f};

	float globeDepth = -7.0f;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear Screen And Depth Buffer

	glLoadIdentity();									// Reset The Current Modelview Matrix
	glTranslatef(0.0f,0.0f,globeDepth);						// Move Right 1.5 Units And Into The Screen 7.0

	glRotatef(globeRot[DIM_X],1.0f,0.0f,0.0f);
	glRotatef(globeRot[DIM_Y],0.0f,1.0f,0.0f);
	glRotatef(globeRot[DIM_Z],0.0f,0.0f,1.0f);

	//glRotatef(rquad,0.0f,1.0f,0.0f);					// Rotate The Quad On The X axis ( NEW )
	glScalef(globeZoom, globeZoom, globeZoom);

	// BEGIN GLOBE

	int prevGlobeStatus = globeDrawStatus;
	//qDebug("	STATUS GLOBE %i ",globeDrawStatus);
	if (globeDrawStatus == STATUS_READY){

		globeIndex = glGenLists(1);

		glNewList(globeIndex, GL_COMPILE);

		for (int i=0; i<numGlobeLists; i++){
			glBegin(GL_LINES);
			if (globeVertexLists[i].type == 0){ // BDY
				glColor3f(0.0f,1.0f,0.0f);
			} else if (globeVertexLists[i].type == 1){ // CIL
				glColor3f(0.0f,0.0f,1.0f);
			} else if (globeVertexLists[i].type == 2){ // RIV
				glColor3f(0.0f,0.0f,1.0f);
			}  

			int step = 1;
			for (int j=0; j<globeVertexLists[i].numVertices-step; j+=step){
				glVertex3f(globeVertexLists[i].vertexList[j].coordX,globeVertexLists[i].vertexList[j].coordY,globeVertexLists[i].vertexList[j].coordZ);
				glVertex3f(globeVertexLists[i].vertexList[j+1].coordX,globeVertexLists[i].vertexList[j+1].coordY,globeVertexLists[i].vertexList[j+1].coordZ);
			}	
			glEnd();
		}
		glEndList();

		globeDrawStatus = STATUS_COMPLETE_GL;
		qDebug("	CREATED GLOBE LIST");
	} else if (globeDrawStatus == STATUS_COMPLETE_GL){	
		
		glCallList(globeIndex);
	}

	// END GLOBE

	// overlay watch / reject regions

	glColor3f(0.0f,1.0f,0.0f);
	// watch vertices
	glBegin(GL_POINTS);
	int step = 1;
	if (regionWatchDrawStatus == STATUS_COMPLETE_GL && regionWatchActivated == ON){
		for (int j=0; j<watchVertexLists.numVertices; j+=step){
			glVertex3f(watchVertexLists.vertexList[j].coordX,watchVertexLists.vertexList[j].coordY,watchVertexLists.vertexList[j].coordZ);
		}
	}
	glEnd();
	// watch radii
	glBegin(GL_LINES);
	if (regionWatchDrawStatus == STATUS_COMPLETE_GL && regionWatchRadiusActivated == ON){
		for (int j=0; j<watchRadiusVertexLists.numVertices; j+=step){
			glVertex3f(watchRadiusVertexLists.vertexList[j].coordX,watchRadiusVertexLists.vertexList[j].coordY,watchRadiusVertexLists.vertexList[j].coordZ);
		}
	}
	glEnd();
	glColor3f(1.0f,.6f,0.0f);

	// reject vertices
	glBegin(GL_POINTS);
	if (regionRejectDrawStatus == STATUS_COMPLETE_GL && regionRejectActivated == ON){
		for (int j=0; j<rejectVertexLists.numVertices; j+=step){
			glVertex3f(rejectVertexLists.vertexList[j].coordX,rejectVertexLists.vertexList[j].coordY,rejectVertexLists.vertexList[j].coordZ);
		}
	}
	glEnd();

	// reject radii - needs fixing
	if (regionRejectDrawStatus == STATUS_COMPLETE_GL && regionRejectRadiusActivated == ON){
		for (int i=0; i<rejectVertexLists.numVertices; i++){
			glPushMatrix();


			glTranslatef(rejectVertexLists.vertexList[i].coordX,rejectVertexLists.vertexList[i].coordY,rejectVertexLists.vertexList[i].coordZ);

			//glRotatef(90,0.0f,1.0f,0.0f);

			//RotationAxis = cross(N, N')
			//RotationAngle = dot(N, N') / (|N| * |N'|)

			float start[3] = {0,0,1};
			//float start[3] = {0,1,0};

			float* rotAxis;
			float rotAngle;

			float vec2[3] = {0,0,0}; 
			vec2[DIM_X] = rejectVertexLists.vertexList[i].coordX;
			vec2[DIM_Y] = rejectVertexLists.vertexList[i].coordY;
			vec2[DIM_Z] = rejectVertexLists.vertexList[i].coordZ;

			float degToRad = pi/180.0f;
			float radToDeg = 180.0f/pi;

			rotAxis = crossProd(start, vec2);
			rotAngle = dotProd(start,vec2);

			// convert to deg
			rotAngle *= radToDeg;

			glRotatef(rotAngle,rotAxis[DIM_X],rotAxis[DIM_Y],rotAxis[DIM_Z]);

			glScalef(regionRejectRadius,regionRejectRadius,regionRejectRadius);


			glBegin(GL_LINE_STRIP);
			for (int j=0; j<rejectRadiusVertexLists.numVertices; j+=step){
				glVertex3f(rejectRadiusVertexLists.vertexList[j].coordX,rejectRadiusVertexLists.vertexList[j].coordY,rejectRadiusVertexLists.vertexList[j].coordZ);
			}
			glVertex3f(rejectRadiusVertexLists.vertexList[0].coordX,rejectRadiusVertexLists.vertexList[0].coordY,rejectRadiusVertexLists.vertexList[0].coordZ);
			glEnd();
			glPopMatrix();
		}
	}

	// end overlay watch / reject regions

	glLoadIdentity();									// Reset The Current Modelview Matrix
	glTranslatef(0.0f,0.0f,globeDepth);						// Move Right 1.5 Units And Into The Screen 7.0

	glRotatef(globeRot[DIM_X],1.0f,0.0f,0.0f);
	glRotatef(globeRot[DIM_Y],0.0f,1.0f,0.0f);
	glRotatef(globeRot[DIM_Z],0.0f,0.0f,1.0f);

	//	glRotatef(rquad,0.0f,1.0f,0.0f);	

	//glDisable(GL_DEPTH);
	glScalef(globeZoom, globeZoom, globeZoom);
	// draw data as textured quads
	glPolygonMode(GL_FRONT, GL_LINE);
	glPolygonMode(GL_BACK, GL_FILL);

	glColor3f(1.0f,1.0f,1.0f);

	glShadeModel(GL_SMOOTH);

	glEnable(GL_TEXTURE_2D);

	for (int a=0; a<TOTAL_SENSORS; a++){
		for (int b=0; b<TOTAL_SCAS; b++){


			
			int iPrev = wfIndexP2Ray[a][b];
			if (iPrev != STATUS_ERROR){
				glCallList(witFrameRay[iPrev].drawListIndex);	// fixes flicker
			}
			
			int i = wfIndexP1Ray[a][b];
			if (i != STATUS_ERROR){


	if (witFrameRay[i].frameStatus[MODE_LOAD] == STATUS_COMPLETE_IO && witFrameRay[i].frameStatus[MODE_CUDA_FILTER_T] == STATUS_COMPLETE_CUDA_T){
		
		if (witFrameRay[i].frameStatus[MODE_GL_LIST] == STATUS_READY){
			// create drawList for new frame
			
			witFrameRay[i].drawListIndex = glGenLists(1);
			glNewList(witFrameRay[i].drawListIndex, GL_COMPILE);

			glBindTexture( GL_TEXTURE_2D, witFrameRay[i].textures[0]); // set basic parametersglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);

			if (textureInterpolation == ON){
				glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
				glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			} else if (textureInterpolation == OFF){
				glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
				glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
			}  

			// the texture wraps over at the edges (repeat)
			glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
			glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

			glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

			if (contrastActivated == OFF){
				glTexImage2D( GL_TEXTURE_2D, 0, GL_LUMINANCE, witFrameRay[i].w, witFrameRay[i].h, 0, GL_LUMINANCE, GL_FLOAT, witFrameRay[i].dataRes ); // Unbind the textureglBindTexture( GL_TEXTURE_2D, 0 );
				
			} else {
				for (int y=0; y<numPy; y++){
					for (int x=0; x<numPx; x++){
						int loc = (y*numPx)+x;
						float *contrast = getContrastFromVal(witFrameRay[i].dataRes[loc]);
						for (int k=0; k<3; k++){
							int locRgb = (((y*numPx)+x)*3);
							dataResContrastBuffer[locRgb +DIM_R] = contrast[DIM_R];
							dataResContrastBuffer[locRgb +DIM_G] = contrast[DIM_G];
							dataResContrastBuffer[locRgb +DIM_B] = contrast[DIM_B];
						}
					}
				}
				glTexImage2D( GL_TEXTURE_2D, 0, GL_RGB, witFrameRay[i].w, witFrameRay[i].h, 0, GL_RGB, GL_FLOAT, dataResContrastBuffer);
			}

			glBegin(GL_QUADS);
			for (int j=0; j<witFrameRay[i].gridNumX-1; j++){
				for (int k=0; k<witFrameRay[i].gridNumY-1; k++){
					int j2 = j+1;
					int k2 = k+1;

					float jf1 = (float)(j*TILE_SIZE_X)/(float)witFrameRay[i].w;
					float jf2 = (float)(j2*TILE_SIZE_X)/(float)witFrameRay[i].w;

					float kf1 = (float)(k*TILE_SIZE_Y)/(float)witFrameRay[i].h;
					float kf2 = (float)(k2*TILE_SIZE_Y)/(float)witFrameRay[i].h;

					int validCoords = 4;

					if (witFrameRay[i].coordsLat[j][k] == BAD_GEOLOC){
						validCoords--;
					}
					if (witFrameRay[i].coordsLat[j2][k] == BAD_GEOLOC){
						validCoords--;
					}
					if (witFrameRay[i].coordsLat[j][k2] == BAD_GEOLOC){
						validCoords--;
					}
					if (witFrameRay[i].coordsLat[j2][k2] == BAD_GEOLOC){
						validCoords--;
					}

					if (validCoords == 4){

					glTexCoord2f(jf1,kf1);
					glVertex3f(witFrameRay[i].coordsX[j][k],witFrameRay[i].coordsY[j][k],witFrameRay[i].coordsZ[j][k]);

					glTexCoord2f(jf2,kf1);
					glVertex3f(witFrameRay[i].coordsX[j2][k],witFrameRay[i].coordsY[j2][k],witFrameRay[i].coordsZ[j2][k]);

					glTexCoord2f(jf2,kf2);
					glVertex3f(witFrameRay[i].coordsX[j2][k2],witFrameRay[i].coordsY[j2][k2],witFrameRay[i].coordsZ[j2][k2]);

					glTexCoord2f(jf1,kf2);
					glVertex3f(witFrameRay[i].coordsX[j][k2],witFrameRay[i].coordsY[j][k2],witFrameRay[i].coordsZ[j][k2]);

					}
				}
			}
			glEnd();

			glBindTexture( GL_TEXTURE_2D, 0 );

			glEndList();

			string fnStr = boost::lexical_cast<std::string>(i);

			witFrameRay[i].frameStatus[MODE_GL_LIST] = STATUS_COMPLETE_GL;
			
		} else if (witFrameRay[i].frameStatus[MODE_GL_LIST] == STATUS_COMPLETE_GL){
			glCallList(witFrameRay[i].drawListIndex);
		}
		}
	}
		}
	}


	glBindTexture( GL_TEXTURE_2D, 0 );
	glDisable(GL_TEXTURE_2D);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	// glEnable(GL_DEPTH);

	// end draw data

	// draw event detections

	glLoadIdentity();								
	glTranslatef(0.0f,0.0f,globeDepth);					

	glRotatef(globeRot[DIM_X],1.0f,0.0f,0.0f);
	glRotatef(globeRot[DIM_Y],0.0f,1.0f,0.0f);
	glRotatef(globeRot[DIM_Z],0.0f,0.0f,1.0f);

	glScalef(globeZoom, globeZoom, globeZoom);

	detectConstCurrSpan = detectConstCurrMax - detectConstCurrMin;
	detectSigmaCurrSpan = detectSigmaCurrMax - detectSigmaCurrMin;

	glBegin(GL_LINES);
	for (int a=0; a<TOTAL_SENSORS; a++){
		for (int b=0; b<TOTAL_SCAS; b++){
	for (int i=0; i<eventCount; i++){
		if (witEventRay[i].highlighted == OFF){
			float detectConstStrength = (witEventRay[i].valFilter-detectConstCurrMin)*(1.0/(detectConstCurrSpan));
		
			if (witEventRay[i].frameId == wfIndexP1Ray[a][b]){
				glColor3fv(colorUiGreen);
			} else {
				glColor4f(1.0,detectConstStrength, 0, 1.0f );
			}
		} else if (witEventRay[i].highlighted == ON){
			if (witEventRay[i].frameId == wfIndexP1Ray[a][b]){
				glColor3fv(colorUiBrightestBlue);
			} else {
				glColor3fv(colorUiBrightBlue);
			}
		}

			glVertex3fv(witEventRay[i].renderPoint1);
			glVertex3fv(witEventRay[i].renderPoint2);
		}

		}
	}
	glEnd();
	// end draw event detections

	// draw globe opacity

	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_FILL);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); 

	glLoadIdentity();	
	glTranslatef(0.0f,0.0f,globeDepth);
	float qSize = 10;
	float gray = 0.0f;
	glColor4f(gray,gray,gray,.7f);
	glBegin(GL_QUADS);
	glVertex3f(-qSize,qSize,0);
	glVertex3f(qSize,qSize,0);
	glVertex3f(qSize,-qSize,0);
	glVertex3f(-qSize,-qSize,0);
	glEnd();
	// end globe overlay

	// overlay elements
	glPushMatrix();

	// alter view volume
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();

	glOrtho(0.0f, winSizeW, 0.0f, winSizeH, 0.0f, 1.0f); 

	glMatrixMode(GL_MODELVIEW);

	float uiScale = .05f;
	float uiLocX = -0.00f;
	float uiLocY = -0.40f;
	float uiLocZ =  globeDepth/2.0f;
	glLoadIdentity();						

	glLineWidth((GLfloat)2.0f); 

	glDisable(GL_DEPTH);

	// blanking
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	float blankingHeight = 120;
	glBegin(GL_QUADS);
	glColor3fv(colorUiBlack);
	glVertex3f(0.0f,0.0f,0.0f);
	glVertex3f(0.0f,blankingHeight,0.0f);
	glVertex3f(winSizeW,blankingHeight,0.0f);
	glVertex3f(winSizeW,0.0f,0.0f);
	glEnd();

	// timeline and ticks
	float secsInDay = 60*60*25; // 25 hrs - need to add multi-day and zooming
	float tickSpace = 1.0f;

	float timelineStripeH = 4;
	float timelineY = blankingHeight-10;
	float timelineY2 = blankingHeight-14;
	float playheadY = blankingHeight-8;
	float sensorOffsetY = timelineY2-timelineY;
	float playheadY2 = blankingHeight-16 +(sensorOffsetY*(numSensorsRender*TOTAL_SCAS+(numSensorsRender-1)));

	float timelineLocX = 300.0f;
	glTranslatef(timelineLocX, 0,0);
	glTranslatef(timeUserScroll, 0,0);//userTimelinePos

	glBegin(GL_QUADS);

	// status per sensor - background  
	for (int i=sensorRenderStart; i<sensorRenderStart+numSensorsRender; i++){
		for (int j=0; j<TOTAL_SCAS; j++){
		int xStart = timeMin[i];
		int xStop = timeMax[i];

		if (sensorToggleLoad[i][j] == OFF){
			glColor3fv(colorUiDarkGray);
			
			float soY1 = sensorOffsetY*(j+(i*(TOTAL_SCAS+1)));
			float soY2 = soY1+2;

			glVertex3f((GLfloat)((0*tickSpace)),(GLfloat)timelineY+soY1,(GLfloat)0);
			glVertex3f((GLfloat)((0*tickSpace)),(GLfloat)timelineY2+soY2,(GLfloat)0);
			glVertex3f((GLfloat)((xStart*tickSpace)),(GLfloat)timelineY2+soY2,(GLfloat)0);
			glVertex3f((GLfloat)((xStart*tickSpace)),(GLfloat)timelineY+soY1,(GLfloat)0);

			glVertex3f((GLfloat)((xStop*tickSpace)),(GLfloat)timelineY+soY1,(GLfloat)0);
			glVertex3f((GLfloat)((xStop*tickSpace)),(GLfloat)timelineY2+soY2,(GLfloat)0);
			glVertex3f((GLfloat)((secsInDay*tickSpace)),(GLfloat)timelineY2+soY2,(GLfloat)0);
			glVertex3f((GLfloat)((secsInDay*tickSpace)),(GLfloat)timelineY+soY1,(GLfloat)0);

		}
		}
	}

	// minute ticks - background

	float ty1 = timelineY;
	float ty2 = timelineY+sensorOffsetY*(numSensorsRender*TOTAL_SCAS+(numSensorsRender-1))+2;
	
	int tickInc = 60;
	glColor3fv(colorUiDarkGray);
	for (int i=0; i<secsInDay; i+=tickInc){
		float tx = i;
		glVertex3f((GLfloat)(tx),(GLfloat)ty1,(GLfloat)0);
		glVertex3f((GLfloat)(tx),(GLfloat)ty2,(GLfloat)0);
		glVertex3f((GLfloat)(tx+1.0f),(GLfloat)ty2,(GLfloat)0);
		glVertex3f((GLfloat)(tx+1.0f),(GLfloat)ty1,(GLfloat)0);
	}

	tickInc = 600;
	glColor3fv(colorUiMedGray);
	for (int i=0; i<secsInDay; i+=tickInc){
		float tx = i;
		glVertex3f((GLfloat)(tx),(GLfloat)ty1,(GLfloat)0);
		glVertex3f((GLfloat)(tx),(GLfloat)ty2,(GLfloat)0);
		glVertex3f((GLfloat)(tx+1.0f),(GLfloat)ty2,(GLfloat)0);
		glVertex3f((GLfloat)(tx+1.0f),(GLfloat)ty1,(GLfloat)0);
	}

	// status per sensor - meta data and loading
	for (int i=sensorRenderStart; i<sensorRenderStart+numSensorsRender; i++){
		for (int j=0; j<TOTAL_SCAS; j++){

		int xStart = timeMin[i];
		int xStop = timeMax[i];

		if (sensorToggleLoad[i][j] == ON){
			glColor3fv(colorUiMedGray);
		
			float soY1 = sensorOffsetY*(j+(i*(TOTAL_SCAS+1)));
			float soY2 = soY1+2;

			glVertex3f((GLfloat)((0*tickSpace)),(GLfloat)timelineY+soY1,(GLfloat)0);
			glVertex3f((GLfloat)((0*tickSpace)),(GLfloat)timelineY2+soY2,(GLfloat)0);
			glVertex3f((GLfloat)((xStart*tickSpace)),(GLfloat)timelineY2+soY2,(GLfloat)0);
			glVertex3f((GLfloat)((xStart*tickSpace)),(GLfloat)timelineY+soY1,(GLfloat)0);

			glVertex3f((GLfloat)((xStop*tickSpace)),(GLfloat)timelineY+soY1,(GLfloat)0);
			glVertex3f((GLfloat)((xStop*tickSpace)),(GLfloat)timelineY2+soY2,(GLfloat)0);
			glVertex3f((GLfloat)((secsInDay*tickSpace)),(GLfloat)timelineY2+soY2,(GLfloat)0);
			glVertex3f((GLfloat)((secsInDay*tickSpace)),(GLfloat)timelineY+soY1,(GLfloat)0);

			glColor3fv(colorUiBlue);
			for (int w=0; w<numFiles; w++){
				if (witFileRay[i].fileStatus[MODE_LOAD] != STATUS_READY && witFileRay[i].fileStatus[MODE_LOAD] != STATUS_ERROR){
					float tx1 =witFileRay[i].secsStart*tickSpace;
					float tx2 =witFileRay[i].secsStop*tickSpace;

					glVertex3f((GLfloat)(tx1),(GLfloat)timelineY+soY1,(GLfloat)0);
					glVertex3f((GLfloat)(tx1),(GLfloat)timelineY2+soY2,(GLfloat)0);
					glVertex3f((GLfloat)(tx2),(GLfloat)timelineY2+soY2,(GLfloat)0);
					glVertex3f((GLfloat)(tx2),(GLfloat)timelineY+soY1,(GLfloat)0);
				}
			}

		glColor3fv(colorUiGreen);
		float tx;
		for (int w=0; w<numFrames; w++){
			if (witFrameRay[w].sensorId == i){
			if (witFrameRay[w].chipId == j){
				if (witFrameRay[w].frameStatus[MODE_LOAD] == STATUS_COMPLETE_IO){
					tx = witFrameRay[w].segSecs*tickSpace;
					glVertex3f((GLfloat)(tx),(GLfloat)timelineY+soY1,(GLfloat)0);
					glVertex3f((GLfloat)(tx),(GLfloat)timelineY2+soY2,(GLfloat)0);
					glVertex3f((GLfloat)(tx+1.0f),(GLfloat)timelineY2+soY2,(GLfloat)0);
					glVertex3f((GLfloat)(tx+1.0f),(GLfloat)timelineY+soY1,(GLfloat)0);
				}
			}
			}
		}
		}
	}
	}
	glEnd();

	glBegin(GL_LINES);
	glColor3fv(colorUiRed);
	float txMin = timeUserMin*tickSpace;
	glVertex3f((GLfloat)(txMin),(GLfloat)playheadY,(GLfloat)0);
	glVertex3f((GLfloat)(txMin),(GLfloat)playheadY2,(GLfloat)0);

	float txMax = timeUserMax*tickSpace;
	glVertex3f((GLfloat)(txMax),(GLfloat)playheadY,(GLfloat)0);
	glVertex3f((GLfloat)(txMax),(GLfloat)playheadY2,(GLfloat)0);

	glEnd();

	float handleW = 3.0f;
	float handleH = 6.0f;
	glBegin(GL_QUADS);
	glVertex3f((GLfloat)(txMin),(GLfloat)playheadY2,(GLfloat)0);
	glVertex3f((GLfloat)(txMin-handleW),(GLfloat)playheadY2,(GLfloat)0);
	glVertex3f((GLfloat)(txMin-handleW),(GLfloat)playheadY2+handleH,(GLfloat)0);
	glVertex3f((GLfloat)(txMin),(GLfloat)playheadY2+handleH,(GLfloat)0);

	glVertex3f((GLfloat)(txMax),(GLfloat)playheadY2,(GLfloat)0);
	glVertex3f((GLfloat)(txMax+handleW),(GLfloat)playheadY2,(GLfloat)0);
	glVertex3f((GLfloat)(txMax+handleW),(GLfloat)playheadY2+handleH,(GLfloat)0);
	glVertex3f((GLfloat)(txMax),(GLfloat)playheadY2+handleH,(GLfloat)0);

	glEnd();

	// render playhead
	glColor3fv(colorUiWhite);
	float tx = playheadSecsOfDay*tickSpace;
	glBegin(GL_LINES);
	glVertex3f((GLfloat)(tx),(GLfloat)playheadY,(GLfloat)0);
	glVertex3f((GLfloat)(tx),(GLfloat)playheadY2,(GLfloat)0);
	glEnd();

	glTranslatef(-timelineLocX, 0,0);
	glTranslatef(-timeUserScroll, 0,0);

	glBegin(GL_QUADS); 
	glColor4fv(colorUiBlackOverlay);
	glVertex3f((GLfloat)(0),(GLfloat)0,(GLfloat)0);
	glVertex3f((GLfloat)(0),(GLfloat)blankingHeight,(GLfloat)0);
	glVertex3f((GLfloat)(timelineLocX),(GLfloat)blankingHeight,(GLfloat)0);
	glVertex3f((GLfloat)(timelineLocX),(GLfloat)0,(GLfloat)0);

	glColor3fv(colorUiMedGray);
	glVertex3f(0.0f,blankingHeight-1,0.0f);
	glVertex3f(0.0f,blankingHeight,0.0f);
	glVertex3f(winSizeW,blankingHeight,0.0f);
	glVertex3f(winSizeW,blankingHeight-1,0.0f);

	glEnd();

	// thread pool status
	glBegin(GL_LINES);
	float uiTpLocX = 10.0f;
	float uiTpLocY = 10.0f;
	float uiTpSpaceX = 3.0f;
	float uiTpHeightY = 10.0f;

	int tc1 = threadsActive + threadsQueued;
	for (int i=0; i<threadPoolSize; i++){

		if (i<threadsActive){
			glColor3fv(colorUiGreen);
		} else if (i>=threadsActive && i<tc1){
			glColor3fv(colorUiBlue);
		} else {
			glColor3fv(colorUiMedGray);
		} 
		glVertex3f((GLfloat)(uiTpLocX+(i*uiTpSpaceX)),(GLfloat)uiTpLocY,(GLfloat)0);
		glVertex3f((GLfloat)(uiTpLocX+(i*uiTpSpaceX)),(GLfloat)(uiTpLocY+uiTpHeightY),(GLfloat)0);
	}
	glEnd();
	// end thread pool

	
	if (contrastActivated == ON){

	}

	if (histogramActivated == ON){ // draw histogram

		
	for (int a=0; a<TOTAL_SENSORS; a++){
		for (int b=0; b<TOTAL_SCAS; b++){

			int iPrev = wfIndexP2Ray[a][b];

			if (iPrev != STATUS_ERROR){

		float spaceX = histRenderW/(float)PX_VAL_MAX;
		float spaceXshim = (histRenderW/(float)PX_VAL_MAX)*.8f;

		// to scale histogram
		for (int j=0; j<PX_VAL_MAX; j++){
			int val = witFrameRay[iPrev].histValRaw[j];
			if (val> histMaxBinCount){
				histMaxBinCount = val;
			}
		}

		glPolygonMode(GL_FRONT, GL_FILL);
		glPolygonMode(GL_BACK, GL_FILL);
		glColor4f(0,0,0,.5f);
		glBegin(GL_QUADS);
		glVertex3f(histRenderX, histRenderY, 0);
		glVertex3f(histRenderX+histRenderW, histRenderY, 0);
		glVertex3f(histRenderX+histRenderW, histRenderY+histRenderH, 0);
		glVertex3f(histRenderX, histRenderY+histRenderH, 0);
		glEnd();

		glBegin(GL_QUADS);
		glColor3fv(colorUiBlue);
		for (int j=0; j<witFrameRay[iPrev].valQ1; j++){
			int val = witFrameRay[iPrev].histValRaw[j];

			float sliceScale = histRenderH/(float)histMaxBinCount;
			float sliceHeight = sliceScale*val;
			glVertex3f(histRenderX+ (float)j*spaceX, histRenderY, 0);
			glVertex3f(histRenderX+ (float)j*spaceX+spaceXshim, histRenderY, 0);
			glVertex3f(histRenderX+ (float)j*spaceX+spaceXshim, histRenderY+sliceHeight, 0);
			glVertex3f(histRenderX+ (float)j*spaceX, histRenderY+sliceHeight, 0);
		}
		for (int j=witFrameRay[iPrev].valQ3; j<PX_VAL_MAX-1; j++){
			int val = witFrameRay[iPrev].histValRaw[j];

			float sliceScale = histRenderH/(float)histMaxBinCount;
			float sliceHeight = sliceScale*val;
			glVertex3f(histRenderX+ (float)j*spaceX, histRenderY, 0);
			glVertex3f(histRenderX+ (float)j*spaceX+spaceXshim, histRenderY, 0);
			glVertex3f(histRenderX+ (float)j*spaceX+spaceXshim, histRenderY+sliceHeight, 0);
			glVertex3f(histRenderX+ (float)j*spaceX, histRenderY+sliceHeight, 0);
		}

		glColor3fv(colorUiBrightBlue);
		for (int j=witFrameRay[iPrev].valQ1; j<witFrameRay[iPrev].valQ3-1; j++){
			int val = witFrameRay[iPrev].histValRaw[j];

			float sliceScale = histRenderH/(float)histMaxBinCount;
			float sliceHeight = sliceScale*val;
			glVertex3f(histRenderX+ (float)j*spaceX, histRenderY, 0);
			glVertex3f(histRenderX+ (float)j*spaceX+spaceXshim, histRenderY, 0);
			glVertex3f(histRenderX+ (float)j*spaceX+spaceXshim, histRenderY+sliceHeight, 0);
			glVertex3f(histRenderX+ (float)j*spaceX, histRenderY+sliceHeight, 0);
		}

		glColor3fv(colorUiGreen);
		for (int j=witFrameRay[iPrev].valQ2; j<witFrameRay[iPrev].valQ2+1; j++){
			int val = witFrameRay[iPrev].histValRaw[j];

			float sliceScale = histRenderH/(float)histMaxBinCount;
			float sliceHeight = sliceScale*val;
			glVertex3f(histRenderX+ (float)j*spaceX, histRenderY, 0);
			glVertex3f(histRenderX+ (float)j*spaceX+spaceXshim, histRenderY, 0);
			glVertex3f(histRenderX+ (float)j*spaceX+spaceXshim, histRenderY+sliceHeight, 0);
			glVertex3f(histRenderX+ (float)j*spaceX, histRenderY+sliceHeight, 0);
		}

		glEnd();

		}
		}
	}

		// contrast curve / control
		glColor3fv(colorUiRed);
		glBegin(GL_LINES);
		float tickY = 5;
		for (int i=0; i<fcRampSlots[fcSelected]-1; i++){

			float vx = contrastCpRastX[i];
			float vy = contrastCpRastY[i];

			float vx2 = contrastCpRastX[i+1];
			float vy2 = contrastCpRastY[i+1];

			glVertex3f(vx, vy, 0);
			glVertex3f(vx2, vy2, 0);

			if (i==0){

				glVertex3f(vx, vy-tickY, 0);
				glVertex3f(vx, vy+tickY, 0);
			}

			glVertex3f(vx2, vy2-tickY, 0);
			glVertex3f(vx2, vy2+tickY, 0);
		}
		glEnd();

		glPolygonMode(GL_FRONT, GL_LINE);
		glPolygonMode(GL_BACK, GL_LINE);
		glColor3fv(colorUiWhite);
		glBegin(GL_QUADS);
		glVertex3f(histRenderX-1, histRenderY-1, 0);
		glVertex3f(histRenderX+histRenderW+1, histRenderY-1, 0);
		glVertex3f(histRenderX+histRenderW+1, histRenderY+histRenderH+1, 0);
		glVertex3f(histRenderX-1, histRenderY+histRenderH+1, 0);
		glEnd();

	}

	// end timeline and ticks

	glEnable(GL_DEPTH);
	glLineWidth((GLfloat)1.0f); 
	// memory status

	// restore view volume
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);

	glPopMatrix();

	return TRUE;	
}


float QtGL2::checkTimeBounds(float p){
	// forwards
	if (p > timeUserMax){
		p = timeUserMin;
	}
	// backwards
	if (p<timeUserMin){
		p = timeUserMax;
	}
	return p;
}

void QtGL2::findFallbackFrames(void){
	for (int i=0; i<TOTAL_SENSORS; i++){
		for (int j=0; j<TOTAL_SCAS; j++){
			ptPrev1 = playheadSecsOfDay-(timeStep*playbackDirection);
			ptPrev1 = checkTimeBounds(ptPrev1);
			wfIndexP1Ray[i][j] = getFrameAtTime(ptPrev1, i, j, scanDir[i], 0);

			ptPrev2 = ptPrev1-(timeStep*playbackDirection);
			ptPrev2 = checkTimeBounds(ptPrev2);
			wfIndexP2Ray[i][j] = getFrameAtTime(ptPrev2, i, j, scanDir[i], 0);
		}
	}
}

void QtGL2::resetCudaResults(void){


	int tempPauseFlag = playback; // suspend during cleanup
	if(playback == ON){
		playback = OFF;
	}

	outputResultFlag = 1;

	// !! NEED TO FIX
	playheadSecsOfDay = timeUserMin;
	
	for (int i=0; i<TOTAL_SENSORS; i++){
		for (int j=0; j<TOTAL_SCAS; j++){
			wfIndexRay[i][j] = getFrameAtTime(playheadSecsOfDay, i, j, scanDir[i], 0);
		}
	}

	findFallbackFrames();

	// reset texture status

	for (int i=0; i<numFrames; i++){
		glDeleteTextures( 1, &witFrameRay[i].textures[0]);

		if (witFrameRay[i].frameStatus[MODE_LOAD] == STATUS_COMPLETE_IO){
			if (witFrameRay[i].frameStatus[MODE_GL_LIST] == STATUS_COMPLETE_GL){
				glDeleteLists(witFrameRay[i].drawListIndex, 1);
			}
		}

		witFrameRay[i].frameStatus[MODE_GL_LIST] = STATUS_READY;
		witFrameRay[i].frameStatus[MODE_CUDA_FILTER_T] = STATUS_READY;
	}

	timeProcGlobalStart = microsec_clock::local_time();
	playback = tempPauseFlag; // unpause if neccessary

	qDebug("RESET CUDA RESULTS");	
}


int QtGL2::getFrameAtTime(float secs, int scid, int sca, int dir, int beginLine){
	int frame = STATUS_ERROR;

	// find temporally-nearest past frame meeting criteria
	float nearestFrameDiff = timeStepMax;
	for (int i=0; i<numFrames; i++){
		if (witFrameRay[i].frameStatus[MODE_LOAD] == STATUS_COMPLETE_IO){
			if (witFrameRay[i].chipId == sca && witFrameRay[i].sensorId == scid){
			if (witFrameRay[i].segScanDir == dir || dir == SCAN_DIR_BOTH){
				if (witFrameRay[i].segBeginLine == beginLine){

			float delta = secs - witFrameRay[i].segSecs;
			if (delta < nearestFrameDiff && delta >= 0){
				nearestFrameDiff = delta;
				frame = i;
			}
				}
			}
			}
		}
	}
	return frame;
}

void QtGL2::allocFrameData(void){
	qDebug("ALLOC FRAME DATA");

	int w = numPx;
	int h = numPy;


	int gridX = TILE_SIZE_X;
	int gridY = TILE_SIZE_Y;

	int gridNumX = w/gridX;
	int gridNumY = h/gridY;

	int maxValue = 255;

	dataResContrastBuffer = new float[w*h*3];

	for (int i=0; i<numFrames; i++){

		witFrameRay[i].dataSrc = new float*[w];
		witFrameRay[i].dataRes = new float[w*h];
		witFrameRay[i].histValRaw = new float[maxValue];

		for (int x=0; x<w; x++){
			witFrameRay[i].dataSrc[x] = new float[h];
		}

		witFrameRay[i].textures = new GLuint[MAX_TILES_PER_FRAME];

		witFrameRay[i].coordsLon = new float*[gridNumX];
		witFrameRay[i].coordsLat = new float*[gridNumX];
		witFrameRay[i].coordsX = new float*[gridNumX];
		witFrameRay[i].coordsY = new float*[gridNumX];
		witFrameRay[i].coordsZ = new float*[gridNumX];

		for (int x=0; x<gridNumX; x++){
			witFrameRay[i].coordsLon[x] = new float[gridNumY];
			witFrameRay[i].coordsLat[x] = new float[gridNumY];
			witFrameRay[i].coordsX[x] = new float[gridNumY];
			witFrameRay[i].coordsY[x] = new float[gridNumY];
			witFrameRay[i].coordsZ[x] = new float[gridNumY];
		}

	}
}

void QtGL2::prepEventList(void){

	for (int i=0; i< numEvents; i++){
		witEventRay[i].displayStatus = STATUS_ERROR;

		witEventRay[i].renderPoint1 = new GLfloat[3];
		witEventRay[i].renderPoint2 = new GLfloat[3];

		witEventRay[i].highlighted = OFF;
	}

}

void QtGL2::resetFramesAndFiles(void){
	for (int i=0; i<numFrames; i++){
		for (int m=0; m<MODES; m++){
			witFrameRay[i].setModeStatus(m, STATUS_READY);
		}
	}
	for (int i=0; i<numFiles; i++){
		witFileRay[i].numReservedFrames=0;
		for (int m=0; m<MODES; m++){
			witFileRay[i].setModeStatus(m, STATUS_READY);
		}
	}
	framesUsed=0;
	
	timeUserMax = 0;

	resetThreads();
	qDebug("RESET FRAMES AND FILES");
}


void QtGL2::prepFrames(void){
	qDebug("PREP FRAMES");
	videoExportFrameNo = 0; 


	for (int i=0; i<numFrames; i++){
		witFrameRay[i].frameStatus = new int[MODES];
		witFrameRay[i].frameStatus[MODE_LOAD] = STATUS_READY;
	}
	for (int i=0; i<numFrames; i++){

		witFrameRay[i].w=0;
		witFrameRay[i].h=0;
		witFrameRay[i].setModeStatus(MODE_LOAD, STATUS_READY);
		witFrameRay[i].setModeStatus(MODE_CUDA_FILTER_T, STATUS_READY);
		witFrameRay[i].setModeStatus(MODE_GL_LIST, STATUS_READY);

		glGenTextures( 1, &witFrameRay[i].textures[0]);
	}
	for (int i=0; i<numFiles; i++){
		witFileRay[i].fileStatus = new int[MODES];
		witFileRay[i].setModeStatus(MODE_LOAD, STATUS_READY);
		witFileRay[i].numReservedFrames=0;
	}
}


void QtGL2::prepGpuResources(void){

	ptr_a = allocCudaF(aPxy, numPct);
	ptr_res = allocCudaF(resPxy, numPc);
	ptr_kc = allocCudaF(kc_a, numT);
}


void QtGL2::resetContrastResults(){

	for (int i=0; i<numFrames; i++){
		witFrameRay[i].setModeStatus(MODE_GL_LIST, STATUS_READY);
	}
}

void QtGL2::setContrastCpRastPos(){

	for (int i=0; i<contrastNumCp; i++){
		if (contrastCpActive[i] == ON){
			contrastCpRastX[i] = histRenderX+contrastCpVal[i]*(float)histRenderW;
			contrastCpRastY[i] = histRenderY+contrastCpOut[i]*(float)histRenderH;
		}
	}
}

int QtGL2::getNearestContrastCp(int x, int y){

	int nearestId = -1;
	float nearestDist=histRenderW*histRenderW+histRenderH*histRenderH+100;
	float clickRadiusSq = 300;

	for (int i=0; i<contrastNumCp; i++){
		if (contrastCpActive[i] == ON){
			float dx = contrastCpRastX[i]-x;
			float dy = contrastCpRastY[i]-y;

			float dist = dx*dx + dy*dy;

			if (dist < nearestDist && dist < clickRadiusSq){

				nearestDist = dist;
				nearestId = i;
			}
		}
	}

	return nearestId;
}

void QtGL2::prepProcessing(void){


	resetThreads();

	qDebug("PREP PROCESSING");
	// raw
	kc_e[0] = 1.0f;//.0001;
	kc_e[1] = 0;
	kc_e[2] = 0;
	kc_e[3] = 0;
	kc_e[4] = 0;
	kc_e[5] = 0;
	kc_e[6] = 0;
	kc_e[7] = 0;
	kc_e[8] = 0;

	// cummulative
	kc_d[0] = 42.0f;
	kc_d[1] = -42.0f;
	kc_d[2] = 0.0f;
	kc_d[3] = 0.0f;
	kc_d[4] = 0.0f;
	kc_d[5] = 0.0f;
	kc_d[6] = 0.0f;
	kc_d[7] = 0.0f;
	kc_d[8] = 0.0f;

	// temporal kernel
	kc_c[4] = 1.0f;
	kc_c[3] = -.5f;
	kc_c[5] = -.5f;
	kc_c[2] = .25f;
	kc_c[6] = .25f;
	kc_c[1] = -.3f;
	kc_c[7] = -.3f;
	kc_c[0] = .05f;
	kc_c[8] = .05f;

	// temporal kernel 2
	kc_c[4] = .40f;
	kc_c[3] = .2f;
	kc_c[5] = .2f;
	kc_c[2] = .1f;
	kc_c[6] = .1f;
	kc_c[1] = -.2f;
	kc_c[7] = -.2f;
	kc_c[0] = -.30f;
	kc_c[8] = -.30f;

	// temporal kernel 3
	kc_c[4] = 1.0f;
	kc_c[3] = .4f;
	kc_c[5] = .4f;
	kc_c[2] = .2f;
	kc_c[6] = .2f;
	kc_c[1] = -.35f;
	kc_c[7] = -.35f;
	kc_c[0] = -.75f;
	kc_c[8] = -.75f;

	// diff vs running average
	kc_a[0] = 1.0f;
	kc_a[1] = -.125f;
	kc_a[2] = -.125f;
	kc_a[3] = -.125f;
	kc_a[4] = -.125f;
	kc_a[5] = -.125f;
	kc_a[6] = -.125f;
	kc_a[7] = -.125f;
	kc_a[8] = -.125f;

	// straight 2-frame diffs
	kc_b[0] = 1.0f;
	kc_b[1] = -1.0f;
	kc_b[2] = 0;
	kc_b[3] = 0;
	kc_b[4] = 0;
	kc_b[5] = 0;
	kc_b[6] = 0;
	kc_b[7] = 0;
	kc_b[8] = 0;


	frameStr = boost::lexical_cast<std::string>(frameNo);


	timeDraw1 = microsec_clock::local_time();
	timeDraw2 = microsec_clock::local_time();

	timeAnim1 = microsec_clock::local_time();
	timeAnim2 = microsec_clock::local_time();

	timeBackend1 = microsec_clock::local_time();
	timeBackend2 = microsec_clock::local_time();

	timeProcGlobalStart = microsec_clock::local_time();

	incomingDataStateArchive = OFF;
	incomingDataStateStream = OFF;

	updateThreshUi(detectThreshConst);
	updateWatchRadiusUi(regionWatchRadius);
	updateRejectRadiusUi(regionRejectRadius);

	// contrast
	contrastCpVal[0] = 0;
	contrastCpOut[0] = 0;
	contrastCpActive[0] = ON;

	contrastCpVal[1] = .25;
	contrastCpOut[1] = .30;
	contrastCpActive[1] = ON;

	contrastCpVal[2] = .5;
	contrastCpOut[2] = .6;
	contrastCpActive[2] = ON;

	contrastCpVal[3] = .75;
	contrastCpOut[3] = .8;
	contrastCpActive[3] = ON;

	contrastCpVal[4] = 1.0;
	contrastCpOut[4] = 1.0;
	contrastCpActive[4] = ON;

	setContrastCpRastPos();

	// false color ramps

	// ramp1 - classic
	int rampId=0;
	fcRamps[rampId][0][DIM_R] = 0;
	fcRamps[rampId][0][DIM_G] = 0;
	fcRamps[rampId][0][DIM_B] = 0;

	fcRamps[rampId][1][DIM_R] = 1;
	fcRamps[rampId][1][DIM_G] = 1;
	fcRamps[rampId][1][DIM_B] = 1;

	fcRamps[rampId][2][DIM_R] = 0;
	fcRamps[rampId][2][DIM_G] = 0;
	fcRamps[rampId][2][DIM_B] = 1;

	fcRamps[rampId][3][DIM_R] = 0;
	fcRamps[rampId][3][DIM_G] = 1;
	fcRamps[rampId][3][DIM_B] = 1;

	fcRamps[rampId][4][DIM_R] = 1;
	fcRamps[rampId][4][DIM_G] = 0;
	fcRamps[rampId][4][DIM_B] = 0;

	fcRampSlots[rampId] = 5;

	// ramp2 - grey
	rampId=1;
	fcRamps[rampId][0][DIM_R] = 0;
	fcRamps[rampId][0][DIM_G] = 0;
	fcRamps[rampId][0][DIM_B] = 0;

	fcRamps[rampId][1][DIM_R] = .25f;
	fcRamps[rampId][1][DIM_G] = .25f;
	fcRamps[rampId][1][DIM_B] = .25f;

	fcRamps[rampId][2][DIM_R] = .5f;
	fcRamps[rampId][2][DIM_G] = .5f;
	fcRamps[rampId][2][DIM_B] = .5f;

	fcRamps[rampId][3][DIM_R] = .75f;
	fcRamps[rampId][3][DIM_G] = .75f;
	fcRamps[rampId][3][DIM_B] = .75f;

	fcRamps[rampId][4][DIM_R] = 1;
	fcRamps[rampId][4][DIM_G] = 1;
	fcRamps[rampId][4][DIM_B] = 1;

	fcRampSlots[rampId] = 5;

	// ramp3 - mars
	rampId=2;
	fcRamps[rampId][0][DIM_R] = 0;
	fcRamps[rampId][0][DIM_G] = 0;
	fcRamps[rampId][0][DIM_B] = 0;

	fcRamps[rampId][1][DIM_R] = .4f;
	fcRamps[rampId][1][DIM_G] = 0;
	fcRamps[rampId][1][DIM_B] = 0;

	fcRamps[rampId][2][DIM_R] = .8f;
	fcRamps[rampId][2][DIM_G] = .1f;
	fcRamps[rampId][2][DIM_B] = 0;

	fcRamps[rampId][3][DIM_R] = 1;
	fcRamps[rampId][3][DIM_G] = .5f;
	fcRamps[rampId][3][DIM_B] = 0;

	fcRamps[rampId][4][DIM_R] = 1;
	fcRamps[rampId][4][DIM_G] = 1;
	fcRamps[rampId][4][DIM_B] = 1;

	fcRampSlots[rampId] = 5;

	catchImage = QImage();
	catchImageCrop = QImage();
	playbackPaused = OFF;

}

//void QtGL2::drawGlobe(){
void QtGL2::paintGL(){


	if (videoExportActivated == ON){

		videoExportCounter--;

		if (videoExportCounter <= 0){

			videoExportCounter = videoExportCounterStartVal;

			drawGLScene();

			QString dirStr = QString(vid_scratch_dir.c_str());
			QString fileStr = dirStr + QString::number(videoExportFrameNo) + ".png";
			catchImage = this->grabFrameBuffer();

			catchImageCrop = catchImage.copy(0,0,winSizeW,winSizeH);
			int scaledW = (float)winSizeW*videoExportScaleFactor;
			int scaledH = (float)winSizeH*videoExportScaleFactor;

			if (scaledW %2 == 1){
				scaledW +=1;
			}
			if (scaledH %2 == 1){
				scaledH +=1;
			}

			catchImageCrop = catchImageCrop.scaled(scaledW,scaledH);
			
			// burn in classification and title
			QPainter imPainter;//(&catchImageCrop);
			imPainter.begin(&catchImageCrop);

			imPainter.setPen(Qt::black);
			imPainter.setBrush(Qt::red);
			imPainter.setFont(QFont("Arial", 8, QFont::Bold));

			QString qsClass = QString(labelClassification.c_str());
			QString qsTitle = QString(labelTitle.c_str());

			int lineHeight = 12;
			QRect rect1 = QRect(0,0,scaledW, lineHeight);
			QRect rect2 = QRect(0,lineHeight,scaledW, lineHeight);
			QRect rect3 = QRect(0,scaledH-lineHeight,scaledW, lineHeight);


			imPainter.fillRect(rect1, QBrush(Qt::red));
			imPainter.fillRect(rect2, QBrush(Qt::yellow));
			imPainter.fillRect(rect3, QBrush(Qt::red));

			imPainter.drawText(rect1, Qt::AlignCenter, qsClass);
			imPainter.drawText(rect3, Qt::AlignCenter, qsClass);

			imPainter.setFont(QFont("Arial", 8, QFont::Bold));
			imPainter.drawText(rect2, Qt::AlignCenter, qsTitle);

			catchImageCrop.save(fileStr);

			qDebug("SAVING FRAME %i - %s",videoExportFrameNo, fileStr.toStdString().c_str());

			videoExportFrameNo++;

		}

	} else {
		drawGLScene();
	}

	counter++;
}

void QtGL2::genRegionRadius(MapVertexList& mv, MapVertexList& mvr, float radius){
	mvr = MapVertexList();

	mvr.numVertices=0;
	mvr.vertexList = new MapVertex[regionRadiusPoints]();

	float x = mv.vertexList[0].coordX;
	float y = mv.vertexList[0].coordY;
	float z = mv.vertexList[0].coordZ;

	float step = (pi*2)/(float)regionRadiusPoints;

	int i=0;
	for(float theta=0;  theta < 2*pi;  theta+=step){
		mvr.vertexList[i].coordX = radius*cos(theta);
		mvr.vertexList[i].coordY = - radius*sin(theta);    
		mvr.vertexList[i].coordZ = 0;
		i++;
	}

	mvr.numVertices=regionRadiusPoints;
}

void QtGL2::loadRegion(string dir, MapVertexList& mv, int& flag, int& segCount){
	qDebug("LOADING REGION");

	int fCountMax = 100;
	string *fNames = new string[fCountMax];
	int fCount=0;

	namespace fs = boost::filesystem; 
	boost::filesystem::directory_iterator end_itr;

	qDebug("   DIR %s", dir.c_str());

	// pass 1...collect the file names
	for( boost::filesystem::directory_iterator i( dir ); i != end_itr; ++i ) 
	{
		if( boost::filesystem::is_regular_file( i->status() ) ){
			if (fCount < fCountMax){
				fNames[fCount] = i->path().string();
				qDebug("   FILE %s", fNames[fCount].c_str());

				fCount++;
			}
		}
	}
	mv = MapVertexList();


	// pass 2...load points
	int segmentCount = 0;
	char line[256];
	std::ifstream infile;
	string lineStr;
	int segmentIndex = 0;
	int vertexIndex = 0;

	int pointCount = 0;

	for (int i=0; i<fCount; i++){
		//for (int i=0; i<fCount; i++){
		vertexIndex = 0;

		segmentCount = i;

		infile.open (fNames[i], std::ifstream::in);
		while (infile.good()){
			infile.getline(line, 256);
			lineStr = line;

			if (lineStr.find_first_of(",") != -1 && lineStr.length()>=3){
				int gapIndex1 = 0;
				int gapIndex2 = lineStr.find_first_of(",");
				int gapIndex3 = lineStr.length();
				string xStr = lineStr.substr(gapIndex1, gapIndex2);
				string yStr = lineStr.substr(gapIndex2+1, gapIndex3);
				//cout << "x/y _"+xStr+"_" +yStr+"_" << endl;


				pointCount++;
			}
		}
		infile.clear(); 
		infile.close();
	}

	mv.vertexList = new MapVertex[pointCount]();
	mv.numVertices = pointCount;

	for (int i=0; i<fCount; i++){
		qDebug("COUNTED POINTS %i", pointCount);

		infile.open (fNames[i], std::ifstream::in);
		while (infile.good()){
			infile.getline(line, 256);
			lineStr = line;

			if (lineStr.find_first_of(",") != -1 && lineStr.length()>=3){
				int gapIndex1 = 0;
				int gapIndex2 = lineStr.find_first_of(",");
				int gapIndex3 = lineStr.length();
				string xStr = lineStr.substr(gapIndex1, gapIndex2);
				string yStr = lineStr.substr(gapIndex2+1, gapIndex3);

				qDebug("LOADING REGION %s %s",xStr, yStr);

				float x=0;
				float y=0;

				if (xStr.find_last_of(".") != -1){
					x = boost::lexical_cast<float>(xStr);
				} else {
					x = boost::lexical_cast<int>(xStr);
				}

				if (yStr.find_last_of(".") != -1){
					y = boost::lexical_cast<float>(yStr);
				} else {
					y = boost::lexical_cast<int>(yStr);
				}

				mv.vertexList[vertexIndex].coordLon = x;
				mv.vertexList[vertexIndex].coordLat = y;

				mv.vertexList[vertexIndex].coordX = getLatLonX(globeRadius, y, x);
				mv.vertexList[vertexIndex].coordY = getLatLonY(globeRadius, y, x);
				mv.vertexList[vertexIndex].coordZ = getLatLonZ(globeRadius, y, x);

				vertexIndex++;
			}
		}

		infile.clear();
		infile.close();
	}

	segCount = fCount;

	flag = STATUS_COMPLETE_GL;
}

void QtGL2::loadMap(string dir, int sparseness){

	qDebug("LOADING MAP DATA %s - SPARSENESS %i", dir.c_str(), sparseness);
	// read the data files

	int fCountMax = 100;
	string *fNames = new string[fCountMax];
	int fCount=0;

	namespace fs = boost::filesystem; 
	boost::filesystem::directory_iterator end_itr;

	// pass 1...collect the file names
	for( boost::filesystem::directory_iterator i( dir ); i != end_itr; ++i ) 
	{
		if( boost::filesystem::is_regular_file( i->status() ) ){
			if (fCount < fCountMax){
				fNames[fCount] = i->path().string();
				string sub = fNames[fCount].substr(fNames[fCount].length()-7, fNames[fCount].length());
				if (sub.find_last_of("bdy.txt") != -1){
					cout << fNames[fCount] << endl;
				}
				fCount++;
			}
		}
	}

	// pass 2...collect the segment lengths
	int segmentCount = 0;
	char line[256];
	std::ifstream infile;
	string lineStr;

	for (int i=0; i<fCount; i++){

		infile.open (fNames[i], std::ifstream::in);
		while (infile.good()){

			infile.getline(line, 256);
			lineStr = line;
			if (lineStr.find_first_of("segment") != -1){
				segmentCount++;
			}
		}

		infile.clear();
		infile.close();
	}

	// pass 3...create containers

	numGlobeLists = segmentCount;
	globeVertexLists = new MapVertexList[numGlobeLists]();
	int *segmentLengths = new int[numGlobeLists];
	string segmentCountStr = boost::lexical_cast<std::string>(segmentCount);

	cout << "found "+segmentCountStr+" segments" << endl;

	qDebug("	SEGMENTS %i",segmentCount);
	segmentCount = 0;
	int segmentIndex = 0;
	string pointCountStr;
	int pointCount;
	for (int i=0; i<fCount; i++){
		infile.open (fNames[i], std::ifstream::in);
		
		while (infile.good()){

			infile.getline(line, 256);
			lineStr = line;
			if (lineStr.find_first_of("segment") != -1){
				int gapIndex = lineStr.find_last_of(" ")+1;

				pointCountStr = lineStr.substr(gapIndex, lineStr.length());
				pointCount = boost::lexical_cast<int>(pointCountStr);

				segmentLengths[segmentCount] = pointCount;
				if (fNames[i].find_first_of("bdy") != -1){
					globeVertexLists[segmentCount].type = 0;
				} 
				if (fNames[i].find_first_of("pby") != -1){
					globeVertexLists[segmentCount].type = 0;
				} 
				if (fNames[i].find_first_of("riv") != -1){
					globeVertexLists[segmentCount].type = 2;
				} 
				if (fNames[i].find_first_of("cil") != -1){
					globeVertexLists[segmentCount].type = 1;
				}  
				globeVertexLists[segmentCount].numVertices = pointCount;
				globeVertexLists[segmentCount].vertexList = new MapVertex[pointCount]();

				if (segmentCount%1000 ==0){
					string sCountStr = boost::lexical_cast<std::string>(segmentCount);
					cout << " found "+pointCountStr+" points - segment "+sCountStr << endl;

					qDebug("	POINTS %i",pointCount);
				}

				segmentCount++;
			} else {

			}
		}
		infile.clear();
		infile.close();
	}

	delete segmentLengths;

	// pass 4...populate the vertices
	segmentCount = 0;
	segmentIndex = 0;
	int vertexIndex = 0;

	int lineCounter = 0;

	for (int i=0; i<fCount; i++){

		infile.open (fNames[i], std::ifstream::in);

		while (infile.good()){

			infile.getline(line, 256);
			lineStr = line;

			if (lineStr.find_first_of("segment") != -1){

				segmentIndex = segmentCount;
				segmentCount++;
				vertexIndex=0;

			} else {

				if (vertexIndex < globeVertexLists[segmentIndex].numVertices){
					//if (lineCounter%sparseness == 0){ // !! fix for faster loads, coarser detail - should make this multithreaded also
					int gapIndex1 = 1;
					int gapIndex2 = lineStr.find_first_of(" ");
					int gapIndex3 = lineStr.length();
					string xStr = lineStr.substr(gapIndex1, gapIndex2-1);
					string yStr = lineStr.substr(gapIndex2+1, gapIndex3);

					float x = boost::lexical_cast<float>(xStr);
					float y = boost::lexical_cast<float>(yStr);

					if (vertexIndex == 0 && segmentIndex %1000 == 0){
						string vCountStr = boost::lexical_cast<std::string>(vertexIndex);
						string vLimitStr = boost::lexical_cast<std::string>(globeVertexLists[segmentIndex].numVertices);
						string sCountStr = boost::lexical_cast<std::string>(segmentIndex);
						cout << " vertex "+vCountStr+" of " +vLimitStr+" - segment " +sCountStr +" - point "+xStr +" " +yStr<< endl;
					}
					
					
					globeVertexLists[segmentIndex].vertexList[vertexIndex].coordLon = y;
					globeVertexLists[segmentIndex].vertexList[vertexIndex].coordLat = x;

					globeVertexLists[segmentIndex].vertexList[vertexIndex].coordX = getLatLonX(globeRadius, globeVertexLists[segmentIndex].vertexList[vertexIndex].coordLat, globeVertexLists[segmentIndex].vertexList[vertexIndex].coordLon);
					globeVertexLists[segmentIndex].vertexList[vertexIndex].coordY = getLatLonY(globeRadius, globeVertexLists[segmentIndex].vertexList[vertexIndex].coordLat, globeVertexLists[segmentIndex].vertexList[vertexIndex].coordLon);
					globeVertexLists[segmentIndex].vertexList[vertexIndex].coordZ = getLatLonZ(globeRadius, globeVertexLists[segmentIndex].vertexList[vertexIndex].coordLat, globeVertexLists[segmentIndex].vertexList[vertexIndex].coordLon);

					vertexIndex++;

					//}
					lineCounter++;
				}
			}
		}
		infile.clear();
		infile.close();
	}

	globeDrawStatus = STATUS_READY;
}

