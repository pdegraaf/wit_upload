#pragma once
class MapVertex
{
public:
	MapVertex(void);
	~MapVertex(void);
	
	float coordX;
	float coordY;
	float coordZ;

	float coordLat;
	float coordLon;
};

