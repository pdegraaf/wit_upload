#include "detection.h"

Detection::Detection(QObject *parent)
	: QObject(parent)
{

}

Detection::Detection()
{

}

Detection::~Detection()
{

}
