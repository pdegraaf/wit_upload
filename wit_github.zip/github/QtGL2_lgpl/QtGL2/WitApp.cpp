/*

NOTICE
�
This software was produced for the U. S. Government under Contract No. FA8721-11-C-0001, 
and is subject to the Rights in Noncommercial Computer Software and Noncommercial 
Computer Software Documentation Clause (DFARS) 252.227-7014 (JUN 1995)
�
� 2011 The MITRE Corporation. All Rights Reserved.
�
This file is part of Wideband Imagery Tool (WIT).
WIT is free software: you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. WIT is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU Lesser 
General Public License for more details. You should have received a copy of the GNU 
Lesser General Public License along with WIT.� If not, see <http://www.gnu.org/licenses/>.

*/

#include "WitApp.h"


namespace Wit{

WitApp::WitApp(void)
{
}

WitApp::~WitApp(void)
{
}

void WitApp::loadConfig(string conf){
	char * confPath;
	confPath = getenv ("WIT_HOME"); // !! if WIT_HOME variable isn't set, program will crash
	string confPathStr = string(confPath);
	string configFilePath = confPathStr+"WIT_CONFIG.txt";

	if (conf.length()>0){
		configFilePath = conf;
	}

	qDebug("LOADING CONFIG: %s",configFilePath.c_str());

	int segmentCount = 0;
	char line[256];
	std::ifstream infile;
	string lineStr;

	const int itemCount = 20;
	string confItems[itemCount];
	int confItemsFound[itemCount];

	for (int i=0; i<itemCount; i++){
		confItemsFound[i] = OFF;
	}

	confItems[0] = "DATA_SOURCE_STREAM";
	confItems[1] = "DATA_SOURCE_HDF5R";
	confItems[2] = "DATA_OUTPUT_STREAM";
	confItems[3] = "DATA_OUTPUT_DIR";
	confItems[4] = "PLAYBACK_SPEED_MS";
	confItems[5] = "THREADS_CPU_MAX";
	confItems[6] = "REGION_REJECT_DIR";
	confItems[7] = "REGION_WATCH_DIR";
	confItems[8] = "REGION_REJECT_RADIUS";
	confItems[9] = "REGION_WATCH_RADIUS";
	confItems[10] = "MAP_DATA_DIR";
	confItems[11] = "DISPLAY_WIDTH";
	confItems[12] = "DISPLAY_HEIGHT";
	confItems[13] = "FFMPEG_SCRATCH";
	confItems[14] = "LABEL_CLASSIFICATION";
	confItems[15] = "LABEL_TITLE";
	confItems[16] = "VIDEO_EXPORT_SCALE";
	confItems[17] = "VIDEO_STREAM_SCALE";
	confItems[18] = "MAP_SPARSENESS";
	confItems[19] = "SCAN_DIR";
	
	glw->mapSparseness=1; // default

	infile.open (configFilePath, std::ifstream::in);
	while (infile.good()){

		infile.getline(line, 256);
		lineStr = line;

		QString qs = QString(lineStr.c_str());	

		int contentStart = -1;
		int contentStop = -1;
		int itemFound = STATUS_ERROR;

		for (int i=0; i<itemCount; i++){
			if (lineStr.find(confItems[i]) != string::npos){
				int index1 = lineStr.find(confItems[i]);
				int index2 = lineStr.find("/"+confItems[i], index1+1);

				if (index1 != index2){

					index1 = index1 + confItems[i].length()+1;
					index2 = index2-1;

					int len = index2-index1;
					qs = qs.mid(index1, len);

					windowInput->textInputStream->setText(qs);
					itemFound = i;
				}

				i=itemCount;

			}
		}

		if (confItemsFound[itemFound] == OFF){
			confItemsFound[itemFound] = ON;
		} else {
			itemFound = STATUS_ERROR; //
		}

		if (itemFound == 0){
			windowInput->textInputStream->setText(qs);
		}
		if (itemFound == 1){
			windowInput->textInputArchive->setText(qs);
		}


		if (itemFound == 2){
			windowOutput->textVideoStream->setText(qs);
		}
		if (itemFound == 3){
			windowOutput->textVideoExport->setText(qs);
			glw->vid_path_export = qs.toStdString();
		}

		if (itemFound == 4){
			windowPlayback->textPlaybackSpeed->setText(qs);
		}
		if (itemFound == 5){

		}

		if (itemFound == 6){
			windowFilterThreshold->textRegionRejectFile->setText(qs);
		}
		if (itemFound == 7){
			windowFilterThreshold->textRegionWatchFile->setText(qs);
		}
		if (itemFound == 8){
			windowFilterThreshold->textRegionRejectRadius->setText(qs);
		}
		if (itemFound == 9){
			windowFilterThreshold->textRegionWatchRadius->setText(qs);
		}
		if (itemFound == 10){
			glw->mapDataDir = qs.toUtf8().constData();
		}

		if (itemFound == 11){
			displayW = getValidatedIntFromQString(qs);
		}
		if (itemFound == 12){
			displayH = getValidatedIntFromQString(qs);
		}
		if (itemFound == 13){
			glw->vid_scratch_dir = qs.toStdString();
		} 
		if (itemFound == 14){
			glw->labelClassification = qs.toStdString();
		} 
		if (itemFound == 15){
			glw->labelTitle = qs.toStdString();
		}
		if (itemFound == 16){
			glw->videoExportScaleFactor = getValidatedFloatFromQString(qs);
		}
		if (itemFound == 17){
			glw->videoStreamScaleFactor = getValidatedFloatFromQString(qs);
		}
		if (itemFound == 18){
			glw->mapSparseness = getValidatedIntFromQString(qs);
		}
		if (itemFound == 19){
			for (int a=0; a<TOTAL_SENSORS; a++){
				glw->scanDir[a] = getValidatedIntFromQString(qs);
			}
		}
	}
	infile.close();
}

int WitApp::getValidatedIntFromQString(QString str){

	str.simplified();
	str.remove(QRegExp("[a-zA-Z]"));
	str.remove(QRegExp(QString::fromUtf8("[-`~!@#$%^&*()_�+=|:.;<>��,?/{}\'\"\\\[\\\]\\\\]")));
	int num = boost::lexical_cast<int>(str.toStdString());

	return num;
}

float WitApp::getValidatedFloatFromQString(QString str){

	str.simplified();
	str.remove(QRegExp("[a-zA-Z]"));
	int perCount = str.count(".");
	while (perCount > 1){
		str.remove(str.lastIndexOf("."), 1);
		perCount = str.count(".");
	}
	str.remove(QRegExp(QString::fromUtf8("[-`~!@#$%^&*()_�+=|:;<>��,?/{}\'\"\\\[\\\]\\\\]")));
	float newThresh = ((float)boost::lexical_cast<float>(str.toStdString()));

	return newThresh;
}

QMainWindow* WitApp::initWit(string config)
{

	qDebug("WIT INITIALIZING");

	qDebug(config.c_str());

	window = new QMainWindow();    
	window->move(0,0);
	dockWindowGlobe = new QDockWidget();  

	windowInput = new InputPane();
	windowInput->setupItems();
	windowOutput = new OutputPane();
	windowOutput->setupItems();

	windowPlayback = new PlaybackPane();
	windowPlayback->setupItems();
	windowProjection = new ProjectionPane();
	windowProjection->setupItems();
	windowFilterTemporal = new FilterPane();
	windowFilterTemporal->setupItems();
	windowFilterContrast = new ContrastPane();
	windowFilterContrast->setupItems();
	windowFilterThreshold = new ThreshPane();
	windowFilterThreshold->setupItems();
	windowFilterReview = new ReviewPane();
	windowFilterReview->setupItems();

	dockWindowInput = new QDockWidget();
	dockWindowOutput = new QDockWidget();

	dockWindowPlayback = new QDockWidget();
	dockWindowProjection = new QDockWidget();
	dockWindowFilterTemporal = new QDockWidget();
	dockWindowFilterContrast = new QDockWidget();  
	dockWindowFilterThreshold = new QDockWidget(); 
	dockWindowFilterReview = new QDockWidget(); 

	dockWindowInput->setWidget(windowInput);
	dockWindowOutput->setWidget(windowOutput);

	dockWindowPlayback->setWidget(windowPlayback);
	dockWindowProjection->setWidget(windowProjection);
	dockWindowFilterTemporal->setWidget(windowFilterTemporal);
	dockWindowFilterContrast->setWidget(windowFilterContrast);
	dockWindowFilterThreshold->setWidget(windowFilterThreshold);
	dockWindowFilterReview->setWidget(windowFilterReview); // !! has caused errors on 1 machine...unresolved

	int drawDelayMs = 32;
	int drawDelayMsMax = 3000;
	int drawDelayMsMin = 2;

	ptime time1;
	ptime time2;

	window->setCentralWidget(dockWindowGlobe);

	window->show();

	glw = new QtGL2(dockWindowGlobe);
	
	setupUi();
	
	QObject::connect(windowProjection->cbAutoZoom, SIGNAL(stateChanged(int)), glw, SLOT(toggleAutoOrient()));
	QObject::connect(windowProjection->cbAutoZoomSnap, SIGNAL(stateChanged(int)), glw, SLOT(toggleAutoOrientSnap()));
	QObject::connect(windowFilterThreshold->cbDetectConst, SIGNAL(stateChanged(int)), glw, SLOT(toggleThreshConstOnOff()));
	QObject::connect(windowFilterThreshold->cbDetectSigma, SIGNAL(stateChanged(int)), glw, SLOT(toggleThreshSigmaOnOff()));
	QObject::connect(windowPlayback->cbPause, SIGNAL(stateChanged(int)), glw, SLOT(togglePlaybackPaused()));
	QObject::connect(windowPlayback->cbReverse, SIGNAL(stateChanged(int)), glw, SLOT(togglePlaybackDirection()));

	QObject::connect(windowFilterReview->qbClear, SIGNAL(clicked()), windowFilterReview, SLOT(detectTableClear()));
	QObject::connect(windowFilterReview->qbClear, SIGNAL(clicked()), glw, SLOT(detectListClear()));

	QObject::connect(windowInput->cbArchive, SIGNAL(stateChanged(int)), glw, SLOT(changeIncomingDataMonitor()));
	QObject::connect(windowInput->qbLoadFromArchive, SIGNAL(clicked()), glw, SLOT(changeIncomingDataArchive()));
	QObject::connect(windowInput->textInputArchive, SIGNAL(textChanged(QString)), glw, SLOT(changeIncomingDataArchiveLocation(QString)));

	QObject::connect(windowFilterTemporal->cbTemporal, SIGNAL(stateChanged(int)), glw, SLOT(toggleCudaFilterOnOff()));
	QObject::connect(windowFilterTemporal->filterList, SIGNAL(currentIndexChanged(int)), glw, SLOT(setKernelPreset(int)));
	QObject::connect(windowFilterTemporal->filterList, SIGNAL(currentIndexChanged(int)), windowFilterReview, SLOT(detectTableClear()));
	QObject::connect(windowFilterTemporal->filterList, SIGNAL(currentIndexChanged(int)), glw, SLOT(resetDetections()));

	QObject::connect(windowFilterContrast->contrastList, SIGNAL(currentIndexChanged(int)), glw, SLOT(setContrastPreset(int)));
	QObject::connect(windowFilterContrast->contrastList, SIGNAL(currentIndexChanged(int)), glw, SLOT(resetContrastResults()));

	QObject::connect(windowFilterReview->qbAccept, SIGNAL(clicked()), windowFilterReview, SLOT(setRowAccept()));
	QObject::connect(windowFilterReview->qbReject, SIGNAL(clicked()), windowFilterReview, SLOT(setRowReject()));

	QObject::connect(windowFilterReview->qbUnknown, SIGNAL(clicked()), windowFilterReview, SLOT(setRowUnknown()));
	QObject::connect(windowFilterReview->qbDelete, SIGNAL(clicked()), windowFilterReview, SLOT(setRowDelete()));
	QObject::connect(windowFilterReview->qbShow, SIGNAL(clicked()), windowFilterReview, SLOT(setRowShow()));

	QObject::connect(windowFilterReview->reviewTable, SIGNAL(cellClicked(int, int)), glw, SLOT(highlightDetectionNone(int, int)));
	QObject::connect(windowFilterReview->reviewTable, SIGNAL(currentCellChanged(int, int, int, int)), glw, SLOT(highlightDetection(int, int, int, int)));

	typedef EventDetection* EventDetection;
	qRegisterMetaType<EventDetection>("EventDetection");

	QObject::connect(glw, SIGNAL(updateUiToggleAutoOrient()), windowProjection, SLOT(toggleAutoOrientButton()));

	QObject::connect(glw, SIGNAL(updateUiToggleReverse()), windowPlayback, SLOT(toggleReverseButton()));
	QObject::connect(glw, SIGNAL(updateUiTogglePause()), windowPlayback, SLOT(togglePauseButton()));

	QObject::connect(glw, SIGNAL(updateUiToggleHistogram()), windowFilterContrast, SLOT(toggleHistogramButton()));
	QObject::connect(glw, SIGNAL(updateUiToggleContrast()), windowFilterContrast, SLOT(toggleContrastButton()));

	QObject::connect(glw, SIGNAL(updateUiToggleFilter()), windowFilterTemporal, SLOT(toggleFilterButton()));
	QObject::connect(glw, SIGNAL(updateUiToggleThreshold()), windowFilterThreshold, SLOT(toggleThresholdButton()));

	QObject::connect(glw, SIGNAL(thresholdDetected(EventDetection*)), windowFilterReview, SLOT(updateTable(EventDetection*)));

	QObject::connect(glw, SIGNAL(pushKernelTap(int, float)), windowFilterTemporal, SLOT(updateKernelTap(int, float)));
	QObject::connect(glw, SIGNAL(pushKernelTapStr(int, QString)), windowFilterTemporal, SLOT(updateKernelTapStr(int, QString)));

	QObject::connect(glw, SIGNAL(updateUiToggleExportButtonText(int)), windowOutput, SLOT(toggleExportButtonText(int)));
	QObject::connect(glw, SIGNAL(updateUiToggleExportVideo()), windowOutput, SLOT(toggleVideoExportButton()));
	QObject::connect(windowOutput->textVideoExport, SIGNAL(textChanged(QString)), glw, SLOT(changeVideoExportName(QString)));
	QObject::connect(glw, SIGNAL(updateUiToggleExportVideo()), glw, SLOT(toggleVideoExportOnOff()));

	QObject::connect(windowPlayback->textPlaybackSpeed, SIGNAL(textChanged(QString)), glw, SLOT(changePlaybackSpeed(QString)));

	QObject::connect(windowFilterTemporal, SIGNAL(applyTapEdits(QLineEdit *, int)), glw, SLOT(changeKTaps(QLineEdit *, int)));
	QObject::connect(windowFilterTemporal->qbApplyTapEdits, SIGNAL(clicked()), windowFilterTemporal, SLOT(relayTapEdits()));
	QObject::connect(windowFilterTemporal->qbApplyTapEdits, SIGNAL(clicked()), windowFilterReview, SLOT(detectTableClear()));
	QObject::connect(windowFilterTemporal->qbApplyTapEdits, SIGNAL(clicked()), glw, SLOT(resetDetections()));

	QObject::connect(windowFilterTemporal->qbUndoTapEdits, SIGNAL(clicked()), glw, SLOT(undoKernelEdits()));
	QObject::connect(windowFilterTemporal->qbUndoTapEdits, SIGNAL(clicked()), glw, SLOT(resetDetections()));
	QObject::connect(windowFilterTemporal->qbUndoTapEdits, SIGNAL(clicked()), windowFilterReview, SLOT(detectTableClear()));

	QObject::connect(windowOutput->cbVideoExport, SIGNAL(clicked()), glw, SLOT(toggleVideoExportOnOff()));
	QObject::connect(windowOutput->cbVideoStream, SIGNAL(clicked()), glw, SLOT(toggleVideoStreamOnOff()));

	QObject::connect(windowFilterThreshold->textThreshLevelConst, SIGNAL(textChanged(QString)), glw, SLOT(changeThreshConst(QString)));
	QObject::connect(windowFilterThreshold->textThreshLevelSigma, SIGNAL(textChanged(QString)), glw, SLOT(changeThreshSigma(QString)));

	QObject::connect(windowFilterThreshold->cbRegionWatch, SIGNAL(stateChanged(int)), glw, SLOT(toggleRegionWatchOnOff()));
	QObject::connect(windowFilterThreshold->cbRegionReject, SIGNAL(stateChanged(int)), glw, SLOT(toggleRegionRejectOnOff()));

	QObject::connect(windowFilterThreshold->cbRegionWatchRadius, SIGNAL(stateChanged(int)), glw, SLOT(toggleRegionWatchRadiusOnOff()));
	QObject::connect(windowFilterThreshold->cbRegionRejectRadius, SIGNAL(stateChanged(int)), glw, SLOT(toggleRegionRejectRadiusOnOff()));

	QObject::connect(windowFilterThreshold->textRegionWatchRadius, SIGNAL(textChanged(QString)), glw, SLOT(changeRegionWatchRadius(QString)));
	QObject::connect(windowFilterThreshold->textRegionRejectRadius, SIGNAL(textChanged(QString)), glw, SLOT(changeRegionRejectRadius(QString)));

	QObject::connect(glw, SIGNAL(updateWatchRadiusUi(float)), windowFilterThreshold, SLOT(updateRegionWatchRadius(float)));
	QObject::connect(glw, SIGNAL(updateRejectRadiusUi(float)), windowFilterThreshold, SLOT(updateRegionRejectRadius(float)));

	QObject::connect(windowFilterThreshold->threshConstList, SIGNAL(currentIndexChanged(int)), glw, SLOT(changeThreshConstPreset(int)));
	QObject::connect(windowFilterThreshold->threshConstList, SIGNAL(currentIndexChanged(int)), glw, SLOT(resetDetections()));
	QObject::connect(windowFilterThreshold->threshConstList, SIGNAL(currentIndexChanged(int)), windowFilterReview, SLOT(detectTableClear()));
	QObject::connect(glw, SIGNAL(updateThreshUi(float)), windowFilterThreshold, SLOT(updateThreshConst(float)));

	QObject::connect(windowFilterContrast->cbHistogram, SIGNAL(stateChanged(int)), glw, SLOT(toggleHistogramOnOff()));
	QObject::connect(windowFilterContrast->cbContrast, SIGNAL(stateChanged(int)), glw, SLOT(toggleContrastOnOff()));

	window->addDockWidget(Qt::LeftDockWidgetArea, dockWindowGlobe);
		
	// load now that certain triggers are in place
	loadConfig(config);

	window->show();
	window->setFixedSize(displayW,displayH);
	window->setWindowTitle(QString::fromUtf8("WIT 1.3.X"));

	glw->setWindowTitle(QString::fromUtf8("DISPLAY"));

	glw->setFixedSize(displayW,displayH);
	glw->show();
	glw->setWindowOpacity(1.0);

	glw->initializeGL();
	glw->viewW = displayW;
	glw->viewH = displayH;
	glw->setupItems();
	glw->resizeGL(displayW-QT_DOCK_WIDGET_W,displayH);

	glw->runSystem(); 
	
	qDebug("WIT APP INIT COMPLETE");
	
	return window;
}


QMainWindow* WitApp::getQMainWindow(){
	return window;
}

QApplication* WitApp::getQApplication(){
	return app;
}

void WitApp::setupUi(){
	
	window->addDockWidget(Qt::RightDockWidgetArea, dockWindowInput);
	window->addDockWidget(Qt::RightDockWidgetArea, dockWindowPlayback);
	window->addDockWidget(Qt::RightDockWidgetArea, dockWindowProjection);
	window->addDockWidget(Qt::RightDockWidgetArea, dockWindowFilterTemporal);
	window->addDockWidget(Qt::RightDockWidgetArea, dockWindowFilterThreshold);
	window->addDockWidget(Qt::RightDockWidgetArea, dockWindowFilterReview);
	window->addDockWidget(Qt::RightDockWidgetArea, dockWindowFilterContrast);
	window->addDockWidget(Qt::RightDockWidgetArea, dockWindowOutput);

	int dockWidgetW = QT_DOCK_WIDGET_W;
	int dockWidgetH = 20;
	
	dockWindowInput->setBaseSize(dockWidgetW,dockWidgetH);
	dockWindowInput->setFixedWidth(dockWidgetW);
	dockWindowInput->setMinimumHeight(dockWidgetH);
	dockWindowInput->setWindowTitle(QString::fromUtf8("INPUT"));

	dockWindowPlayback->setBaseSize(dockWidgetW,dockWidgetH);
	dockWindowPlayback->setFixedWidth(dockWidgetW);
	dockWindowPlayback->setMinimumHeight(dockWidgetH);
	dockWindowPlayback->setWindowTitle(QString::fromUtf8("PLAYBACK"));

	dockWindowProjection->setBaseSize(dockWidgetW,dockWidgetH);
	dockWindowProjection->setFixedWidth(dockWidgetW);
	dockWindowProjection->setMinimumHeight(dockWidgetH);
	dockWindowProjection->setWindowTitle(QString::fromUtf8("PROJECTION"));

	dockWindowFilterTemporal->setBaseSize(dockWidgetW,dockWidgetH);
	dockWindowFilterTemporal->setFixedWidth(dockWidgetW);
	dockWindowFilterTemporal->setMinimumHeight(dockWidgetH);
	dockWindowFilterTemporal->setWindowTitle(QString::fromUtf8("TEMPORAL FILTER"));

	dockWindowFilterThreshold->setBaseSize(dockWidgetW,dockWidgetH);
	dockWindowFilterThreshold->setFixedWidth(dockWidgetW);
	dockWindowFilterThreshold->setMinimumHeight(dockWidgetH);
	dockWindowFilterThreshold->setWindowTitle(QString::fromUtf8("THRESHOLD"));

	dockWindowFilterReview->setBaseSize(dockWidgetW,dockWidgetH);
	dockWindowFilterReview->setFixedWidth(dockWidgetW);
	dockWindowFilterReview->setMinimumHeight(100);
	dockWindowFilterReview->setMinimumHeight(dockWidgetH);
	dockWindowFilterReview->setWindowTitle(QString::fromUtf8("DETECTION REVIEW"));

	dockWindowFilterContrast->setBaseSize(dockWidgetW,dockWidgetH);
	dockWindowFilterContrast->setFixedWidth(dockWidgetW);
	dockWindowFilterContrast->setMinimumHeight(dockWidgetH);
	dockWindowFilterContrast->setWindowTitle(QString::fromUtf8("CONTRAST"));

	dockWindowOutput->setBaseSize(dockWidgetW,dockWidgetH);
	dockWindowOutput->setFixedWidth(dockWidgetW);
	dockWindowOutput->setMinimumHeight(dockWidgetH);
	dockWindowOutput->setWindowTitle(QString::fromUtf8("OUTPUT"));

	}
}