#pragma once


#define STATUS_STATES 20
#define STATUS_ERROR -1
#define STATUS_READY 0
#define STATUS_QUEUED 1
#define STATUS_WORKING 2
#define STATUS_COMPLETE_IO 3
#define STATUS_COMPLETE_RASTER 5
#define STATUS_COMPLETE_GL 6
#define STATUS_COMPLETE_THREAD 7

#define STATUS_COMPLETE_CUDA_T 10	// initial temporal filter
#define STATUS_COMPLETE_CUDA_S 11	// spatial / morphological
#define STATUS_COMPLETE_CUDA_C 12	// contrast / false color

#define MODES 40

#define MODE_LOAD 0
#define MODE_RASTER 1
#define MODE_CUDA_COPY_C_TO_G 2
#define MODE_CUDA_COPY_G_TO_C 4
#define MODE_RENDER 5
#define MODE_GL_LIST 6
#define MODE_GL_LIST_CONTRAST 7

#define MODE_CUDA_FILTER_T 10
#define MODE_CUDA_FILTER_S 11
#define MODE_CUDA_FILTER_C 12

#define MODE_TEMPORAL 20
#define MODE_THRESHOLD 21
#define MODE_REVIEW 22
#define MODE_FALSE_COLOR 23  

#define MODE_READ_SOCKET 30
#define MODE_WRIE_SOCKET 31
#define MODE_WRIE_FILE 32
#define MODE_FFMPEG_EXPORT 33

#define DIM_X 0
#define DIM_Y 1
#define DIM_Z 2

#define DIM_R 0
#define DIM_G 1
#define DIM_B 2
#define DIM_A 3

#define DIM_LON 0
#define DIM_LAT 1
#define DIM_EL 2

#define PX_INT_MIN 0
#define PX_INT_MAX 255
#define PX_INT_MEAN 128

#define PX_VAL_MAX 255

#define TILE_SIZE_X 12
#define TILE_SIZE_Y 12

//#define TILE_SIZE_X 96
//#define TILE_SIZE_Y 96

#define ON 1
#define OFF 0

#define CURRENT 0
#define GOAL 1

#define KC_TEMPORAL 0
#define KC_DILATE 1
#define KC_ERODE 2
#define KC_FILTER_X 3
#define KC_CONTRAST 4
#define KC_MODES 5

#define MAX_TILES_PER_FRAME 1

#define EVENT_REVIEW_STATUS_UNKNOWN 0
#define EVENT_REVIEW_STATUS_ACCEPT 1
#define EVENT_REVIEW_STATUS_REJECT 2
#define EVENT_REVIEW_STATUS_DEFER 3

#define EVENT_TYPE_UNKNOWN 0
#define EVENT_TYPE_STATIC 1
#define EVENT_TYPE_MOVER 2

#define SECS_IN_DAY (60*60*24)

#define QT_DOCK_WIDGET_W 400

#define MOUSE_STATE_READY 0

#define MOUSE_STATE_CLICK_HIST 2
#define MOUSE_STATE_DRAG_HIST 3

#define MOUSE_STATE_CLICK_DETECT 10
#define MOUSE_STATE_DRAG_DETECT 11 

#define MOUSE_STATE_CLICK_WB 20
#define MOUSE_STATE_DRAG_WB 21

#define VID_FORMAT_WMV 0
#define VID_FORMAT_FLV 1
#define VID_FORMAT_MPG 2
#define VID_FORMAT_MP4 3

#define FILE_INPUT_PNG 0 
#define FILE_INPUT_H5 1

#define TOTAL_SENSORS 2
#define TOTAL_SCAS 8

#define BAD_GEOLOC -200

#define DRAW_DELAY_STANDARD 15 // default operating speed
#define DRAW_DELAY_IO_BOUND 60 // input/output limited operating speed...for saving frames to disk

#define PNG_DEFAULT_FRAME_RATE 1.0f

#define SCAN_DIR_0 0
#define SCAN_DIR_1 1
#define SCAN_DIR_BOTH 2