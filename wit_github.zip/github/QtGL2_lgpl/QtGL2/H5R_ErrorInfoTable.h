//#pragma once
#ifndef H5R_ERRORINFOTABLE
#define H5R_ERRORINFOTABLE

#include <iostream>
using namespace std;

#include "hdf5.h"
#include "H5Classes.h"
using namespace H5;


class H5R_ErrorInfoTableEntry 
{
public:
	string errorTag;
	int affectedFrameCount;
	float percentOfFramesAffected;
};


class H5R_ErrorInfoTable
{
public:
	H5R_ErrorInfoTable(CompType *ds);
	H5R_ErrorInfoTable();
	//H5R_ErrorInfoTable(CompoundDS ds);
	~H5R_ErrorInfoTable(void);

	H5R_ErrorInfoTableEntry* errorInfoTableEntry;
	int NUM_COLS;
	int numRows;

	int getNumRows();
	H5R_ErrorInfoTableEntry* getErrorInfoTableEntry();
};

#endif