#ifndef INPUTPANE_H
#define INPUTPANE_H

#include <QWidget>
#include <QObject>
#include <QtGui>

class InputPane : public QWidget
{
	Q_OBJECT

public:
	InputPane();
	~InputPane();

	QHBoxLayout *hboxInput1;
	QHBoxLayout *hboxInput2;
	QHBoxLayout *hboxInput3;
	QVBoxLayout *vboxInput1;

	QCheckBox *cbInput;

	QLineEdit *textInputMonitorFreq;
	QLineEdit *textInputMonitorSpan;
	QLineEdit *textInputMonitorAdvance;
		
	QLabel *labelInputMonitorFreq; 
	QLabel *labelInputMonitorSpan; 
	QLabel *labelInputMonitorAdvance; 
	
	QLabel *labelInputStream; 
	QLineEdit *textInputStream;

	QCheckBox *cbArchive;
	QLabel *labelInputArchive; 
	QLineEdit *textInputArchive;

	QPushButton *qbLoadFromArchive;

	void setupItems();

private:
	
};

#endif // INPUTPANE_H
